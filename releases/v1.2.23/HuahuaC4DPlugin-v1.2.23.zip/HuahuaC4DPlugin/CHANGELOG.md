# CHANGELOG

## v1.2.23
- 模型库无缩略图模型增加“没有预览图”占位显示
- 缩略图加载或绘制失败时自动回退到统一占位图
- 保持模型扫描、加载、Grid 布局、滚动、过滤和收藏逻辑不变

## v1.2.22
- AssetViewer 单个模型卡片绘制增加异常隔离，避免一个缩略图或文字绘制失败中断后续模型
- 增加 Draw Start / Draw Item / Draw End 绘制日志
- 保持模型扫描、加载、Grid 布局、过滤、收藏和缩略图查找逻辑不变

## v1.2.21
- 修复模型库 Grid 宽度 / 高度计算不一致导致部分卡片绘制在可视区域外的问题
- 统一 AssetViewer 列数、行数、坐标和滚动高度计算
- 增加模型卡片绘制坐标调试日志
- 保持模型扫描、加载、过滤、收藏、排序和缩略图逻辑不变

## v1.2.20
- 修复模型库数据已加载但滚动区域高度未及时更新导致底部模型卡片显示不完整的问题
- 模型库列表更新和缩放调整后会同步刷新 UserArea / ScrollGroup 布局
- 保持模型扫描、排序、过滤、缩略图和加载逻辑不变

## v1.2.19
- 模型库增加模型数量显示
- 刷新后显示加载数量

## v1.2.18
- 修复模型库扫描依赖模型文件名与文件夹名一致导致部分模型不显示的问题
- 模型库扫描支持以模型文件夹作为模型单位，文件夹内任意名称 .c4d 均可识别
- 模型显示名称优先使用模型文件夹名称
- 缩略图优先匹配文件夹名、模型文件名，再回退到同目录任意 jpg / png / jpeg
- 保持旧的根目录 .c4d 模型结构、自定义模型库路径、收藏、模型加载、替换逻辑不变

## v1.2.17
- 修复“选择隐藏对象”扫描层级时偶发 NoneType.GetNext 报错
- 优化隐藏对象递归遍历的空值保护和 next 指针保存
- 保持隐藏对象判断规则不变
- 保持插件名称、模型库、AI JSON 导入、smart stack、授权、检查更新、CDK 兑换逻辑不变

## v1.2.16
- 插件界面名称统一改为“花花智能建模-C4D端”
- 更新窗口标题、面板标题、菜单显示名称和关于信息中的用户可见名称
- 保持授权 pluginCode、clientCode、插件 ID、配置路径、更新地址不变
- 保持模型库、AI JSON 导入、smart stack、stroke ring 合并、贴图路径、授权、检查更新、CDK 兑换逻辑不变

## v1.2.15
- 模型库新增自定义存储位置功能
- 用户可选择模型库根目录，后续模型读取、保存、刷新统一使用该目录
- 模型库路径会保存到插件配置，下次启动自动恢复
- 未选择自定义路径时继续使用默认模型库目录
- 打开模型库文件夹会打开当前生效目录
- 保持授权、machineId、检查更新、CDK 兑换、AI JSON 导入逻辑不变

## v1.2.14
- 收紧 smart stack 的同源对象跳过规则
- same source skip 只使用 sourceObjectId / sourceItemId / strokeCompoundGroupId / objectId / itemId 等强身份字段
- 不再使用 name / group / groupKey / groupId 作为 smart stack 同源跳过依据
- key 缺失时不再跳过 smart stack
- 修复普通文字和白色圆形可能被误判同源导致重叠 / 穿插的问题
- 保留 AI stack 全局处理顺序
- 保留所有 2D overlap 使用 cache.back_z 做厚度避让
- 保留同一原始对象拆分出的 fill / stroke ring 不互相 smart stack
- 保持旧 JSON 兼容

## v1.2.13
- 基于 v1.2.12 修复普通对象与底板重叠 / 穿插问题
- 保留 AI stack 全局处理顺序，确保上层对象先处理、下层对象后处理
- smart stack 对所有 2D 重叠对象使用 placed_cache back_z 做厚度避让
- placed_cache 记录 front_z / back_z / thickness
- 普通文字、圆形、底板等对象重叠时也会按厚度留出安全距离
- 保留同一源对象 fill / stroke ring / texture item 跳过互相 smart stack
- 不恢复 v1.2.10 的大幅全局 Z placement
- 不采用 v1.2.13 / v1.2.14 的 stroke thickness 局部裁判方向

## v1.2.12
- 新增 AI stack aware smart stack ordering
- 使用 sourceStackIndex / sourceZOrderIndex 控制智能堆叠处理顺序
- 不再使用 AI stack 字段做大幅全局 Z 位移
- AI 上层对象先进入 placed_cache，下层重叠对象自动放到后方
- 同一源对象的 fill / stroke ring 跳过互相 smart stack
- 保持旧 JSON 的 _original_index 智能堆叠兼容
- 保持 stroke ring 合并、贴图路径、授权、machineId、检查更新逻辑不变

## v1.2.11
- 恢复原有智能堆叠行为
- 暂停使用 AI stack 字段直接驱动大层级 Z 位置，避免导入对象被打散
- 保留 sourceStackIndex / sourceZOrderIndex / sourceLayerIndex / sourceLayerName / partOrder 字段读取
- 保留 v1.2.9 stroke ring 合并和分组逻辑
- 保持贴图路径、授权、machineId、检查更新、CDK 兑换逻辑不变

## v1.2.10
- 读取 AI v28.236 导出的 sourceStackIndex / sourceZOrderIndex / sourceLayerIndex / sourceLayerName / partOrder
- 新增 AI 原始层级驱动的 Z 堆叠定位
- sourceStackIndex 越大的对象在 C4D 中越靠前
- 同一源对象的 fill / stroke ring / texture / fallback item 共享基础 Z 层级
- 当 JSON 含 AI stack 字段时，smart stack 不再覆盖 AI 原始层级
- 保持旧 JSON smart stack 兼容
- 保持 stroke ring 合并、贴图路径、授权、machineId、检查更新逻辑不变

## v1.2.9
- 优化 AI stroke ring 导入兼容逻辑
- 支持同一 stroke ring 组内按 group + partType + color + depth 合并
- group 字段仍用于 C4D 对象管理器层级
- 普通未编组对象仍按 objectId / itemId / importIndex 隔离
- 不同源对象不会误合并
- 保持旧 JSON 兼容
- 保持授权、machineId、检查更新、CDK 兑换、贴图路径逻辑不变

## v1.2.8
- 兼容 AI 面板新版 stroke ring 导出规则
- preserveSeparateStrokeRing / doNotMergeGeometry 对象不再参与 group 几何合并
- group 字段用于 C4D 对象管理器层级，不再强制代表几何合并
- stroke ring 可归入同一 Null 子组，但每个 ring 保持独立 Extrude / Spline
- 避免复杂描边文字因 ring 合并导致内孔、镂空和描边结构错误
- 保持旧 JSON 普通合并逻辑兼容

## v1.2.7
- 修复未编组对象描边厚度相同被错误合并的问题
- 真实 group 才允许按 group 合并
- 未编组对象按 objectId / itemId / importIndex 隔离
- partType=stroke 也遵守未编组隔离规则
- 旧字段 group 不再单独作为真实 group 判断依据
- 保持真实 AI 编组对象的合并能力
- 保持旧 JSON 兼容

## v1.2.6
- 修复真实导入中文贴图仍提示缺失的问题
- 增加中文文件名 Unicode NFC / NFD 规范化匹配
- 增加 URL 编码贴图路径兼容
- 显式 texturePath 找不到时不再静默退回旧规则避免错贴
- 增强缺失贴图日志，列出真实查找路径和候选文件
- 支持 fill / stroke 子结构中的贴图路径读取

## v1.2.5
- 修复导入 JSON 贴图路径含中文时无法识别的问题
- 区分真实贴图路径和安全材质名
- 真实贴图路径不再做英文数字清洗
- 支持中文目录、中文贴图文件名和空格路径
- 保持材质命名安全化但不影响贴图加载路径

## v1.2.4
- 修复导入 JSON 时优先读取 texturePath / textureRelPath / texture / imagePath 的贴图路径
- 支持 AI 新版带 JSON 文件名前缀的贴图命名
- 相对贴图路径按 JSON 文件所在目录解析
- 支持中文贴图文件名和中文目录
- 保留旧 JSON 贴图查找兜底逻辑
- 降低多次导出同一文件夹后贴图错乱和材质复用风险

## v1.2.3
- 新增插件内 CDK 兑换窗口
- 用户登录后可直接兑换 CDK
- 兑换成功后弹窗提醒并自动刷新授权状态
- 增加 CDK 兑换失败 reason 中文提示
- 未登录状态禁止兑换并提示用户先登录
- 不影响授权、注册、machineId、检查更新、session_replaced、machine_replaced 逻辑

## v1.2.2
- 发布：C4D 插件后台更新检查正式同步版本
- 保持：更新检查只请求后台服务器
- 保持：云端授权、注册、machineId、session_replaced、machine_replaced 逻辑不变
- 保持：C4D 插件不直接访问 GitHub update.json
- 同步：私人源码仓库与公共发布仓库

## v1.2.1
- 更新：检查更新统一改为只请求后台服务器
- 调整：C4D 插件不再直接访问 GitHub update.json
- 调整：C4D 插件不再直接访问 GitHub Release 下载地址
- 说明：GitHub 公共仓库由后台安装包管理读取和同步
- 调整：下载地址全部使用后台返回的 downloadUrl / mirrorDownloadUrl
- 调整：fallbackUrl 也只使用后台返回字段
- 新增：更新弹窗显示服务器镜像下载 / 备用下载信息
- 优化：后台检查更新失败时不再 fallback 到 GitHub
- 保持：不影响授权、注册、machineId、session_replaced、machine_replaced 规则

## v1.2.0
- 新增：公共 machineId，用于适配后台单账号单电脑授权规则
- 新增：AI 面板和 C4D 插件可共用同一个 machineId
- 新增：授权请求上报 machineId
- 新增：register-device / check-license / heartbeat 均携带 machineId
- 新增：machine_replaced 处理
- 优化：machine_replaced / session_replaced 不进入离线宽限，立即清除 token 并提示重新登录
- 保留：C4D 插件自身 deviceId，用于记录 c4d_python 客户端
- 调整：授权弹窗设备数量文案改为设备记录
- 新增：授权弹窗显示电脑标识前 8 位

## v1.1.10
- 备份：C4D 插件云端授权 v1.1.1 适配版本
- 保留：插件内注册账号入口
- 保留：session_replaced 识别与重新登录提示
- 保留：clientCode=c4d_python 设备记录
- 保留：单会话授权、heartbeat、核心功能补验、24 小时离线宽限
- 调整：设备数量不再由 C4D 插件本地 maxDevices 拦截
- 已知：注册 / 密码相关问题后续单独修复

## v1.1.9
- 适配：Huahua Plugin Admin v1.1.1 普通用户单会话授权规则
- 新增：插件内“注册账号”入口
- 新增：识别 session_replaced，并提示账号已在其他设备登录
- 优化：session_replaced 不进入离线宽限，立即退出登录并禁用核心功能
- 保持：register-device 继续记录设备历史与 clientCode=c4d_python
- 调整：设备数量限制改为后台历史设备记录，不再本地拦截
- 保留：10 分钟授权补验、10 分钟 heartbeat、24 小时离线宽限

## v1.1.8
- 统一：云端授权验证规则
- 新增：启动时自动 check-license
- 确认：登录后执行 me / check-license / register-device
- 新增：每 10 分钟 heartbeat
- 新增：核心功能前 10 分钟授权补验
- 新增：24 小时离线宽限
- 优化：后台明确拒绝时立即禁用核心功能
- 优化：清理 localhost 旧 token 缓存
- 保持：公开 update.json 检查更新逻辑不变

## v1.1.7
- 新增：本地开发测试开关 DEV_DISABLE_AUTH_GATE
- 新增：本地开发模式下临时跳过后台授权拦截
- 优化：未登录状态下允许测试核心功能按钮
- 保留：Huahua Plugin Admin 授权接入代码
- 保留：登录、token、deviceId、授权校验逻辑
- 说明：仅用于本地开发测试，正式发布前需要关闭开发模式
- 更新：将 Huahua Plugin Admin 授权后台地址切换为云端 http://43.155.144.82
- 保持：pluginCode=hh_ai_c4d
- 新增：clientCode=c4d_python
- 支持：云端登录、授权校验、设备注册、heartbeat 请求字段
- 优化：自动清理 localhost 旧 token 缓存，保留 deviceId
- 恢复：正式授权拦截，关闭本地开发绕过开关
- 说明：当前仅本地测试，不发布公开仓库

## v1.1.6
- 新增：接入 Huahua Plugin Admin 本地后台
- 新增：后台账号登录
- 新增：token 本地保存和自动校验
- 新增：插件授权校验
- 新增：设备注册 / 设备超限提示
- 新增：后台版本检查
- 新增：heartbeat 启动上报
- 优化：授权失败时禁用核心功能
- 说明：当前仅用于本地测试，不发布公共仓库

## v1.1.5
- 优化：“分布式独立探测（防穿模贴墙）”性能
- 新增：候选对象 broad-phase 过滤
- 优化：跳过明显不可能命中的对象，减少射线碰撞检测数量
- 保留：原有多点采样和 GeRayCollider 精确检测
- 提升：复杂场景下顶/地/左/右/前/后探测按钮响应速度

## v1.1.4
- 新增：“检查更新”按钮
- 新增：支持读取远程 update.json
- 新增：支持判断当前版本是否为最新版
- 新增：支持检测到新版本时弹窗提示
- 新增：支持网络失败提示
- 更新：检查更新地址已指向公共发布仓库

## v1.1.2
- 修复：JSON 监听文件夹选择后未触发检测的问题
- 优化：监听改为 2 秒定时检查，并同时接入 `Timer` 与 `BFM_TIMER` 消息回调
- 优化：选择目录后立即建立 baseline，目录中已有 JSON 不弹窗，只监听之后新增的 JSON
- 优化：新增 JSON 需连续两次检测到 size 和 mtime 不变后才提示导入
- 新增：监听流程输出调试日志，便于在 C4D 控制台查看目录选择、Timer、文件稳定、弹窗、导入和异常信息

## v1.1.1
- 新增：基础设置页增加“选择 JSON 监听文件夹”按钮
- 新增：后台定时检测监听目录中新出现的 `.json` 文件
- 新增：检测到新 JSON 后弹窗确认，确认后复用现有 AI JSON 导入逻辑
- 优化：隐藏基础设置页中暂不需要显示的“样条路径”和“贴图目录”输入区域，保留原有变量和逻辑
- 稳定性：监听导入前等待文件大小和修改时间稳定，避免导入仍在写入的 JSON 文件
- 说明：本版本基于 v1.1-stable 稳定版做小功能更新，不包含 v1.2 UI 调整

## v1.1 稳定备份
- 版本号：花花广告设计 v1.1
- 备份原因：v1.2 UI 优化出现按钮丢失和面板缩放问题，因此退回并备份 v1.1 稳定版本
- 当前状态：v1.1 为当前可用稳定版本
- 主要功能：保留 v1.0 原有完整功能，新增文件加载进度条和加载状态文字
- 导入提示：导入文件时显示读取、解析、创建对象、完成等状态
- 本次备份不做功能开发
- 本次备份不继续 v1.2 UI 优化
- 恢复方式：`git checkout v1.1-stable` 或 `git checkout backup/v1.1-stable`

## v1.1
- 新增：文件加载进度条
- 新增：导入文件时显示加载状态文字
- 新增：读取、解析、创建对象、刷新场景等阶段进度提示
- 优化：用户导入大文件时可以看到当前加载状态
- 说明：本版本基于 v1.0 稳定备份版开发
