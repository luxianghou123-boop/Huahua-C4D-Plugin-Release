# -*- coding: utf-8 -*-
"""Room ceiling geometry. Saved generators embed this module, not a disk import."""
import math
from collections import deque

EPS = 1e-6
MAX_CELLS = 40000
MAX_SLATS = 500


def polygon_engine():
    # The same vendored source is embedded in saved generators for portability.
    global _POLYGON_ENGINE
    if '_POLYGON_ENGINE' not in globals():
        import types
        engine = types.ModuleType('huahua_polybool')
        source = globals().get('POLYBOOL_SOURCE')
        if source is None:
            import os
            with open(os.path.join(os.path.dirname(__file__), 'huahua_polybool.py'), encoding='utf-8') as handle:
                source = handle.read()
        exec(compile(source, '<huahua_polybool>', 'exec'), engine.__dict__)
        _POLYGON_ENGINE = engine
    return _POLYGON_ENGINE


def oriented(loops):
    result = []
    for i, loop in enumerate(loops):
        depth = sum(inside(loop[0], [other]) for j, other in enumerate(loops) if i != j)
        result.append(list(reversed(loop)) if (area(loop) > 0) != (depth % 2 == 0) else list(loop))
    return result


def boolean(a, b, operation):
    engine = polygon_engine()
    try:
        result = getattr(engine, operation)(engine.Polygon(a), engine.Polygon(b))
    except engine.PolyBoolException as exc:
        raise ValueError('轮廓布尔计算失败，请检查重合点和极短边：' + str(exc))
    loops = [[(p.x, p.y) for p in loop] for loop in result.regions]
    return oriented([loop for loop in loops if len(loop) >= 3 and abs(area(loop)) > EPS])


def orthogonal(loops):
    return all(abs(a[0]-b[0]) < EPS or abs(a[1]-b[1]) < EPS
               for loop in loops for a, b in zip(loop, loop[1:]+loop[:1]))


def inset_boundary(loops, gap):
    validate_loops(loops)
    if not math.isfinite(gap) or gap < 0:
        raise ValueError('离墙间隙不能为负数')
    if orthogonal(loops):
        return union_loops(room_cells(loops, gap))
    result = oriented(loops)
    if gap > EPS:
        # Erode by edge strips and round vertex caps; booleans preserve concave
        # boundaries, islands and holes instead of filling their bounding boxes.
        for loop in loops:
            for a, b in zip(loop, loop[1:]+loop[:1]):
                dx, dz = b[0]-a[0], b[1]-a[1]
                length = math.hypot(dx, dz)
                nx, nz = -dz/length*gap, dx/length*gap
                strip = [(a[0]+nx,a[1]+nz),(b[0]+nx,b[1]+nz),
                         (b[0]-nx,b[1]-nz),(a[0]-nx,a[1]-nz)]
                result = boolean(result, [strip], 'difference')
                radius = gap/math.cos(math.pi/16)
                cap = [(a[0]+radius*math.cos(i*math.pi/8), a[1]+radius*math.sin(i*math.pi/8)) for i in range(16)]
                result = boolean(result, [cap], 'difference')
    if not result:
        raise ValueError('离墙间隙过大，没有剩余吊顶范围')
    return result


def area(poly):
    return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1]))/2


def inside(point, loops):
    x,z = point
    result = False
    for loop in loops:
        for a,b in zip(loop,loop[1:]+loop[:1]):
            if (a[1]>z) != (b[1]>z) and x < a[0]+(z-a[1])*(b[0]-a[0])/(b[1]-a[1]):
                result = not result
    return result


def validate_loops(loops):
    if not loops or sum(map(len,loops)) > 400:
        raise ValueError("范围为空或轮廓过于复杂（最多 400 个顶点）")
    edges = []
    for loop in loops:
        if len(loop)<3 or abs(area(loop))<EPS:
            raise ValueError("请使用有面积的闭合直线轮廓")
        for i,(a,b) in enumerate(zip(loop,loop[1:]+loop[:1])):
            if not all(math.isfinite(v) for v in a+b):
                raise ValueError("轮廓存在无效坐标")
            if math.hypot(a[0]-b[0], a[1]-b[1]) < EPS:
                raise ValueError("轮廓存在重复点或极短边")
            edges.append((loop,i,a,b))
    for k,(loop,i,a,b) in enumerate(edges):
        for other,j,c,d in edges[k+1:]:
            adjacent = loop is other and ((i-j)%len(loop) in (1,len(loop)-1))
            if adjacent: continue
            def cross(p,q,r):
                return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
            bbox = max(min(a[0],b[0]),min(c[0],d[0])) <= min(max(a[0],b[0]),max(c[0],d[0]))+EPS and max(min(a[1],b[1]),min(c[1],d[1])) <= min(max(a[1],b[1]),max(c[1],d[1]))+EPS
            if bbox and cross(a,b,c)*cross(a,b,d)<=EPS*EPS and cross(c,d,a)*cross(c,d,b)<=EPS*EPS:
                raise ValueError("轮廓存在交叉或接触，请分离外边界与预留洞")


def grid(xs,zs):
    xs,zs = sorted(set(round(v,6) for v in xs)),sorted(set(round(v,6) for v in zs))
    if (len(xs)-1)*(len(zs)-1)>MAX_CELLS:
        raise ValueError("范围过于复杂，请简化墙体或使用闭合样条")
    return xs,zs


def cell_rect(xs,zs,i,j):
    return (xs[i],zs[j],xs[i+1],zs[j+1])


def rect_poly(r):
    x,z,X,Z=r
    return [(x,z),(X,z),(X,Z),(x,Z)]


def union_loops(polygons):
    # Input pieces share a compressed grid. Clip uses identical planes on both
    # sides of a grid edge, so reversed interior edges cancel exactly.
    edges=set()
    for poly in polygons:
        points=[]
        for p in poly:
            p=tuple(round(v,6) for v in p)
            if not points or p!=points[-1]:points.append(p)
        if len(points)>1 and points[-1]==points[0]:points.pop()
        if len(points)<3 or abs(area(points))<EPS:continue
        if area(points)<0:points.reverse()
        for a,b in zip(points,points[1:]+points[:1]):
            if (b,a) in edges:edges.remove((b,a))
            else:edges.add((a,b))
    following={}
    for a,b in edges:
        if a in following:raise ValueError("边界存在点接触，请调整间隙或轮廓")
        following[a]=b
    loops=[]
    while following:
        first=next(iter(following));p=first;loop=[]
        while True:
            loop.append(p)
            if p not in following:raise ValueError("吊顶边界未闭合")
            p=following.pop(p)
            if p==first:break
        loops.append(loop)
    return loops


def parallel_wall_boundary(rects):
    # Use facing inner surfaces and the shared longitudinal span, never the
    # outer bounding box: staggered wall ends must not create unsupported area.
    axes=[]
    for x,z,X,Z in rects:
        dx,dz=X-x,Z-z
        if min(dx,dz)<=EPS or abs(dx-dz)<=EPS:
            raise ValueError("两墙模式需要长度方向明确的矩形墙体")
        axes.append(0 if dx>dz else 1)
    if axes[0]!=axes[1]:
        raise ValueError("两墙模式需要两面相对的平行墙；转角墙请使用闭合样条指定范围")
    along=axes[0];across=1-along
    first,second=sorted(rects,key=lambda r:r[across])
    lo=max(first[along],second[along]);hi=min(first[along+2],second[along+2])
    inner_start=first[across+2];inner_end=second[across]
    if hi-lo<=EPS or inner_end-inner_start<=EPS:
        raise ValueError("两面墙之间没有有效空间或共同覆盖长度，请调整墙体或使用闭合样条")
    rect=(lo,inner_start,hi,inner_end) if along==0 else (inner_start,lo,inner_end,hi)
    return [rect_poly(rect)]


def three_wall_boundary(rects):
    axes=[]
    for x,z,X,Z in rects:
        dx,dz=X-x,Z-z
        if min(dx,dz)<=EPS or abs(dx-dz)<=EPS:
            raise ValueError("三墙模式需要长度方向明确的矩形墙体")
        axes.append(0 if dx>dz else 1)
    if len(set(axes))!=2:
        raise ValueError("三墙模式需要两面平行侧墙和一面垂直端墙，请用闭合样条指定其他范围")
    along=0 if axes.count(0)==2 else 1
    across=1-along
    sides=[r for r,a in zip(rects,axes) if a==along]
    end=next(r for r,a in zip(rects,axes) if a!=along)
    # Reuse the two-wall checks: distinct inner faces and overlapping lengths.
    base=parallel_wall_boundary(sides)[0]
    inner_lo=min(p[across] for p in base);inner_hi=max(p[across] for p in base)
    if end[across]>inner_lo+EPS or end[across+2]<inner_hi-EPS:
        raise ValueError("端墙未覆盖两侧墙之间的宽度，请调整端墙或用闭合样条指定范围")
    # An end wall may be detached, as in an open corridor. It must remain at
    # one end of BOTH side walls, never cut through their shared middle.
    if end[along]<=min(r[along] for r in sides)+EPS:
        lo=end[along+2];hi=min(r[along+2] for r in sides)
    elif end[along+2]>=max(r[along+2] for r in sides)-EPS:
        lo=max(r[along] for r in sides);hi=end[along]
    else:
        raise ValueError("第三面墙位于侧墙中段，无法确定吊顶朝哪侧延伸，请使用闭合样条")
    if hi-lo<=EPS:
        raise ValueError("三面墙之间没有有效吊顶空间")
    rect=(lo,inner_lo,hi,inner_hi) if along==0 else (inner_lo,lo,inner_hi,hi)
    return [rect_poly(rect)]


def four_wall_boundary(rects):
    # Start between inward faces, then bridge detached ends with orthogonal
    # returns. Long end walls form wider wings, not an infinite narrow corridor.
    pairs=[[],[]]
    for x,z,X,Z in rects:
        dx,dz=X-x,Z-z
        if min(dx,dz)<=EPS or abs(dx-dz)<=EPS:
            raise ValueError("四墙推定需要长度方向明确的矩形墙体")
        pairs[0 if dx>dz else 1].append((x,z,X,Z))
    if any(len(pair)!=2 for pair in pairs):
        raise ValueError("未识别到两组相对墙体，请使用闭合样条指定范围")
    bottom,top=sorted(pairs[0],key=lambda r:r[1])
    left,right=sorted(pairs[1],key=lambda r:r[0])
    x,z,X,Z=left[2],bottom[3],right[0],top[1]
    if X-x<=EPS or Z-z<=EPS:
        raise ValueError("四面墙内侧没有有效吊顶空间")
    cx,cz=(x+X)/2,(z+Z)/2
    if any(not r[0]+EPS<cx<r[2]-EPS for r in pairs[0]) or any(not r[1]+EPS<cz<r[3]-EPS for r in pairs[1]):
        raise ValueError("四面墙错位过大，无法确定房间范围，请使用闭合样条")
    regions=[(x,z,X,Z)]
    def end_wings(horizontal,vertical,swapped=False):
        bottom,top=sorted(horizontal,key=lambda r:r[1])
        left,right=sorted(vertical,key=lambda r:r[0])
        x,z,X,Z=left[2],bottom[3],right[0],top[1]
        candidates=(
            (bottom[0],z,x,min(left[1],Z)),
            (X,z,bottom[2],min(right[1],Z)),
            (top[0],max(left[3],z),x,Z),
            (X,max(right[3],z),top[2],Z),
        )
        for a,b,A,B in candidates:
            if A-a>EPS and B-b>EPS:
                regions.append((b,a,B,A) if swapped else (a,b,A,B))
    end_wings(pairs[0],pairs[1])
    swapped=[[(r[1],r[0],r[3],r[2]) for r in pair] for pair in pairs]
    end_wings(swapped[1],swapped[0],True)
    # Split at all region edges before union so shared partial edges cancel.
    xs,zs=grid([v for r in regions for v in (r[0],r[2])],
               [v for r in regions for v in (r[1],r[3])])
    cells=[]
    for i in range(len(xs)-1):
        for j in range(len(zs)-1):
            cx,cz=(xs[i]+xs[i+1])/2,(zs[j]+zs[j+1])/2
            if any(a<cx<A and b<cz<B for a,b,A,B in regions):
                cells.append(rect_poly(cell_rect(xs,zs,i,j)))
    loops=union_loops(cells)
    validate_loops(loops)
    return loops


def recognize_walls(rects,details=None):
    if len(rects)==2:return parallel_wall_boundary(rects)
    if len(rects)==3:return three_wall_boundary(rects)
    if not 4<=len(rects)<=100:raise ValueError("请选择两面平行墙、三面 U 形墙、围合房间墙体，或一个闭合样条")
    xs=[v for r in rects for v in (r[0],r[2])]
    zs=[v for r in rects for v in (r[1],r[3])]
    xs,zs=grid(xs+[min(xs)-1,max(xs)+1],zs+[min(zs)-1,max(zs)+1])
    free=set()
    for i in range(len(xs)-1):
        for j in range(len(zs)-1):
            x,z=(xs[i]+xs[i+1])/2,(zs[j]+zs[j+1])/2
            if not any(a<x<b and c<z<d for a,c,b,d in rects):free.add((i,j))
    exterior={(i,j) for i,j in free if i in (0,len(xs)-2) or j in (0,len(zs)-2)}
    queue=deque(exterior)
    while queue:
        i,j=queue.popleft()
        for q in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
            if q in free and q not in exterior:exterior.add(q);queue.append(q)
    room=free-exterior
    if not room:
        if len(rects)==4:
            loops=four_wall_boundary(rects)
            if details is not None:details['inferred']=True
            return loops
        raise ValueError("没有识别到封闭房间；门洞或缺墙请用闭合样条指定范围")
    seen={next(iter(room))};queue=deque(seen)
    while queue:
        i,j=queue.popleft()
        for q in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
            if q in room and q not in seen:seen.add(q);queue.append(q)
    if seen!=room:raise ValueError("识别到多个房间，请一次只选择一个房间")
    return union_loops([rect_poly(cell_rect(xs,zs,i,j)) for i,j in sorted(room)])


def room_cells(loops,gap):
    validate_loops(loops)
    if not math.isfinite(gap) or gap<0:raise ValueError("离墙间隙不能为负数")
    xs=[p[0] for loop in loops for p in loop];zs=[p[1] for loop in loops for p in loop]
    xs,zs=grid([v+d for v in xs for d in (-gap,0,gap)],[v+d for v in zs for d in (-gap,0,gap)])
    cells=[]
    edges=[(a,b) for loop in loops for a,b in zip(loop,loop[1:]+loop[:1])]
    for i in range(len(xs)-1):
        for j in range(len(zs)-1):
            x,z=(xs[i]+xs[i+1])/2,(zs[j]+zs[j+1])/2
            if not inside((x,z),loops):continue
            near=False
            if gap:
                for a,b in edges:
                    dx=max(min(a[0],b[0])-x,0,x-max(a[0],b[0]))
                    dz=max(min(a[1],b[1])-z,0,z-max(a[1],b[1]))
                    if max(dx,dz)<gap-EPS:near=True;break
            if not near:cells.append(rect_poly(cell_rect(xs,zs,i,j)))
    if not cells:raise ValueError("离墙间隙过大，没有剩余吊顶范围")
    return cells


def clip_halfplane(poly,n,limit,sign):
    output=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da=sign*(a[0]*n[0]+a[1]*n[1]-limit)
        db=sign*(b[0]*n[0]+b[1]*n[1]-limit)
        if da<=EPS:output.append(a)
        if (da<0<db) or (db<0<da):
            t=da/(da-db);output.append((a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t))
    return output


def layout(loops,kind,gap,width,spacing,angle,offset):
    if kind not in (0,1) or not all(math.isfinite(v) for v in (width,spacing,angle,offset)):
        raise ValueError("吊顶参数无效")
    if not orthogonal(loops):
        boundary = inset_boundary(loops,gap)
        if kind==1:return [boundary]
        if width<=0 or spacing<0:raise ValueError("方通宽度必须大于零，净间距不能为负数")
        n=(-math.sin(math.radians(angle)),math.cos(math.radians(angle)))
        t=(n[1],-n[0])
        points=[p for loop in boundary for p in loop]
        positions=[x*n[0]+z*n[1] for x,z in points]
        lengths=[x*t[0]+z*t[1] for x,z in points]
        lo,hi=min(positions),max(positions);pitch=width+spacing
        start=lo+(offset%pitch)-pitch
        count=int(math.ceil((hi-start)/pitch))
        if count>MAX_SLATS:raise ValueError("方通超过 500 根，请增大宽度或间距")
        result=[]
        for i in range(count):
            a=start+i*pitch
            strip=[(n[0]*u+t[0]*v,n[1]*u+t[1]*v) for u,v in
                   ((a,min(lengths)-1),(a+width,min(lengths)-1),(a+width,max(lengths)+1),(a,max(lengths)+1))]
            clipped=boolean(boundary,[strip],'intersect')
            if clipped:result.append(clipped)
        return result
    cells=room_cells(loops,gap)
    if kind==1:return [union_loops(cells)]
    if width<=0 or spacing<0:raise ValueError("方通宽度必须大于零，净间距不能为负数")
    n=(-math.sin(math.radians(angle)),math.cos(math.radians(angle)))
    positions=[x*n[0]+z*n[1] for cell in cells for x,z in cell]
    lo,hi=min(positions),max(positions);pitch=width+spacing
    start=lo+(offset%pitch)-pitch
    count=int(math.ceil((hi-start)/pitch))
    if count>MAX_SLATS:raise ValueError("方通超过 500 根，请增大宽度或间距")
    if count*len(cells)>1000000:raise ValueError("裁切计算量过大，请简化范围或增大方通间距")
    result=[]
    for i in range(count):
        a=start+i*pitch;b=a+width
        pieces=[]
        for cell in cells:
            clipped=clip_halfplane(clip_halfplane(cell,n,a,-1),n,b,1)
            if len(clipped)>=3 and abs(area(clipped))>EPS:pieces.append(clipped)
        if pieces:result.append(union_loops(pieces))
    return result


def tile_layout(loops,gap,tile_x,tile_z,joint,offset_x,offset_z):
    if not all(math.isfinite(v) for v in (tile_x,tile_z,joint,offset_x,offset_z)):
        raise ValueError("方格板参数无效")
    if min(tile_x,tile_z)<=0 or not 0<joint<min(tile_x,tile_z):
        raise ValueError("龙骨分缝宽度必须大于零且小于板块模数")
    if not orthogonal(loops):
        boundary=inset_boundary(loops,gap)
        xs=[p[0] for loop in boundary for p in loop];zs=[p[1] for loop in boundary for p in loop]
        ox=min(xs)+(offset_x%tile_x);oz=min(zs)+(offset_z%tile_z)
        nx=int(math.ceil((max(xs)-ox)/tile_x));nz=int(math.ceil((max(zs)-oz)/tile_z))
        if (nx+1)*(nz+1)>1000:raise ValueError("方格板超过 1000 块，请增大模数")
        panels=[];rails=boundary
        for i in range(-1,nx):
            for j in range(-1,nz):
                tile=rect_poly((ox+i*tile_x+joint/2,oz+j*tile_z+joint/2,
                                ox+(i+1)*tile_x-joint/2,oz+(j+1)*tile_z-joint/2))
                clipped=boolean(boundary,[tile],'intersect')
                if clipped:
                    panels.append(clipped)
                    rails=boolean(rails,[tile],'difference')
        return panels,rails
    boundary=union_loops(room_cells(loops,gap))
    xs=[p[0] for loop in boundary for p in loop];zs=[p[1] for loop in boundary for p in loop]
    ox=min(xs)+(offset_x%tile_x);oz=min(zs)+(offset_z%tile_z)
    def cuts(coords,origin,pitch):
        first=math.floor((min(coords)-origin)/pitch)-1
        last=math.ceil((max(coords)-origin)/pitch)+1
        if last-first>1000:raise ValueError("方格板过密，请增大模数")
        return coords+[origin+i*pitch+d for i in range(first,last+1) for d in (-joint/2,joint/2)
                       if min(coords)<origin+i*pitch+d<max(coords)]
    xs,zs=grid(cuts(xs,ox,tile_x),cuts(zs,oz,tile_z))
    panels={};rails=[]
    # Partition on every room edge and joint edge, so panels and rails share
    # exact boundaries without overlapping faces or crossing reserved holes.
    for i in range(len(xs)-1):
        for j in range(len(zs)-1):
            x,z=(xs[i]+xs[i+1])/2,(zs[j]+zs[j+1])/2
            if not inside((x,z),boundary):continue
            u,v=(x-ox)/tile_x,(z-oz)/tile_z
            poly=rect_poly(cell_rect(xs,zs,i,j))
            if abs(u-round(u))*tile_x<joint/2 or abs(v-round(v))*tile_z<joint/2:
                rails.append(poly)
            else:
                panels.setdefault((math.floor(u),math.floor(v)),[]).append(poly)
    if len(panels)>1000:raise ValueError("方格板超过 1000 块，请增大模数")
    return [union_loops(panels[key]) for key in sorted(panels)],union_loops(rails)


def make_spline(loops,height,name):
    import c4d
    count=sum(map(len,loops))
    obj=c4d.SplineObject(count,c4d.SPLINETYPE_LINEAR)
    obj.ResizeObject(count,len(loops))
    obj.SetAllPoints([c4d.Vector(x,height,z) for loop in loops for x,z in loop])
    for i,loop in enumerate(loops):obj.SetSegment(i,len(loop),True)
    obj[c4d.SPLINEOBJECT_CLOSED]=True
    obj.SetName(name);obj.Message(c4d.MSG_UPDATE)
    return obj


def circle_loop(x,z,radius):
    return [(x+radius*math.cos(i*math.pi/24),z+radius*math.sin(i*math.pi/24)) for i in range(48)]


def radial_fixture_mesh(positions,profile,elevation,segments=48):
    """Revolve a closed radial profile without spline cap triangulation."""
    points=[];faces=[]
    for x,z in positions:
        rings=[]
        for radius,y in profile:
            ring=[]
            for i in range(segments if radius else 1):
                angle=2*math.pi*i/segments
                ring.append(len(points))
                points.append((x+radius*math.cos(angle),elevation+y,z+radius*math.sin(angle)))
            rings.append(ring)
        for a,b in zip(rings,rings[1:]+rings[:1]):
            if len(a)==len(b)==1:continue
            for i in range(segments):
                j=(i+1)%segments
                if len(a)==1:faces.append((a[0],b[i],b[j]))
                elif len(b)==1:faces.append((a[i],b[0],a[j]))
                else:faces.append((a[i],b[i],b[j],a[j]))
    return points,faces


def edge_distance(point,loops):
    best=float('inf');x,z=point
    for loop in loops:
        for a,b in zip(loop,loop[1:]+loop[:1]):
            dx,dz=b[0]-a[0],b[1]-a[1]
            t=max(0,min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz)))
            best=min(best,math.hypot(x-a[0]-t*dx,z-a[1]-t*dz))
    return best


def spotlight_layout(loops,gap,band,pitch,diameter):
    if pitch<diameter+2 or band<diameter+2 or diameter<=0:
        raise ValueError("射灯间距和周边板宽度必须至少比灯具外径大 2 cm")
    outer=inset_boundary(loops,gap);inner=inset_boundary(loops,gap+band)
    track=inset_boundary(loops,gap+band/2)
    positions=[];attempts=0
    for loop in track:
        # Cell unions may split a straight wall into many small edges.
        path=[p for i,p in enumerate(loop)
              if abs((p[0]-loop[i-1][0])*(loop[(i+1)%len(loop)][1]-p[1])-
                     (p[1]-loop[i-1][1])*(loop[(i+1)%len(loop)][0]-p[0]))>EPS]
        for a,b in zip(path,path[1:]+path[:1]):
            length=math.hypot(b[0]-a[0],b[1]-a[1])
            count=max(1,int(length/pitch))
            attempts+=count
            if attempts>200:raise ValueError("射灯超过 200 个，请增大间距")
            for i in range(count):
                t=(i+.5)/count;p=(a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]))
                if not inside(p,outer) or inside(p,inner):continue
                if min(edge_distance(p,outer),edge_distance(p,inner))<diameter/2+.5:continue
                if any(math.hypot(p[0]-q[0],p[1]-q[1])<diameter+2 for q in positions):continue
                positions.append(p)
    if not positions:raise ValueError("当前周边范围无法容纳射灯，请减小外径或调整板宽")
    return positions


def flat_spotlight_layout(loops,gap,pitch_x,pitch_z,margin,diameter,offset_x=0,offset_z=0):
    if min(pitch_x,pitch_z)<diameter+2 or diameter<=0 or margin<0:
        raise ValueError("射灯横纵间距必须至少比外径大 2 cm，离边距离不能为负数")
    boundary=inset_boundary(loops,gap)
    clearance=max(margin,diameter/2+1)
    xs=[p[0] for loop in boundary for p in loop];zs=[p[1] for loop in boundary for p in loop]
    def positions(low,high,pitch,offset):
        usable=high-low-2*clearance
        if usable<0:return []
        count=int(math.floor(usable/pitch))+1
        origin=(low+high)/2-(count-1)*pitch/2+offset%pitch
        first=int(math.ceil((low+clearance-origin)/pitch-EPS))
        last=int(math.floor((high-clearance-origin)/pitch+EPS))
        return [origin+i*pitch for i in range(first,last+1)]
    xx=positions(min(xs),max(xs),pitch_x,offset_x)
    zz=positions(min(zs),max(zs),pitch_z,offset_z)
    if len(xx)*len(zz)>10000:raise ValueError("射灯排布过密，请增大间距")
    result=[]
    for x in xx:
        for z in zz:
            if inside((x,z),boundary) and edge_distance((x,z),boundary)>=clearance-EPS:
                result.append((x,z))
                if len(result)>200:raise ValueError("射灯超过 200 个，请增大间距")
    if not result:raise ValueError("平顶范围无法容纳射灯，请减小外径或离边距离")
    return result


def luminous_tile_indices(shapes,boundary,tile_params,columns,rows,column_offset,row_offset):
    columns,rows=int(columns),int(rows)
    if min(columns,rows)<1:raise ValueError("发光灯板行列间隔必须大于零")
    tx,tz,joint,dx,dz=tile_params
    ox=min(p[0] for loop in boundary for p in loop)+dx%tx
    oz=min(p[1] for loop in boundary for p in loop)+dz%tz
    result=set()
    for index,contours in enumerate(shapes):
        # Only complete tiles become luminaires, never edge scraps or cutouts.
        if abs(sum(area(p) for p in oriented(contours))-(tx-joint)*(tz-joint))>1e-4:continue
        x=(min(p[0] for poly in contours for p in poly)+max(p[0] for poly in contours for p in poly))/2
        z=(min(p[1] for poly in contours for p in poly)+max(p[1] for poly in contours for p in poly))/2
        col=int(math.floor((x-ox)/tx));row=int(math.floor((z-oz)/tz))
        if (col-int(column_offset))%columns==0 and (row-int(row_offset))%rows==0:result.add(index)
    return result


def contour_components(loops):
    loops=oriented(loops)
    outers=[loop for loop in loops if area(loop)>0]
    groups=[[loop] for loop in outers]
    for hole in (loop for loop in loops if area(loop)<0):
        parents=[i for i,outer in enumerate(outers) if inside(hole[0],[outer])]
        if parents:groups[min(parents,key=lambda i:abs(area(outers[i])))].append(hole)
    return groups


def lamp_zones(lamps,boundary,t,n,gap):
    # A continuous strip through a corridor must still stop at its cross wings.
    cuts=[]
    for loop in oriented(boundary):
        for i,p in enumerate(loop):
            a=loop[i-1];b=loop[(i+1)%len(loop)]
            incoming=(p[0]-a[0],p[1]-a[1]);outgoing=(b[0]-p[0],b[1]-p[1])
            if incoming[0]*outgoing[1]-incoming[1]*outgoing[0]>=-EPS:continue
            for v in (incoming,outgoing):
                size=math.hypot(*v)
                if size>EPS and abs(v[0]*t[0]+v[1]*t[1])<=EPS*max(1,size):
                    cuts.append(p[0]*t[0]+p[1]*t[1]+gap*(-v[1]*t[0]+v[0]*t[1])/size)
    cuts=sorted(set(round(v,6) for v in cuts))
    result=[]
    for lamp in lamps:
        for component in contour_components(lamp):
            along=[x*t[0]+z*t[1] for loop in component for x,z in loop]
            across=[x*n[0]+z*n[1] for loop in component for x,z in loop]
            low,high=min(along),max(along)
            boundaries=[low]+[v for v in cuts if low+EPS<v<high-EPS]+[high]
            if len(boundaries)==2:
                result.append(component)
                continue
            for a,b in zip(boundaries,boundaries[1:]):
                cutter=[(t[0]*u+n[0]*v,t[1]*u+n[1]*v) for u,v in
                        ((a,min(across)-1),(b,min(across)-1),(b,max(across)+1),(a,max(across)+1))]
                clipped=boolean(component,[cutter],'intersect')
                if clipped:result.extend(contour_components(clipped))
                if len(result)>MAX_SLATS:raise ValueError("长条灯分区过多，请简化范围或增大隔排数")
    return result


def strip_light_layout(loops,gap,width,spacing,angle,offset,every,lamp_width,length=0,length_offset=0,count=1,segment_gap=30):
    if not all(math.isfinite(v) for v in (length,length_offset)) or length<0:
        raise ValueError("长条灯长度不能为负数，长度和偏移必须为有效数值")
    if not math.isfinite(count) or int(count)!=count or not 1<=count<=50:
        raise ValueError("每行长条灯数量必须为 1 到 50 的整数")
    if not math.isfinite(segment_gap) or segment_gap<0:
        raise ValueError("长条灯段间距不能为负数")
    count=int(count)
    pitch=width+spacing
    if every<1 or int(every)!=every or not 0<lamp_width<every*pitch:
        raise ValueError("长条灯排数必须为正整数，灯宽必须小于相邻灯的中心距离")
    # Use the exact same first-row origin as the slats; centre in their gaps.
    start=offset%pitch+width+(spacing-lamp_width)/2
    lamps=layout(loops,0,gap,lamp_width,every*pitch-lamp_width,angle,start)
    if length==0 and count==1:return lamps
    t=(math.cos(math.radians(angle)),math.sin(math.radians(angle)))
    n=(-t[1],t[0]);result=[]
    components=lamp_zones(lamps,loops,t,n,gap)
    if len(components)*count>MAX_SLATS:
        raise ValueError("长条灯超过 500 段，请减少每行数量或增大隔排数")
    for contours in components:
        along=[x*t[0]+z*t[1] for loop in contours for x,z in loop]
        across=[x*n[0]+z*n[1] for loop in contours for x,z in loop]
        center=(min(along)+max(along))/2+length_offset
        lamp_length=length or (max(along)-min(along)-(count-1)*segment_gap)/count
        if lamp_length<=EPS:
            raise ValueError("当前范围容不下长条灯段间距，请减小数量或间距，或指定灯长")
        # Clip the existing lamp rather than moving it across room holes or walls.
        for i in range(count):
            middle=center+(i-(count-1)/2)*(lamp_length+segment_gap)
            cutter=[(t[0]*u+n[0]*v,t[1]*u+n[1]*v) for u,v in
                    ((middle-lamp_length/2,min(across)-1),(middle+lamp_length/2,min(across)-1),
                     (middle+lamp_length/2,max(across)+1),(middle-lamp_length/2,max(across)+1))]
            clipped=boolean(contours,[cutter],'intersect')
            if clipped:result.append(clipped)
    return result


def clear_slats_for_lights(shapes,lights,angle):
    n=(-math.sin(math.radians(angle)),math.cos(math.radians(angle)))
    def bounds(contours):
        u=[x*n[0]+z*n[1] for loop in contours for x,z in loop]
        return min(u),max(u)
    lamps=[(bounds(lamp),lamp) for lamp in lights]
    result=[]
    for shape in shapes:
        lo,hi=bounds(shape)
        for (a,b),lamp in lamps:
            if a<hi-EPS and b>lo+EPS:shape=boolean(shape,lamp,'difference')
            if not shape:break
        if shape:result.append(shape)
    return result


def recessed_cove(loops,gap,board,rim,rise,width,lip):
    if width<=2*board+1 or lip<1 or board+lip>=rise-1:
        raise ValueError("灯槽需宽于两倍板厚加 1 cm；挡光沿顶端需低于中央顶板至少 1 cm")
    start=gap+rim+board
    outer=inset_boundary(loops,start)
    inner=inset_boundary(loops,start+width)
    lip_outer=inset_boundary(loops,start+width-board)
    source_width=min(1.2,(width-board)*.15)
    source_offset=(width-board)*.5
    source_outer=inset_boundary(loops,start+source_offset-source_width/2)
    source_inner=inset_boundary(loops,start+source_offset+source_width/2)
    shelf=boolean(outer,inner,'difference')
    parts=[(shelf,"内藏灯槽槽底",board,0,0),
           (boolean(lip_outer,inner,'difference'),"灯槽挡光沿",lip,0,board),
           (boolean(source_outer,source_inner,'difference'),"内藏向上灯带",.15,5,board+.25)]
    lights=[]
    track=inset_boundary(loops,start+source_offset)
    for loop in track:
        path=[p for i,p in enumerate(loop)
              if abs((p[0]-loop[i-1][0])*(loop[(i+1)%len(loop)][1]-p[1])-
                     (p[1]-loop[i-1][1])*(loop[(i+1)%len(loop)][0]-p[0]))>EPS]
        for a,b in zip(path,path[1:]+path[:1]):
            length=math.hypot(b[0]-a[0],b[1]-a[1])
            if length<=source_width*2:continue
            x,z=(a[0]+b[0])/2,(a[1]+b[1])/2
            if not inside((x,z),shelf):continue
            lights.append((x,z,(b[0]-a[0])/length,(b[1]-a[1])/length,
                           length-source_width*2,source_width))
    if len(lights)>64:raise ValueError("灯槽轮廓过于复杂，请简化至 64 个直边以内")
    return parts,lights


def tray_layout(loops,gap,board,params,lip=6,lamp_length=0,lamp_offset=0):
    rim,rise,cove,cove_width,center,pitch,lamp_width,angle,vents,vent_width,vent_offset,fin_count=params
    if not all(math.isfinite(v) for v in (lamp_length,lamp_offset)) or lamp_length<0:
        raise ValueError("中央灯带长度不能为负数，长度和偏移必须为有效数值")
    if rim<=board*2 or rise<=board or (center and pitch<=lamp_width+2):
        raise ValueError("跌级边顶需宽于两倍板厚，抬高需大于板厚，灯带间距需大于灯宽加 2 cm")
    if cove and cove_width<=0:raise ValueError("灯槽宽度必须大于零")
    if vents and (vent_width<=0 or vent_offset<board or vent_offset+vent_width>rim-board):
        raise ValueError("风口必须位于边顶内，请调整风口宽度、离墙距离或边顶宽度")
    outer=inset_boundary(loops,gap)
    opening=inset_boundary(loops,gap+rim)
    upper=inset_boundary(loops,gap+rim+board)
    side=boolean(opening,upper,'difference')
    lower=boolean(outer,opening,'difference')
    parts=[]
    def part(contours,name,thickness,slot,elevation):
        if contours:parts.append((contours,name,thickness,slot,elevation))
    if vents:
        # Follow long perimeter edges perpendicular to the cross-light direction.
        t=(math.cos(math.radians(angle)),math.sin(math.radians(angle)))
        voids=[];fins=[];vent_covers=[]
        for loop in oriented(outer):
            if area(loop)<=0:continue
            for a,b in zip(loop,loop[1:]+loop[:1]):
                dx,dz=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dz)
                if length<rim*2+20 or abs((dx*t[0]+dz*t[1])/length)>.25:continue
                ux,uz=dx/length,dz/length;nx,nz=-uz,ux
                def strip(start,end,padding=0):
                    return [(a[0]+ux*s+nx*d,a[1]+uz*s+nz*d)
                            for s,d in ((rim-padding,start),(length-rim+padding,start),
                                        (length-rim+padding,end),(rim-padding,end))]
                contour=boolean([strip(vent_offset,vent_offset+vent_width)],lower,'intersect')
                if not contour:continue
                voids=boolean(voids,contour,'union')
                overlap=min(board*.5,.6)
                cover=boolean([strip(vent_offset-overlap,vent_offset+vent_width+overlap,overlap)],lower,'intersect')
                vent_covers=boolean(vent_covers,cover,'union')
                for i in range(1,int(fin_count)+1):
                    d=vent_offset+vent_width*i/(int(fin_count)+1)
                    half=min(.18,vent_width/(int(fin_count)+1)*.15)
                    fins.extend(boolean([strip(d-half,d+half)],contour,'intersect'))
        if voids:
            lower=boolean(lower,voids,'difference')
            # Enclose the open grille from above and every side; overlap the slab
            # and lid so neither grazing light nor cap tolerances reveal a seam.
            wall=min(board*.5,vent_width*.15,.6)
            try:cavity=inset_boundary(voids,wall)
            except ValueError:cavity=[]
            walls=boolean(voids,cavity,'difference') if cavity else voids
            lid_y=board+.6+max(2,min(6,vent_width*.3))
            wall_y=board*.75
            part(vent_covers,"线性风口遮光背板",board,4,lid_y)
            part(walls,"线性风口四周封边",lid_y+board*.25-wall_y,4,wall_y)
            part(fins,"线性风口格栅",board+.6,2,0)
    part(lower,"跌级周边底板",board,0,0)
    part(side,"跌级内侧立板",rise+board,0,0)
    central=upper
    if cove:
        cove_parts,_=recessed_cove(loops,gap,board,rim,rise,cove_width,lip)
        parts.extend(cove_parts)
    if center:
        usable_gap=gap+rim+board+(cove_width if cove else 0)+3
        usable=inset_boundary(loops,usable_gap)
        n=(-math.sin(math.radians(angle)),math.cos(math.radians(angle)))
        projections=[x*n[0]+z*n[1] for loop in usable for x,z in loop]
        span=max(projections)-min(projections)
        count=max(1,int(math.floor((span-lamp_width)/pitch))+1)
        offset=max(0,(span-((count-1)*pitch+lamp_width))/2)
        lamps=layout(loops,0,usable_gap,lamp_width,pitch-lamp_width,angle,offset)
        if lamp_length>0:
            t=(n[1],-n[0]);clipped_lamps=[]
            # Trim within each local zone without spanning holes or concave corners.
            for contours in lamp_zones(lamps,loops,t,n,usable_gap):
                along=[x*t[0]+z*t[1] for loop in contours for x,z in loop]
                across=[x*n[0]+z*n[1] for loop in contours for x,z in loop]
                middle=(min(along)+max(along))/2+lamp_offset
                cutter=[(t[0]*u+n[0]*v,t[1]*u+n[1]*v) for u,v in
                        ((middle-lamp_length/2,min(across)-1),(middle+lamp_length/2,min(across)-1),
                         (middle+lamp_length/2,max(across)+1),(middle-lamp_length/2,max(across)+1))]
                clipped=boolean(contours,[cutter],'intersect')
                if clipped:clipped_lamps.append(clipped)
            lamps=clipped_lamps
        for i,contours in enumerate(lamps):
            central=boolean(central,contours,'difference')
            part(contours,"中央灯带发光面 %03d"%(i+1),min(.2,board/2),5,rise)
            part(contours,"中央灯带灯体 %03d"%(i+1),board,4,rise+min(.2,board/2))
    part(central,"中央抬高顶板",board,0,rise)
    return parts,lower


def ceiling_parameter_visibility(values):
    kind=int(values[0]);spots=bool(values[18]);strips=kind==0 and bool(values[22])
    visible={0,1,2,9,18}
    if values[9]:visible.add(10)
    if kind==0:
        visible.update((3,4,5,6,7,16,22))
        if values[16]:visible.add(17)
    else:visible.add(8)
    if kind==2:
        visible.update(range(11,16));visible.add(36)
        if len(values)>36 and values[36]:visible.update(range(37,41))
    if kind==3:
        visible.difference_update((9,10))
        visible.update((41,42,43,45,48,49))
        if values[43]:
            visible.update((44,53,54))
            if len(values)>54 and values[54]:visible.add(55)
        if values[45]:
            visible.update((46,47,56))
            if len(values)>56 and values[56]>0:visible.add(57)
        if values[49]:visible.update((50,51,52))
    if spots:
        visible.update((19,21,26))
        if kind==1:visible.update(range(32,36))
        elif kind!=3:visible.add(20)
        if values[26]:visible.add(27)
    if strips:visible.update((23,24,25,28,29,30,31))
    return visible


def sync_ceiling_ui(obj,param_ids,material_ids):
    import c4d
    values=[obj[c4d.ID_USERDATA,i] for i in param_ids]
    visible=ceiling_parameter_visibility(values);kind=int(values[0]);spots=bool(values[18])
    material_visible={0}
    if values[9] or (spots and kind!=1) or (kind==0 and values[16]):material_visible.add(1)
    if kind==2:material_visible.add(2)
    if kind==0 and values[16]:material_visible.add(3)
    if spots or (kind==0 and values[22]) or (kind==2 and len(values)>36 and values[36]):
        material_visible.update((4,5))
    if kind==2 and len(values)>36 and values[36]:material_visible.add(1)
    if kind==3:
        material_visible={0}
        if values[49]:material_visible.update((2,4))
        if values[43] or values[45] or spots:material_visible.update((4,5))
    hidden={key:i not in visible for i,key in enumerate(param_ids)}
    hidden.update({key:i not in material_visible for i,key in enumerate(material_ids)})
    labels={param_ids[18]:"平顶阵列射灯" if kind==1 else "周边射灯",
            param_ids[19]:"射灯横向间距 (cm)" if kind==1 else "射灯间距 (cm)",
            param_ids[8]:"跌级板厚度 (cm)" if kind==3 else "平顶板厚度 (cm)" if kind==1 else "方格板厚度 (cm)"}
    changed=False
    for key,bc in obj.GetUserDataContainer():
        uid=key[1].id
        if uid not in hidden:continue
        label=labels.get(uid,bc[c4d.DESC_NAME])
        if bool(bc[c4d.DESC_HIDE])==hidden[uid] and bc[c4d.DESC_NAME]==label:continue
        bc[c4d.DESC_HIDE]=hidden[uid]
        bc[c4d.DESC_NAME]=bc[c4d.DESC_SHORT_NAME]=label
        obj.SetUserDataContainer(key,bc);changed=True
    return changed


def build(loops,values,materials):
    import c4d
    kind,height,gap,width,depth,spacing,angle,offset,board,trim,trim_width=values[:11]
    tile_params=values[11:16] if len(values)>=16 else (60.0,60.0,.8,0.0,0.0)
    options=[False,1.2,False,120.0,24.0,8.0,False,6,3.0,2.0,False,100.0]
    options[:len(values[16:28])]=values[16:28]
    cover,cover_thickness,spots,spot_pitch,band,diameter,strips,every,lamp_width,lamp_depth,real_spots,brightness=options
    lamp_length=values[28] if len(values)>28 else 0
    lamp_offset=values[29] if len(values)>29 else 0
    lamp_count=values[30] if len(values)>30 else 1
    lamp_gap=values[31] if len(values)>31 else 30
    tray_params=values[41:53] if len(values)>=53 else (50,18,True,5,True,120,5,0,True,10,30,4)
    cove_lip=values[53] if len(values)>53 else 6
    cove_lights=bool(values[54]) if len(values)>54 else False
    cove_brightness=values[55] if len(values)>55 else 300
    tray_lamp_length=values[56] if len(values)>56 else 0
    tray_lamp_offset=values[57] if len(values)>57 else 0
    mode_options=[120.0,30.0,0.0,0.0,True,3,3,1,1]
    mode_options[:len(values[32:41])]=values[32:41]
    spot_pitch_z,spot_margin,spot_dx,spot_dz,tile_lights,tile_columns,tile_rows,tile_col_offset,tile_row_offset=mode_options
    if not all(math.isfinite(float(v)) for v in values) or min(depth,board,trim_width)<=0:
        raise ValueError("厚度与收边宽度必须大于零")
    if min(cover_thickness,lamp_depth)<=0 or brightness<0:
        raise ValueError("封板和灯体厚度必须大于零，亮度不能为负数")
    perimeter_spots=spots and kind!=1
    rim_width=max(trim_width if trim else 0,band if perimeter_spots else 0)
    side_width=min(cover_thickness,rim_width) if rim_width else cover_thickness
    inner_gap=gap+max(rim_width,side_width if kind==0 and cover else 0)
    tray_parts=[]
    if kind==3:
        tray_parts,tray_lower=tray_layout(loops,gap,board,tray_params,cove_lip,tray_lamp_length,tray_lamp_offset)
        rim_width=tray_params[0]
    spot_positions=(flat_spotlight_layout(loops,inner_gap,spot_pitch,spot_pitch_z,spot_margin,diameter,spot_dx,spot_dz)
                    if kind==1 else spotlight_layout(loops,gap,rim_width,spot_pitch,diameter)) if spots else []
    if kind==3 and spot_positions:
        # Keep fixtures away from the recessed ventilation slots.
        spot_positions=[p for p in spot_positions if inside(p,tray_lower)
                        and edge_distance(p,tray_lower)>diameter/2+.5]
        for contours,name,thickness,slot,elevation in tray_parts:
            if name=="跌级周边底板":
                contours.extend(list(reversed(circle_loop(x,z,diameter*.42))) for x,z in spot_positions)
    rails=[]
    luminous=set()
    if kind==3:shapes=[]
    elif kind==2:
        shapes,rails=tile_layout(loops,inner_gap,*tile_params)
        if tile_lights and len(values)>36:
            luminous=luminous_tile_indices(shapes,inset_boundary(loops,inner_gap),tile_params,
                tile_columns,tile_rows,tile_col_offset,tile_row_offset)
    else:
        shapes=layout(loops,int(kind),inner_gap,width,spacing,angle,offset)
    if kind==1 and spot_positions:
        shapes[0].extend(list(reversed(circle_loop(x,z,diameter*.42))) for x,z in spot_positions)
    lamps=strip_light_layout(loops,inner_gap,width,spacing,angle,offset,every,lamp_width,lamp_length,lamp_offset,lamp_count,lamp_gap) if kind==0 and strips else []
    if lamps and lamp_width>spacing:shapes=clear_slats_for_lights(shapes,lamps,angle)
    root=c4d.BaseObject(c4d.Onull);root.SetName("花花吊顶模型")
    def extrude(contours,name,thickness,slot,elevation=None):
        obj=c4d.BaseObject(c4d.Oextrude);obj.SetName(name)
        obj[c4d.EXTRUDEOBJECT_MOVE]=c4d.Vector(0,thickness,0)
        if hasattr(c4d,'EXTRUDEOBJECT_DIRECTION'):
            obj[c4d.EXTRUDEOBJECT_DIRECTION]=getattr(c4d,'EXTRUDEOBJECT_DIRECTION_Y',2)
        if hasattr(c4d,'EXTRUDEOBJECT_EXTRUSIONOFFSET'):
            obj[c4d.EXTRUDEOBJECT_EXTRUSIONOFFSET]=thickness
        make_spline(contours,height if elevation is None else elevation,"吊顶闭合截面").InsertUnderLast(obj)
        material=materials[slot] if slot<len(materials) else None
        if material is not None:
            tag=c4d.TextureTag();tag.SetMaterial(material)
            tag[c4d.TEXTURETAG_PROJECTION]=c4d.TEXTURETAG_PROJECTION_CUBIC;obj.InsertTag(tag)
        obj.InsertUnderLast(root)
    for contours,name,thickness,slot,elevation in tray_parts:
        extrude(contours,name,thickness,slot,height+elevation)
    if kind==3 and tray_params[2] and cove_lights:
        _,sources=recessed_cove(loops,gap,board,tray_params[0],tray_params[1],tray_params[3],cove_lip)
        for i,(x,z,ux,uz,length,source_width) in enumerate(sources):
            light=c4d.BaseObject(c4d.Olight);light.SetName("灯槽向上洗光 %03d"%(i+1))
            light[c4d.LIGHT_TYPE]=c4d.LIGHT_TYPE_AREA
            light[c4d.LIGHT_AREADETAILS_SHAPE]=c4d.LIGHT_AREADETAILS_SHAPE_RECTANGLE
            light[c4d.LIGHT_AREADETAILS_SIZEX]=length
            light[c4d.LIGHT_AREADETAILS_SIZEY]=source_width
            light[c4d.LIGHT_DETAILS_ONLYZ]=True
            light[c4d.LIGHT_AREADETAILS_SHOWINRENDER]=False
            light[c4d.LIGHT_AREADETAILS_SHOWINSPECULAR]=False
            light[c4d.LIGHT_AREADETAILS_SHOWASSOLIDINVIEWPORT]=False
            light[c4d.LIGHT_COLOR]=c4d.Vector(1,.86,.65)
            light[c4d.LIGHT_BRIGHTNESS]=max(0,cove_brightness)/100
            # A center-based decay sphere would extinguish the ends of a long strip.
            # The closed tray and raised lip confine the upward area light instead.
            light[c4d.LIGHT_DETAILS_FALLOFF]=c4d.LIGHT_DETAILS_FALLOFF_NONE
            light[c4d.LIGHT_SHADOWTYPE]=c4d.LIGHT_SHADOWTYPE_AREA
            light.SetMg(c4d.Matrix(c4d.Vector(x,height+board+.45,z),c4d.Vector(ux,0,uz),
                                  c4d.Vector(uz,0,-ux),c4d.Vector(0,1,0)))
            light.InsertUnderLast(root)
    for i,contours in enumerate(shapes):
        if i in luminous:
            inset=min(.8,tile_params[0]*.02,tile_params[1]*.02)
            diffuser=inset_boundary(contours,inset)
            skin=min(.2,board*.25)
            extrude(contours,"方格灯板灯体 %03d"%(i+1),board-skin,4,height+skin)
            extrude(boolean(contours,diffuser,'difference'),"方格灯板边框 %03d"%(i+1),skin,1)
            extrude(diffuser,"方格灯板发光面 %03d"%(i+1),skin,5)
            continue
        name="铝方通 %03d"%(i+1) if kind==0 else "方格板 %03d"%(i+1) if kind==2 else "平顶吊顶"
        extrude(contours,name,depth if kind==0 else board,0)
    if rails:extrude(rails,"方格板细龙骨",board,2 if len(materials)>2 else 1)
    if rim_width>0 and kind!=3:
        outer=inset_boundary(loops,gap)
        try:inner=inset_boundary(loops,inner_gap)
        except ValueError as exc:
            raise ValueError("收边宽度过大或范围复杂："+str(exc))
        rim=boolean(outer,inner,'difference')
        # Placement already guarantees disjoint circles wholly inside the rim.
        # Add spline holes directly instead of repeating a growing Boolean cut.
        if perimeter_spots:rim.extend(list(reversed(circle_loop(x,z,diameter*.42))) for x,z in spot_positions)
        extrude(rim,"周边射灯板" if perimeter_spots else "周边收口",min(depth,board) if kind==0 else board,1)
    if kind==0 and cover:
        outer=inset_boundary(loops,gap)
        extrude(outer,"铝方通顶部封板",cover_thickness,3,height+depth)
        side=boolean(outer,inset_boundary(loops,gap+side_width),'difference')
        base=min(depth,board) if trim or spots else 0
        if depth>base:extrude(side,"铝方通周边侧封板",depth-base,1,height+base)
    for i,(x,z) in enumerate(spot_positions):
        if real_spots:
            light=c4d.BaseObject(c4d.Olight);light.SetName("射灯光源 %03d"%(i+1))
            light[c4d.LIGHT_TYPE]=c4d.LIGHT_TYPE_SPOT
            light[c4d.LIGHT_COLOR]=c4d.Vector(1,.92,.8)
            light[c4d.LIGHT_BRIGHTNESS]=brightness/100
            light[c4d.LIGHT_DETAILS_OUTERANGLE]=math.radians(60)
            light[c4d.LIGHT_SHADOWTYPE]=c4d.LIGHT_SHADOWTYPE_HARD
            light.SetMg(c4d.Matrix(c4d.Vector(x,height-.35,z),c4d.Vector(1,0,0),
                                   c4d.Vector(0,0,1),c4d.Vector(0,-1,0)))
            light.InsertUnderLast(root)
    if spot_positions:
        r=diameter/2;inner=diameter*.39;bevel=min(.08,diameter*.02)
        profiles=(
            ("射灯边框（合并）",4,[(r-bevel,-.3),(r,-.3+bevel),(r,.2-bevel),
                (r-bevel,.2),(inner+bevel,.2),(inner,.2-bevel),
                (inner,-.3+bevel),(inner+bevel,-.3)]),
            ("射灯内筒（合并）",4,[(diameter*.42,.2),(diameter*.42,1.6),(inner,1.6),(inner,.2)]),
            ("射灯发光面（合并）",5,[(inner,1.4),(inner,1.6),(0,1.6),(0,1.4)]))
        for name,slot,profile in profiles:
            points,faces=radial_fixture_mesh(spot_positions,profile,height)
            obj=c4d.PolygonObject(len(points),len(faces));obj.SetName(name)
            obj.SetAllPoints([c4d.Vector(*p) for p in points])
            for i,face in enumerate(faces):obj.SetPolygon(i,c4d.CPolygon(*face))
            obj.SetPhong(True,True,math.radians(40))
            material=materials[slot] if slot<len(materials) else None
            if material is not None:
                tag=c4d.TextureTag();tag.SetMaterial(material)
                tag[c4d.TEXTURETAG_PROJECTION]=c4d.TEXTURETAG_PROJECTION_CUBIC;obj.InsertTag(tag)
            obj.Message(c4d.MSG_UPDATE);obj.InsertUnderLast(root)
    if lamps:
        for i,contours in enumerate(lamps):
            extrude(contours,"长条灯灯体 %03d"%(i+1),lamp_depth,4)
            try:diffuser=inset_boundary(contours,min(.2,lamp_width*.1))
            except ValueError:continue
            extrude(diffuser,"长条灯发光面 %03d"%(i+1),.15,5,height-.15)
    return root


def read_spline(obj, local=False):
    import c4d
    if not obj.CheckType(c4d.Ospline) or obj[c4d.SPLINEOBJECT_TYPE]!=c4d.SPLINETYPE_LINEAR:
        raise ValueError("请选择水平的可编辑闭合直线样条，支持凹角和斜边")
    matrix=obj.GetMl() if local else obj.GetMg()
    points=[matrix*p for p in obj.GetAllPoints()]
    if not points or max(p.y for p in points)-min(p.y for p in points)>.01:
        raise ValueError("吊顶范围样条必须位于水平 XZ 平面")
    segments=[obj.GetSegment(i) for i in range(obj.GetSegmentCount())]
    if not segments:segments=[{'cnt':len(points),'closed':bool(obj[c4d.SPLINEOBJECT_CLOSED])}]
    loops=[];cursor=0
    for segment in segments:
        if not segment['closed']:raise ValueError("范围存在开放子路径，请先闭合")
        loop=[(round(p.x,6),round(p.z,6)) for p in points[cursor:cursor+segment['cnt']]]
        if len(loop)>1 and loop[0]==loop[-1]:loop.pop()
        loops.append(loop);cursor+=segment['cnt']
    validate_loops(loops)
    return loops,points[0].y


def recognize_wall_polygons(polygons,wall_count=None):
    if not polygons or (len(polygons) if wall_count is None else wall_count)>100:
        raise ValueError('请选择单个房间的墙体（最多 100 面）或闭合范围样条')
    solid=[]
    for footprint in polygons:
        solid=boolean(solid,[footprint],'union')
    # Holes in the union of wall solids are enclosed rooms, not the exterior.
    rooms=[loop for loop in solid if area(loop)<0]
    if len(rooms)!=1:
        raise ValueError('没有识别到唯一闭合房间；请补齐范围样条的缺口，或只选择一个房间')
    room=rooms[0]
    islands=[loop for loop in solid if area(loop)>0 and inside(loop[0],[room])]
    result=oriented([room]+islands)
    validate_loops(result)
    return result


def selection_boundary(objects,details=None):
    import c4d
    if len(objects)==1 and objects[0].CheckType(c4d.Ospline):
        loops,height=read_spline(objects[0]);return loops,height,height
    rects=[];footprints=[];tops=[];bases=[];cap_groups=[];seen=[]
    def collect_caps(root):
        stack=[root];pieces=[]
        while stack:
            mesh=stack.pop();stack.extend(mesh.GetChildren())
            if mesh.CheckType(c4d.Opolygon) and mesh.GetPointCount():
                m=mesh.GetMg();points=[m*p for p in mesh.GetAllPoints()]
                pieces.append((points,mesh))
        if not pieces:raise ValueError("墙体没有可读取的多边形缓存")
        top=max(p.y for points,_ in pieces for p in points)
        caps=[]
        for points,mesh in pieces:
            for face in mesh.GetAllPolygons():
                idx=(face.a,face.b,face.c) if face.c==face.d else (face.a,face.b,face.c,face.d)
                if all(top-points[i].y<=.01 for i in idx):
                    poly=[(points[i].x,points[i].z) for i in idx]
                    if abs(area(poly))>EPS:caps.append(poly)
        if not caps:raise ValueError("墙体没有水平封顶面，请使用闭合范围样条")
        cap_groups.append((top,caps))
    def visit(obj):
        if obj in seen:return
        seen.append(obj)
        children=obj.GetChildren()
        if obj.CheckType(c4d.Onull):
            for child in children:visit(child)
            return
        if obj.CheckType(c4d.Oextrude):
            cache=obj.GetDeformCache() or obj.GetCache()
            if cache is None:raise ValueError("挤压墙尚未生成几何缓存")
            collect_caps(cache)
            return
        if not obj.CheckType(c4d.Ocube) and not obj.CheckType(c4d.Opolygon):
            raise ValueError("墙体自动识别暂支持矩形立方体/长方体多边形墙；复杂墙请使用闭合样条")
        m=obj.GetMg();r=obj.GetRad();p=obj.GetMp()
        axes=(m.v1.GetNormalized(),m.v2.GetNormalized(),m.v3.GetNormalized())
        if obj.CheckType(c4d.Opolygon):
            pts=obj.GetAllPoints()
            if len(pts)!=8 or any(any(min(abs(getattr(q,k)-getattr(p,k)-getattr(r,k)),abs(getattr(q,k)-getattr(p,k)+getattr(r,k)))>.001 for k in ('x','y','z')) for q in pts):
                collect_caps(obj)
                return
        if abs(axes[1].y)<1-1e-5 or abs(axes[0].y)>1e-5 or abs(axes[2].y)>1e-5:
            if obj.CheckType(c4d.Opolygon):
                collect_caps(obj)
                return
            raise ValueError("墙体必须竖直；倾斜墙体请使用水平闭合样条指定范围")
        corners=[m*(p+c4d.Vector(sx*r.x,sy*r.y,sz*r.z)) for sx in (-1,1) for sy in (-1,1) for sz in (-1,1)]
        low=[min(getattr(q,k) for q in corners) for k in ('x','y','z')]
        high=[max(getattr(q,k) for q in corners) for k in ('x','y','z')]
        if min(high[i]-low[i] for i in range(3))<=EPS:raise ValueError("墙体尺寸无效")
        base=[m*(p+c4d.Vector(sx*r.x,-r.y,sz*r.z)) for sx,sz in ((-1,-1),(1,-1),(1,1),(-1,1))]
        footprints.append([(q.x,q.z) for q in base])
        rects.append((low[0],low[2],high[0],high[2]));tops.append(high[1]);bases.append(low[1])
    # Parent selection owns descendants; don't scan selected children twice.
    for obj in objects:
        parent=obj.GetUp();nested=False
        while parent is not None:
            if any(parent==candidate for candidate in objects):nested=True;break
            parent=parent.GetUp()
        if not nested:visit(obj)
    if cap_groups:
        # Only join material present at the ceiling plane. Door lintels and
        # full-height walls can share a top without sharing a base elevation.
        groups=cap_groups+[(y,[poly]) for poly,y in zip(footprints,tops)]
        top=max(y for y,_ in groups)
        caps=[poly for y,faces in groups if top-y<=.02 for poly in faces]
        # Imported CAD sections can differ by a few thousandths of a cm.
        maps=[]
        for axis in (0,1):
            mapping={};anchor=None
            for v in sorted({p[axis] for poly in caps for p in poly}):
                if anchor is None or v-anchor>.01:anchor=v
                mapping[v]=anchor
            maps.append(mapping)
        caps=[[(maps[0][x],maps[1][z]) for x,z in poly] for poly in caps]
        recognition={}
        if 2<=len(caps)<=100 and orthogonal(caps) and all(len(poly)==4 and len(set(poly))==4 for poly in caps):
            boxes=[(min(x for x,z in poly),min(z for x,z in poly),
                    max(x for x,z in poly),max(z for x,z in poly)) for poly in caps]
            loops=recognize_walls(boxes,recognition)
        else:
            loops=recognize_wall_polygons(caps,len(groups))
        if details is not None:details.update(wall_count=len(groups),inferred=len(caps) in (2,3) or recognition.get('inferred',False))
        return loops,top,top
    if bases and max(bases)-min(bases)>.01:
        raise ValueError("墙体底部标高不一致（可能包含门楣或不同楼层），请用闭合样条指定范围")
    if not footprints:raise ValueError("所选组中没有可识别墙体")
    axis_aligned=orthogonal(footprints)
    # A shared frame also handles disconnected opposing walls rotated as a group.
    inferred=len(footprints) in (2,3)
    recognition={}
    if len(footprints) in (2,3,4):
        first=footprints[0];a,b=first[0],first[1]
        length=math.hypot(b[0]-a[0],b[1]-a[1]);ux,uz=(b[0]-a[0])/length,(b[1]-a[1])/length
        local=[[(x*ux+z*uz,-x*uz+z*ux) for x,z in poly] for poly in footprints]
        if orthogonal(local):
            boxes=[(min(p[0] for p in poly),min(p[1] for p in poly),max(p[0] for p in poly),max(p[1] for p in poly)) for poly in local]
            loops=[[(x*ux-z*uz,x*uz+z*ux) for x,z in loop] for loop in recognize_walls(boxes,recognition)]
        elif inferred:
            raise ValueError('开放墙体的边界不明确，请使用闭合样条指定范围')
        else:
            loops=recognize_wall_polygons(footprints)
    else:
        loops=recognize_walls(rects) if axis_aligned else recognize_wall_polygons(footprints)
    if details is not None:
        details['wall_count']=len(rects)
        details['inferred']=inferred or recognition.get('inferred',False)
    return loops,min(tops),max(tops)
