# -*- coding: utf-8 -*-
import c4d
from c4d import gui, plugins, storage, documents, utils, bitmaps
import os
import sys
import json
import traceback
import re
import math
import shutil
import tempfile
import time
import subprocess
import urllib.request
import urllib.error
import urllib.parse
import webbrowser
import socket
import getpass
import uuid
import hashlib
import platform as py_platform
import datetime
import unicodedata

# ==============================================================================
# 全局配置
# ==============================================================================
LIBRARY_PATH = r"D:\C4D_Auto_Assets" 
FAV_FILE_NAME = "my_favorites.json"
CURRENT_VERSION = "1.2.61"
PLUGIN_DISPLAY_NAME = "花花智能建模-C4D端"
AI_STACK_SAFETY_GAP = 0.2
API_BASE_URL = "http://43.155.144.82"
# 仅本地开发测试时可设 True；正式云端授权测试和发布前必须保持 False。
DEV_DISABLE_AUTH_GATE = False
PLUGIN_CODE = "hh_ai_c4d"
CLIENT_CODE = "c4d_python"
PLUGIN_VERSION = CURRENT_VERSION
ADMIN_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".huahua_c4d_plugin")
ADMIN_CONFIG_FILE = os.path.join(ADMIN_CONFIG_DIR, "config.json")
SHARED_MACHINE_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".huahua_plugin")
SHARED_MACHINE_CONFIG_FILE = os.path.join(SHARED_MACHINE_CONFIG_DIR, "machine_id.json")
DEVICE_ID_SALT = "huahua-c4d-plugin-device-v1"
AUTH_REFRESH_INTERVAL_SECONDS = 10 * 60
HEARTBEAT_INTERVAL_SECONDS = 10 * 60
OFFLINE_GRACE_SECONDS = 24 * 60 * 60
AUTH_REJECT_STATUSES = set([
    "license_disabled",
    "license_expired",
    "expired",
    "disabled",
    "user_disabled",
    "plugin_disabled",
    "device_limit_exceeded",
    "device_limit",
    "session_replaced",
    "machine_replaced",
    "unauthorized",
    "forbidden",
    "no_license",
    "plugin_not_found",
    "token_invalid"
])

# ==============================================================================
# 花花智能建模-C4D端 v1.2.6
# ==============================================================================

def get_machine_id_file_path():
    try:
        if py_platform.system() == "Windows":
            appdata = os.environ.get("APPDATA")
            if appdata:
                return os.path.join(appdata, "HuahuaPlugin", "machine_id.json")
        return SHARED_MACHINE_CONFIG_FILE
    except Exception:
        return SHARED_MACHINE_CONFIG_FILE

def read_machine_id_file():
    path = get_machine_id_file_path()
    try:
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception as e:
        try:
            print("[Admin Auth] 读取公共 machineId 失败: " + str(e))
        except Exception:
            pass
        return {}

def write_machine_id_file(machine_id, created_at=None):
    path = get_machine_id_file_path()
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        data = {
            "machineId": str(machine_id),
            "createdAt": str(created_at or datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z")
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        try:
            print("[Admin Auth] 写入公共 machineId 失败: " + str(e))
        except Exception:
            pass
        return False

def generate_uuid():
    return str(uuid.uuid4())

def get_or_create_machine_id(fallback_machine_id=""):
    data = read_machine_id_file()
    machine_id = str(data.get("machineId") or "").strip()
    created_at = str(data.get("createdAt") or "").strip()
    if machine_id:
        return machine_id
    machine_id = str(fallback_machine_id or "").strip() or generate_uuid()
    write_machine_id_file(machine_id, created_at or None)
    return machine_id

PLUGIN_ID = 1060004 
ADMIN_AUTH_DIALOG_ID = PLUGIN_ID + 101
ADMIN_REGISTER_DIALOG_ID = PLUGIN_ID + 102
ADMIN_REDEEM_CDK_DIALOG_ID = PLUGIN_ID + 103
AI_COLOR_DATA_ID = 10599999 
ID_STORED_JSON_DATA = 1060005 
ID_STORED_SCALE_VAL = 1060006

C4D_EXTRUDE_TYPEID    = 5116
C4D_EXTRUDE_OFFSET_ID = 1009
AI_PT_TO_CM = 0.03527778

ID_SPLINEWRAP = 1019221 # 样条约束变形器ID

# --- UI IDs ---
ID_GRP_MAIN            = 1000
ID_RATIO_LABEL         = 1001
ID_RATIO_COMBO         = 1002
ID_KEEP_LAYER          = 1003
ID_AUTO_CLOSE          = 1004
ID_SMART_STACK         = 1005
ID_SPLINE_PATH         = 1006
ID_SPLINE_BTN          = 1007
ID_TEX_PATH            = 1008
ID_TEX_BTN             = 1009
ID_EXTRUDE_ENABLE      = 1010
ID_EXTRUDE_DEPTH       = 1011
ID_EXTRUDE_SLIDER      = 1012
ID_DELETE_SPLINE       = 1013
ID_IMPORT_BTN          = 1014
ID_CLOSE_BTN           = 1015
ID_CHECK_UPDATE_BTN    = 1093
ID_REPLACE_BTN         = 1019
ID_LOAD_PROGRESS_GROUP = 1040
ID_LOAD_PROGRESS_BAR   = 1041
ID_LOAD_PROGRESS_TEXT  = 1042
ID_IMPORT_TO_NEW_DOC   = 1060 
ID_BEVEL_ENABLE        = 1080
ID_BEVEL_RADIUS        = 1081
ID_Z_STAGGER_ENABLE    = 1082
ID_Z_STEP_VAL          = 1083
ID_SPL_TYPE_COMBO      = 1100
ID_SPL_CLOSE_CHK       = 1101
ID_SPL_INTER_COMBO     = 1102
ID_SPL_SUB_VAL         = 1103

# 亚克力部分 IDs
ID_ACRY_DEPTH_LABEL    = 1104
ID_ACRY_DEPTH_INPUT    = 1105
ID_ACRY_DEPTH_DIR      = 1106
ID_ACRY_SIDE_GROUP     = 1110
ID_ACRY_CHK_T          = 1111
ID_ACRY_CHK_B          = 1112
ID_ACRY_CHK_L          = 1113
ID_ACRY_CHK_R          = 1114
ID_ACRY_SHELL_LABEL    = 1120
ID_ACRY_SHELL_INPUT    = 1121
ID_BTN_ACRY_GENERATE   = 1130

# 广告字工艺 IDs
ID_SIGN_GRP_MAIN       = 5100
ID_SIGN_COLOR          = 5101
ID_SIGN_THICK_F        = 5102
ID_SIGN_THICK_B        = 5103
ID_BTN_SIGN_BACK       = 5104
ID_BTN_SIGN_FRONT      = 5105
ID_BTN_SIGN_CRYSTAL    = 5106
ID_BTN_SIGN_DUAL       = 5107
ID_BTN_OPEN_GROOVE     = 5108

ID_BTN_SMART_MERGE     = 1016 
ID_BTN_SIMPLE_EXTRUDE  = 1027 
ID_BTN_CONNECT_DELETE  = 1017
ID_BTN_APPLY_DEPTH     = 1018
ID_BTN_AXIS_CENTER     = 1020
ID_BTN_APPLY_TEX       = 1021
ID_CAP_SIDE_COMBO      = 1022
ID_BTN_EXTRUDE_FLIP    = 1023
ID_BTN_BAKE_UVW        = 1024
ID_IMPORT_COLOR        = 1025
ID_BTN_APPLY_COLOR_DATA = 1026 
ID_BTN_SEL_HIDDEN      = 1061 
ID_BTN_SEL_TEXTURED    = 1062 
ID_TENSION_VAL         = 1070
ID_BTN_DROP_FLOOR      = 1030 
ID_BTN_STAND_UP        = 1031 
ID_BTN_CENTER_X        = 1032 
ID_BTN_RESET_PSR       = 1033 

ID_MOVE_DIST_VAL       = 1050
ID_BTN_MOV_X_SUB       = 1051 
ID_BTN_MOV_X_ADD       = 1052 
ID_BTN_MOV_Y_SUB       = 1053 
ID_BTN_MOV_Y_ADD       = 1054 
ID_BTN_MOV_Z_SUB       = 1055 
ID_BTN_MOV_Z_ADD       = 1056
ID_GAMMA_CORRECT       = 1090
ID_JSON_WATCH_BTN      = 1091
ID_JSON_WATCH_STATUS   = 1092

ID_ADMIN_GROUP         = 12000
ID_ADMIN_ACCOUNT       = 12001
ID_ADMIN_PASSWORD      = 12002
ID_ADMIN_LOGIN_BTN     = 12003
ID_ADMIN_LOGOUT_BTN    = 12004
ID_ADMIN_RELOGIN_BTN   = 12005
ID_ADMIN_BACKEND_TEXT  = 12006
ID_ADMIN_USER_TEXT     = 12007
ID_ADMIN_LICENSE_TEXT  = 12008
ID_ADMIN_PLAN_TEXT     = 12009
ID_ADMIN_DEVICE_TEXT   = 12010
ID_ADMIN_MESSAGE_TEXT  = 12011
ID_ADMIN_UPDATE_TEXT   = 12012
ID_ADMIN_OPEN_DIALOG_BTN = 12013
ID_ADMIN_REMAINING_TEXT  = 12014
ID_ADMIN_AUTH_TITLE_TEXT = 12015
ID_ADMIN_AUTH_CLOSE_BTN  = 12016
ID_ADMIN_REGISTER_OPEN_BTN = 12017
ID_ADMIN_REGISTER_EMAIL = 12018
ID_ADMIN_REGISTER_PASSWORD = 12019
ID_ADMIN_REGISTER_PASSWORD_CONFIRM = 12020
ID_ADMIN_REGISTER_NICKNAME = 12021
ID_ADMIN_REGISTER_SUBMIT_BTN = 12022
ID_ADMIN_REGISTER_CANCEL_BTN = 12023
ID_ADMIN_MACHINE_TEXT = 12024
ID_ADMIN_REDEEM_OPEN_BTN = 12025
ID_ADMIN_CDK_CODE = 12026
ID_ADMIN_CDK_SUBMIT_BTN = 12027
ID_ADMIN_CDK_CANCEL_BTN = 12028
ID_ADMIN_CDK_STATUS_TEXT = 12029

JSON_WATCH_INTERVAL_MS = 2000
JSON_WATCH_PREF_PATH   = 1

# Tab IDs
ID_TAB_MAIN            = 9000
ID_TAB_GRP_BASIC       = 9001
ID_TAB_GRP_ALIGN       = 9002
ID_TAB_GRP_SCENE       = 9003
ID_TAB_GRP_ACRYLIC     = 9004
ID_TAB_GRP_SMART_SCENE = 9005 
ID_TAB_GRP_ASSETS      = 9006 

# --- Asset Manager IDs ---
ID_ASSET_USER_AREA   = 20001
ID_ASSET_SLIDER_SIZE = 20002
ID_ASSET_BTN_REFRESH = 20003
ID_ASSET_SCROLL_GRP  = 20004
ID_ASSET_BTN_LOAD    = 20005
ID_ASSET_CHK_SIZE    = 20007 
ID_ASSET_TXT_SEARCH  = 20008
ID_ASSET_CHK_ONLY_FAV= 20009
ID_ASSET_PATH_TEXT   = 20010
ID_ASSET_BTN_CHOOSE_DIR = 20011
ID_ASSET_BTN_OPEN_DIR   = 20012
ID_ASSET_COUNT_TEXT  = 20013

# --- Scene Generator IDs ---
ID_BTN_GEN_CEILING     = 21001
ID_BTN_GEN_SMART_ROOM  = 21002 
ID_CURVED_WALL_MODE    = 21003 
ID_BTN_CURVED_WALL     = 21004
ID_STAIR_HEIGHT       = 21005
ID_STAIR_DEPTH        = 21006
ID_STAIR_WIDTH        = 21007
ID_STAIR_COUNT        = 21008
ID_BTN_GEN_STAIRS     = 21009
ID_STAIR_FORM         = 21010
ID_STAIR_FLIGHT       = 21011
ID_STAIR_LANDING      = 21012
ID_STAIR_TURN         = 21013
ID_STAIR_GAP          = 21014
ID_STAIR_ADD          = 21015
ID_STAIR_REMOVE       = 21016
ID_OPENING_PRESET     = 21017
ID_OPENING_PLANE      = 21018
ID_OPENING_WIDTH      = 21019
ID_OPENING_HEIGHT     = 21020
ID_OPENING_DEPTH      = 21021
ID_OPENING_USE_SELECTION = 21022
ID_BTN_GEN_OPENING    = 21023
ID_OPENING_PREVIEW    = 21024
ID_OPENING_NEW_MATERIALS = 21025
ID_STAIR_FLOOR_MODE   = 21026
ID_STAIR_FLOORS       = 21027
ID_STAIR_STOREY_HEIGHT = 21028
ID_ROOM_CEILING_PREVIEW = 21030
ID_ROOM_CEILING_GENERATE = 21031
ID_ROOM_CEILING_STATUS = 21032
# These ordered fields are also the saved generator's parameter contract.
ROOM_CEILING_FIELDS = (
    (21033, "吊顶类型", "choice", 0, 0, 3),
    (21034, "吊顶底面标高 (cm)", "real", 280.0, -1000000, 1000000),
    (21035, "离墙间隙 (cm)", "real", 1.0, 0, 10000),
    (21036, "方通宽度 (cm)", "real", 5.0, .01, 10000),
    (21037, "方通高度 (cm)", "real", 10.0, .01, 10000),
    (21038, "方通净间距 (cm)", "real", 5.0, 0, 10000),
    (21039, "方通方向 (度)", "real", 0.0, -360, 360),
    (21040, "排列偏移 (cm)", "real", 0.0, -10000, 10000),
    (21041, "平顶 / 方格板厚度 (cm)", "real", 1.2, .01, 10000),
    (21042, "生成周边收口", "bool", True, 0, 1),
    (21043, "收口宽度 (cm)", "real", 3.0, .01, 10000),
    (21044, "方格横向模数 (cm)", "real", 60.0, 1, 10000),
    (21045, "方格纵向模数 (cm)", "real", 60.0, 1, 10000),
    (21046, "龙骨分缝宽度 (cm)", "real", .8, .01, 1000),
    (21047, "方格横向偏移 (cm)", "real", 0.0, -10000, 10000),
    (21048, "方格纵向偏移 (cm)", "real", 0.0, -10000, 10000),
    (21049, "铝方通顶部封板", "bool", True, 0, 1),
    (21050, "顶部封板厚度 (cm)", "real", 1.2, .1, 1000),
    (21051, "周边射灯", "bool", False, 0, 1),
    (21052, "射灯间距 (cm)", "real", 120.0, 10, 10000),
    (21053, "周边灯带板宽度 (cm)", "real", 24.0, 5, 1000),
    (21054, "射灯外径 (cm)", "real", 8.0, 2, 100),
    (21055, "方通间长条灯", "bool", False, 0, 1),
    (21056, "长条灯每隔几排", "integer", 6, 1, 100),
    (21057, "长条灯宽度 (cm)", "real", 3.0, .5, 100),
    (21058, "长条灯灯体高度 (cm)", "real", 2.0, .5, 100),
    (21059, "启用射灯光源", "bool", False, 0, 1),
    (21060, "射灯亮度 (%)", "real", 100.0, 0, 1000),
    (21061, "长条灯长度 (cm，0 为自动)", "real", 0.0, 0, 100000),
    (21062, "长条灯长度方向偏移 (cm)", "real", 0.0, -100000, 100000),
    (21063, "每行长条灯数量", "integer", 1, 1, 50),
    (21064, "长条灯段间距 (cm)", "real", 30.0, 0, 10000),
    (21065, "射灯纵向间距 (cm)", "real", 120.0, 10, 10000),
    (21066, "射灯离边距离 (cm)", "real", 30.0, 0, 10000),
    (21067, "射灯横向偏移 (cm)", "real", 0.0, -10000, 10000),
    (21068, "射灯纵向偏移 (cm)", "real", 0.0, -10000, 10000),
    (21069, "方格发光灯板", "bool", True, 0, 1),
    (21070, "灯板每隔几列", "integer", 3, 1, 100),
    (21071, "灯板每隔几行", "integer", 3, 1, 100),
    (21072, "灯板列偏移 (格)", "integer", 1, 0, 100),
    (21073, "灯板行偏移 (格)", "integer", 1, 0, 100),
    (21074, "跌级边顶宽度 (cm)", "real", 50.0, 10, 1000),
    (21075, "中央抬高高度 (cm)", "real", 18.0, 2, 200),
    (21076, "环形灯槽", "bool", True, 0, 1),
    (21077, "内藏灯槽宽度 (cm)", "real", 18.0, 4, 100),
    (21078, "中央横向灯带", "bool", True, 0, 1),
    (21079, "中央灯带间距 (cm)", "real", 120.0, 10, 10000),
    (21080, "中央灯带宽度 (cm)", "real", 5.0, .5, 50),
    (21081, "中央灯带方向 (度)", "real", 0.0, -360, 360),
    (21082, "两侧线性风口", "bool", True, 0, 1),
    (21083, "风口宽度 (cm)", "real", 10.0, 2, 100),
    (21084, "风口离墙距离 (cm)", "real", 30.0, 2, 1000),
    (21085, "风口格栅条数", "integer", 4, 2, 12),
    (21086, "灯槽挡光沿高度 (cm)", "real", 6.0, 1, 100),
    (21087, "启用灯槽光源", "bool", True, 0, 1),
    (21088, "灯槽光源亮度 (%)", "real", 300.0, 0, 1000),
    (21089, "中央灯带长度 (cm，0=通长)", "real", 0.0, 0, 100000),
    (21090, "中央灯带沿长度偏移 (cm)", "real", 0.0, -100000, 100000),
)

OPENING_PRESETS = ("双扇推拉窗", "四扇推拉窗", "双扇推拉窗 + 上亮",
                   "四扇推拉窗 + 上亮", "白色单开门", "白色双开门", "木色双开门",
                   "窄玻璃单开门", "窄玻璃子母门", "窄玻璃双开门",
                   "玻璃双开门 + 上亮", "玻璃双开门 + 侧固定玻璃 + 上亮",
                   "玻璃单开门 + 侧固定玻璃 + 上亮", "消火栓组合柜（上下玻璃门）",
                   "消火栓单格柜（玻璃门）", "消火栓单格柜（红色铁皮门）",
                   "消火栓组合柜（上下铁皮门）")

def GetOpeningDefaultSize(preset):
    return ((120.0,150.0),(240.0,150.0),(120.0,150.0),(240.0,150.0),
            (90.0,260.0),(160.0,260.0),(160.0,260.0),(100.0,220.0),
            (140.0,220.0),(180.0,220.0),(180.0,260.0),(280.0,260.0),
            (140.0,240.0),(80.0,200.0),(80.0,140.0),(80.0,140.0),(80.0,200.0))[preset]

def GetOpeningMaterialSpecs(preset):
    if preset in (13,14,15,16):
        return (("消防柜金属五金",(.48,.5,.52)),("消防柜白色门框",(.88,.89,.87)),
                ("消防柜红色烤漆",(.62,.015,.02)),("消防柜透明玻璃",(.95,.98,1.0)),
                ("消防柜密封条",(.025,.025,.025)),("消防柜水带织物",(.78,.75,.65)),
                ("消防柜红色标识",(.95,.025,.02)))
    return (("深灰铝合金",(.08,.085,.09)),("白色门饰面",(.85,.84,.81)),
            ("木色门饰面",(.48,.32,.18)),("玻璃",(.82,.9,.93)),("五金 / 密封条",(.035,.035,.035)))

# --- Super Align IDs ---
ID_BTN_NW = 4101; ID_BTN_N = 4102; ID_BTN_NE = 4103
ID_BTN_W = 4104; ID_BTN_C = 4105; ID_BTN_E = 4106
ID_BTN_SW = 4107; ID_BTN_S = 4108; ID_BTN_SE = 4109
ID_BTN_Z_FRONT = 4110; ID_BTN_Z_MID = 4111; ID_BTN_Z_BACK = 4112
ID_CHK_SURFACE_MODE = 4113
ID_BTN_RAY_UP = 4114; ID_BTN_RAY_DOWN = 4115
ID_BTN_RAY_LEFT = 4116; ID_BTN_RAY_RIGHT = 4117
ID_BTN_RAY_FRONT = 4118; ID_BTN_RAY_BACK = 4119
RAYCAST_MAX_DISTANCE = 20000.0

# --- 全方位轴心工具 IDs ---
ID_AXIS_TL = 4201; ID_AXIS_TC = 4202; ID_AXIS_TR = 4203 
ID_AXIS_ML = 4204; ID_AXIS_MC = 4205; ID_AXIS_MR = 4206 
ID_AXIS_BL = 4207; ID_AXIS_BC = 4208; ID_AXIS_BR = 4209 
ID_AXIS_RADIO_Z = 4210
ID_AXIS_Z_FRONT = 4211; ID_AXIS_Z_MID = 4212; ID_AXIS_Z_BACK = 4213

EXTRUDE_NAME_PREFIX = "AI_Extrude_"
SPLINE_NAME_PREFIX  = "AI_Path_"
LAYER_NULL_PREFIX   = "AI_Layer_"
GROUP_NULL_PREFIX   = "AI_Group_"

CORE_BUTTON_IDS = [
    ID_IMPORT_BTN, ID_REPLACE_BTN, ID_JSON_WATCH_BTN,
    ID_BTN_RAY_UP, ID_BTN_RAY_DOWN, ID_BTN_RAY_LEFT, ID_BTN_RAY_RIGHT, ID_BTN_RAY_FRONT, ID_BTN_RAY_BACK,
    ID_BTN_SMART_MERGE, ID_BTN_SIMPLE_EXTRUDE, ID_BTN_CONNECT_DELETE, ID_BTN_AXIS_CENTER,
    ID_BTN_APPLY_TEX, ID_BTN_APPLY_DEPTH, ID_BTN_BAKE_UVW,
    ID_BTN_ACRY_GENERATE, ID_BTN_SIGN_BACK, ID_BTN_SIGN_FRONT, ID_BTN_SIGN_CRYSTAL, ID_BTN_SIGN_DUAL,
    ID_BTN_OPEN_GROOVE, ID_BTN_GEN_CEILING, ID_BTN_GEN_SMART_ROOM, ID_BTN_CURVED_WALL,
    ID_ROOM_CEILING_PREVIEW, ID_ROOM_CEILING_GENERATE,
    ID_BTN_GEN_STAIRS, ID_STAIR_ADD, ID_STAIR_REMOVE, ID_BTN_GEN_OPENING
]

# ==============================================================================
# Helper Functions (Global)
# ==============================================================================
def CenterAxis(obj):
    if not obj: return
    points = obj.GetAllPoints()
    if not points: return
    min_x = min([p.x for p in points])
    max_x = max([p.x for p in points])
    min_y = min([p.y for p in points])
    max_y = max([p.y for p in points])
    min_z = min([p.z for p in points])
    max_z = max([p.z for p in points])
    center = c4d.Vector((min_x+max_x)*0.5, (min_y+max_y)*0.5, (min_z+max_z)*0.5)
    if center.GetLength() < 0.001: return
    mg = obj.GetMg()
    new_axis_world_pos = mg * center
    new_points = [p - center for p in points]
    obj.SetAllPoints(new_points)
    obj.Message(c4d.MSG_UPDATE)
    mg.off = new_axis_world_pos
    obj.SetMg(mg)

def RecenterGroupAxis(group_null):
    if not group_null: return
    all_points_global =[]
    def collect_points(op):
        if not op: return
        mg = op.GetMg()
        if op.CheckType(c4d.Opoint):
            pts = op.GetAllPoints()
            for p in pts:
                all_points_global.append(mg * p)
        child = op.GetDown()
        while child:
            collect_points(child)
            child = child.GetNext()
    collect_points(group_null)
    if not all_points_global: return
    min_x = min_y = min_z = float('inf')
    max_x = max_y = max_z = float('-inf')
    for p in all_points_global:
        if p.x < min_x: min_x = p.x
        if p.x > max_x: max_x = p.x
        if p.y < min_y: min_y = p.y
        if p.y > max_y: max_y = p.y
        if p.z < min_z: min_z = p.z
        if p.z > max_z: max_z = p.z
    center_global = c4d.Vector((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, (min_z + max_z) * 0.5)
    doc = documents.GetActiveDocument()
    if doc: doc.AddUndo(c4d.UNDOTYPE_CHANGE, group_null)
    old_mg = group_null.GetMg()
    new_mg = c4d.Matrix(old_mg)
    new_mg.off = center_global
    children = group_null.GetChildren()
    child_mgs = [child.GetMg() for child in children]
    group_null.SetMg(new_mg)
    for child, mg in zip(children, child_mgs):
        if doc: doc.AddUndo(c4d.UNDOTYPE_CHANGE, child)
        child.SetMg(mg)

def GetSplineSegmentBoxes(spline_obj):
    points = spline_obj.GetAllPoints()
    if not points: return[]
    mg = spline_obj.GetMg()
    seg_count = spline_obj.GetSegmentCount()
    if seg_count <= 0: 
        bb = GetSplineGlobalAABB(spline_obj)
        return [bb] if bb else []
    boxes =[]
    p_idx = 0
    for i in range(seg_count):
        cnt = spline_obj.GetSegment(i)['cnt']
        if cnt < 1: continue
        seg_points = points[p_idx : p_idx+cnt]
        p_idx += cnt
        if cnt < 2: continue
        min_x = float('inf'); max_x = float('-inf')
        min_y = float('inf'); max_y = float('-inf')
        for p in seg_points:
            gp = mg * p
            if gp.x < min_x: min_x = gp.x
            if gp.x > max_x: max_x = gp.x
            if gp.y < min_y: min_y = gp.y
            if gp.y > max_y: max_y = gp.y
        boxes.append((min_x, max_x, min_y, max_y))
    return boxes

def GetSplineGlobalAABB(spline_obj):
    points = spline_obj.GetAllPoints()
    if not points: return None
    mg = spline_obj.GetMg()
    min_x = float('inf'); max_x = float('-inf')
    min_y = float('inf'); max_y = float('-inf')
    for p in points:
        gp = mg * p 
        if gp.x < min_x: min_x = gp.x
        if gp.x > max_x: max_x = gp.x
        if gp.y < min_y: min_y = gp.y
        if gp.y > max_y: max_y = gp.y
    return (min_x, max_x, min_y, max_y)

def RayCastPolygon(x, y, poly_points):
    inside = False
    n = len(poly_points)
    p1x, p1y = poly_points[0].x, poly_points[0].y
    for i in range(n + 1):
        p2x, p2y = poly_points[i % n].x, poly_points[i % n].y
        if y > min(p1y, p2y):
            if y <= max(p1y, p2y):
                if x <= max(p1x, p2x):
                    if p1y != p2y:
                        xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                    if p1x == p2x or x <= xinters:
                        inside = not inside
        p1x, p1y = p2x, p2y
    return inside

def IsPointInSpline(check_x, check_y, spline_obj):
    if not spline_obj: return False
    mg = spline_obj.GetMg()
    all_points = spline_obj.GetAllPoints()
    seg_count = spline_obj.GetSegmentCount()
    
    if seg_count == 0:
        if not all_points: return False
        points = [mg * p for p in all_points]
        return RayCastPolygon(check_x, check_y, points)
    
    current_pt_index = 0
    hit_count = 0
    for i in range(seg_count):
        cnt = spline_obj.GetSegment(i)['cnt']
        if cnt < 3: 
            current_pt_index += cnt
            continue
        segment_points_local = all_points[current_pt_index : current_pt_index + cnt]
        current_pt_index += cnt
        segment_points_world = [mg * p for p in segment_points_local]
        if RayCastPolygon(check_x, check_y, segment_points_world):
            hit_count += 1
            
    return (hit_count % 2 == 1)

def CheckSplineOverlapHybrid(source_spline, target_spline):
    if not source_spline or not target_spline: return False
    bb_s = GetSplineGlobalAABB(source_spline)
    bb_t = GetSplineGlobalAABB(target_spline)
    if not bb_s or not bb_t: return False
    shrink = 0.05
    s_min_x, s_max_x, s_min_y, s_max_y = bb_s
    t_min_x, t_max_x, t_min_y, t_max_y = bb_t
    if (s_max_x - s_min_x) > 0.2: s_min_x += shrink; s_max_x -= shrink
    if (s_max_y - s_min_y) > 0.2: s_min_y += shrink; s_max_y -= shrink
    if (t_max_x - t_min_x) > 0.2: t_min_x += shrink; t_max_x -= shrink
    if (t_max_y - t_min_y) > 0.2: t_min_y += shrink; t_max_y -= shrink
    if s_max_x <= t_min_x or s_min_x >= t_max_x: return False
    if s_max_y <= t_min_y or s_min_y >= t_max_y: return False

    min_x, max_x, min_y, max_y = bb_s
    w = max_x - min_x
    h = max_y - min_y
    if w <= 0.001 or h <= 0.001: return False
    
    sample_res = 32
    step_x = w / float(sample_res)
    step_y = h / float(sample_res)
    start_x = min_x + step_x * 0.5
    start_y = min_y + step_y * 0.5
    if step_x < 0.005: step_x = 0.005
    if step_y < 0.005: step_y = 0.005

    valid_source_points = 0
    hits_in_target = 0
    for i in range(sample_res):
        for j in range(sample_res):
            px = start_x + i * step_x
            py = start_y + j * step_y
            if IsPointInSpline(px, py, source_spline):
                valid_source_points += 1
                if IsPointInSpline(px, py, target_spline):
                    hits_in_target += 1
    
    area_ratio = 0.0
    if valid_source_points > 0: area_ratio = float(hits_in_target) / float(valid_source_points)
    if area_ratio > 0.30: return True 

    real_points = source_spline.GetAllPoints()
    total_pts = len(real_points)
    if total_pts == 0: return False
    step_v = 1
    if total_pts > 80: step_v = int(total_pts / 40)
    mg = source_spline.GetMg()
    checked_v = 0
    hits_v = 0
    for k in range(0, total_pts, step_v):
        pt_world = mg * real_points[k]
        checked_v += 1
        if IsPointInSpline(pt_world.x, pt_world.y, target_spline): hits_v += 1
            
    if checked_v == 0: return False
    if float(hits_v) / float(checked_v) > 0.85: return True
    return False

FIT_CMD_ID = None
def FindFitToObjectCommand():
    global FIT_CMD_ID
    if FIT_CMD_ID is not None: return FIT_CMD_ID
    for cid in range(1000, 200000):
        name = c4d.GetCommandName(cid)
        if not name: continue
        if ("Fit to Object" in name) or (u"适合对象" in name):
            FIT_CMD_ID = cid
            return FIT_CMD_ID
    return 100004766 

def BatchFitTextureTags(doc, obj_tag_pairs):
    if not obj_tag_pairs: return
    cmd_id = FindFitToObjectCommand()
    c4d.CallCommand(12113) 
    has_items = False
    for obj, tag in obj_tag_pairs:
        if not obj or not tag or not tag.IsAlive(): continue
        obj.SetBit(c4d.BIT_ACTIVE)
        tag.SetBit(c4d.BIT_ACTIVE)
        has_items = True
    if has_items and c4d.IsCommandEnabled(cmd_id):
        c4d.CallCommand(cmd_id)
    c4d.CallCommand(12113)

# ==============================================================================
# 建模辅助函数
# ==============================================================================
def SetupSplineParams(spline):
    if not spline or not spline.CheckType(c4d.Ospline): return
    spline[c4d.SPLINEOBJECT_TYPE] = c4d.SPLINETYPE_BEZIER
    spline[c4d.SPLINEOBJECT_CLOSED] = True
    spline[c4d.SPLINEOBJECT_INTERPOLATION] = c4d.SPLINEOBJECT_INTERPOLATION_ADAPTIVE
    spline[c4d.SPLINEOBJECT_ANGLE] = utils.Rad(5.0)
    spline[c4d.SPLINEOBJECT_MAXIMUMLENGTH] = 5.0
    spline.Message(c4d.MSG_UPDATE)

def GetPolyNormal(obj, poly):
    pts = obj.GetAllPoints()
    return (pts[poly.b]-pts[poly.a]).Cross(pts[poly.c]-pts[poly.a]).GetNormalized()

def CreateOrGetTransparentMaterial(doc):
    for m in doc.GetMaterials() or[]:
        if m.GetName() == "Acrylic_Transparent": return m
    mat = c4d.BaseMaterial(c4d.Mmaterial)
    mat.SetName("Acrylic_Transparent")
    mat[c4d.MATERIAL_USE_COLOR] = False
    mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(1.0, 1.0, 1.0)
    mat[c4d.MATERIAL_USE_TRANSPARENCY] = True
    mat[c4d.MATERIAL_TRANSPARENCY_BRIGHTNESS] = 1.0
    if hasattr(c4d, "MATERIAL_TRANSPARENCY_REFRACTION"):
        mat[c4d.MATERIAL_TRANSPARENCY_REFRACTION] = 1.49 
    doc.InsertMaterial(mat)
    doc.AddUndo(c4d.UNDOTYPE_NEW, mat)
    return mat

def ProcessOneSpline(doc, spline, target_depth, side_cfg, shell_thickness):
    if not spline or not spline.CheckType(c4d.Ospline): return None
    extrude = c4d.BaseObject(5116)
    extrude.SetName("Standard_Base")
    if hasattr(c4d, "EXTRUDEOBJECT_DIRECTION"): extrude[c4d.EXTRUDEOBJECT_DIRECTION] = 3 
    extrude[c4d.EXTRUDEOBJECT_MOVE] = c4d.Vector(0, 0, -abs(float(target_depth)))
    try: extrude[C4D_EXTRUDE_OFFSET_ID] = -abs(float(target_depth))
    except: pass
    
    doc.InsertObject(extrude, pred=spline)
    doc.AddUndo(c4d.UNDOTYPE_NEW, extrude)
    extrude.SetMg(spline.GetMg())
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, spline)
    spline.Remove()
    spline.InsertUnder(extrude)
    spline.SetMl(c4d.Matrix())
    doc.SetActiveObject(extrude, c4d.SELECTION_NEW)
    c4d.CallCommand(12236)
    new_op = doc.GetActiveObject()
    if not new_op or not new_op.CheckType(c4d.Opolygon): return None

    tags = new_op.GetTags()
    c1_tag = next((t for t in tags if t.CheckType(c4d.Tpolygonselection) and t.GetName() == "C1"), None)
    if c1_tag:
        bs = new_op.GetPolygonS()
        bs.DeselectAll()
        c1_tag.GetBaseSelect().CopyTo(bs)
        bc_del_c1 = c4d.BaseContainer()
        utils.SendModelingCommand(c4d.MCOMMAND_DELETE, [new_op], c4d.MODELINGCOMMANDMODE_POLYGONSELECTION, bc_del_c1, doc)
        c1_tag.Remove()
        utils.SendModelingCommand(c4d.MCOMMAND_OPTIMIZE, [new_op], c4d.MODELINGCOMMANDMODE_ALL, c4d.BaseContainer(), doc)

    if not side_cfg["skip"]:
        polys = new_op.GetAllPolygons()
        pts = new_op.GetAllPoints()
        bs_del = c4d.BaseSelect()
        center = new_op.GetMp()
        rad = new_op.GetRad()
        min_x, max_x = center.x - rad.x, center.x + rad.x
        min_y, max_y = center.y - rad.y, center.y + rad.y
        total_h, total_w = max_y - min_y, max_x - min_x
        band_y, band_x = total_h * 0.30, total_w * 0.30
        top_start, bottom_end = max_y - band_y, min_y + band_y
        left_end, right_start = min_x + band_x, max_x - band_x

        for i, p in enumerate(polys):
            pa, pb, pc, pd = pts[p.a], pts[p.b], pts[p.c], pts[p.d]
            poly_center = (pa + pb + pc + pd) * 0.25
            n = GetPolyNormal(new_op, p)
            is_cap = abs(n.z) > 0.9
            del_flag = False
            if side_cfg["dt"] and poly_center.y >= top_start: del_flag = True
            if side_cfg["db"] and poly_center.y <= bottom_end: del_flag = True
            if side_cfg["dl"] and poly_center.x <= left_end: del_flag = True
            if side_cfg["dr"] and poly_center.x >= right_start: del_flag = True
            if del_flag and not is_cap: bs_del.Select(i)

        if bs_del.GetCount() > 0:
            bs = new_op.GetPolygonS()
            bs.DeselectAll()
            bs_del.CopyTo(bs)
            utils.SendModelingCommand(c4d.MCOMMAND_DELETE, [new_op], c4d.MODELINGCOMMANDMODE_POLYGONSELECTION, c4d.BaseContainer(), doc)
            utils.SendModelingCommand(c4d.MCOMMAND_OPTIMIZE,[new_op], c4d.MODELINGCOMMANDMODE_ALL, c4d.BaseContainer(), doc)

    if shell_thickness is not None and shell_thickness > 0.0:
        target_obj = new_op
        if target_obj.CheckType(c4d.Opolygon):
            bs = target_obj.GetPolygonS()
            bs.DeselectAll()
            for i in range(target_obj.GetPolygonCount()): bs.Select(i)
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, target_obj)
            bc_ex = c4d.BaseContainer()
            bc_ex[c4d.MDATA_EXTRUDE_OFFSET] = shell_thickness
            bc_ex[c4d.MDATA_EXTRUDE_PRESERVEGROUPS] = True
            bc_ex[c4d.MDATA_EXTRUDE_ANGLE] = utils.Rad(180.0)
            if hasattr(c4d, "MDATA_EXTRUDE_CREATECAPS"): bc_ex[c4d.MDATA_EXTRUDE_CREATECAPS] = True
            utils.SendModelingCommand(c4d.ID_MODELING_EXTRUDE_TOOL,[target_obj], c4d.MODELINGCOMMANDMODE_POLYGONSELECTION, bc_ex, doc, c4d.MODELINGCOMMANDFLAGS_CREATEUNDO)
    return new_op

def RunGenerate(target_depth, side_cfg, shell_thickness):
    doc = c4d.documents.GetActiveDocument()
    c4d.CallCommand(16768) 
    c4d.EventAdd()
    op = doc.GetActiveObject()
    if not op:
        gui.MessageDialog("未选中对象，或合并失败。")
        return
    doc.StartUndo()
    
    targets =[]
    if op.CheckType(c4d.Ospline) and op.GetSegmentCount() > 1:
        utils.SendModelingCommand(c4d.MCOMMAND_EXPLODESEGMENTS, list=[op], mode=c4d.MODELINGCOMMANDMODE_ALL, doc=doc)
        c4d.EventAdd()
        group_null = doc.GetActiveObject()
        if group_null and group_null.GetDown():
            targets = group_null.GetChildren()
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, group_null)
    else:
        targets = [op]
        
    for t_obj in targets:
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, t_obj)
        if t_obj.CheckType(c4d.Ospline): SetupSplineParams(t_obj)
        poly = ProcessOneSpline(doc, t_obj, target_depth, side_cfg, shell_thickness)
        if poly and poly.CheckType(c4d.Opolygon):
            mat = CreateOrGetTransparentMaterial(doc)
            if mat:
                tex = c4d.BaseTag(c4d.Ttexture)
                tex[c4d.TEXTURETAG_MATERIAL] = mat
                poly.InsertTag(tex)
                doc.AddUndo(c4d.UNDOTYPE_NEW, tex)
    doc.EndUndo()
    c4d.EventAdd()

# ==============================================================================
# 花花智能建模-C4D端 v1.1 - 广告字工艺核心逻辑
# ==============================================================================
def Signage_GetObjColor(obj, default_color):
    if not obj: return default_color
    tags = obj.GetTags()
    for t in tags:
        if t.CheckType(c4d.Ttexture):
            mat = t.GetMaterial()
            if mat and mat[c4d.MATERIAL_USE_COLOR]:
                return mat[c4d.MATERIAL_COLOR_COLOR]
    if obj[c4d.ID_BASEOBJECT_USECOLOR] > 0:
        return obj[c4d.ID_BASEOBJECT_COLOR]
    return default_color

def Signage_CreateMat(doc, name, color, type_mode):
    col_suffix = f"{int(color.x*255)}_{int(color.y*255)}_{int(color.z*255)}"
    if type_mode == 2: mat_name = "Mat_Crystal_Clear" 
    elif type_mode == 1 and name == "Back_Light": mat_name = "Mat_Light_White"   
    elif type_mode == 3 and name == "Case_Metal": mat_name = "Mat_Case_Dark"     
    else: mat_name = f"Mat_{name}_{col_suffix}"

    mat = doc.SearchMaterial(mat_name)
    if mat: return mat
    
    mat = c4d.BaseMaterial(c4d.Mmaterial)
    mat.SetName(mat_name)
    vec_col = c4d.Vector(color.x, color.y, color.z)
    
    if type_mode == 0: # 面板
        mat[c4d.MATERIAL_USE_COLOR] = True
        mat[c4d.MATERIAL_COLOR_COLOR] = vec_col
        mat[c4d.MATERIAL_USE_REFLECTION] = True
    elif type_mode == 1: # 发光
        mat[c4d.MATERIAL_USE_COLOR] = False
        mat[c4d.MATERIAL_USE_LUMINANCE] = True
        if name == "Back_Light": mat[c4d.MATERIAL_LUMINANCE_COLOR] = c4d.Vector(1,1,1)
        else: mat[c4d.MATERIAL_LUMINANCE_COLOR] = vec_col
        mat[c4d.MATERIAL_LUMINANCE_BRIGHTNESS] = 1.5
    elif type_mode == 2: # 透明
        mat[c4d.MATERIAL_USE_COLOR] = False
        mat[c4d.MATERIAL_USE_TRANSPARENCY] = True
        mat[c4d.MATERIAL_TRANSPARENCY_BRIGHTNESS] = 0.95
        mat[c4d.MATERIAL_TRANSPARENCY_REFRACTION] = 1.49
        mat[c4d.MATERIAL_USE_REFLECTION] = True
    elif type_mode == 3: # 金属
        mat[c4d.MATERIAL_USE_COLOR] = True
        if name == "Shell_Metal": mat[c4d.MATERIAL_COLOR_COLOR] = vec_col
        else: mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(0.2, 0.2, 0.2)
        mat[c4d.MATERIAL_USE_REFLECTION] = True
    
    doc.InsertMaterial(mat)
    return mat

def Signage_SetupExtrude(extrude_obj, depth_val):
    if hasattr(c4d, "EXTRUDEOBJECT_DIRECTION"): extrude_obj[c4d.EXTRUDEOBJECT_DIRECTION] = 3
    else:
        try: extrude_obj[2003] = 3 
        except: pass
    neg_depth = -abs(float(depth_val))
    if hasattr(c4d, "EXTRUDEOBJECT_MOVE"): extrude_obj[c4d.EXTRUDEOBJECT_MOVE] = c4d.Vector(0, 0, neg_depth)
    offset_id = 1009
    try: extrude_obj[offset_id] = neg_depth
    except: pass

def Signage_FindSpline(obj):
    if not obj: return None
    if obj.CheckType(c4d.Ospline): return obj
    child = obj.GetDown()
    while child:
        res = Signage_FindSpline(child)
        if res: return res
        child = child.GetNext()
    return None

def Signage_GetTargets(doc):
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
    targets =[]
    for obj in sel:
        data = {'spline': None, 'parent': None, 'mg': obj.GetMg(), 'origin_obj': obj}
        if obj.CheckType(c4d.Ospline):
            data['spline'] = obj
            targets.append(data)
        else:
            found_spline = Signage_FindSpline(obj)
            if found_spline:
                data['spline'] = found_spline
                data['parent'] = obj
                targets.append(data)
    return targets

def Signage_Finalize(doc, new_obj, target_data):
    parent_to_delete = target_data['parent']
    if parent_to_delete:
        doc.InsertObject(new_obj, pred=parent_to_delete)
        new_obj.SetMg(target_data['mg']) # 【关键修复】放入层级后再赋予世界坐标
        doc.AddUndo(c4d.UNDOTYPE_DELETE, parent_to_delete)
        parent_to_delete.Remove()
    else:
        ref_spline = target_data['spline']
        doc.InsertObject(new_obj, pred=ref_spline)
        new_obj.SetMg(target_data['mg']) # 【关键修复】放入层级后再赋予世界坐标
    doc.AddUndo(c4d.UNDOTYPE_NEW, new_obj)

def Gen_Backlit(doc, data_list, front_val, back_val, default_color):
    mat_shell = Signage_CreateMat(doc, "Metal_Shell", default_color, 3) 
    mat_light = Signage_CreateMat(doc, "Back_Light", c4d.Vector(1,1,1), 1)
    for data in data_list:
        sp = data['spline']
        use_col = Signage_GetObjColor(data['origin_obj'], default_color)
        mat_shell = Signage_CreateMat(doc, "Shell_Metal", use_col, 3)
        root = c4d.BaseObject(c4d.Onull); root.SetName(f"BackLit_{sp.GetName()}")
        
        shell = c4d.BaseObject(c4d.Oextrude); shell.SetName("1_Shell_Metal")
        shell.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_val)))) 
        Signage_SetupExtrude(shell, front_val)
        sp_shell = sp.GetClone(); sp_shell.InsertUnder(shell); sp_shell.SetMl(c4d.Matrix())
        t1 = shell.MakeTag(c4d.Ttexture); t1.SetMaterial(mat_shell)
        shell.InsertUnder(root)
        
        light = c4d.BaseObject(c4d.Oextrude); light.SetName("2_Back_Light")
        light.SetAbsPos(c4d.Vector(0, 0, 0)) 
        Signage_SetupExtrude(light, back_val)
        sp_light = sp.GetClone(); sp_light.InsertUnder(light); sp_light.SetMl(c4d.Matrix())
        t2 = light.MakeTag(c4d.Ttexture); t2.SetMaterial(mat_light)
        light.InsertUnder(root)
        Signage_Finalize(doc, root, data)

def Gen_Frontlit(doc, data_list, front_val, back_val, default_color):
    for data in data_list:
        sp = data['spline']
        use_col = Signage_GetObjColor(data['origin_obj'], default_color)
        mat_face = Signage_CreateMat(doc, "Face_Acrylic", use_col, 1)
        mat_case = Signage_CreateMat(doc, "Case_Metal", c4d.Vector(0.2,0.2,0.2), 3)
        root = c4d.BaseObject(c4d.Onull); root.SetName(f"FrontLit_{sp.GetName()}")
        
        face = c4d.BaseObject(c4d.Oextrude); face.SetName("1_Face_Acrylic")
        face.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_val)))) 
        Signage_SetupExtrude(face, front_val)
        sp_face = sp.GetClone(); sp_face.InsertUnder(face); sp_face.SetMl(c4d.Matrix())
        t1 = face.MakeTag(c4d.Ttexture); t1.SetMaterial(mat_face)
        face.InsertUnder(root)
        
        case = c4d.BaseObject(c4d.Oextrude); case.SetName("2_Case_Metal")
        case.SetAbsPos(c4d.Vector(0, 0, 0)) 
        Signage_SetupExtrude(case, back_val)
        case[c4d.CAP_START] = False 
        sp_case = sp.GetClone(); sp_case.InsertUnder(case); sp_case.SetMl(c4d.Matrix())
        t2 = case.MakeTag(c4d.Ttexture); t2.SetMaterial(mat_case)
        case.InsertUnder(root)
        Signage_Finalize(doc, root, data)

def Gen_Crystal(doc, data_list, front_val, back_val, default_color):
    mat_bot = Signage_CreateMat(doc, "Crystal_Clear", c4d.Vector(1,1,1), 2) 
    for data in data_list:
        sp = data['spline']
        use_col = Signage_GetObjColor(data['origin_obj'], default_color)
        mat_top = Signage_CreateMat(doc, "Crystal_Color", use_col, 0)
        root = c4d.BaseObject(c4d.Onull); root.SetName(f"Crystal_{sp.GetName()}")
        
        top = c4d.BaseObject(c4d.Oextrude); top.SetName("1_Color_Face")
        top.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_val))))
        Signage_SetupExtrude(top, front_val)
        sp_top = sp.GetClone(); sp_top.InsertUnder(top); sp_top.SetMl(c4d.Matrix())
        t1 = top.MakeTag(c4d.Ttexture); t1.SetMaterial(mat_top)
        top.InsertUnder(root)
        
        bot = c4d.BaseObject(c4d.Oextrude); bot.SetName("2_Clear_Base")
        bot.SetAbsPos(c4d.Vector(0, 0, 0)) 
        Signage_SetupExtrude(bot, back_val)
        bot[c4d.CAP_START] = False
        sp_bot = sp.GetClone(); sp_bot.InsertUnder(bot); sp_bot.SetMl(c4d.Matrix())
        t2 = bot.MakeTag(c4d.Ttexture); t2.SetMaterial(mat_bot)
        bot.InsertUnder(root)
        Signage_Finalize(doc, root, data)

def Gen_DualLit(doc, data_list, front_val, back_val, default_color):
    back_plate_thick = 1.0 
    mat_case = Signage_CreateMat(doc, "Case_Metal", c4d.Vector(0.2,0.2,0.2), 3) 
    mat_back = Signage_CreateMat(doc, "Back_Light", c4d.Vector(1,1,1), 1) 
    for data in data_list:
        sp = data['spline']
        use_col = Signage_GetObjColor(data['origin_obj'], default_color)
        mat_face = Signage_CreateMat(doc, "Face_Acrylic", use_col, 1)
        root = c4d.BaseObject(c4d.Onull); root.SetName(f"DualLit_{sp.GetName()}")
        
        face = c4d.BaseObject(c4d.Oextrude); face.SetName("1_Face_Lit")
        face.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_val + back_plate_thick)))) 
        Signage_SetupExtrude(face, front_val)
        sp_face = sp.GetClone(); sp_face.InsertUnder(face); sp_face.SetMl(c4d.Matrix())
        t1 = face.MakeTag(c4d.Ttexture); t1.SetMaterial(mat_face)
        face.InsertUnder(root)
        
        case = c4d.BaseObject(c4d.Oextrude); case.SetName("2_Case_Metal")
        case.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_plate_thick)))) 
        Signage_SetupExtrude(case, back_val)
        case[c4d.CAP_START] = False 
        sp_case = sp.GetClone(); sp_case.InsertUnder(case); sp_case.SetMl(c4d.Matrix())
        t2 = case.MakeTag(c4d.Ttexture); t2.SetMaterial(mat_case)
        case.InsertUnder(root)
        
        back = c4d.BaseObject(c4d.Oextrude); back.SetName("3_Back_Lit")
        back.SetAbsPos(c4d.Vector(0, 0, 0)) 
        Signage_SetupExtrude(back, back_plate_thick)
        sp_back = sp.GetClone(); sp_back.InsertUnder(back); sp_back.SetMl(c4d.Matrix())
        t3 = back.MakeTag(c4d.Ttexture); t3.SetMaterial(mat_back)
        back.InsertUnder(root)
        Signage_Finalize(doc, root, data)


# ==============================================================================
# 资产库辅助函数
# ==============================================================================
def FixTexturePaths(materials, asset_file_path, library_root=None):
    asset_dir = os.path.dirname(asset_file_path) 
    parent_dir = os.path.dirname(asset_dir)      
    effective_library_root = library_root or LIBRARY_PATH
    search_dirs =[
        asset_dir,
        os.path.join(asset_dir, "tex"),
        parent_dir,
        os.path.join(parent_dir, "tex"),
        os.path.join(effective_library_root, "tex")
    ]
    count = 0
    def ScanAndFixShader(shader):
        nonlocal count
        while shader:
            if shader.CheckType(c4d.Xbitmap):
                old_path = shader[c4d.BITMAPSHADER_FILENAME]
                if old_path:
                    file_name = os.path.basename(old_path)
                    found_new_path = None
                    for search_path in search_dirs:
                        if not os.path.exists(search_path): continue
                        potential_file = os.path.join(search_path, file_name)
                        if os.path.exists(potential_file):
                            found_new_path = potential_file; break
                    if found_new_path:
                        if str(old_path) != str(found_new_path):
                            shader[c4d.BITMAPSHADER_FILENAME] = str(found_new_path)
                            count += 1
            if shader.GetDown(): ScanAndFixShader(shader.GetDown())
            shader = shader.GetNext()

    for mat in materials:
        first_shader = mat.GetFirstShader()
        if first_shader: ScanAndFixShader(first_shader)
        mat.Message(c4d.MSG_UPDATE)
        mat.Update(True, True)
    if count > 0: print(f"   ✅ 成功链接 {count} 张贴图")

def GetBoundsInfo(op):
    min_v = c4d.Vector(1e10); max_v = c4d.Vector(-1e10)
    found_geo = False
    root_mg_inv = ~op.GetMg()
    def Traverse(obj):
        nonlocal min_v, max_v, found_geo
        if isinstance(obj, c4d.PointObject): 
            found_geo = True
            mg = obj.GetMg(); points = obj.GetAllPoints()
            for p in points:
                local_p = root_mg_inv * (mg * p)
                min_v.x, min_v.y, min_v.z = min(min_v.x, local_p.x), min(min_v.y, local_p.y), min(min_v.z, local_p.z)
                max_v.x, max_v.y, max_v.z = max(max_v.x, local_p.x), max(max_v.y, local_p.y), max(max_v.z, local_p.z)
        for child in obj.GetChildren(): Traverse(child)
    Traverse(op)
    if not found_geo:
        rad = op.GetRad(); scale = op.GetAbsScale()
        size = c4d.Vector(abs(rad.x*scale.x*2), abs(rad.y*scale.y*2), abs(rad.z*scale.z*2))
        return size, -size/2, size/2
    size = max_v - min_v
    size.x = max(0.001, abs(size.x)); size.y = max(0.001, abs(size.y)); size.z = max(0.001, abs(size.z))
    return size, min_v, max_v

def ProcessReplacement(doc, asset_obj, target_obj, do_size_match):
    asset_obj.Remove()
    asset_obj.InsertAfter(target_obj) 
    target_mg = target_obj.GetMg()
    asset_obj.SetMg(target_mg) 

    if do_size_match:
        target_size, _, _ = GetBoundsInfo(target_obj)
        new_size, new_min, _ = GetBoundsInfo(asset_obj)
        if new_size.GetLength() > 0.001:
            size_map =[{'val': new_size.x, 'idx': 0}, {'val': new_size.y, 'idx': 1}, {'val': new_size.z, 'idx': 2}]
            size_map.sort(key=lambda x: x['val'])
            thickness_axis_idx = size_map[0]['idx']
            ratio_y = target_size.y / new_size.y if new_size.y != 0 else 1.0
            target_width = max(target_size.x, target_size.z)
            asset_width = max(new_size.x, new_size.z)
            ratio_width = target_width / asset_width if asset_width != 0 else 1.0
            scale_matrix = c4d.utils.MatrixScale(c4d.Vector(1,1,1))
            if thickness_axis_idx == 0: scale_matrix = c4d.utils.MatrixScale(c4d.Vector(1.0, ratio_y, ratio_width))
            elif thickness_axis_idx == 2: scale_matrix = c4d.utils.MatrixScale(c4d.Vector(ratio_width, ratio_y, 1.0))
            else: scale_matrix = c4d.utils.MatrixScale(c4d.Vector(ratio_width, 1.0, ratio_y))
            asset_obj.SetMg(asset_obj.GetMg() * scale_matrix)
            
            _, new_min_scaled, _ = GetBoundsInfo(asset_obj)
            _, target_min, _ = GetBoundsInfo(target_obj)
            target_bottom_world_y = (target_obj.GetMg() * c4d.Vector(0, target_min.y, 0)).y
            new_bottom_world_y = (asset_obj.GetMg() * c4d.Vector(0, new_min_scaled.y, 0)).y
            shift_y = target_bottom_world_y - new_bottom_world_y
            asset_obj.SetMg(c4d.utils.MatrixMove(c4d.Vector(0, shift_y, 0)) * asset_obj.GetMg())
            
    doc.AddUndo(c4d.UNDOTYPE_NEW, asset_obj)

def SafeLoadBitmap(path):
    if not path or not os.path.exists(path): return None
    bmp = bitmaps.BaseBitmap()
    try:
        bmp.InitWith(path)
        if bmp.GetBw() > 0: return bmp
        temp_dir = tempfile.gettempdir()
        ext = os.path.splitext(path)[1]
        temp_path = os.path.join(temp_dir, "c4d_asset_temp" + ext)
        shutil.copy2(path, temp_path)
        bmp_temp = bitmaps.BaseBitmap()
        bmp_temp.InitWith(temp_path)
        if bmp_temp.GetBw() > 0: return bmp_temp
    except: pass
    return None

def GetLocalCursorPos(ua, msg):
    mx = msg.GetLong(c4d.BFM_INPUT_X); my = msg.GetLong(c4d.BFM_INPUT_Y)
    off_x, off_y = 0, 0
    try:
        res = ua.Local2Global()
        if isinstance(res, dict): off_x, off_y = res['x'], res['y']
        elif isinstance(res, c4d.Vector): off_x, off_y = res.x, res.y
        elif isinstance(res, tuple): off_x, off_y = res[0], res[1]
    except: pass
    return mx - off_x, my - off_y

# ------------------------------------------------------------------------------
# 智能场景/吊顶辅助函数
# ------------------------------------------------------------------------------
MATERIAL_REFERENCE_SCRIPT = r'''
# HH_PERSISTENT_MATERIAL_REFS_V1
def sync_material_references(obj, ids):
    prefix = "HH_MATERIAL_REF_"
    existing = {tag.GetName(): tag for tag in obj.GetTags()
                if tag.CheckType(c4d.Ttexture) and tag.GetName().startswith(prefix)}
    wanted = set()
    for uid in ids:
        name = prefix + str(uid)
        mat = obj[c4d.ID_USERDATA, uid]
        if mat is None:
            continue
        wanted.add(name)
        tag = existing.get(name)
        if tag is None:
            tag = c4d.TextureTag()
            tag.SetName(name)
            # A reserved, absent polygon selection prevents inherited shading.
            tag[c4d.TEXTURETAG_RESTRICTION] = "__HH_REFERENCE_ONLY__"
            tag.SetMaterial(mat)
            obj.InsertTag(tag)
        elif tag.GetMaterial() != mat:
            tag.SetMaterial(mat)
    for name, tag in existing.items():
        if name not in wanted:
            tag.Remove()
'''

def InstallMaterialReferences(gen, ids):
    code = gen[c4d.OPYTHON_CODE]
    if "# HH_PERSISTENT_MATERIAL_REFS_V1" not in code:
        code += "\n" + MATERIAL_REFERENCE_SCRIPT + r'''
if getattr(globals().get('message'), '__name__', '') != '_hh_material_message':
    _hh_previous_message = globals().get('message')
def _hh_material_message(mid, data):
    if c4d.threading.GeIsMainThreadAndNoDrawThread() and not globals().get('_hh_refs_busy'):
        globals()['_hh_refs_busy'] = True
        try:
            sync_material_references(op, MATERIAL_IDS)
        finally:
            globals()['_hh_refs_busy'] = False
    if _hh_previous_message is not None:
        return _hh_previous_message(mid, data)
    return True
message = _hh_material_message
'''
        gen[c4d.OPYTHON_CODE] = code
    scope = {'c4d': c4d}
    exec(MATERIAL_REFERENCE_SCRIPT, scope)
    scope['sync_material_references'](gen, ids)

OPENING_GENERATOR_SCRIPT = r'''import c4d
import math

# HH_SMART_OPENING_V1: self-contained scene generator; no plugin-file dependency.
PARAM_IDS = __PARAMS__
MATERIAL_IDS = __MATS__

def material(obj, slot):
    link = op[c4d.ID_USERDATA,MATERIAL_IDS[slot]]
    if link is not None:
        tag = c4d.TextureTag()
        tag.SetMaterial(link)
        tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_CUBIC
        obj.InsertTag(tag)

def mesh(parent, name, faces, slot):
    points, polygons, lookup = [], [], {}
    for face in faces:
        indices = []
        for p in face:
            if p not in lookup:
                lookup[p] = len(points)
                points.append(c4d.Vector(*p))
            indices.append(lookup[p])
        polygons.append(c4d.CPolygon(*indices))
    obj = c4d.PolygonObject(len(points),len(polygons))
    obj.SetName(name)
    obj.SetAllPoints(points)
    for i,poly in enumerate(polygons): obj.SetPolygon(i,poly)
    material(obj,slot)
    phong = c4d.BaseTag(c4d.Tphong)
    phong[c4d.PHONGTAG_PHONG_ANGLELIMIT] = True
    phong[c4d.PHONGTAG_PHONG_ANGLE] = math.radians(30)
    obj.InsertTag(phong)
    obj.Message(c4d.MSG_UPDATE)
    obj.InsertUnderLast(parent)
    return obj

def bar(parent,name,l,r,low,high,front,back,slot,bevel=0.12):
    if min(r-l,high-low,back-front) < 0.000001: return
    bevel = min(bevel,(r-l)*.12,(high-low)*.12,(back-front)*.12)
    def loop(inset,z):
        a,b,c,d = l+inset,r-inset,low+inset,high-inset
        e = bevel*.5
        return [(a+e,c,z),(b-e,c,z),(b,c+e,z),(b,d-e,z),
                (b-e,d,z),(a+e,d,z),(a,d-e,z),(a,c+e,z)]
    rings = [loop(bevel,front),loop(0,front+bevel),loop(0,back-bevel),loop(bevel,back)]
    faces = []
    for ring,next_ring in zip(rings,rings[1:]):
        for j in range(8):
            k=(j+1)%8
            faces.append([ring[j],ring[k],next_ring[k],next_ring[j]])
    for ring,reverse in ((rings[0],True),(rings[-1],False)):
        center=((l+r)/2,(low+high)/2,ring[0][2])
        for j in range(8):
            tri=[center,ring[j],ring[(j+1)%8]]
            faces.append(list(reversed(tri)) if reverse else tri)
    return mesh(parent,name,faces,slot)

def frame(parent,name,l,r,low,high,front,back,rim,slot):
    rim=min(rim,(r-l)*.22,(high-low)*.22)
    e=min(.12,rim*.12,(back-front)*.12)
    def loop(a,b,c,d,z):return [(a,c,z),(b,c,z),(b,d,z),(a,d,z)]
    rings=[loop(l+e,r-e,low+e,high-e,front),loop(l,r,low,high,front+e),
           loop(l,r,low,high,back-e),loop(l+e,r-e,low+e,high-e,back),
           loop(l+rim-e,r-rim+e,low+rim-e,high-rim+e,back),
           loop(l+rim,r-rim,low+rim,high-rim,back-e),
           loop(l+rim,r-rim,low+rim,high-rim,front+e),
           loop(l+rim-e,r-rim+e,low+rim-e,high-rim+e,front)]
    faces=[]
    for i,ring in enumerate(rings):
        following=rings[(i+1)%len(rings)]
        for j in range(4):
            k=(j+1)%4
            faces.append([ring[j],ring[k],following[k],following[j]])
    return mesh(parent,name,faces,slot)

def disc(parent,name,x,y,z,radius,depth,slot):
    n=32
    rings=[]
    bevel=min(radius*.12,depth*.2)
    for rad,zz in ((radius-bevel,z-depth/2),(radius,z-depth/2+bevel),
                   (radius,z+depth/2-bevel),(radius-bevel,z+depth/2)):
        rings.append([(x+rad*math.cos(i*math.tau/n),y+rad*math.sin(i*math.tau/n),zz) for i in range(n)])
    faces=[]
    for ring,following in zip(rings,rings[1:]):
        for j in range(n):
            k=(j+1)%n
            faces.append([ring[j],ring[k],following[k],following[j]])
    for ring,reverse in ((rings[0],True),(rings[-1],False)):
        center=(x,y,ring[0][2])
        for j in range(n):
            tri=[center,ring[j],ring[(j+1)%n]]
            faces.append(list(reversed(tri)) if reverse else tri)
    return mesh(parent,name,faces,slot)

def glazing(parent,l,r,low,high,zc,rim,depth):
    seal=min(rim*.25,(r-l)*.08,(high-low)*.08)
    frame(parent,"密封胶条",l,r,low,high,zc-depth*.025,zc+depth*.025,seal,4)
    bar(parent,"独立玻璃",l+seal,r-seal,low+seal,high-seal,zc-depth*.018,zc+depth*.018,3)

def windows(root,w,h,d,f,style,ratio,opening):
    count=4 if style in (1,3) else 2
    transom=style in (2,3)
    f=min(f,w/(count*7),h*.08)
    front,back=-d/2,d/2
    frame(root,"整体斜接外框",-w/2,w/2,0,h,front,back,f,0)
    for z in (front,back-d*.08):
        frame(root,"外框压边",-w/2,w/2,0,h,z-d*.025,z+d*.08,f*.28,0)
    l,r,low,high=-w/2+f,w/2-f,f,h-f
    rim=min(f*.65,(r-l)/(count*9),(high-low)*.08)
    if transom:
        divider=high-(high-low)*ratio/100
        beam=min(f*.7,(high-low)*.06)
        bar(root,"上亮横梁",l,r,divider-beam/2,divider+beam/2,front,back,0)
        lower=divider+beam/2
        top_count=2 if count==4 else 1
        for i in range(top_count):
            a=l+(r-l)*i/top_count
            b=l+(r-l)*(i+1)/top_count
            frame(root,"上亮固定窗框",a,b,lower,high,-d*.18,d*.18,rim,0)
            glazing(root,a+rim,b-rim,lower+rim,high-rim,0,rim,d)
        high=divider-beam/2
    gap=min(f*.07,(high-low)*.015)
    span=(r-l)/count
    overlap=rim*.6
    for i in range(count):
        a=l+i*span+(gap if i==0 else -overlap)
        b=l+(i+1)*span+(-gap if i==count-1 else overlap)
        zc=(-1 if i%2==0 else 1)*d*.23
        leaf=c4d.BaseObject(c4d.Onull)
        leaf.SetName("推拉窗扇 "+str(i+1))
        leaf.InsertUnderLast(root)
        # Pairwise sliding stays within the outer frame; no sash is scaled.
        shift=(span-2*overlap)*opening/100*(1 if i%2==0 else -1)
        leaf.SetRelPos(c4d.Vector(shift,0,0))
        frame(leaf,"窗扇型材",a,b,low+gap,high-gap,zc-d*.18,zc+d*.18,rim,0)
        frame(leaf,"玻璃压条",a+rim*.72,b-rim*.72,low+gap+rim*.72,high-gap-rim*.72,
              zc-d*.205,zc-d*.12,rim*.22,0)
        glazing(leaf,a+rim,b-rim,low+gap+rim,high-gap-rim,zc,rim,d)
        hx=a+rim*.5 if i%2==0 else b-rim*.5
        hy=(low+high)/2; hw=rim*.45; hh=min(12,(high-low)*.2)
        bar(leaf,"嵌入拉手座",hx-hw/2,hx+hw/2,hy-hh/2,hy+hh/2,zc-d*.225,zc-d*.18,4)
        bar(leaf,"拉手拨片",hx-hw*.12,hx+hw*.12,hy-hh*.3,hy+hh*.3,zc-d*.245,zc-d*.22,0)
    for zc in (-d*.23,d*.23):
        for y in (low,high-gap*.45):
            bar(root,"双轨滑槽",l,r,y,y+gap*.45,zc-d*.025,zc+d*.025,4)
    bar(root,"底部排水收边",-w/2,w/2,0,f*.3,front-d*.09,front+d*.04,0)

def rod(parent,name,start,end,radius,slot):
    direction=end-start
    if direction.GetLength()<0.000001:return
    axis=direction.GetNormalized()
    ref=c4d.Vector(0,1,0) if abs(axis.y)<.9 else c4d.Vector(1,0,0)
    u=axis.Cross(ref).GetNormalized();v=axis.Cross(u)
    rings=[];n=24
    for center in (start,end):
        ring=[]
        for i in range(n):
            p=center+(u*math.cos(i*math.tau/n)+v*math.sin(i*math.tau/n))*radius
            ring.append((p.x,p.y,p.z))
        rings.append(ring)
    faces=[]
    for i in range(n):
        j=(i+1)%n
        faces.append([rings[0][i],rings[0][j],rings[1][j],rings[1][i]])
        faces.append([(start.x,start.y,start.z),rings[0][j],rings[0][i]])
        faces.append([(end.x,end.y,end.z),rings[1][i],rings[1][j]])
    return mesh(parent,name,faces,slot)

def vision_leaf(parent,a,b,bottom,top,depth,width_ratio,height_ratio,hinge_left,slot=1,window=None):
    width=b-a;height=top-bottom
    # One closed panel with a true aperture avoids bevel seams across the face.
    cx=a+width*(.64 if hinge_left else .36)
    half=min(width*width_ratio/200,width*.21)
    l,r=cx-half,cx+half
    high=top-height*.12;low=high-height*height_ratio/100
    if window is not None:
        window_width,window_height,offset,center_height=window
        margin_x=min(6,width*.12);margin_y=min(8,height*.08)
        ww=min(window_width,width-2*margin_x)
        wh=min(window_height,height-2*margin_y)
        cx=max(a+margin_x+ww/2,min(b-margin_x-ww/2,(a+b)/2+offset))
        cy=bottom+height*.72 if center_height==0 else center_height
        cy=max(bottom+margin_y+wh/2,min(top-margin_y-wh/2,cy))
        l,r=cx-ww/2,cx+ww/2
        low,high=cy-wh/2,cy+wh/2
    e=min(.08,depth*.1,(l-a)*.1,(b-r)*.1,(low-bottom)*.1,(top-high)*.1)
    def loop(x0,x1,y0,y1,z):return [(x0,y0,z),(x1,y0,z),(x1,y1,z),(x0,y1,z)]
    rings=[loop(a+e,b-e,bottom+e,top-e,-depth/2),loop(a,b,bottom,top,-depth/2+e),
           loop(a,b,bottom,top,depth/2-e),loop(a+e,b-e,bottom+e,top-e,depth/2),
           loop(l-e,r+e,low-e,high+e,depth/2),loop(l,r,low,high,depth/2-e),
           loop(l,r,low,high,-depth/2+e),loop(l-e,r+e,low-e,high+e,-depth/2)]
    faces=[]
    for i,ring in enumerate(rings):
        following=rings[(i+1)%len(rings)]
        for j in range(4):
            k=(j+1)%4
            faces.append([ring[j],ring[k],following[k],following[j]])
    mesh(parent,"一体观察窗门板",faces,slot)
    rim=min(1.8,width*.025,height*.012,(r-l)*.15,(high-low)*.15)
    frame(parent,"观察窗洞内衬",l,r,low,high,-depth/2,depth/2,rim*.4,0)
    for face in (-1,1):
        z=face*(depth/2+.16)
        frame(parent,"观察窗双面压框",l-rim,r+rim,low-rim,high+rim,z-.22,z+.22,rim,slot)
    glazing(parent,l+rim*.4,r-rim*.4,low+rim*.4,high-rim*.4,0,rim,min(depth,12))

def door_closer(parent,root,a,b,top,depth,hinge_left,theta,pivot,zcenter,frame_front,frame_top):
    width=b-a
    unit=min(1.0,width/60,top/180,depth/2)
    x=a+width*.22 if hinge_left else b-width*.22
    y=top-5*unit;z=-depth/2-2*unit
    bar(parent,"闭门器安装背板",x-10.5*unit,x+10.5*unit,y-2*unit,y+2*unit,z+1.3*unit,-depth/2+.1*unit,0)
    bar(parent,"闭门器外壳",x-10*unit,x+10*unit,y-1.8*unit,y+1.8*unit,z-1.5*unit,z+1.5*unit,0,.4*unit)
    arm_y=top-.8*unit
    rod(parent,"闭门器驱动轴",c4d.Vector(x,y+1.5*unit,z),c4d.Vector(x,arm_y+.5*unit,z),.65*unit,4)
    fixed_x=pivot+(a+width*.35 if hinge_left else b-width*.35)
    fixed_z=frame_front-1.5*unit
    plate_low=top+.2*unit
    plate_high=min(frame_top,top+3*unit)
    bar(root,"闭门器门框固定座",fixed_x-3*unit,fixed_x+3*unit,plate_low,plate_high,
        frame_front-.5*unit,frame_front+.15*unit,0)
    bar(root,"闭门器固定托架",fixed_x-unit,fixed_x+unit,plate_low,plate_high,
        fixed_z-.8*unit,frame_front+.1*unit,0)
    rod(root,"闭门器固定转轴",c4d.Vector(fixed_x,arm_y-.5*unit,fixed_z),
        c4d.Vector(fixed_x,plate_high,fixed_z),.65*unit,4)
    for xx in (fixed_x-2*unit,fixed_x+2*unit):
        disc(root,"固定座螺钉",xx,(plate_low+plate_high)/2,frame_front-.5*unit,.28*unit,.15*unit,4)
    start=c4d.Vector(pivot+math.cos(theta)*x+math.sin(theta)*z,arm_y,
                     zcenter-math.sin(theta)*x+math.cos(theta)*z)
    anchor=c4d.Vector(fixed_x,arm_y,fixed_z)
    delta=anchor-start;distance=delta.GetLength()
    # Equal-length articulated arms keep both ends seated throughout opening.
    reach_a=math.hypot(x,z)
    reach_b=math.hypot(fixed_x-pivot,fixed_z-zcenter)
    length=(reach_a+reach_b)*.55+unit
    perpendicular=c4d.Vector(delta.z,0,-delta.x)
    if distance<.000001:perpendicular=c4d.Vector(0,0,-1)
    else:perpendicular=perpendicular*(1.0/distance)
    if perpendicular.z>0:perpendicular=perpendicular*-1
    elbow=(start+anchor)*.5+perpendicular*math.sqrt(max(0,length*length-distance*distance*.25))
    for label,p,q in (("闭门器主摇臂",start,elbow),("闭门器副摇臂",elbow,anchor)):
        axis=(q-p).GetNormalized();up=c4d.Vector(0,1,0)
        link=c4d.BaseObject(c4d.Onull);link.SetName(label);link.InsertUnderLast(root)
        link.SetMl(c4d.Matrix(p,axis,up,axis.Cross(up)))
        bar(link,"扁平连杆",-.5*unit,(q-p).GetLength()+.5*unit,-.3*unit,.3*unit,-.65*unit,.65*unit,0,.1*unit)
    for p in (start,elbow,anchor):
        rod(root,"连杆铰接销",p+c4d.Vector(0,-.5*unit,0),p+c4d.Vector(0,.5*unit,0),.8*unit,4)

def doors(root,w,h,d,f,style,header,angle,hand,leaf_depth,handle_height,details,wood_window=None):
    slot=2 if style==6 else 1
    f=min(f,w*.1,h*.07)
    header=0 if style>=7 else min(header,h*.4)
    top=h-f-header
    leaf_depth=min(leaf_depth,d*.75,w*.1,top*.08)
    front,back=-d/2,d/2
    l,r=-w/2+f,w/2-f
    # U-shaped door casing: no window-like sill across the walking opening.
    for a,b in ((-w/2,l),(r,w/2)):
        bar(root,"门套立框",a,b,0,h,front,back,slot)
    bar(root,"门套上框",l,r,top,h,front,back,slot)
    reveal=min(f*.28,1.4)
    for z in (front-d*.035,back-d*.03):
        bar(root,"左门套压边",-w/2,l-reveal*.2,0,h,z,z+d*.065,slot)
        bar(root,"右门套压边",r+reveal*.2,w/2,0,h,z,z+d*.065,slot)
        bar(root,"上门套压边",l-reveal*.2,r+reveal*.2,top+reveal*.2,h,z,z+d*.065,slot)
    clearance=min(.3,(r-l)*.005,top*.005)
    seam=min(.4,(r-l)*.006)
    count=1 if style in (4,7) else 2
    zcenter=front+leaf_depth/2+d*.12
    for i in range(count):
        left=l+clearance if i==0 else -seam/2
        right=r-clearance if i==count-1 else seam/2
        if count==2:
            split=l+(r-l)*(details[2]/100 if style==8 else .5)
            left=l+clearance if i==0 else split+seam/2
            right=split-seam/2 if i==0 else r-clearance
        hinge_left=(hand==0) if count==1 else i==0
        pivot=left if hinge_left else right
        leaf=c4d.BaseObject(c4d.Onull)
        leaf.SetName("左门扇" if hinge_left else "右门扇")
        leaf.InsertUnderLast(root)
        theta=math.radians(angle)*(1 if hinge_left else -1)
        u=c4d.Vector(math.cos(theta),0,-math.sin(theta))
        v=c4d.Vector(0,1,0)
        leaf.SetMl(c4d.Matrix(c4d.Vector(pivot,0,zcenter),u,v,u.Cross(v)))
        a,b=left-pivot,right-pivot
        bottom=clearance*2
        if style>=7 and not (style==8 and i==1):
            vision_leaf(leaf,a,b,bottom,top-clearance,leaf_depth,details[0],details[1],hinge_left)
        elif style in (4,5,6) and wood_window is not None:
            vision_leaf(leaf,a,b,bottom,top-clearance,leaf_depth,details[0],details[1],hinge_left,slot,wood_window)
        else:
            bar(leaf,"实心门扇饰面",a,b,bottom,top-clearance,-leaf_depth/2,leaf_depth/2,slot,.18)
        if style>=7 and details[4] and not (style==8 and i==1):
            door_closer(leaf,root,a,b,top-clearance,leaf_depth,hinge_left,theta,pivot,zcenter,front,h)
        # Dark stops remain attached to the fixed jamb, not the moving leaf.
        stops = ((left,left+reveal),(right-reveal,right)) if count==1 else (
            ((left,left+reveal),) if hinge_left else ((right-reveal,right),))
        for x0,x1 in stops:
            bar(root,"门框密封止口",x0,x1,0,top,zcenter+leaf_depth/2+clearance,zcenter+leaf_depth/2+clearance+reveal,4)
        bar(root,"门顶密封止口",left,right,top-reveal,top,zcenter+leaf_depth/2+clearance,zcenter+leaf_depth/2+clearance+reveal,4)
        hx=b-min(6,(b-a)*.18) if hinge_left else a+min(6,(b-a)*.18)
        hy=min(max(handle_height,top*.2),top*.8)
        radius=min(2.3,(b-a)*.045,top*.018)
        lever=min(11,(b-a)*.28)
        if style==8 and i==1:
            for y in (bottom+5,top-5):
                bar(leaf,"子扇暗插销",a+.3,a+1.0,y-2,y+2,-leaf_depth/2-.1,-leaf_depth/2,4)
        else:
            add_door_handles(leaf,hx,hy,radius,lever,hinge_left,leaf_depth)
        for y in (top*.17,top*.5,top*.83):
            x=a+radius*.2 if hinge_left else b-radius*.2
            bar(leaf,"合页",x-radius*.3,x+radius*.3,y-radius,y+radius,
                -leaf_depth*.45,leaf_depth*.45,4)

def add_door_handles(leaf,hx,hy,radius,lever,hinge_left,leaf_depth):
    for face in (-1,1):
        z=face*(leaf_depth/2+.25)
        disc(leaf,"执手圆底座",hx,hy,z,radius,.65,4)
        disc(leaf,"锁芯底座",hx,hy-radius*3,z,radius*.72,.65,4)
        bar(leaf,"锁孔",hx-radius*.12,hx+radius*.12,hy-radius*3.35,hy-radius*2.65,
            z-.38,z+.38,0)
        disc(leaf,"执手轴",hx,hy,face*(leaf_depth/2+1.3),radius*.35,1.8,4)
        a0,a1=(hx-lever,hx+radius*.3) if hinge_left else (hx-radius*.3,hx+lever)
        zz=face*(leaf_depth/2+2.1)
        bar(leaf,"圆角执手",a0,a1,hy-radius*.28,hy+radius*.28,zz-.55,zz+.55,4,.25)

def glass_doors(root,w,h,d,f,style,header,angle,leaf_depth,details,hand=0):
    f=min(f,w*.025,h*.02)
    d=min(d,25)
    l,r=-w/2+f,w/2-f
    transom=min(max(header,h*.08),h*.35)
    top=h-f-transom
    thickness=min(max(.3,leaf_depth*.25),1.5,w*.015,h*.01)
    seam=min(.4,w*.003)
    for a,b in ((-w/2,l),(r,w/2)):
        bar(root,"不锈钢侧边槽",a,b,0,h,-d/2,d/2,0)
    bar(root,"不锈钢顶槽",l,r,h-f,h,-d/2,d/2,0)
    side=(r-l)*details[3]/100 if style in (11,12) else 0
    left=l+side if style==11 or (style==12 and hand==1) else l
    right=r-side if style==11 or (style==12 and hand==0) else r
    if side:
        fixed_spans=[]
        if left>l:fixed_spans.append((l,left-seam))
        if right<r:fixed_spans.append((right+seam,r))
        for a,b in fixed_spans:
            bar(root,"侧固定玻璃",a,b,seam,top-seam,-thickness/2,thickness/2,3)
            clamp_width=min(6,(b-a)*.5)
            x0=a if a==l else b-clamp_width
            for y in (seam,top-min(6,top*.04)):
                bar(root,"侧玻璃固定夹",x0,x0+clamp_width,y,y+min(6,top*.04),-thickness,thickness,0)
            bar(root,"固定玻璃底槽",a,b,0,min(2,h*.01),-thickness,thickness,0)
    bar(root,"上亮固定玻璃",l,r,top+seam,h-f,-thickness/2,thickness/2,3)
    spans=((left+seam,right-seam),) if style==12 else ((left+seam,-seam/2),(seam/2,right-seam))
    for i,(a,b) in enumerate(spans):
        hinge_left=hand==0 if style==12 else i==0
        pivot=a if hinge_left else b
        theta=math.radians(angle)*(1 if hinge_left else -1)
        u=c4d.Vector(math.cos(theta),0,-math.sin(theta));up=c4d.Vector(0,1,0)
        leaf=c4d.BaseObject(c4d.Onull);leaf.SetName("玻璃左门扇" if hinge_left else "玻璃右门扇")
        leaf.InsertUnderLast(root);leaf.SetMl(c4d.Matrix(c4d.Vector(pivot,0,0),u,up,u.Cross(up)))
        a-=pivot;b-=pivot
        bar(leaf,"钢化玻璃门扇",a,b,seam*2,top-seam,-thickness/2,thickness/2,3,.05)
        unit=min(1,(b-a)/65,top/180)
        for y in (seam*2,top-seam-6*unit):
            x0=a if hinge_left else b-12*unit
            bar(leaf,"转轴门夹",x0,x0+12*unit,y,y+6*unit,-thickness/2-.6*unit,thickness/2+.6*unit,0)
            # The moving patch and fixed bearing share the actual hinge axis.
            bar(leaf,"门夹轴套",-.9*unit,.9*unit,y,y+6*unit,-thickness/2-.6*unit,thickness/2+.6*unit,0)
            y0=0 if y==seam*2 else y
            y1=y+6*unit if y==seam*2 else top+seam+2*unit
            rod(leaf,"门夹转轴",c4d.Vector(0,y0,0),c4d.Vector(0,y1,0),.55*unit,4)
            for face in (-1,1):
                for xx in (x0+3*unit,x0+9*unit):
                    disc(leaf,"门夹固定螺钉",xx,y+3*unit,face*(thickness/2+.61*unit),.25*unit,.12*unit,4)
        hx=b-7*unit if hinge_left else a+7*unit
        y0=top*.27;y1=top*.64
        for face in (-1,1):
            z=face*(thickness/2+4*unit)
            rod(leaf,"双面长拉手",c4d.Vector(hx,y0,z),c4d.Vector(hx,y1,z),1.15*unit,0)
            for y in (y0+4*unit,y1-4*unit):
                rod(leaf,"拉手连接座",c4d.Vector(hx,y,face*thickness/2),c4d.Vector(hx,y,z),.7*unit,0)
                disc(leaf,"拉手垫片",hx,y,face*(thickness/2+.1*unit),1.5*unit,.3*unit,4)
        bar(root,"上转轴固定夹",pivot-2*unit,pivot+2*unit,top+seam,top+seam+5*unit,-thickness,thickness,0)
        bar(root,"地弹簧盖板",pivot-2*unit,pivot+2*unit,0,.3*unit,-4*unit,4*unit,0)

def fire_cabinet(root,w,h,d,upper_angle,lower_angle,mode=0):
    # Shell fits the opening; equipment keeps uniform scale and a usable depth.
    single=mode in (1,2)
    steel=mode in (2,3)
    y_shift=61.5 if single else 0
    cabinet_height=200-y_shift
    equipment_scale=min(w/80,h/cabinet_height)
    d=max(d,24*equipment_scale)
    sx,sy,sz=w/80,h/cabinet_height,d/24
    door_front=-12.5
    door_back=door_front+min(1.2/sz,1.2)
    glass_front=door_front+.25*(door_back-door_front)
    body=c4d.BaseObject(c4d.Onull);body.SetName("消火栓组合柜")
    body.SetRelScale(c4d.Vector(w/80,h/cabinet_height,d/24));body.InsertUnderLast(root)

    def equipment_group(label,base_y,source_y=None):
        group=c4d.BaseObject(c4d.Onull);group.SetName(label)
        scale=c4d.Vector(equipment_scale/(w/80),equipment_scale/(h/cabinet_height),equipment_scale/(d/24))
        source_y=base_y if source_y is None else source_y
        group.SetMl(c4d.Matrix(c4d.Vector(0,base_y-source_y*scale.y,0),
                              c4d.Vector(scale.x,0,0),c4d.Vector(0,scale.y,0),c4d.Vector(0,0,scale.z)))
        group.InsertUnderLast(body)
        return group

    def tube(parent,name,points,radius,slot,depth_radius=None):
        closed=(points[0]-points[-1]).GetLength()<.00001
        if closed:points=points[:-1]
        rings=[];n=20
        for i,p in enumerate(points):
            tangent=(points[(i+1)%len(points)]-points[(i-1)%len(points)] if closed else
                     points[min(i+1,len(points)-1)]-points[max(0,i-1)]).GetNormalized()
            ref=c4d.Vector(0,0,1) if abs(tangent.z)<.9 else c4d.Vector(0,1,0)
            u=tangent.Cross(ref).GetNormalized();v=tangent.Cross(u)
            ring=[]
            for j in range(n):
                q=p+u*(math.cos(j*math.tau/n)*radius)+v*(math.sin(j*math.tau/n)*(depth_radius or radius))
                ring.append((q.x,q.y,q.z))
            rings.append(ring)
        faces=[]
        for a,b in zip(rings,rings[1:]+([rings[0]] if closed else [])):
            for j in range(n):
                k=(j+1)%n;faces.append([a[j],a[k],b[k],b[j]])
        for p,ring,reverse in (() if closed else ((points[0],rings[0],True),(points[-1],rings[-1],False))):
            for j in range(n):
                face=[(p.x,p.y,p.z),ring[j],ring[(j+1)%n]]
                faces.append(list(reversed(face)) if reverse else face)
        return mesh(parent,name,faces,slot)

    def round_body(parent,name,x,z,profile,slot):
        n=48;rings=[];faces=[]
        for y,r in profile:
            rings.append([(x+r*math.cos(j*math.tau/n),y,z-r*math.sin(j*math.tau/n)) for j in range(n)])
        for a,b in zip(rings,rings[1:]):
            for j in range(n):
                k=(j+1)%n;faces.append([a[j],a[k],b[k],b[j]])
        for ring,(y,r),reverse in ((rings[0],profile[0],True),(rings[-1],profile[-1],False)):
            for j in range(n):
                face=[(x,y,z),ring[j],ring[(j+1)%n]]
                faces.append(list(reversed(face)) if reverse else face)
        return mesh(parent,name,faces,slot)

    def sign(parent,text,y,height):
        # Baked glyph geometry keeps Chinese lettering independent of installed fonts.
        glyph=FIRE_SIGN_MESHES.get(text)
        if not glyph:return
        points,polys=glyph
        height=min(height,62/max(.001,max(p[0] for p in points)-min(p[0] for p in points)))
        surface=door_front if steel else glass_front
        zmin=min(p[2] for p in points);zmax=max(p[2] for p in points)
        faces=[[(points[i][0]*height,points[i][1]*height+y,
                 surface-(.035-.025*(points[i][2]-zmin)/max(zmax-zmin,.000001))/sz)
                for i in poly] for poly in polys]
        mesh(parent,text,faces,1 if steel else 6)

    def bezier(points,steps=32):
        a,b,c,e=points
        return [a*((1-t)**3)+b*(3*t*(1-t)**2)+c*(3*t*t*(1-t))+e*(t**3)
                for t in [i/steps for i in range(steps+1)]]

    bar(body,"红色折边背板",-40,40,0,cabinet_height,10.8,12,2)
    for a,b in ((-40,-38.5),(38.5,40)):
        bar(body,"红色侧板",a,b,0,cabinet_height,-12,10.8,2)
    for y in ((0,cabinet_height-1.5) if single else (0,61.5,198.5)):
        bar(body,"柜底 / 分隔搁板",-38.5,38.5,y,y+1.5,-12,10.8,2)
    frame(body,"柜口折边",-40,40,0,cabinet_height,-12.5,-11,1.5,2 if steel else 1)
    if not single:
        bar(body,"中部门框横梁",-38.5,38.5,61,64,-12.6,-10,2 if steel else 1)
    for x in (-35,35):
        for y in ((8,cabinet_height-8) if single else (8,69,192)):
            disc(body,"背板安装螺钉",x,y,10.65,.45,.3,0)

    # Upper compartment: feed pipe, valve, coupling, nozzle and wound fabric hose.
    shell=body
    body=equipment_group("上层立体消防器件（等比例）",63-y_shift,63)
    rear_z=10.8*(d/24)/equipment_scale
    rod(body,"镀锌进水立管",c4d.Vector(-23,63,2),c4d.Vector(-23,168,2),3.0,0)
    round_body(body,"进水管穿板法兰",-23,2,[(63,4.8),(63.3,5),(64.2,5),(64.6,3.4)],0)
    for xx,zz in ((-26.9,2),(-19.1,2),(-23,-1.9),(-23,5.9)):
        rod(body,"法兰螺栓",c4d.Vector(xx,64.1,zz),c4d.Vector(xx,64.8,zz),.35,0)
    for y in (70,106,153):
        round_body(body,"管路连接套箍",-23,2,[(y,3.25),(y+.4,3.8),(y+3,3.8),(y+3.4,3.25)],0)
    for y in (76,149):
        rod(body,"立管背板支座",c4d.Vector(-23,y,4.8),c4d.Vector(-23,y,rear_z),1,0)
        bar(body,"立管支座底板",-26,-20,y-2,y+2,rear_z-.6,rear_z,0,.12)
    round_body(body,"消火栓阀体",-23,2,[(158,3),(160,4.5),(168,4.5),(171,3.2)],2)
    rod(body,"阀门出口",c4d.Vector(-23,164,2),c4d.Vector(-23,164,-5),3.4,0)
    disc(body,"快速接头",-23,164,-5.2,4.4,2.5,0)
    disc(body,"出口内孔",-23,164,-6.51,2.8,.15,4)
    rod(body,"阀门丝杆",c4d.Vector(-23,171,2),c4d.Vector(-23,179,2),.9,0)
    wheel=[c4d.Vector(-23+6*math.cos(i*math.tau/64),179,2+6*math.sin(i*math.tau/64)) for i in range(65)]
    tube(body,"红色阀门手轮",wheel,.65,2)
    for a in (0,math.tau/3,2*math.tau/3):
        rod(body,"手轮辐条",c4d.Vector(-23,179,2),c4d.Vector(-23+6*math.cos(a),179,2+6*math.sin(a)),.45,2)
    disc(body,"水带托盘",12,139,5.5,20,1.3,2)
    rod(body,"卷盘背板支轴",c4d.Vector(12,139,5.5),c4d.Vector(12,139,rear_z),2,0)
    bar(body,"卷盘安装底板",8,16,135,143,rear_z-.7,rear_z,0,.15)
    for i in range(6):
        radius=5+i*2.45
        coil=[c4d.Vector(12+radius*math.cos(j*math.tau/96),139+radius*math.sin(j*math.tau/96),1.7) for j in range(97)]
        tube(body,"织物水带卷 %d" % (i+1),coil,1.18,5,3.6)
    disc(body,"水带卷中心接扣",12,139,1.4,4.1,7.2,0)
    hose=bezier([c4d.Vector(-16,112,1.7),c4d.Vector(-10,112,1.7),
                 c4d.Vector(-15,90,1.7),c4d.Vector(-4,90,1.7)])
    hose+=bezier([c4d.Vector(-4,90,1.7),c4d.Vector(7,90,1.7),
                  c4d.Vector(12,106,1.7),c4d.Vector(12,121.5,1.7)])[1:]
    tube(body,"垂落水带",hose,1.7,5)
    rod(body,"水带接头引出",c4d.Vector(-23,112,1.7),c4d.Vector(-15.5,112,1.7),2.4,0)
    round_body(body,"消防喷枪",30,4,[(163,2.5),(166,2.5),(171,1.9),(184,.9),(188,.9)],0)
    for y in (164,180):
        # Clamp follows the tapered barrel; bracket ends at the actual cabinet back.
        r=2.5 if y==164 else 1.32
        round_body(body,"喷枪固定环",30,4,[(y,r+.16),(y+.8,r+.16)],4)
        bar(body,"喷枪固定扣",29,31,y,y+.8,4+r-.2,rear_z,4,.1)
        bar(body,"喷枪背板座",27,33,y-1,y+2,rear_z-.5,rear_z,0,.1)
    body=shell
    for x in (-26,-21,-16,-11,-6):
        bar(body,"内侧通风槽",x,x+2,187-y_shift,192-y_shift,10.55,10.7,4,.04)

    equipment=equipment_group("下层立体灭火器（等比例）",1.5) if not single else None
    for x in (() if single else (-17,17)):
        bottle=c4d.BaseObject(c4d.Onull);bottle.SetName("干粉灭火器")
        bottle.InsertUnderLast(equipment)
        round_body(bottle,"圆底压力罐",x,1,[(3,4.6),(3.5,5.8),(4.5,6.5),(7,6.8),
                   (36,6.8),(39,6.3),(41,4.8),(42,2.6),(44,2.0)],2)
        round_body(bottle,"黑色底圈",x,1,[(1.5,6.2),(1.9,6.9),(4,6.9),(4.5,6.6)],4)
        round_body(bottle,"说明标签",x,1,[(23,6.83),(30,6.83)],1)
        for yy in (24,25.4,26.8,28.2):
            arc=[c4d.Vector(x+6.9*math.sin(a),yy,1-6.9*math.cos(a))
                 for a in [-.5+i/24 for i in range(25)]]
            tube(bottle,"标签细则",arc,.09,4)
        round_body(bottle,"瓶颈阀门",x,1,[(43,2.0),(46,2.0)],0)
        bar(bottle,"提把",x-1,x+8,47,48.2,-.5,2.5,4,.3)
        bar(bottle,"压把",x-1,x+7.5,49,50,-.3,2.3,2,.25)
        rod(bottle,"提把支撑",c4d.Vector(x,44,1),c4d.Vector(x,48,1),1.3,0)
        for zz in (-.65,2.05):
            bar(bottle,"压把铰接耳",x-.8,x+.8,47.8,49.6,zz,zz+.6,0,.12)
        rod(bottle,"压把铰接销",c4d.Vector(x,49.2,-.85),c4d.Vector(x,49.2,2.9),.4,0)
        disc(bottle,"压力表金属圈",x,45.8,-1.7,1.65,1.0,0)
        disc(bottle,"压力表表盘",x,45.8,-2.24,1.25,.1,1)
        rod(bottle,"压力表指针",c4d.Vector(x,45.8,-2.32),c4d.Vector(x+.6,46.5,-2.32),.09,4)
        rod(bottle,"软管阀口接头",c4d.Vector(x-1.5,45,1),c4d.Vector(x-3.2,45,1),.9,0)
        path=bezier([c4d.Vector(x-3,45,1),c4d.Vector(x-9,45,1),
                     c4d.Vector(x-9,44,1),c4d.Vector(x-9,39,1)])
        path+=[c4d.Vector(x-9,39-19*i/16,1) for i in range(1,17)]
        tube(bottle,"灭火器黑色软管",path,.65,4)
        rod(bottle,"软管喷嘴",path[-1],path[-1]+c4d.Vector(0,-5,0),.9,4)
        for yy in (21,33):
            bar(bottle,"软管固定卡",x-9.7,x-6.55,yy,yy+.7,.6,1.4,4,.12)

    doors=[(63 if single else 64,198.5,upper_angle,"红色铁皮柜门" if steel else "消火栓玻璃门")]
    if not single:doors.append((1.5,61,lower_angle,"下层灭火器铁皮门" if steel else "下层灭火器玻璃门"))
    for bottom,top,angle,label in doors:
        # Derive every door from its opening; keep the reveal small in world units.
        gap_x=min(.2/sx,.3);gap_y=min(.2/sy,(top-bottom)*.01)
        l,r=-38.5+gap_x,38.5-gap_x
        low,high=bottom+gap_y,top-gap_y
        rim=min(3.1,(r-l)*.1,(high-low)*.1)
        il,ir,ib,it=l+rim,r-rim,low+rim,high-rim
        dz=door_back-door_front
        frame(body,"柜门背部密封止口",-38.5,38.5,bottom-y_shift,top-y_shift,
              door_back+.02/sz,door_back+.25/sz,.8,4)
        leaf=c4d.BaseObject(c4d.Onull);leaf.SetName(label);leaf.InsertUnderLast(body)
        pivot=38.5;theta=math.radians(angle)
        right=c4d.Vector(math.cos(theta),0,math.sin(theta));up=c4d.Vector(0,1,0)
        leaf.SetMl(c4d.Matrix(c4d.Vector(pivot,-y_shift,door_front),right,up,right.Cross(up)))
        # The pivot node stays on the hinge; an inner node keeps the model coordinates legible.
        panel=c4d.BaseObject(c4d.Onull);panel.SetName("门框与玻璃")
        panel.SetRelPos(c4d.Vector(-pivot,0,-door_front));panel.InsertUnderLast(leaf)
        frame(panel,"红色折边门框" if steel else "白色倒角门框",l,r,low,high,door_front,door_back,rim,2 if steel else 1)
        if steel:
            bar(panel,"红色实心铁皮门板",il-.1,ir+.1,ib-.1,it+.1,door_front,door_front+dz*.55,2,.04)
            frame(panel,"门板背面加强折边",il-.05,ir+.05,ib-.05,it+.05,door_front+dz*.5,door_back,.65,2)
        else:
            frame(panel,"黑色玻璃密封胶条",il-.08,ir+.08,ib-.08,it+.08,door_front+dz*.15,door_front+dz*.8,.45,4)
            bar(panel,"透明钢化玻璃",il+.3,ir-.3,ib+.3,it-.3,glass_front,door_front+dz*.65,3,.02)
        cy=(bottom+top)/2
        lock_x=l+rim/2
        bar(panel,"嵌入锁扣底座",lock_x-.85,lock_x+.85,cy-5,cy+5,door_front-.18/sz,door_front+.15/sz,4,.05)
        bar(panel,"红色锁扣按钮",lock_x-.6,lock_x+.6,cy+2,cy+4,door_front-.25/sz,door_front-.12/sz,2,.03)
        disc(panel,"锁芯",lock_x,cy-2,door_front-.2/sz,.45,.12/sz,0)
        for yy in (bottom+7,top-7):
            rod(leaf,"门铰链轴",c4d.Vector(0,yy-2.5,0),c4d.Vector(0,yy+2.5,0),.22,0)
            bar(panel,"门铰链活动页",r-1,38.55,yy-2,yy+2,door_front-.05,door_front+.18,0,.025)
            bar(body,"铰链固定页",38.5,39.3,yy-2.5-y_shift,yy+2.5-y_shift,door_front-.12,door_front+.25,2 if steel else 1,.025)
        if bottom>60:
            sign(panel,"消火栓",155,10)
            sign(panel,"FIRE HYDRANT",149,3)
            sign(panel,"火警119",123,6)
            sign(panel,"FIRE EMERGENCY 119",118,2.4)
        else:
            sign(panel,"灭火器",37,9)
            sign(panel,"FIRE EXTINGUISHERS",31,2.8)

FIRE_SIGN_MESHES = {}

def main():
    values=[op[c4d.ID_USERDATA,key] for key in PARAM_IDS]
    if any(not math.isfinite(float(v)) for v in values): return None
    style,w,h,d,f,ratio,opening,header,angle,hand,leaf_depth,handle_height=values[:12]
    details=values[12:17] if len(values)>=17 else (23,48,70,18,True)
    wood_window=None
    if len(values)>=22 and values[17]:
        wood_window=values[18:22]
        if min(wood_window[:2])<=0 or wood_window[3]<0:return None
    if style not in range(17) or min(w,h,d,f,leaf_depth)<=0 or min(w,h)<1 or min(header,handle_height)<0:
        return None
    if not 15<=ratio<=45 or not 0<=opening<=100 or not 0<=angle<=150 or hand not in (0,1):return None
    if not (10<=details[0]<=35 and 20<=details[1]<=55 and 55<=details[2]<=80 and 10<=details[3]<=25):return None
    root=c4d.BaseObject(c4d.Onull)
    root.SetName("智能门窗模型")
    if style<4:windows(root,w,h,d,f,int(style),ratio,opening)
    elif style<10:doors(root,w,h,d,f,int(style),header,angle,int(hand),leaf_depth,handle_height,details,wood_window)
    elif style<13:glass_doors(root,w,h,d,f,int(style),header,angle,leaf_depth,details,int(hand))
    else:
        upper,lower=values[22:24] if len(values)>=24 else (angle,angle)
        if not 0<=upper<=150 or not 0<=lower<=150:return None
        fire_cabinet(root,w,h,d,upper,lower,int(style)-13)
    return root
'''

def GetOpeningFit(obj, plane):
    size, center, _, _ = GetHierarchyLocalBounds_Gen(obj)
    mg = obj.GetMg()
    axes = (mg.v1,mg.v2,mg.v3)
    lengths = [axis.GetLength() for axis in axes]
    if min(lengths) <= 0.000001:
        raise ValueError("选中对象缩放为零，无法识别门窗方向。")
    axes = [axis.GetNormalized() for axis in axes]
    if any(abs(axes[a].Dot(axes[b])) > 0.001 for a,b in ((0,1),(0,2),(1,2))):
        raise ValueError("对象存在剪切变换，请先整理对象缩放和旋转后再生成。")
    dimensions = [size.x*lengths[0],size.y*lengths[1],size.z*lengths[2]]
    normal = min((2,0,1),key=lambda i:dimensions[i]) if plane == 0 else {1:2,2:0,3:1}[plane]
    wi,hi = {2:(0,1),0:(2,1),1:(0,2)}[normal]
    width,height,depth = dimensions[wi],dimensions[hi],dimensions[normal]
    if min(width,height) < 1.0:
        raise ValueError("对象没有有效门窗面积，请选择矩形占位模型或调整对象正面。")
    right = axes[wi] * (-1 if normal == 0 else 1)
    up = axes[hi] * (-1 if normal == 1 else 1)
    matrix = c4d.Matrix(mg*center-up*(height/2),right,up,right.Cross(up))
    return width,height,depth,matrix

def GetHierarchyLocalBounds_Gen(obj):
    if not obj: return c4d.Vector(0), c4d.Vector(0), c4d.Vector(0), c4d.Vector(0)
    root_mg = obj.GetMg()
    inv_root_mg = ~root_mg
    min_p = c4d.Vector(float('inf')); max_p = c4d.Vector(float('-inf'))
    found = False
    
    def traverse(op):
        nonlocal min_p, max_p, found
        curr_mg = op.GetMg()
        local_to_root = inv_root_mg * curr_mg
        points = None
        if op.CheckType(c4d.Opoint): points = op.GetAllPoints()
        if points:
            found = True
            for p in points:
                p_rel = local_to_root * p
                if p_rel.x < min_p.x: min_p.x = p_rel.x
                if p_rel.x > max_p.x: max_p.x = p_rel.x
                if p_rel.y < min_p.y: min_p.y = p_rel.y
                if p_rel.y > max_p.y: max_p.y = p_rel.y
                if p_rel.z < min_p.z: min_p.z = p_rel.z
                if p_rel.z > max_p.z: max_p.z = p_rel.z
        else:
            cache = op.GetCache()
            if cache: traverse(cache)
            rad = op.GetRad()
            if rad.x > 0.001 or rad.y > 0.001 or rad.z > 0.001:
                found = True
                mp = op.GetMp()
                corners =[
                    c4d.Vector(mp.x-rad.x, mp.y-rad.y, mp.z-rad.z), c4d.Vector(mp.x+rad.x, mp.y-rad.y, mp.z-rad.z),
                    c4d.Vector(mp.x-rad.x, mp.y+rad.y, mp.z-rad.z), c4d.Vector(mp.x+rad.x, mp.y+rad.y, mp.z-rad.z),
                    c4d.Vector(mp.x-rad.x, mp.y-rad.y, mp.z+rad.z), c4d.Vector(mp.x+rad.x, mp.y-rad.y, mp.z+rad.z),
                    c4d.Vector(mp.x-rad.x, mp.y+rad.y, mp.z+rad.z), c4d.Vector(mp.x+rad.x, mp.y+rad.y, mp.z+rad.z)
                ]
                for p in corners:
                    p_rel = local_to_root * p
                    if p_rel.x < min_p.x: min_p.x = p_rel.x
                    if p_rel.x > max_p.x: max_p.x = p_rel.x
                    if p_rel.y < min_p.y: min_p.y = p_rel.y
                    if p_rel.y > max_p.y: max_p.y = p_rel.y
                    if p_rel.z < min_p.z: min_p.z = p_rel.z
                    if p_rel.z > max_p.z: max_p.z = p_rel.z
        for child in op.GetChildren(): traverse(child)

    traverse(obj)
    if not found: return c4d.Vector(0), c4d.Vector(0), c4d.Vector(0), c4d.Vector(0)
    size = max_p - min_p
    center = (min_p + max_p) * 0.5
    return size, center, min_p, max_p

def CheckAndCreateMaterials(doc=None):
    if not doc: doc = c4d.documents.GetActiveDocument()
    if not doc: return
    try:
        materials_data =[
            ("Pro_Wall_White", c4d.Vector(0.9, 0.9, 0.92), False, False, False),
            ("Pro_Floor_Wood", c4d.Vector(0.45, 0.3, 0.15), False, False, False),
            ("Pro_Metal_Dark", c4d.Vector(0.15, 0.15, 0.15), False, False, True),
            ("Pro_Glass", c4d.Vector(0.9, 0.95, 1.0), False, True, False),
            ("Pro_Door_Wood", c4d.Vector(0.3, 0.15, 0.05), False, False, False),
            ("Pro_Light_Spot", c4d.Vector(1.0, 0.95, 0.9), True, False, False),
            ("Pro_Light_Cove", c4d.Vector(1.0, 0.9, 0.8), True, False, False),
            ("Pro_Light_Linear", c4d.Vector(1.0, 1.0, 1.0), True, False, False),
        ]
        for name, color, is_lum, is_trans, is_metal in materials_data:
            mat = doc.SearchMaterial(name)
            if not mat:
                mat = c4d.BaseMaterial(c4d.Mmaterial)
                mat.SetName(name)
                mat[c4d.MATERIAL_COLOR_COLOR] = color
                if is_lum:
                    mat[c4d.MATERIAL_USE_LUMINANCE] = True
                    mat[c4d.MATERIAL_LUMINANCE_COLOR] = color
                    mat[c4d.MATERIAL_LUMINANCE_BRIGHTNESS] = 2.0 
                if is_trans:
                    mat[c4d.MATERIAL_USE_TRANSPARENCY] = True
                    mat[c4d.MATERIAL_TRANSPARENCY_BRIGHTNESS] = 0.9
                    mat[c4d.MATERIAL_USE_COLOR] = False
                    mat[c4d.MATERIAL_USE_REFLECTION] = True
                if is_metal: mat[c4d.MATERIAL_USE_REFLECTION] = True
                doc.InsertMaterial(mat)
    except: pass
    c4d.EventAdd()

# ==============================================================================
# 花花智能建模-C4D端 v1.1 - 智能展厅核心功能库 (Smart Room Builder)
# ==============================================================================
def GetGlobalGeometryBounds(obj):
    min_v = c4d.Vector(1e20)
    max_v = c4d.Vector(-1e20)
    found = False
    
    def traverse(node, current_min, current_max, has_data):
        mg = node.GetMg()
        points =[]
        if node.CheckType(c4d.Opoint) or node.CheckType(c4d.Ospline):
            points = node.GetAllPoints()
        
        if points:
            has_data = True
            for p in points:
                global_p = mg * p
                if global_p.x < current_min.x: current_min.x = global_p.x
                if global_p.x > current_max.x: current_max.x = global_p.x
                if global_p.y < current_min.y: current_min.y = global_p.y
                if global_p.y > current_max.y: current_max.y = global_p.y
                if global_p.z < current_min.z: current_min.z = global_p.z
                if global_p.z > current_max.z: current_max.z = global_p.z
        
        cache = node.GetCache()
        if cache:
            c_min, c_max, c_found = traverse(cache, current_min, current_max, has_data)
            if c_found: has_data = True

        child = node.GetDown()
        while child:
            c_min, c_max, c_found = traverse(child, current_min, current_max, has_data)
            if c_found: has_data = True
            child = child.GetNext()
            
        return current_min, current_max, has_data

    min_v, max_v, found = traverse(obj, min_v, max_v, found)
    return min_v, max_v, found

def SmartWrapper(doc, obj, name_suffix):
    min_v, max_v, success = GetGlobalGeometryBounds(obj)
    if not success:
        mg = obj.GetMg()
        rad = obj.GetRad()
        center = obj.GetMp()
        world_center = mg * center
        min_v = world_center - rad
        max_v = world_center + rad

    size_v = max_v - min_v
    flat_size =[size_v.x, size_v.z]
    length_real = max(flat_size)
    thickness_real = min(flat_size)
    if thickness_real < 0.1: thickness_real = 20.0
    if length_real < 1.0: length_real = 200.0

    # 轴心: Z轴最大值 (背面)
    pivot_pos = c4d.Vector(
        (min_v.x + max_v.x) * 0.5, 
        min_v.y, 
        max_v.z 
    )

    container = c4d.BaseObject(c4d.Onull)
    container.SetName(obj.GetName() + name_suffix)
    
    # 避免受原群组坐标影响
    container.SetAbsPos(pivot_pos) 
    container.SetAbsRot(c4d.Vector(0,0,0)) 
    
    ud_len = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
    ud_len[c4d.DESC_NAME] = "Baked_Length"
    container.AddUserData(ud_len)
    container[c4d.ID_USERDATA, 1] = length_real
    
    ud_thk = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
    ud_thk[c4d.DESC_NAME] = "Baked_Thickness"
    container.AddUserData(ud_thk)
    container[c4d.ID_USERDATA, 2] = thickness_real
    
    ud_h = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
    ud_h[c4d.DESC_NAME] = "Baked_Height"
    container.AddUserData(ud_h)
    container[c4d.ID_USERDATA, 3] = size_v.y
    
    obj_mg = obj.GetMg()
    
    # 插入到文档根目录，确保坐标纯净
    doc.InsertObject(container) 
    
    obj.Remove()
    obj.InsertUnder(container)
    obj.SetMg(obj_mg)
    
    return container, size_v.y

ROOM_GENERATOR_SCRIPT = r"""
import c4d
from c4d import utils

RECESS_VAL = 10.0
OVERLAP = 2.0

def GetMat(name):
    try:
        doc = c4d.documents.GetActiveDocument()
        return doc.SearchMaterial(name)
    except: return None

def MakeBox(name, size, pos, mat_name, parent):
    cube = c4d.BaseObject(c4d.Ocube)
    cube.SetName(name)
    cube[c4d.PRIM_CUBE_LEN] = size
    cube.SetAbsPos(pos)
    mat = GetMat(mat_name)
    if mat: 
        t = cube.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat)
    if parent: cube.InsertUnderLast(parent)
    return cube

def MakeSpot(name, pos, mat_body_name, show_wireframe, parent):
    group = c4d.BaseObject(c4d.Onull)
    group.SetName(name)
    group.SetAbsPos(pos)
    casing = c4d.BaseObject(c4d.Ocylinder)
    casing[c4d.PRIM_CYLINDER_RADIUS] = 4.0
    casing[c4d.PRIM_CYLINDER_HEIGHT] = 2.0
    casing[c4d.PRIM_AXIS] = 2 
    casing.InsertUnder(group)
    bulb = c4d.BaseObject(c4d.Ocylinder)
    bulb[c4d.PRIM_CYLINDER_RADIUS] = 3.5
    bulb[c4d.PRIM_CYLINDER_HEIGHT] = 0.1
    bulb[c4d.PRIM_AXIS] = 2 
    bulb.SetAbsPos(c4d.Vector(0, -1.0, 0))
    mat_spot = GetMat("Pro_Light_Spot")
    if mat_spot:
        t = bulb.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat_spot)
    bulb.InsertUnder(group)
    if show_wireframe:
        real_light = c4d.BaseObject(c4d.Olight)
        real_light[c4d.LIGHT_TYPE] = c4d.LIGHT_TYPE_SPOT
        real_light[c4d.LIGHT_BRIGHTNESS] = 1.0
        real_light[c4d.LIGHT_DETAILS_OUTERANGLE] = 0.8
        real_light.SetAbsRot(c4d.Vector(0, -1.5708, 0)) 
        real_light.SetAbsPos(c4d.Vector(0, -1.5, 0))
        real_light.InsertUnder(group)
    if parent: group.InsertUnderLast(parent)
    return group

def CreateStepBorder(name, w, h, d, x, y, z, border_type, parent):
    M_WHITE = "Pro_Wall_White"
    M_LIGHT_COVE = "Pro_Light_Cove"
    h_lower = 8.0; h_upper = h - h_lower; recess = RECESS_VAL
    top_y = y + h/2.0
    y_upper = top_y - h_upper/2.0
    y_lower = top_y - h_upper - h_lower/2.0
    light_thick = 0.5; light_width = recess * 0.5; y_light = (y_lower + h_lower/2.0) + light_thick/2.0
    extend_len = (recess * 2.0) + 20.0
    
    if border_type == "L": 
        MakeBox(name+"_Low", c4d.Vector(w,h_lower,d), c4d.Vector(x,y_lower,z), M_WHITE, parent)
        MakeBox(name+"_Up", c4d.Vector(w-recess,h_upper,d), c4d.Vector(x-recess/2.0,y_upper,z), M_WHITE, parent)
        MakeBox(name+"_Light", c4d.Vector(light_width,light_thick,d-2.0), c4d.Vector(x+w/2.0-recess/2.0,y_light,z), M_LIGHT_COVE, parent)
    elif border_type == "R": 
        MakeBox(name+"_Low", c4d.Vector(w,h_lower,d), c4d.Vector(x,y_lower,z), M_WHITE, parent)
        MakeBox(name+"_Up", c4d.Vector(w-recess,h_upper,d), c4d.Vector(x+recess/2.0,y_upper,z), M_WHITE, parent)
        MakeBox(name+"_Light", c4d.Vector(light_width,light_thick,d-2.0), c4d.Vector(x-w/2.0+recess/2.0,y_light,z), M_LIGHT_COVE, parent)
    elif border_type == "F": 
        MakeBox(name+"_Low", c4d.Vector(w,h_lower,d), c4d.Vector(x,y_lower,z), M_WHITE, parent)
        MakeBox(name+"_Up", c4d.Vector(w+extend_len,h_upper,d-recess), c4d.Vector(x,y_upper,z-recess/2.0), M_WHITE, parent)
        MakeBox(name+"_Light", c4d.Vector(w+extend_len,light_thick,light_width), c4d.Vector(x,y_light,z+d/2.0-recess/2.0), M_LIGHT_COVE, parent)
    elif border_type == "B": 
        MakeBox(name+"_Low", c4d.Vector(w,h_lower,d), c4d.Vector(x,y_lower,z), M_WHITE, parent)
        MakeBox(name+"_Up", c4d.Vector(w+extend_len,h_upper,d-recess), c4d.Vector(x,y_upper,z+recess/2.0), M_WHITE, parent)
        MakeBox(name+"_Light", c4d.Vector(w+extend_len,light_thick,light_width), c4d.Vector(x,y_light,z-d/2.0+recess/2.0), M_LIGHT_COVE, parent)

def main():
    try:
        parent = op.GetUp()
        if not parent: return c4d.BaseObject(c4d.Onull)

        try: room_w = op[c4d.ID_USERDATA, 1]; room_d = op[c4d.ID_USERDATA, 2]
        except: room_w = 500.0; room_d = 400.0

        def GetP(id, default):
            try: 
                val = parent[c4d.ID_USERDATA, id]
                if val is None: return default
                return val
            except: return default

        # ID Mapping
        enable_ceil_sys = GetP(6, True)
        custom_ceil_obj = GetP(7, None)
        
        if not enable_ceil_sys:
            return c4d.BaseObject(c4d.Onull)
            
        clear_h = GetP(10, 260.0)
        
        if custom_ceil_obj:
            if isinstance(custom_ceil_obj, c4d.BaseObject):
                if custom_ceil_obj.GetEditorMode() != c4d.OBJECT_OFF:
                    custom_ceil_obj.SetEditorMode(c4d.OBJECT_OFF)
                    custom_ceil_obj.SetRenderMode(c4d.OBJECT_OFF)
                
                clone = custom_ceil_obj.GetClone()
                wrapper = c4d.BaseObject(c4d.Onull)
                wrapper.SetName("Custom_Ceiling_Rotator")
                
                custom_off_y = GetP(9, 0.0)
                wrapper.SetAbsPos(c4d.Vector(0, clear_h + custom_off_y, 0))
                
                rot_vec = GetP(8, c4d.Vector(0))
                wrapper.SetAbsRot(rot_vec)
                
                clone.SetAbsPos(c4d.Vector(0,0,0))
                clone.SetAbsRot(c4d.Vector(0,0,0))
                clone.InsertUnder(wrapper)
                clone.SetEditorMode(c4d.OBJECT_ON)
                clone.SetRenderMode(c4d.OBJECT_ON)
                return wrapper
            else:
                return c4d.BaseObject(c4d.Onull)

        ct = GetP(11, 3)
        master_light = GetP(13, True)
        spot_dist = GetP(14, 120.0)
        expand_x = GetP(15, -12.0)
        expand_z = GetP(16, -12.0)
        
        enable_spots = GetP(17, True) and master_light
        enable_side = GetP(18, True)
        show_wire = GetP(19, True)
        margin = GetP(20, 60.0)
        strip_cnt = GetP(21, 3)
        enable_strips = master_light

        root = c4d.BaseObject(c4d.Onull)
        rw = room_w; rd = room_d; total_rh = clear_h + 30.0
        M_WHITE = "Pro_Wall_White"; M_BLACK = "Pro_Metal_Dark"; M_LIGHT_LINEAR = "Pro_Light_Cove"
        
        if ct == 3: # 跌级
            drop_h = 30.0; drop_y = clear_h + drop_h/2.0
            CreateStepBorder("DL", margin, drop_h, rd, -rw/2.0+margin/2.0, drop_y, 0, "L", root)
            CreateStepBorder("DR", margin, drop_h, rd, rw/2.0-margin/2.0, drop_y, 0, "R", root)
            in_w = rw - margin*2.0
            CreateStepBorder("DF", in_w, drop_h, margin, 0, drop_y, -rd/2.0+margin/2.0, "F", root)
            CreateStepBorder("DB", in_w, drop_h, margin, 0, drop_y, rd/2.0-margin/2.0, "B", root)
            MakeBox("TopSlab", c4d.Vector(rw, 2, rd), c4d.Vector(0, total_rh+1.0, 0), M_BLACK, root)
            
            light_w = 8.0 
            light_padding = 35.0 
            in_d_base = rd - margin*2.0
            in_d_extended = in_d_base + (RECESS_VAL * 2.0) + OVERLAP
            if strip_cnt < 1: strip_cnt = 1
            total_light_w = strip_cnt * light_w
            total_panel_w = in_d_extended - total_light_w
            panel_w = total_panel_w / float(strip_cnt + 1)
            real_light_len = in_w - (light_padding * 2.0)
            if real_light_len < 10: real_light_len = 10
            filler_w = light_padding + RECESS_VAL + OVERLAP
            curr_z = -in_d_extended/2.0
            ceil_y_center = total_rh - 2.5
            light_y_center = total_rh - 4.3
            slot_back_y = total_rh - 1.0
            panel_extend_w = in_w + (RECESS_VAL * 2.0) + OVERLAP
            
            for i in range(strip_cnt + 1):
                p_z = curr_z + panel_w/2.0
                MakeBox("Panel", c4d.Vector(panel_extend_w, 5, panel_w), c4d.Vector(0, ceil_y_center, p_z), M_WHITE, root)
                curr_z += panel_w
                if i < strip_cnt:
                    l_z = curr_z + light_w/2.0
                    MakeBox("Slot_Back", c4d.Vector(real_light_len + 2.0, 2, light_w), c4d.Vector(0, slot_back_y, l_z), M_BLACK, root)
                    if enable_strips:
                        MakeBox("Light_Strip", c4d.Vector(real_light_len, 1, light_w), c4d.Vector(0, light_y_center, l_z), M_LIGHT_LINEAR, root)
                    fx_left = (-in_w/2.0 - RECESS_VAL) + filler_w/2.0 - (OVERLAP/2.0)
                    MakeBox("Filler_L", c4d.Vector(filler_w, 5, light_w), c4d.Vector(fx_left, ceil_y_center, l_z), M_WHITE, root)
                    fx_right = -fx_left
                    MakeBox("Filler_R", c4d.Vector(filler_w, 5, light_w), c4d.Vector(fx_right, ceil_y_center, l_z), M_WHITE, root)
                    curr_z += light_w
            
            if enable_spots:
                base_cx = rw/2.0 - margin/2.0
                base_cz = rd/2.0 - margin/2.0
                sy = clear_h
                cx = base_cx + expand_x
                cz = base_cz + expand_z
                MakeSpot("Corner_FL", c4d.Vector(-cx, sy, -cz), M_BLACK, show_wire, root)
                MakeSpot("Corner_FR", c4d.Vector(cx, sy, -cz), M_BLACK, show_wire, root)
                MakeSpot("Corner_BL", c4d.Vector(-cx, sy, cz), M_BLACK, show_wire, root)
                MakeSpot("Corner_BR", c4d.Vector(cx, sy, cz), M_BLACK, show_wire, root)
                
                if spot_dist < 50.0: spot_dist = 50.0
                dist_x = cx * 2.0
                cnt_x = int(dist_x / spot_dist)
                if cnt_x > 0:
                    step = dist_x / (cnt_x + 1)
                    for k in range(1, cnt_x + 1):
                        x = -cx + k*step 
                        MakeSpot(f"Spot_F_{k}", c4d.Vector(x, sy, -cz), M_BLACK, show_wire, root)
                        MakeSpot(f"Spot_B_{k}", c4d.Vector(x, sy, cz), M_BLACK, show_wire, root)
                if enable_side:
                    dist_z = cz * 2.0
                    cnt_z = int(dist_z / spot_dist)
                    if cnt_z > 0:
                        step = dist_z / (cnt_z + 1)
                        for k in range(1, cnt_z + 1):
                            z = -cz + k*step 
                            MakeSpot(f"Spot_L_{k}", c4d.Vector(-cx, sy, z), M_BLACK, show_wire, root)
                            MakeSpot(f"Spot_R_{k}", c4d.Vector(cx, sy, z), M_BLACK, show_wire, root)

        elif ct == 2: # 平顶
            MakeBox("FlatTop", c4d.Vector(rw, 5, rd), c4d.Vector(0, clear_h+2.5, 0), M_WHITE, root)
            if enable_spots:
                cx = rw/2.0 - 50.0 + expand_x
                cz = rd/2.0 - 50.0 + expand_z
                sy = clear_h
                MakeSpot("L1", c4d.Vector(-cx, sy, -cz), M_BLACK, show_wire, root)
                MakeSpot("L2", c4d.Vector(cx, sy, -cz), M_BLACK, show_wire, root)
                MakeSpot("L3", c4d.Vector(-cx, sy, cz), M_BLACK, show_wire, root)
                MakeSpot("L4", c4d.Vector(cx, sy, cz), M_BLACK, show_wire, root)
        
        return root
    except Exception as e:
        print(f"GenError: {e}")
        return c4d.BaseObject(c4d.Onull)
"""

def AddRoomController(room_null, default_h=260.0):
    for id, bc in room_null.GetUserDataContainer():
        room_null.RemoveUserData(id)

    def AddUD(name, dtype, val, unit=0, cycle=None, min_v=None, max_v=None, parent_id=None):
        bc = c4d.GetCustomDataTypeDefault(dtype)
        bc[c4d.DESC_NAME] = name
        if unit: bc[c4d.DESC_UNIT] = unit
        if cycle:
            cycle_bc = c4d.BaseContainer()
            for k, v in cycle.items(): cycle_bc.SetString(k, v)
            bc[c4d.DESC_CYCLE] = cycle_bc
        if min_v is not None: bc[c4d.DESC_MIN] = min_v
        if max_v is not None: bc[c4d.DESC_MAX] = max_v
        if parent_id: bc[c4d.DESC_PARENTGROUP] = parent_id
        
        bc[c4d.DESC_DEFAULT] = val 
        el = room_null.AddUserData(bc)
        if dtype not in[c4d.DTYPE_SEPARATOR, c4d.DTYPE_GROUP]: room_null[el] = val
        return el

    def AddGroup(name):
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
        bc[c4d.DESC_NAME] = name
        bc[c4d.DESC_TITLEBAR] = 1 
        return room_null.AddUserData(bc)

    # UI布局
    grp_wall = AddGroup("基础结构 (墙/地)") # ID 1
    AddUD("接缝修正 (匀速对齐)", c4d.DTYPE_REAL, 20.0, c4d.DESC_UNIT_METER, parent_id=grp_wall) # ID 2
    AddUD("反转朝向", c4d.DTYPE_BOOL, True, parent_id=grp_wall) # ID 3
    AddUD("地面厚度", c4d.DTYPE_REAL, 10.0, c4d.DESC_UNIT_METER, parent_id=grp_wall) # ID 4
    
    grp_ceil = AddGroup("智能吊顶 & 灯光") # ID 5
    AddUD("✅ 启用智能吊顶", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 6
    AddUD("🔗 替换自定义吊顶", c4d.DTYPE_BASELISTLINK, None, parent_id=grp_ceil) # ID 7
    AddUD("自定义吊顶旋转", c4d.DTYPE_VECTOR, c4d.Vector(0), c4d.DESC_UNIT_DEGREE, parent_id=grp_ceil) # ID 8
    AddUD("自定义吊顶偏移 Y", c4d.DTYPE_REAL, 0.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 9
    
    AddUD("吊顶净高", c4d.DTYPE_REAL, default_h, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 10
    opts = {1:"整体吊顶", 2:"平顶", 3:"跌级吊顶(推荐)"}
    AddUD("吊顶款式", c4d.DTYPE_LONG, 3, cycle=opts, parent_id=grp_ceil) # ID 11
    
    AddUD("--- 灯光细节 ---", c4d.DTYPE_SEPARATOR, None, parent_id=grp_ceil) # ID 12
    AddUD("💡 灯光总开关", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 13
    
    AddUD("射灯间距", c4d.DTYPE_REAL, 120.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 14
    AddUD("射灯外扩 X (左右撑开)", c4d.DTYPE_REAL, -12.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 15
    AddUD("射灯外扩 Z (前后撑开)", c4d.DTYPE_REAL, -12.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 16
    
    AddUD("开启射灯", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 17
    AddUD("开启两侧射灯", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 18
    AddUD("显示灯光线框", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 19
    AddUD("吊顶边距", c4d.DTYPE_REAL, 60.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 20
    AddUD("灯带层数", c4d.DTYPE_LONG, 3, min_v=1, max_v=10, parent_id=grp_ceil) # ID 21

    # Tag脚本
    py_tag = room_null.MakeTag(c4d.Tpython)
    py_tag.SetName("RoomDriver_花花智能建模-C4D端_v1.1")
    
    script =[]
    script.append("import c4d")
    script.append("from c4d import utils")
    script.append("")
    script.append("def main():")
    script.append("    room = op.GetObject()")
    script.append("    if not room: return")
    script.append("    walls =[]; floor = None; ceiling_gen = None")
    script.append("    curr = room.GetDown()")
    script.append("    while curr:")
    script.append("        name = curr.GetName()")
    script.append("        if '智能地面' in name: floor = curr")
    script.append("        elif '智能吊顶' in name: ceiling_gen = curr")
    script.append("        else: walls.append(curr)")
    script.append("        curr = curr.GetNext()")
    script.append("    if len(walls) < 4: return")
    script.append("")
    script.append("    try:")
    script.append("        val_gap = room[c4d.ID_USERDATA, 2]")
    script.append("        val_flip = room[c4d.ID_USERDATA, 3]")
    script.append("        floor_h = room[c4d.ID_USERDATA, 4]")
    script.append("        # 强制读取以触发联动")
    script.append("        _ = room[c4d.ID_USERDATA, 6]; _ = room[c4d.ID_USERDATA, 7]")
    script.append("        _ = room[c4d.ID_USERDATA, 14]; _ = room[c4d.ID_USERDATA, 21]")
    script.append("    except: val_gap=20.0; val_flip=True; floor_h=10.0")
    script.append("")
    script.append("    w1, w2, w3, w4 = walls[0], walls[1], walls[2], walls[3]")
    script.append("    def GetBakedSize(obj):")
    script.append("        try: L = obj[c4d.ID_USERDATA, 1]; T = obj[c4d.ID_USERDATA, 2]")
    script.append("        except: L=200.0; T=20.0")
    script.append("        return L, T")
    script.append("    l1, t1 = GetBakedSize(w1); l2, t2 = GetBakedSize(w2)")
    script.append("    l3, t3 = GetBakedSize(w3); l4, t4 = GetBakedSize(w4)")
    script.append("")
    script.append("    offset = utils.Rad(180) if not val_flip else 0")
    script.append("    w1.SetRelRot(c4d.Vector(utils.Rad(180)+offset,0,0)); w2.SetRelRot(c4d.Vector(utils.Rad(-90)+offset,0,0))")
    script.append("    w3.SetRelRot(c4d.Vector(utils.Rad(0)+offset,0,0)); w4.SetRelRot(c4d.Vector(utils.Rad(90)+offset,0,0))")
    script.append("")
    script.append("    # 花花智能建模-C4D端 v1.1: 极简算法，不依赖标准厚度，只看 Gap")
    script.append("    base_w = max(l1, l3)")
    script.append("    base_d = max(l2, l4)")
    script.append("    z_dist = (base_d / 2.0) + val_gap")
    script.append("    x_dist = (base_w / 2.0) + val_gap")
    script.append("")
    script.append("    w1.SetRelPos(c4d.Vector(0,0,-z_dist)); w3.SetRelPos(c4d.Vector(0,0,z_dist))")
    script.append("    w2.SetRelPos(c4d.Vector(x_dist,0,0)); w4.SetRelPos(c4d.Vector(-x_dist,0,0))")
    script.append("")
    script.append("    ceil_w = (x_dist * 2.0)")
    script.append("    ceil_d = (z_dist * 2.0)")
    script.append("")
    script.append("    if floor:")
    script.append("        floor[c4d.PRIM_CUBE_LEN] = c4d.Vector(ceil_w, floor_h, ceil_d)")
    script.append("        floor.SetRelPos(c4d.Vector(0, -floor_h/2.0, 0))")
    script.append("    if ceiling_gen:")
    script.append("        ceiling_gen[c4d.ID_USERDATA, 1] = ceil_w")
    script.append("        ceiling_gen[c4d.ID_USERDATA, 2] = ceil_d")
    script.append("        ceiling_gen.SetDirty(c4d.DIRTYFLAGS_DATA)")
    script.append("        ceiling_gen.SetDirty(c4d.DIRTYFLAGS_CACHE)")
    script.append("    c4d.EventAdd()")

    py_tag[c4d.TPYTHON_CODE] = "\n".join(script)

def CreateSmartRoom(doc):
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
    
    # 核心：群组识别
    if len(sel) == 1 and sel[0].GetDown():
        group = sel[0]
        sel =[]
        child = group.GetDown()
        while child:
            sel.append(child)
            child = child.GetNext()
    
    if len(sel) != 4:
        gui.MessageDialog("请确保选中了 4 个墙体对象 (或 1 个包含 4 面墙的组)！")
        return

    try:
        # 花花智能建模-C4D端 v1.1: 取消 reverse，恢复列表 Top->Bottom = 前->右->后->左
        sel.reverse() 

        doc.ExecutePasses(None, True, True, True, c4d.BUILDFLAGS_NONE)
        doc.StartUndo()
        CheckAndCreateMaterials(doc)

        room_group = c4d.BaseObject(c4d.Onull)
        room_group.SetName("智能展厅_花花智能建模-C4D端_v1.1 (防炸稳定版)")
        room_group[c4d.NULLOBJECT_DISPLAY] = 14
        room_group[c4d.NULLOBJECT_ORIENTATION] = 1
        room_group[c4d.NULLOBJECT_RADIUS] = 200
        doc.InsertObject(room_group)
        doc.AddUndo(c4d.UNDOTYPE_NEW, room_group)

        max_wall_h = 260.0
        suffixes =["_前", "_右", "_后", "_左"]
        
        for i, obj in enumerate(sel):
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
            container, h = SmartWrapper(doc, obj, suffixes[i])
            if h > max_wall_h: max_wall_h = h
            # 关键：先从世界根目录移除，再加入组
            container.Remove()
            container.InsertUnderLast(room_group)
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, container)

        floor = c4d.BaseObject(c4d.Ocube)
        floor.SetName("智能地面_Floor")
        floor[c4d.PRIM_CUBE_LEN] = c4d.Vector(500, 10, 400)
        floor[c4d.PRIM_CUBE_DOFILLET] = True 
        floor[c4d.PRIM_CUBE_FRAD] = 0.5
        tag = floor.MakeTag(c4d.Ttexture)
        mat = doc.SearchMaterial("Pro_Floor_Wood")
        if mat: tag.SetMaterial(mat)
        tag[c4d.TEXTURETAG_PROJECTION] = 6; tag[c4d.TEXTURETAG_LENGTHX] = 200; tag[c4d.TEXTURETAG_LENGTHY] = 200
        floor.InsertUnderLast(room_group)
        doc.AddUndo(c4d.UNDOTYPE_NEW, floor)

        gen = c4d.BaseObject(c4d.Opython)
        gen.SetName("智能吊顶_Generator")
        bc_hide = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
        bc_hide[c4d.DESC_NAME] = "Auto_W"; bc_hide[c4d.DESC_HIDE] = True 
        gen.AddUserData(bc_hide); gen.AddUserData(bc_hide)
        gen[c4d.OPYTHON_CODE] = ROOM_GENERATOR_SCRIPT
        gen.InsertUnderLast(room_group)
        doc.AddUndo(c4d.UNDOTYPE_NEW, gen)

        AddRoomController(room_group, default_h=max_wall_h)

        doc.SetActiveObject(room_group)
        doc.EndUndo()
        c4d.EventAdd()
        
    except Exception as e:
        gui.MessageDialog(f"生成失败，错误信息:\n{e}\n\n请检查控制台(Shift+F10)获取详细信息")
        traceback.print_exc()

# ==============================================================================
# 花花智能建模-C4D端 v1.1 - 智能弯曲墙体核心功能库 (Curved Wall Builder)
# ==============================================================================
def GetSmartDensity(obj):
    """
    计算最佳初始密度 (0.0 - 1.0)
    基于面积反向逻辑: 大面积->5cm(1.0), 小面积->15cm(0.0)
    """
    if not obj or not obj.CheckType(c4d.Oextrude):
        return 0.5 # 默认中间值

    try:
        rad = obj.GetRad()
        width = rad.x * 2.0
        height = rad.y * 2.0
        area = width * height
        
        area_min = 10000.0   # 1m x 1m
        area_max = 500000.0  # 10m x 5m
        
        if area <= area_min: return 0.0       # 小面积用稀疏
        if area >= area_max: return 1.0       # 大面积用密集
        
        # 线性插值
        ratio = (area - area_min) / (area_max - area_min)
        return ratio
    except:
        return 0.5

def OptimizeObjectTopology(obj):
    """
    花花智能建模-C4D端 v1.1: 仅设置基础属性 (N-gon, 独立控制等)，尺寸交由 Tag 驱动
    """
    if obj is None: return

    # 1. 样条优化
    if obj.GetInfo() & c4d.OBJECT_ISSPLINE:
        try:
            obj[c4d.SPLINEOBJECT_INTERPOLATION] = c4d.SPLINEOBJECT_INTERPOLATION_NATURAL
            obj[c4d.SPLINEOBJECT_SUB] = 48 
        except: pass

    # 2. 挤压对象 (Extrude) 基础设置
    elif obj.CheckType(c4d.Oextrude):
        try:
            # 开启独立控制 (ID 3008)
            obj.SetParameter(c4d.DescID(3008), True, c4d.DESCFLAGS_SET_0)
            # 设置细分类型为 常规网格 (ID 3002 = 4)
            obj.SetParameter(c4d.DescID(3002), 4, c4d.DESCFLAGS_SET_0)
            # 确保封顶启用
            obj.SetParameter(c4d.DescID(2999), True, c4d.DESCFLAGS_SET_0)
            obj.SetParameter(c4d.DescID(3000), True, c4d.DESCFLAGS_SET_0)
        except Exception as e:
            print(f"基础优化失败: {e}")

    # 3. 立方体优化 (Cube)
    elif obj.CheckType(c4d.Ocube):
        try:
            rad = obj.GetRad(); len_x = rad.x * 2.0
            segs = int(len_x / 10.0)
            if segs < 1: segs = 1; 
            if segs > 400: segs = 400 
            obj[c4d.PRIM_CUBE_SUBX] = segs
        except: pass

    child = obj.GetDown()
    while child:
        OptimizeObjectTopology(child)
        child = child.GetNext()

def AddSmartController(obj, fit_mode_default, initial_density):
    # --- 1. 创建 User Data ---
    bc1 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc1[c4d.DESC_NAME] = "偏移 (Offset)"; bc1[c4d.DESC_UNIT] = c4d.DESC_UNIT_PERCENT; bc1[c4d.DESC_MIN] = 0.0; bc1[c4d.DESC_MAX] = 1.0; bc1[c4d.DESC_STEP] = 0.01
    el1 = obj.AddUserData(bc1); obj[el1] = 0.0
    id1 = int(el1[1].id) 
    
    bc2 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc2[c4d.DESC_NAME] = "结束位置 (End)"; bc2[c4d.DESC_UNIT] = c4d.DESC_UNIT_PERCENT; bc2[c4d.DESC_MIN] = 0.0; bc2[c4d.DESC_MAX] = 1.0; bc2[c4d.DESC_STEP] = 0.01
    el2 = obj.AddUserData(bc2); obj[el2] = 1.0
    id2 = int(el2[1].id)
    
    bc3 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_LONG); bc3[c4d.DESC_NAME] = "模式 (Mode)"; 
    cycle = c4d.BaseContainer(); cycle.SetString(0, "匹配样条 (伸缩)"); cycle.SetString(1, "保持长度 (不伸缩)"); 
    bc3[c4d.DESC_CYCLE] = cycle
    el3 = obj.AddUserData(bc3); obj[el3] = int(fit_mode_default)
    id3 = int(el3[1].id)
    
    bc4 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BOOL); bc4[c4d.DESC_NAME] = "翻转墙体 (Flip)"; 
    el4 = obj.AddUserData(bc4); obj[el4] = True 
    id4 = int(el4[1].id)

    bc5 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc5[c4d.DESC_NAME] = "变形器旋转 H"; bc5[c4d.DESC_UNIT] = c4d.DESC_UNIT_DEGREE; bc5[c4d.DESC_STEP] = 1.0
    el5 = obj.AddUserData(bc5); obj[el5] = c4d.utils.Rad(0.0) 
    id5 = int(el5[1].id)

    bc6 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc6[c4d.DESC_NAME] = "变形器旋转 P"; bc6[c4d.DESC_UNIT] = c4d.DESC_UNIT_DEGREE; bc6[c4d.DESC_STEP] = 1.0
    el6 = obj.AddUserData(bc6); obj[el6] = c4d.utils.Rad(180.0) 
    id6 = int(el6[1].id)

    bc7 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc7[c4d.DESC_NAME] = "变形器旋转 B"; bc7[c4d.DESC_UNIT] = c4d.DESC_UNIT_DEGREE; bc7[c4d.DESC_STEP] = 1.0
    el7 = obj.AddUserData(bc7); obj[el7] = c4d.utils.Rad(0.0) 
    id7 = int(el7[1].id)

    bc8 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_LONG); bc8[c4d.DESC_NAME] = "样条精度 (Spline Sub)"; bc8[c4d.DESC_MIN] = 0; bc8[c4d.DESC_MAX] = 500; bc8[c4d.DESC_STEP] = 1
    el8 = obj.AddUserData(bc8); obj[el8] = 48 
    id8 = int(el8[1].id)

    # === 新增：网格疏密控制 ===
    bc9 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
    bc9[c4d.DESC_NAME] = "网格疏密 (Density)"
    bc9[c4d.DESC_UNIT] = c4d.DESC_UNIT_PERCENT
    bc9[c4d.DESC_MIN] = 0.0
    bc9[c4d.DESC_MAX] = 1.0
    bc9[c4d.DESC_STEP] = 0.01
    bc9[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_REALSLIDER 
    el9 = obj.AddUserData(bc9)
    obj[el9] = initial_density 
    id9 = int(el9[1].id)

    # --- 2. 生成 Python 标签 ---
    py_tag = obj.MakeTag(c4d.Tpython)
    py_tag.SetName("SmartDriver_CN_花花智能建模-C4D端_v1.1")
    
    lines =[]
    lines.append("import c4d")
    lines.append("def main():")
    lines.append("    try:")
    lines.append("        host = op.GetObject()")
    lines.append("        if not host: return")
    lines.append("")
    lines.append("        val_offset  = host[c4d.ID_USERDATA, " + str(id1) + "]")
    lines.append("        val_to      = host[c4d.ID_USERDATA, " + str(id2) + "]")
    lines.append("        val_mode    = host[c4d.ID_USERDATA, " + str(id3) + "]")
    lines.append("        val_flip    = host[c4d.ID_USERDATA, " + str(id4) + "]")
    lines.append("        val_h       = host[c4d.ID_USERDATA, " + str(id5) + "]")
    lines.append("        val_p       = host[c4d.ID_USERDATA, " + str(id6) + "]")
    lines.append("        val_b       = host[c4d.ID_USERDATA, " + str(id7) + "]")
    lines.append("        val_sub     = host[c4d.ID_USERDATA, " + str(id8) + "]")
    lines.append("        val_density = host[c4d.ID_USERDATA, " + str(id9) + "]")
    lines.append("")
    lines.append("        grid_size = 15.0 - (val_density * 10.0)")
    lines.append("")
    lines.append("        wall_obj = None")
    lines.append("        spline_obj = None")
    lines.append("")
    lines.append("        child = host.GetDown()")
    lines.append("        while child:")
    lines.append("            if child.GetInfo() & c4d.OBJECT_ISSPLINE:")
    lines.append("                spline_obj = child")
    lines.append("            else:")
    lines.append("                wall_obj = child")
    lines.append("            child = child.GetNext()")
    lines.append("")
    lines.append("        if spline_obj and spline_obj.CheckType(c4d.Ospline):")
    lines.append("             if spline_obj[c4d.SPLINEOBJECT_SUB] != int(val_sub):")
    lines.append("                 spline_obj[c4d.SPLINEOBJECT_SUB] = int(val_sub)")
    lines.append("")
    lines.append("        if wall_obj:")
    lines.append("            target_wrot = c4d.utils.Rad(180) if val_flip else 0.0")
    lines.append("            cur_wrot = wall_obj.GetRelRot()")
    lines.append("            if abs(cur_wrot.x - target_wrot) > 0.001:")
    lines.append("                wall_obj.SetRelRot(c4d.Vector(target_wrot, 0, 0))")
    lines.append("")
    lines.append("            def UpdateExtrude(obj, size):")
    lines.append("                if not obj: return")
    lines.append("                if obj.CheckType(c4d.Oextrude):")
    lines.append("                    if abs(obj[3004] - size) > 0.01:")
    lines.append("                        obj[3004] = size")
    lines.append("                curr = obj.GetDown()")
    lines.append("                while curr:")
    lines.append("                    UpdateExtrude(curr, size)")
    lines.append("                    curr = curr.GetNext()")
    lines.append("")
    lines.append("            UpdateExtrude(wall_obj, grid_size)")
    lines.append("")
    lines.append("            def FindDeformer(obj):")
    lines.append("                if not obj: return None")
    lines.append("                curr = obj.GetDown()")
    lines.append("                while curr:")
    lines.append("                    if curr.CheckType(1019221): return curr")
    lines.append("                    curr = curr.GetNext()")
    lines.append("                return None")
    lines.append("")
    lines.append("            deformer = FindDeformer(wall_obj)")
    lines.append("            if deformer:")
    lines.append("                deformer[1004] = val_offset")
    lines.append("                deformer[1003] = val_to")
    lines.append("                if val_mode is not None:")
    lines.append("                    deformer[1012] = int(val_mode)")
    lines.append("                tv = c4d.Vector(val_h, val_p, val_b)")
    lines.append("                cv = deformer.GetRelRot()")
    lines.append("                if (tv - cv).GetLength() > 0.001:")
    lines.append("                    deformer.SetRelRot(tv)")
    lines.append("    except: pass")
    
    py_tag[c4d.TPYTHON_CODE] = "\n".join(lines)

def NormalizeWallGroup(doc, obj):
    old_mg = obj.GetMg()
    new_mg = c4d.Matrix(old_mg)
    new_mg.off = c4d.Vector(0,0,0)
    obj.SetMg(new_mg)

def CreateCurvedWall(doc, wall_parts, spline_obj, fit_mode):
    if len(wall_parts) > 1:
        group_null = c4d.BaseObject(c4d.Onull)
        group_null.SetName("Wall_Group_Temp")
        doc.InsertObject(group_null)
        for part in wall_parts:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, part)
            mat = part.GetMg()
            part.Remove()
            part.InsertUnder(group_null)
            part.SetMg(mat)
        wall_obj = group_null
    else:
        wall_obj = wall_parts[0]

    OptimizeObjectTopology(wall_obj) 
    OptimizeObjectTopology(spline_obj)
    
    calc_obj = wall_obj
    if wall_obj.CheckType(c4d.Onull) and wall_obj.GetDown():
        calc_obj = wall_obj.GetDown() 
    initial_density = GetSmartDensity(calc_obj)
    
    container = c4d.BaseObject(c4d.Onull)
    container.SetName("智能墙体组_" + wall_obj.GetName())
    container[c4d.NULLOBJECT_DISPLAY] = 2 
    container[c4d.NULLOBJECT_RADIUS] = 20.0 
    container[c4d.NULLOBJECT_ORIENTATION] = 1 
    
    doc.InsertObject(container, pred=wall_obj)
    doc.AddUndo(c4d.UNDOTYPE_NEW, container)
    
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, wall_obj) 
    wall_obj.Remove()
    wall_obj.InsertUnder(container) 
    
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, spline_obj)
    spline_obj.Remove()
    spline_obj.InsertUnder(container)
    
    NormalizeWallGroup(doc, wall_obj) 
    
    swrap = c4d.BaseObject(ID_SPLINEWRAP)
    if not swrap: return
    swrap.SetName("样条约束 (SplineWrap)") 
    swrap[1001] = spline_obj
    swrap[1006] = 1 # +X
    swrap[1012] = int(fit_mode)
    swrap[1009] = False
    swrap.SetRelRot(c4d.Vector(0, c4d.utils.Rad(180), 0))
    
    doc.InsertObject(swrap, parent=wall_obj)
    doc.AddUndo(c4d.UNDOTYPE_NEW, swrap)
    
    AddSmartController(container, fit_mode, initial_density) 
    
    doc.SetActiveObject(container)
    wall_obj.SetRelRot(c4d.Vector(c4d.utils.Rad(180), 0, 0)) 
    
    c4d.EventAdd()
    return container

# ------------------------------------------------------------------------------
# 资产库画布类 (AssetViewer)
# ------------------------------------------------------------------------------
class OpeningPreviewArea(gui.GeUserArea):
    def __init__(self):
        super(OpeningPreviewArea,self).__init__()
        self.preset = 0
        self.bitmap = None
        self._cache = {}

    def GetMinSize(self):
        return 180,120

    def SetPreset(self,preset):
        self.preset = preset
        if preset not in self._cache:
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)),"res","opening_previews","preset_%02d.png" % preset)
            bmp = bitmaps.BaseBitmap()
            try:
                result = bmp.InitWith(path)
                if result[0] == c4d.IMAGERESULT_OK and bmp.GetBw()>0 and bmp.GetBh()>0:
                    self._cache[preset] = bmp
                else:
                    print("[Opening Preview] Unable to load: " + path)
            except Exception as exc:
                print("[Opening Preview] %s: %s" % (path,exc))
        self.bitmap = self._cache.get(preset)
        self.Redraw()

    def DrawMsg(self,x1,y1,x2,y2,msg):
        self.OffScreenOn()
        self.SetClippingRegion(x1,y1,x2,y2)
        width,height = self.GetWidth(),self.GetHeight()
        background = c4d.Vector(.16)
        self.DrawSetPen(background)
        self.DrawRectangle(0,0,width,height)
        bmp = self.bitmap
        if bmp is not None:
            scale = min(max(1,width-12)/float(bmp.GetBw()),max(1,height-12)/float(bmp.GetBh()))
            w,h = int(bmp.GetBw()*scale),int(bmp.GetBh()*scale)
            self.DrawBitmap(bmp,(width-w)//2,(height-h)//2,w,h,0,0,bmp.GetBw(),bmp.GetBh(),c4d.BMP_ALLOWALPHA)
        else:
            self.DrawSetTextCol(c4d.Vector(.85),background)
            self.DrawText("预览图未安装",8,16)


class AssetViewer(gui.GeUserArea):
    def __init__(self, dialog):
        self.parent_dialog = dialog
        self.assets =[]          
        self.icon_size = 130      
        self.gap = 10 
        self.text_height = 25 
        self.margin = 10
        
        self.bg_color = c4d.Vector(0.25)
        self.text_color = c4d.Vector(0.9)
        self.cols = 1             
        self.needed_height = 200 
        self.last_click_time = 0
        self.last_click_index = -1
        self.selected_index = -1 

    def GetMinSize(self): return 100, self.needed_height

    def _get_layout_metrics(self, width=None):
        area_width = width if width is not None else self.GetWidth()
        if area_width < 10:
            area_width = 400
        cell_w = self.icon_size + self.gap
        cell_h = self.icon_size + self.gap + self.text_height
        available_w = max(cell_w, area_width - (self.margin * 2))
        cols = max(1, int((available_w + self.gap) / cell_w))
        rows = int(math.ceil(float(len(self.assets)) / float(cols))) if self.assets else 1
        needed_h = int((rows * cell_h) + (self.margin * 2))
        return area_width, cell_w, cell_h, cols, rows, needed_h

    def DrawThumbnailPlaceholder(self, x_pos, y_pos):
        self.DrawSetPen(c4d.Vector(0.18))
        self.DrawRectangle(x_pos, y_pos, x_pos + self.icon_size, y_pos + self.icon_size)
        self.DrawSetPen(c4d.Vector(0.38))
        self.DrawBorder(c4d.BORDER_THIN_OUT, x_pos, y_pos, x_pos + self.icon_size, y_pos + self.icon_size)
        self.DrawSetTextCol(c4d.Vector(0.72), c4d.Vector(0.18))
        text_x = x_pos + max(8, int((self.icon_size - 72) / 2))
        text_y = y_pos + int((self.icon_size - 16) / 2)
        self.DrawText("没有预览图", text_x, text_y)

    def DrawMsg(self, x1, y1, x2, y2, msg):
        self.OffScreenOn()
        self.DrawSetPen(self.bg_color)
        self.DrawRectangle(x1, y1, x2, y2)
        if not self.assets:
            self.DrawSetTextCol(self.text_color, self.bg_color)
            self.DrawText("无符合条件的资产", 20, 20)
            return
        area_width, cell_w, cell_h, cols, rows, needed_h = self._get_layout_metrics()
        self.cols = cols
        if needed_h != self.needed_height:
            self.needed_height = needed_h
        try:
            print("[AssetViewer Draw Start] count=%s" % str(len(self.assets)))
        except Exception:
            pass
        for i, asset in enumerate(self.assets):
            try:
                row = i // self.cols
                col = i % self.cols
                x_pos = self.margin + col * cell_w
                y_pos = self.margin + row * cell_h
                name_value = asset.get('name', '') if isinstance(asset, dict) else ''
                print("[AssetViewer Draw Item] index=%s name=%s x=%s y=%s row=%s column=%s" % (str(i), str(name_value), str(x_pos), str(y_pos), str(row), str(col)))
                if i == self.selected_index:
                    self.DrawSetPen(c4d.Vector(0.4, 0.3, 0.2)) 
                    self.DrawRectangle(x_pos-2, y_pos-2, x_pos+self.icon_size+2, y_pos+self.icon_size+30)
                    self.DrawSetPen(c4d.Vector(1.0, 0.6, 0.0)) 
                    self.DrawBorder(c4d.BORDER_THIN_OUT, x_pos-2, y_pos-2, x_pos+self.icon_size+2, y_pos+self.icon_size+30)
                bmp = asset.get('bmp', None)
                if bmp and bmp.GetBw() > 0 and bmp.GetBh() > 0:
                    try:
                        self.DrawBitmap(bmp, x_pos, y_pos, self.icon_size, self.icon_size, 0, 0, bmp.GetBw(), bmp.GetBh(), c4d.BMP_ALLOWALPHA)
                    except Exception as e:
                        try:
                            print("[AssetViewer Thumbnail Error] index=%s name=%s error=%s" % (str(i), str(name_value), str(e)))
                        except Exception:
                            pass
                        self.DrawThumbnailPlaceholder(x_pos, y_pos)
                else:
                    self.DrawThumbnailPlaceholder(x_pos, y_pos)
                is_fav = asset.get('is_fav', False)
                star_x = x_pos + self.icon_size - 25; star_y = y_pos + 5
                if is_fav:
                    self.DrawSetTextCol(c4d.Vector(1, 0.8, 0), self.bg_color) 
                    self.DrawText("★", star_x, star_y)
                else:
                    self.DrawSetTextCol(c4d.Vector(0.5), self.bg_color) 
                    self.DrawText("☆", star_x, star_y)
                name = asset['name']
                if len(name) > 15: name = name[:13] + ".."
                self.DrawSetTextCol(self.text_color, self.bg_color)
                self.DrawText(name, x_pos, y_pos + self.icon_size + 5)
            except Exception as e:
                try:
                    print("[AssetViewer Draw Error] index=%s asset=%s error=%s" % (str(i), str(asset), str(e)))
                except Exception:
                    pass
                continue
        try:
            print("[AssetViewer Draw End]")
        except Exception:
            pass

    def InputEvent(self, msg):
        dev = msg.GetLong(c4d.BFM_INPUT_DEVICE)
        chn = msg.GetLong(c4d.BFM_INPUT_CHANNEL)
        if dev == c4d.BFM_INPUT_MOUSE and chn == c4d.BFM_INPUT_MOUSELEFT:
            lx, ly = GetLocalCursorPos(self, msg)
            area_width, cell_w, cell_h, cols, rows, needed_h = self._get_layout_metrics()
            self.cols = cols
            col = int((lx - self.margin) / cell_w)
            row = int((ly - self.margin) / cell_h)
            index = row * self.cols + col
            if 0 <= index < len(self.assets):
                rel_x = (lx - self.margin) % cell_w
                rel_y = (ly - self.margin) % cell_h
                if rel_x > (self.icon_size - 30) and rel_x < self.icon_size and rel_y < 30:
                    self.parent_dialog.ToggleFavorite(index)
                    return True
                self.selected_index = index
                self.Redraw()
                curr_time = time.time()
                if index == self.last_click_index and (curr_time - self.last_click_time) < 0.5:
                    self.last_click_index = -1 
                    self.parent_dialog.LoadAsset(self.assets[index]['path'])
                else:
                    self.last_click_index = index
                    self.last_click_time = curr_time
            else:
                self.selected_index = -1
                self.Redraw()
            return True
        return False

    def RecalculateHeight(self):
        if not self.assets: self.needed_height = 100; return
        area_width, cell_w, cell_h, cols, rows, needed_h = self._get_layout_metrics()
        self.cols = cols
        self.needed_height = needed_h

    def UpdateAssets(self, new_assets):
        self.assets = new_assets
        self.RecalculateHeight()
        self.Redraw()
        try:
            self.parent_dialog.LayoutChanged(ID_ASSET_USER_AREA)
            self.parent_dialog.LayoutChanged(ID_ASSET_SCROLL_GRP)
        except Exception:
            pass

    def UpdateScale(self, size):
        self.icon_size = size
        self.RecalculateHeight()
        self.Redraw()
        try:
            self.parent_dialog.LayoutChanged(ID_ASSET_USER_AREA)
            self.parent_dialog.LayoutChanged(ID_ASSET_SCROLL_GRP)
        except Exception:
            pass
        
    def GetSelectedIndex(self): return self.selected_index
    def GetAssetPath(self, index): return self.assets[index]['path'] if 0 <= index < len(self.assets) else None


class LoadProgressBar(gui.GeUserArea):
    def __init__(self):
        super(LoadProgressBar, self).__init__()
        self.percent = 0.0

    def SetProgress(self, percent):
        try:
            self.percent = max(0.0, min(100.0, float(percent)))
        except Exception:
            self.percent = 0.0
        self.Redraw()

    def GetMinSize(self):
        return 100, 8

    def DrawMsg(self, x1, y1, x2, y2, msg):
        width = max(1, x2 - x1)
        height = max(3, y2 - y1)
        self.OffScreenOn()
        self.DrawSetPen(c4d.Vector(0.12, 0.12, 0.12))
        self.DrawRectangle(x1, y1, x2, y2)
        fill_width = int(width * (self.percent / 100.0))
        if fill_width > 0:
            self.DrawSetPen(c4d.Vector(0.36, 0.52, 0.95))
            self.DrawRectangle(x1, y1, x1 + fill_width, y1 + height)
        self.DrawSetPen(c4d.Vector(0.25, 0.25, 0.25))
        self.DrawBorder(c4d.BORDER_THIN_IN, x1, y1, x2, y2)


# ==============================================================================
# 主 Dialog 类
# ==============================================================================
class AdminAuthDialog(gui.GeDialog):
    def __init__(self, parent_dialog):
        super(AdminAuthDialog, self).__init__()
        self.parent_dialog = parent_dialog

    def CreateLayout(self):
        self.SetTitle("账号授权")
        self.GroupBegin(13000, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0)
        self.GroupBorderSpace(12, 12, 12, 12)
        self.AddStaticText(ID_ADMIN_AUTH_TITLE_TEXT, c4d.BFH_SCALEFIT, name="登录花花账号")

        self.GroupBegin(13001, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="账号:")
        self.AddEditText(ID_ADMIN_ACCOUNT, c4d.BFH_SCALEFIT, 220, 0)
        self.GroupEnd()
        self.GroupBegin(13002, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="密码:")
        self.AddEditText(ID_ADMIN_PASSWORD, c4d.BFH_SCALEFIT, 220, 0)
        self.GroupEnd()

        self.GroupBegin(13003, c4d.BFH_LEFT, 5, 1)
        self.AddButton(ID_ADMIN_LOGIN_BTN, c4d.BFH_LEFT, name="登录")
        self.AddButton(ID_ADMIN_REGISTER_OPEN_BTN, c4d.BFH_LEFT, name="注册账号")
        self.AddButton(ID_ADMIN_REDEEM_OPEN_BTN, c4d.BFH_LEFT, name="兑换 CDK")
        self.AddButton(ID_ADMIN_LOGOUT_BTN, c4d.BFH_LEFT, name="退出登录")
        self.AddButton(ID_ADMIN_RELOGIN_BTN, c4d.BFH_LEFT, name="重新登录")
        self.GroupEnd()

        self.AddSeparatorH(6)
        self.AddStaticText(ID_ADMIN_USER_TEXT, c4d.BFH_SCALEFIT, name="当前账号：未登录")
        self.AddStaticText(ID_ADMIN_LICENSE_TEXT, c4d.BFH_SCALEFIT, name="授权状态：未授权")
        self.AddStaticText(ID_ADMIN_PLAN_TEXT, c4d.BFH_SCALEFIT, name="套餐：- / 到期：-")
        self.AddStaticText(ID_ADMIN_DEVICE_TEXT, c4d.BFH_SCALEFIT, name="设备记录：-")
        self.AddStaticText(ID_ADMIN_MACHINE_TEXT, c4d.BFH_SCALEFIT, name="电脑标识：-")
        self.AddStaticText(ID_ADMIN_REMAINING_TEXT, c4d.BFH_SCALEFIT, name="剩余时间：-")
        self.AddStaticText(ID_ADMIN_UPDATE_TEXT, c4d.BFH_SCALEFIT, name="当前版本：v" + CURRENT_VERSION + " / 最新版本：-")
        self.AddStaticText(ID_ADMIN_MESSAGE_TEXT, c4d.BFH_SCALEFIT, name="请输入后台账号密码")

        self.GroupBegin(13004, c4d.BFH_RIGHT, 1, 1)
        self.AddButton(ID_ADMIN_AUTH_CLOSE_BTN, c4d.BFH_RIGHT, name="关闭")
        self.GroupEnd()
        self.GroupEnd()
        return True

    def InitValues(self):
        self.RefreshValues()
        return True

    def RefreshValues(self):
        parent = self.parent_dialog
        try:
            user = parent.admin_user or {}
            license_info = parent.admin_license or {}
            update_info = parent.admin_update_info or {}
            account = parent._admin_account_label()
            auth_text = parent._admin_auth_status_text()
            plan = license_info.get("plan") or license_info.get("planName") or "-"
            expires = license_info.get("expiresAt") or license_info.get("expireAt") or "-"
            current_devices = license_info.get("currentDevices", license_info.get("deviceCount", "-"))
            latest = update_info.get("latestVersion") or update_info.get("latest_version") or update_info.get("version") or "-"
            remaining = parent._format_remaining_time(expires)
            is_logged_in = bool(parent.admin_token)
            machine_prefix = parent._admin_machine_id_prefix()

            self.SetString(ID_ADMIN_AUTH_TITLE_TEXT, "账号授权" if is_logged_in else "登录花花账号")
            self.SetString(ID_ADMIN_USER_TEXT, "当前账号：" + account)
            self.SetString(ID_ADMIN_LICENSE_TEXT, "授权状态：" + auth_text)
            self.SetString(ID_ADMIN_PLAN_TEXT, "套餐：" + str(plan) + " / 到期：" + str(expires))
            self.SetString(ID_ADMIN_DEVICE_TEXT, "设备记录：" + str(current_devices))
            self.SetString(ID_ADMIN_MACHINE_TEXT, "电脑标识：" + machine_prefix)
            self.SetString(ID_ADMIN_REMAINING_TEXT, "剩余时间：" + remaining)
            self.SetString(ID_ADMIN_UPDATE_TEXT, "当前版本：v" + CURRENT_VERSION + " / 最新版本：" + str(latest))
            message = parent.admin_message or parent.core_disabled_reason or ("授权通过" if parent.core_enabled else "请输入后台账号密码")
            self.SetString(ID_ADMIN_MESSAGE_TEXT, message)
            self.Enable(ID_ADMIN_LOGOUT_BTN, is_logged_in)
            self.Enable(ID_ADMIN_REDEEM_OPEN_BTN, is_logged_in)
            self.Enable(ID_ADMIN_RELOGIN_BTN, True)
        except Exception as e:
            try:
                print("[Admin Auth Dialog] refresh failed: " + str(e))
            except Exception:
                pass

    def Command(self, cid, msg):
        try:
            parent = self.parent_dialog
            if cid == ID_ADMIN_LOGIN_BTN:
                account = self.GetString(ID_ADMIN_ACCOUNT).strip()
                password = self.GetString(ID_ADMIN_PASSWORD)
                if not account or not password:
                    parent._admin_set_message("请输入账号和密码")
                    self.RefreshValues()
                    return True
                parent._admin_login(account, password)
                self.SetString(ID_ADMIN_PASSWORD, "")
                self.RefreshValues()
                return True
            if cid == ID_ADMIN_REGISTER_OPEN_BTN:
                parent._open_admin_register_dialog()
                return True
            if cid == ID_ADMIN_REDEEM_OPEN_BTN:
                parent._open_admin_redeem_dialog()
                return True
            if cid == ID_ADMIN_LOGOUT_BTN:
                parent._admin_logout()
                self.SetString(ID_ADMIN_PASSWORD, "")
                self.RefreshValues()
                return True
            if cid == ID_ADMIN_RELOGIN_BTN:
                parent._admin_logout()
                parent._admin_set_message("请重新输入账号密码登录")
                self.SetString(ID_ADMIN_PASSWORD, "")
                self.RefreshValues()
                return True
            if cid == ID_ADMIN_AUTH_CLOSE_BTN or cid == c4d.DLG_CANCEL:
                self.Close()
                return True
        except Exception as e:
            gui.MessageDialog("账号授权窗口错误:\n" + str(e))
            try:
                traceback.print_exc()
            except Exception:
                pass
        return True


class AdminRegisterDialog(gui.GeDialog):
    def __init__(self, parent_dialog):
        super(AdminRegisterDialog, self).__init__()
        self.parent_dialog = parent_dialog

    def CreateLayout(self):
        self.SetTitle("注册账号")
        self.GroupBegin(13100, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0)
        self.GroupBorderSpace(12, 12, 12, 12)
        self.AddStaticText(0, c4d.BFH_SCALEFIT, name="注册花花账号")

        self.GroupBegin(13101, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="邮箱:")
        self.AddEditText(ID_ADMIN_REGISTER_EMAIL, c4d.BFH_SCALEFIT, 240, 0)
        self.GroupEnd()
        self.GroupBegin(13102, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="昵称:")
        self.AddEditText(ID_ADMIN_REGISTER_NICKNAME, c4d.BFH_SCALEFIT, 240, 0)
        self.GroupEnd()
        self.GroupBegin(13103, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="密码:")
        self.AddEditText(ID_ADMIN_REGISTER_PASSWORD, c4d.BFH_SCALEFIT, 240, 0)
        self.GroupEnd()
        self.GroupBegin(13104, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="确认密码:")
        self.AddEditText(ID_ADMIN_REGISTER_PASSWORD_CONFIRM, c4d.BFH_SCALEFIT, 240, 0)
        self.GroupEnd()

        self.AddStaticText(0, c4d.BFH_SCALEFIT, name="注册成功后请返回登录窗口登录。")
        self.GroupBegin(13105, c4d.BFH_RIGHT, 2, 1)
        self.AddButton(ID_ADMIN_REGISTER_SUBMIT_BTN, c4d.BFH_RIGHT, name="注册")
        self.AddButton(ID_ADMIN_REGISTER_CANCEL_BTN, c4d.BFH_RIGHT, name="取消")
        self.GroupEnd()
        self.GroupEnd()
        return True

    def _clear_passwords(self):
        try:
            self.SetString(ID_ADMIN_REGISTER_PASSWORD, "")
            self.SetString(ID_ADMIN_REGISTER_PASSWORD_CONFIRM, "")
        except Exception:
            pass

    def Command(self, cid, msg):
        try:
            parent = self.parent_dialog
            if cid == ID_ADMIN_REGISTER_SUBMIT_BTN:
                email = self.GetString(ID_ADMIN_REGISTER_EMAIL).strip()
                nickname = self.GetString(ID_ADMIN_REGISTER_NICKNAME).strip()
                password = self.GetString(ID_ADMIN_REGISTER_PASSWORD)
                password_confirm = self.GetString(ID_ADMIN_REGISTER_PASSWORD_CONFIRM)
                if not email or not password:
                    gui.MessageDialog("请输入邮箱和密码。")
                    return True
                if password != password_confirm:
                    self._clear_passwords()
                    gui.MessageDialog("两次输入的密码不一致。")
                    return True
                ok = parent._admin_register_account(email, password, nickname)
                self._clear_passwords()
                if ok:
                    gui.MessageDialog("注册成功，请登录。")
                    self.Close()
                    parent._open_admin_auth_dialog()
                return True
            if cid == ID_ADMIN_REGISTER_CANCEL_BTN or cid == c4d.DLG_CANCEL:
                self._clear_passwords()
                self.Close()
                return True
        except Exception as e:
            gui.MessageDialog("注册窗口错误:\n" + str(e))
            try:
                traceback.print_exc()
            except Exception:
                pass
        return True


class RedeemCdkDialog(gui.GeDialog):
    def __init__(self, parent_dialog):
        super(RedeemCdkDialog, self).__init__()
        self.parent_dialog = parent_dialog
        self.is_redeeming = False

    def CreateLayout(self):
        self.SetTitle("兑换 CDK")
        self.GroupBegin(13200, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0)
        self.GroupBorderSpace(12, 12, 12, 12)
        self.AddStaticText(0, c4d.BFH_SCALEFIT, name="请输入 CDK 兑换码")
        self.AddEditText(ID_ADMIN_CDK_CODE, c4d.BFH_SCALEFIT, 300, 0)
        self.AddStaticText(ID_ADMIN_CDK_STATUS_TEXT, c4d.BFH_SCALEFIT, name="兑换成功后会自动刷新授权状态。")
        self.GroupBegin(13201, c4d.BFH_RIGHT, 2, 1)
        self.AddButton(ID_ADMIN_CDK_SUBMIT_BTN, c4d.BFH_RIGHT, name="立即兑换")
        self.AddButton(ID_ADMIN_CDK_CANCEL_BTN, c4d.BFH_RIGHT, name="取消")
        self.GroupEnd()
        self.GroupEnd()
        return True

    def InitValues(self):
        try:
            self.SetString(ID_ADMIN_CDK_CODE, "")
            self.SetString(ID_ADMIN_CDK_STATUS_TEXT, "兑换成功后会自动刷新授权状态。")
            self.Enable(ID_ADMIN_CDK_SUBMIT_BTN, True)
        except Exception:
            pass
        self.is_redeeming = False
        return True

    def _set_redeeming(self, enabled):
        self.is_redeeming = bool(enabled)
        try:
            self.Enable(ID_ADMIN_CDK_SUBMIT_BTN, not self.is_redeeming)
            self.SetString(ID_ADMIN_CDK_STATUS_TEXT, "兑换中..." if self.is_redeeming else "兑换成功后会自动刷新授权状态。")
        except Exception:
            pass

    def Command(self, cid, msg):
        try:
            parent = self.parent_dialog
            if cid == ID_ADMIN_CDK_SUBMIT_BTN:
                if self.is_redeeming:
                    return True
                code = self.GetString(ID_ADMIN_CDK_CODE).strip()
                if not code:
                    gui.MessageDialog("请输入 CDK 兑换码。")
                    return True
                self._set_redeeming(True)
                try:
                    ok = parent._admin_redeem_cdk(code)
                finally:
                    self.SetString(ID_ADMIN_CDK_CODE, "")
                    self._set_redeeming(False)
                if ok:
                    self.Close()
                return True
            if cid == ID_ADMIN_CDK_CANCEL_BTN or cid == c4d.DLG_CANCEL:
                self.SetString(ID_ADMIN_CDK_CODE, "")
                self.Close()
                return True
        except Exception as e:
            gui.MessageDialog("CDK 兑换窗口错误:\n" + str(e))
            try:
                traceback.print_exc()
            except Exception:
                pass
            self._set_redeeming(False)
        return True


class HHImportDialog(gui.GeDialog):
    def __init__(self):
        super(HHImportDialog, self).__init__()
        self._cap_mode = 1
        self.user_area = AssetViewer(self) 
        self.load_progress_area = LoadProgressBar()
        self.opening_preview = OpeningPreviewArea()
        self.full_data_cache =[] 
        self.favorites = set()    
        self.asset_display_count = 0
        self.json_watch_dir = ""
        self.json_watch_seen = set()
        self.json_watch_candidates = {}
        self.json_watch_processed = set()
        self.json_watch_last_check_time = 0.0
        self.admin_config = {}
        self._admin_load_config()
        self.asset_path = self._get_model_library_dir()
        self.fav_file_path = os.path.join(self.asset_path, FAV_FILE_NAME)
        self.admin_token = ""
        self.admin_user = None
        self.admin_license = None
        self.admin_update_info = None
        self.admin_last_check_license_result = None
        self.admin_last_register_device_result = None
        self.admin_last_check_update_result = None
        self.admin_last_heartbeat_result = None
        self.admin_last_heartbeat_at = 0.0
        self.admin_dialog = None
        self.admin_register_dialog = None
        self.admin_redeem_dialog = None
        self.admin_message = ""
        self.core_enabled = False
        self.core_disabled_reason = "未登录"
        self.device_info = {}
        self.machine_id = ""
        self.LoadFavorites()

    def CreateLayout(self):
        self.SetTitle(PLUGIN_DISPLAY_NAME + " v" + CURRENT_VERSION)
        self.GroupBegin(ID_GRP_MAIN, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0)
        self.GroupBorderSpace(5, 5, 5, 5) 

        self.GroupBegin(12030, c4d.BFH_SCALEFIT, 2, 1)
        self.GroupBegin(ID_LOAD_PROGRESS_GROUP, c4d.BFH_SCALEFIT, 1, 0)
        self.AddStaticText(ID_LOAD_PROGRESS_TEXT, c4d.BFH_SCALEFIT, 0, 0, "等待选择文件")
        self.AddUserArea(ID_LOAD_PROGRESS_BAR, c4d.BFH_SCALEFIT, 0, 8)
        self.AttachUserArea(self.load_progress_area, ID_LOAD_PROGRESS_BAR)
        self.GroupEnd()
        self.AddButton(ID_ADMIN_OPEN_DIALOG_BTN, c4d.BFH_RIGHT, 72, 20, "登录")
        self.GroupEnd()

        self.TabGroupBegin(ID_TAB_MAIN, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, c4d.TAB_TABS)
        
        # Tab 1: Basic
        self.GroupBegin(ID_TAB_GRP_BASIC, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "基础设置")
        self.GroupBorderSpace(8, 8, 8, 8)
        self.GroupBegin(2000, c4d.BFH_SCALEFIT, 1, 0) 
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 核心参数 ---")
        self.AddSeparatorH(5)
        self.GroupBegin(2001, c4d.BFH_SCALEFIT, 4, 1)
        self.AddStaticText(ID_RATIO_LABEL, c4d.BFH_LEFT, name="导入比例:")
        self.AddComboBox(ID_RATIO_COMBO, c4d.BFH_SCALEFIT, 120, 10)
        self.AddStaticText(0, c4d.BFH_LEFT, name="  手柄张力:")
        self.AddEditNumberArrows(ID_TENSION_VAL, c4d.BFH_SCALEFIT, 80, 0)
        self.GroupEnd()
        self.GroupBegin(2002, c4d.BFH_SCALEFIT, 2, 2)
        self.AddCheckbox(ID_IMPORT_TO_NEW_DOC, c4d.BFH_LEFT, 0, 0, "导入到新文件")
        self.AddCheckbox(ID_KEEP_LAYER,   c4d.BFH_LEFT, 0, 0, "保留图层结构")
        self.AddCheckbox(ID_AUTO_CLOSE,   c4d.BFH_LEFT, 0, 0, "自动闭合样条")
        self.AddCheckbox(ID_IMPORT_COLOR, c4d.BFH_LEFT, 0, 0, "创建原始材质") 
        self.AddCheckbox(ID_SMART_STACK, c4d.BFH_LEFT, 0, 0, "启用智能堆叠 (Smart Stack)")
        self.AddCheckbox(ID_GAMMA_CORRECT, c4d.BFH_LEFT, 0, 0, "颜色 Gamma 修正 (sRGB->Linear)")
        self.GroupEnd()
        self.AddSeparatorH(5)
        self.GroupBegin(3000, c4d.BFH_SCALEFIT, 2, 1)
        self.AddButton(ID_JSON_WATCH_BTN, c4d.BFH_LEFT, name="选择 JSON 监听文件夹")
        self.AddStaticText(ID_JSON_WATCH_STATUS, c4d.BFH_SCALEFIT, name="未选择监听目录")
        self.GroupEnd()
        self.GroupEnd()
        self.GroupBegin(2100, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 样条属性 ---")
        self.AddSeparatorH(5)
        self.GroupBegin(2101, c4d.BFH_SCALEFIT, 4, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="类型:")
        self.AddComboBox(ID_SPL_TYPE_COMBO, c4d.BFH_SCALEFIT, 80, 0)
        self.AddCheckbox(ID_SPL_CLOSE_CHK, c4d.BFH_LEFT, 0, 0, "闭合样条")
        self.AddStaticText(0, c4d.BFH_LEFT, name="") 
        self.GroupEnd()
        self.GroupBegin(2102, c4d.BFH_SCALEFIT, 4, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="插值:")
        self.AddComboBox(ID_SPL_INTER_COMBO, c4d.BFH_SCALEFIT, 80, 0)
        self.AddStaticText(0, c4d.BFH_LEFT, name="数量:")
        self.AddEditNumberArrows(ID_SPL_SUB_VAL, c4d.BFH_SCALEFIT, 50, 0)
        self.GroupEnd()
        self.GroupEnd()
        self.GroupBegin(3002, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 挤压建模 ---")
        self.AddSeparatorH(5)
        self.GroupBegin(3003, c4d.BFH_SCALEFIT, 4, 1)
        self.AddCheckbox(ID_EXTRUDE_ENABLE, c4d.BFH_LEFT, 0, 0, "启用挤压")
        self.AddStaticText(0, c4d.BFH_LEFT, name="深度:")
        self.AddEditNumberArrows(ID_EXTRUDE_DEPTH, c4d.BFH_LEFT, 60, 0)
        self.AddEditSlider(ID_EXTRUDE_SLIDER, c4d.BFH_SCALEFIT, 0, 0)
        self.GroupEnd()
        self.GroupBegin(3004, c4d.BFH_SCALEFIT, 2, 1)
        self.AddButton(ID_BTN_SMART_MERGE, c4d.BFH_SCALEFIT, name="按颜色合并并挤压 (Z-)")
        self.AddButton(ID_BTN_SIMPLE_EXTRUDE, c4d.BFH_SCALEFIT, name="原地层级挤压 (Z-)")
        self.GroupEnd()
        self.GroupBegin(3005, c4d.BFH_SCALEFIT, 4, 1)
        self.AddButton(ID_BTN_APPLY_DEPTH, c4d.BFH_LEFT, name="应用深度")
        self.AddButton(ID_BTN_EXTRUDE_FLIP, c4d.BFH_LEFT, name="反转方向")
        self.AddCheckbox(ID_DELETE_SPLINE, c4d.BFH_LEFT, 0, 0, "完成后删除样条")
        self.GroupEnd()
        self.GroupEnd()
        self.GroupEnd() 

        # Tab 2: Align (Super Align + Axis Tool)
        self.GroupBegin(ID_TAB_GRP_ALIGN, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "位置对齐")
        self.GroupBorderSpace(8, 8, 8, 8)
        
        # --- 1. 独立子物体探测区 ---
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_CENTER, name="--- 分布式独立探测 (防穿模贴墙) ---")
        self.GroupBegin(0, c4d.BFH_CENTER, 1, 0)
        self.AddButton(ID_BTN_RAY_UP, c4d.BFH_CENTER, 80, 24, "顶 (+Y)")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_CENTER, 4, 0)
        self.AddButton(ID_BTN_RAY_LEFT, c4d.BFH_CENTER, 60, 24, "左 (-X)")
        self.AddButton(ID_BTN_RAY_FRONT, c4d.BFH_CENTER, 40, 24, "前")
        self.AddButton(ID_BTN_RAY_BACK, c4d.BFH_CENTER, 40, 24, "后")
        self.AddButton(ID_BTN_RAY_RIGHT, c4d.BFH_CENTER, 60, 24, "右 (+X)")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_CENTER, 1, 0)
        self.AddButton(ID_BTN_RAY_DOWN, c4d.BFH_CENTER, 80, 24, "地 (-Y)")
        self.GroupEnd()
        self.GroupEnd()

        # --- 2. 九宫格对齐 ---
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 九宫格多对象对齐 ---")
        self.AddCheckbox(ID_CHK_SURFACE_MODE, c4d.BFH_LEFT, 0, 0, "边缘贴合模式 (取消勾选为中心对齐)")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 3, 0)
        self.AddButton(ID_BTN_NW, c4d.BFH_SCALEFIT, 0, 20, "↖ 左上")
        self.AddButton(ID_BTN_N,  c4d.BFH_SCALEFIT, 0, 20, "↑ 中顶")
        self.AddButton(ID_BTN_NE, c4d.BFH_SCALEFIT, 0, 20, "右上 ↗")
        self.AddButton(ID_BTN_W,  c4d.BFH_SCALEFIT, 0, 20, "← 左中")
        self.AddButton(ID_BTN_C,  c4d.BFH_SCALEFIT, 0, 20, "XY 正中")
        self.AddButton(ID_BTN_E,  c4d.BFH_SCALEFIT, 0, 20, "右中 →")
        self.AddButton(ID_BTN_SW, c4d.BFH_SCALEFIT, 0, 20, "↙ 左下")
        self.AddButton(ID_BTN_S,  c4d.BFH_SCALEFIT, 0, 20, "↓ 中底")
        self.AddButton(ID_BTN_SE, c4d.BFH_SCALEFIT, 0, 20, "右下 ↘")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 3, 0)
        self.AddButton(ID_BTN_Z_FRONT, c4d.BFH_SCALEFIT, 0, 20, "前 (Z-)")
        self.AddButton(ID_BTN_Z_MID,   c4d.BFH_SCALEFIT, 0, 20, "Z 轴中")
        self.AddButton(ID_BTN_Z_BACK,  c4d.BFH_SCALEFIT, 0, 20, "后 (Z+)")
        self.GroupEnd()
        self.GroupEnd()

        # --- 3. 全方位轴心对齐 (独立轴心) ---
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 全方位轴心对齐 (仅移动轴心) ---")
        
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 3, 3)
        self.AddButton(ID_AXIS_TL, c4d.BFH_SCALEFIT, 0, 20, "↖ 左上")
        self.AddButton(ID_AXIS_TC, c4d.BFH_SCALEFIT, 0, 20, "↑ 中上")
        self.AddButton(ID_AXIS_TR, c4d.BFH_SCALEFIT, 0, 20, "↗ 右上")
        self.AddButton(ID_AXIS_ML, c4d.BFH_SCALEFIT, 0, 20, "← 左中")
        self.AddButton(ID_AXIS_MC, c4d.BFH_SCALEFIT, 0, 20, "+ 正中")
        self.AddButton(ID_AXIS_MR, c4d.BFH_SCALEFIT, 0, 20, "→ 右中")
        self.AddButton(ID_AXIS_BL, c4d.BFH_SCALEFIT, 0, 20, "↙ 左下")
        self.AddButton(ID_AXIS_BC, c4d.BFH_SCALEFIT, 0, 20, "↓ 中下")
        self.AddButton(ID_AXIS_BR, c4d.BFH_SCALEFIT, 0, 20, "↘ 右下")
        self.GroupEnd()
        
        self.GroupBegin(0, c4d.BFH_CENTER, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="Z轴位置: ")
        self.AddRadioGroup(ID_AXIS_RADIO_Z, c4d.BFH_LEFT, columns=3)
        self.AddChild(ID_AXIS_RADIO_Z, ID_AXIS_Z_FRONT, "前 (+Z)")
        self.AddChild(ID_AXIS_RADIO_Z, ID_AXIS_Z_MID,   "中 (0)")
        self.AddChild(ID_AXIS_RADIO_Z, ID_AXIS_Z_BACK,  "后 (-Z)")
        self.GroupEnd()
        self.GroupEnd()

        # --- 4. 基础快捷与微调 ---
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 快捷与微调 ---")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 4, 1)
        self.AddButton(ID_BTN_DROP_FLOOR, c4d.BFH_SCALEFIT, name="一键落地")
        self.AddButton(ID_BTN_STAND_UP,   c4d.BFH_SCALEFIT, name="一键站立")
        self.AddButton(ID_BTN_CENTER_X,   c4d.BFH_SCALEFIT, name="X轴居中")
        self.AddButton(ID_BTN_RESET_PSR,  c4d.BFH_SCALEFIT, name="轴心归零")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 3, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="微调步长:")
        self.AddEditNumberArrows(ID_MOVE_DIST_VAL, c4d.BFH_SCALEFIT, 70, 0)
        self.AddStaticText(0, c4d.BFH_LEFT, name="cm")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 6, 1)
        self.AddButton(ID_BTN_MOV_X_SUB, c4d.BFH_SCALEFIT, name="< X")
        self.AddButton(ID_BTN_MOV_X_ADD, c4d.BFH_SCALEFIT, name="X >")
        self.AddButton(ID_BTN_MOV_Y_ADD, c4d.BFH_SCALEFIT, name="^ Y")
        self.AddButton(ID_BTN_MOV_Y_SUB, c4d.BFH_SCALEFIT, name="v Y")
        self.AddButton(ID_BTN_MOV_Z_ADD, c4d.BFH_SCALEFIT, name="Z(出)")
        self.AddButton(ID_BTN_MOV_Z_SUB, c4d.BFH_SCALEFIT, name="Z(入)")
        self.GroupEnd()
        self.GroupEnd()
        
        self.GroupEnd()

        # Tab 3: Scene Tools
        self.GroupBegin(ID_TAB_GRP_SCENE, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "场景工具")
        self.GroupBorderSpace(8, 8, 8, 8)
        self.GroupBegin(3100, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 场景工具 ---")
        self.AddSeparatorH(5)
        self.GroupBegin(3105, c4d.BFH_SCALEFIT, 2, 1)
        self.AddButton(ID_BTN_SEL_HIDDEN, c4d.BFH_SCALEFIT, name="选中红点隐藏对象")
        self.AddButton(ID_BTN_SEL_TEXTURED, c4d.BFH_SCALEFIT, name="选中带贴图对象")
        self.GroupEnd()
        self.GroupBegin(3106, c4d.BFH_SCALEFIT, 2, 1)
        self.AddButton(ID_BTN_CONNECT_DELETE, c4d.BFH_SCALEFIT, name="连接对象+删除")
        self.AddButton(ID_BTN_AXIS_CENTER, c4d.BFH_SCALEFIT, name="系统默认轴心居中")
        self.GroupEnd()
        self.AddSeparatorH(5)
        self.GroupBegin(3107, c4d.BFH_SCALEFIT, 3, 1)
        self.AddButton(ID_BTN_APPLY_TEX, c4d.BFH_SCALEFIT, name="选择贴图")
        self.AddButton(ID_BTN_APPLY_COLOR_DATA, c4d.BFH_SCALEFIT, name="重置材质")
        self.AddButton(ID_BTN_BAKE_UVW, c4d.BFH_SCALEFIT, name="强制烘焙UVW")
        self.GroupEnd()
        self.GroupBegin(3102, c4d.BFH_LEFT, 2, 1)
        self.AddStaticText(3101, c4d.BFH_LEFT, name="当前贴图选集:")
        self.AddButton(ID_CAP_SIDE_COMBO, c4d.BFH_LEFT, name="C1 (前封盖)")
        self.GroupEnd()
        self.GroupEnd()
        self.GroupEnd()

        # Tab 4: Modeling Aids (Acrylic & Signage)
        self.GroupBegin(ID_TAB_GRP_ACRYLIC, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "建模辅助工具")
        self.GroupBorderSpace(8, 8, 8, 8)
        
        self.GroupBegin(5000, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="-- 亚克力插槽生成 --")
        self.AddSeparatorH(3)
        self.GroupBegin(5001, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(ID_ACRY_DEPTH_LABEL, c4d.BFH_LEFT, 0, 0, "样条挤压高度 (cm):", 0)
        self.AddEditNumberArrows(ID_ACRY_DEPTH_INPUT, c4d.BFH_SCALEFIT, 80, 0)
        self.GroupEnd()
        self.GroupBegin(5002, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, 0, 0, "挤压方向:", 0)
        self.AddComboBox(ID_ACRY_DEPTH_DIR, c4d.BFH_LEFT, 0, 0)
        self.AddChild(ID_ACRY_DEPTH_DIR, 0, "Z+ 正向挤压")
        self.AddChild(ID_ACRY_DEPTH_DIR, 1, "Z- 反向挤压")
        self.GroupEnd()
        self.AddStaticText(0, c4d.BFH_LEFT, 0, 0, "要删除的侧面：", 0)
        self.GroupBegin(ID_ACRY_SIDE_GROUP, c4d.BFH_SCALEFIT, 2, 2)
        self.AddCheckbox(ID_ACRY_CHK_T, c4d.BFH_LEFT, 0, 0, "删顶 (+Y)")
        self.AddCheckbox(ID_ACRY_CHK_B, c4d.BFH_LEFT, 0, 0, "删底 (-Y)")
        self.AddCheckbox(ID_ACRY_CHK_L, c4d.BFH_LEFT, 0, 0, "删左 (-X)")
        self.AddCheckbox(ID_ACRY_CHK_R, c4d.BFH_LEFT, 0, 0, "删右 (+X)")
        self.GroupEnd()
        self.GroupBegin(5003, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(ID_ACRY_SHELL_LABEL, c4d.BFH_LEFT, 0, 0, "最终板厚 (cm):", 0)
        self.AddEditNumberArrows(ID_ACRY_SHELL_INPUT, c4d.BFH_SCALEFIT, 80, 0)
        self.GroupEnd()
        self.GroupBegin(5004, c4d.BFH_SCALEFIT, 1, 1)
        self.AddButton(ID_BTN_ACRY_GENERATE, c4d.BFH_SCALEFIT, name="立即生成亚克力插槽")
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(ID_SIGN_GRP_MAIN, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="-- 花花智能建模-C4D端 v1.1 - 广告字工艺 --")
        self.AddSeparatorH(3)
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="基础颜色:")
        self.AddColorField(ID_SIGN_COLOR, c4d.BFH_SCALEFIT, 0, 0)
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 4, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="前厚(mm):")
        self.AddEditNumberArrows(ID_SIGN_THICK_F, c4d.BFH_SCALEFIT, 50, 0)
        self.AddStaticText(0, c4d.BFH_LEFT, name="后厚(mm):")
        self.AddEditNumberArrows(ID_SIGN_THICK_B, c4d.BFH_SCALEFIT, 50, 0)
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 2)
        self.AddButton(ID_BTN_SIGN_BACK, c4d.BFH_SCALEFIT, name="🔙 背发光")
        self.AddButton(ID_BTN_SIGN_FRONT, c4d.BFH_SCALEFIT, name="🔆 正发光")
        self.AddButton(ID_BTN_SIGN_CRYSTAL, c4d.BFH_SCALEFIT, name="💎 水晶字")
        self.AddButton(ID_BTN_SIGN_DUAL, c4d.BFH_SCALEFIT, name="♊ 正背发")
        self.GroupEnd()
        self.AddStaticText(0, c4d.BFH_CENTER, name="提示: 输入0自动使用标准参数; 颜色自动继承")
        self.GroupEnd()

        self.GroupBegin(5200, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="-- 花花智能建模-C4D端 v1.1 - 智能灯槽生成器 --")
        self.AddSeparatorH(3)
        self.AddStaticText(0, c4d.BFH_LEFT, name="提示: 先选中模型，再打开灯槽面板执行。")
        self.AddButton(ID_BTN_OPEN_GROOVE, c4d.BFH_SCALEFIT, name="打开智能灯槽面板")
        self.GroupEnd()
        self.GroupEnd() 

        # Tab 5: Smart Scene
        self.GroupBegin(ID_TAB_GRP_SMART_SCENE, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "智能场景")
        self.GroupBorderSpace(8, 8, 8, 8)
        self.ScrollGroupBegin(6013, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, c4d.SCROLLGROUP_VERT)
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBegin(6012, c4d.BFH_SCALEFIT, 1, 0, "智能门窗")
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(8, 8, 8, 8)
        self.AddStaticText(0, c4d.BFH_LEFT, name="智能门窗")
        self.AddUserArea(ID_OPENING_PREVIEW,c4d.BFH_SCALEFIT,180,120)
        self.AttachUserArea(self.opening_preview,ID_OPENING_PREVIEW)
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 0)
        self.AddStaticText(0, c4d.BFH_LEFT, name="门窗预设")
        self.AddComboBox(ID_OPENING_PRESET, c4d.BFH_SCALEFIT)
        self.AddStaticText(0, c4d.BFH_LEFT, name="对象正面")
        self.AddComboBox(ID_OPENING_PLANE, c4d.BFH_SCALEFIT)
        for cid, label in ((ID_OPENING_WIDTH,"默认宽度 (cm)"),
                           (ID_OPENING_HEIGHT,"默认高度 (cm)"),
                           (ID_OPENING_DEPTH,"默认框深 (cm)")):
            self.AddStaticText(0, c4d.BFH_LEFT, name=label)
            self.AddEditNumberArrows(cid,c4d.BFH_SCALEFIT)
        self.GroupEnd()
        self.AddCheckbox(ID_OPENING_USE_SELECTION,c4d.BFH_LEFT,0,0,name="适配选中对象并隐藏原对象")
        self.AddCheckbox(ID_OPENING_NEW_MATERIALS,c4d.BFH_LEFT,0,0,name="为每个新门窗新建独立材质")
        self.AddButton(ID_BTN_GEN_OPENING,c4d.BFH_SCALEFIT,name="生成智能门窗")
        self.GroupEnd()
        self.GroupBegin(6011, c4d.BFH_SCALEFIT, 1, 0, "楼梯生成")
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(8, 8, 8, 8)
        self.AddStaticText(0, c4d.BFH_LEFT, name="楼梯生成")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 0)
        for control_id, label in ((ID_STAIR_HEIGHT, "每级高度 (cm)"),
                                  (ID_STAIR_DEPTH, "每级深度 (cm)"),
                                  (ID_STAIR_WIDTH, "楼梯宽度 (cm)"),
                                  (ID_STAIR_COUNT, "首段台阶数量")):
            self.AddStaticText(0, c4d.BFH_LEFT, name=label)
            self.AddEditNumberArrows(control_id, c4d.BFH_SCALEFIT)
        self.GroupEnd()
        self.AddCheckbox(ID_STAIR_FLOOR_MODE, c4d.BFH_LEFT, 0, 0, name="按楼层生成（每层两段）")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 0)
        for control_id, label in ((ID_STAIR_FLOORS, "生成层数"),):
            self.AddStaticText(0, c4d.BFH_LEFT, name=label)
            self.AddEditNumberArrows(control_id, c4d.BFH_SCALEFIT)
        self.GroupEnd()
        self.AddButton(ID_BTN_GEN_STAIRS, c4d.BFH_SCALEFIT, name="生成楼梯")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 0)
        self.AddButton(ID_STAIR_ADD, c4d.BFH_SCALEFIT, name="添加一段楼梯")
        self.AddButton(ID_STAIR_REMOVE, c4d.BFH_SCALEFIT, name="删除最后一段")
        self.GroupEnd()
        self.GroupEnd()
        
        self.GroupBegin(6014, c4d.BFH_SCALEFIT, 1, 0, "墙体适配吊顶")
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(8, 8, 8, 8)
        self.AddButton(ID_ROOM_CEILING_PREVIEW, c4d.BFH_SCALEFIT, name="识别 / 预览吊顶范围")
        self.AddStaticText(ID_ROOM_CEILING_STATUS, c4d.BFH_SCALEFIT, name="未识别吊顶范围")
        self.AddButton(ID_ROOM_CEILING_GENERATE, c4d.BFH_SCALEFIT, name="生成墙体适配吊顶")
        self.GroupEnd()

        # 吊顶生成器
        self.GroupBegin(6000, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(20, 20, 20, 20)
        self.AddStaticText(0, c4d.BFH_CENTER, name="生成智能吊顶系统 (花花智能建模-C4D端 v1.1)")
        self.AddSeparatorH(10)
        self.AddButton(ID_BTN_GEN_CEILING, c4d.BFH_SCALEFIT, name="生成智能吊顶对象")
        self.AddStaticText(0, c4d.BFH_LEFT, name="提示: 生成后请在对象属性面板中调整参数。")
        self.GroupEnd()
        
        # 花花智能建模-C4D端 v1.1 - 智能展厅生成器
        self.GroupBegin(6001, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(20, 20, 20, 20)
        self.AddStaticText(0, c4d.BFH_CENTER, name="生成智能展厅系统 (花花智能建模-C4D端 v1.1 防炸稳定版)")
        self.AddSeparatorH(10)
        self.AddStaticText(0, c4d.BFH_LEFT, name="💡 提示: 请先选中 4 个墙体对象 (或1个包含4面墙的群组)")
        self.AddStaticText(0, c4d.BFH_LEFT, name="📋 列表顺序要求 (从下到上): 前墙 -> 右墙 -> 后墙 -> 左墙")
        self.AddButton(ID_BTN_GEN_SMART_ROOM, c4d.BFH_SCALEFIT, name="🔨 一键生成智能展厅")
        self.GroupEnd()

        # 花花智能建模-C4D端 v1.1 - 智能弯曲墙体生成器
        self.GroupBegin(6010, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(20, 20, 20, 20)
        self.AddStaticText(0, c4d.BFH_CENTER, name="生成智能弯曲墙体系统 (花花智能建模-C4D端 v1.1 手动滑块版)")
        self.AddSeparatorH(10)
        self.AddStaticText(0, c4d.BFH_LEFT, name="💡 提示: 请同时选中 [1根样条] +[1个或多个墙体/挤压对象]")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="适配模式:")
        self.AddComboBox(ID_CURVED_WALL_MODE, c4d.BFH_SCALEFIT, 150, 0)
        self.GroupEnd()
        self.AddButton(ID_BTN_CURVED_WALL, c4d.BFH_SCALEFIT, name="🧲 一键生成智能弯曲墙体")
        self.GroupEnd()

        self.GroupEnd()

        # Tab 6: Asset Manager
        self.GroupEnd()
        self.GroupEnd()
        self.GroupBegin(ID_TAB_GRP_ASSETS, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "模型库")
        self.GroupBorderSpace(8, 8, 8, 8)
        self.AddStaticText(ID_ASSET_PATH_TEXT, c4d.BFH_SCALEFIT, name="当前模型库路径：" + str(self.asset_path))
        self.AddStaticText(ID_ASSET_COUNT_TEXT, c4d.BFH_LEFT, name="模型数量：0")
        if self.GroupBegin(6999, c4d.BFH_SCALEFIT, cols=2, rows=1, groupflags=c4d.BORDER_NONE):
            self.AddButton(ID_ASSET_BTN_CHOOSE_DIR, c4d.BFH_LEFT, name="选择模型库位置")
            self.AddButton(ID_ASSET_BTN_OPEN_DIR, c4d.BFH_LEFT, name="打开模型库文件夹")
            self.GroupEnd()
        if self.GroupBegin(7000, c4d.BFH_SCALEFIT, cols=4, rows=1, groupflags=c4d.BORDER_NONE):
            self.AddEditText(ID_ASSET_TXT_SEARCH, c4d.BFH_SCALEFIT, 200, 0)
            self.SetString(ID_ASSET_TXT_SEARCH, "") 
            self.AddButton(ID_ASSET_BTN_REFRESH, c4d.BFH_LEFT, name="刷新")
            self.AddButton(ID_ASSET_BTN_LOAD, c4d.BFH_LEFT, name="⚡ 加载")
            self.GroupEnd()
        if self.GroupBegin(7001, c4d.BFH_SCALEFIT, cols=4, rows=1, groupflags=c4d.BORDER_NONE):
            self.AddCheckbox(ID_ASSET_CHK_SIZE, c4d.BFH_LEFT, 0, 0, name="📏 匹配尺寸")
            self.AddCheckbox(ID_ASSET_CHK_ONLY_FAV, c4d.BFH_LEFT, 0, 0, name="★ 只看收藏")
            self.AddStaticText(0, c4d.BFH_LEFT, name="缩放:")
            self.AddEditSlider(ID_ASSET_SLIDER_SIZE, c4d.BFH_SCALEFIT, 150, 0)
            self.GroupEnd()
        self.AddSeparatorH(c4d.BFH_SCALEFIT)
        if self.ScrollGroupBegin(ID_ASSET_SCROLL_GRP, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, c4d.SCROLLGROUP_VERT):
            self.AddUserArea(ID_ASSET_USER_AREA, c4d.BFH_SCALEFIT | c4d.BFV_TOP)
            self.AttachUserArea(self.user_area, ID_ASSET_USER_AREA)
            self.GroupEnd()
        self.GroupEnd()
        
        self.GroupEnd() 
        self.AddSeparatorH(5)
        self.GroupBegin(4000, c4d.BFH_CENTER, 4, 1)
        self.AddButton(ID_IMPORT_BTN, c4d.BFH_SCALEFIT, name="  导入 AI JSON 文件  ")
        self.AddButton(ID_REPLACE_BTN, c4d.BFH_SCALEFIT, name=" ⚡ 替换选中模型 ")
        self.AddButton(ID_CHECK_UPDATE_BTN, c4d.BFH_SCALEFIT, name="检查更新")
        self.AddButton(ID_CLOSE_BTN,  c4d.BFH_SCALEFIT, name=" 关闭面板 ")
        self.GroupEnd()
        self.GroupEnd()
        return True

    def InitValues(self):
        for index, name in enumerate(OPENING_PRESETS):
            self.AddChild(ID_OPENING_PRESET,index,name)
        for index, name in enumerate(("自动识别薄轴", "XY 正面（厚度 Z）", "YZ 正面（厚度 X）", "XZ 正面（厚度 Y）")):
            self.AddChild(ID_OPENING_PLANE,index,name)
        self.SetInt32(ID_OPENING_PRESET,0)
        self.opening_preview.SetPreset(0)
        self.SetInt32(ID_OPENING_PLANE,0)
        self.SetBool(ID_OPENING_USE_SELECTION,True)
        self.SetBool(ID_OPENING_NEW_MATERIALS,False)
        for cid,value in ((ID_OPENING_WIDTH,120.0),(ID_OPENING_HEIGHT,150.0),(ID_OPENING_DEPTH,14.0)):
            self.SetFloat(cid,value,min=1.0,max=100000.0,step=1.0)
        self.AddChild(ID_RATIO_COMBO, 1, "1:1")
        self.SetFloat(ID_STAIR_HEIGHT, 18.0, min=0.01, max=100000.0, step=1.0)
        self.SetFloat(ID_STAIR_DEPTH, 28.0, min=0.01, max=100000.0, step=1.0)
        self.SetFloat(ID_STAIR_WIDTH, 120.0, min=0.01, max=100000.0, step=1.0)
        self.SetInt32(ID_STAIR_COUNT, 10, min=1, max=1000)
        self.SetBool(ID_STAIR_FLOOR_MODE, False)
        self.SetInt32(ID_STAIR_FLOORS, 5, min=1, max=20)
        self.AddChild(ID_RATIO_COMBO, 10, "1:10")
        self.AddChild(ID_RATIO_COMBO, 100, "1:100")
        self.AddChild(ID_RATIO_COMBO, 1000, "1:1000")
        self.SetInt32(ID_RATIO_COMBO, 10) 
        self.SetFloat(ID_TENSION_VAL, 0.751425, min=0.0, max=100.0, step=0.000001, format=c4d.FORMAT_FLOAT)
        
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_LINEAR, "线性")
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_CUBIC, "立方")
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_AKIMA, "阿基玛")
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_BSPLINE, "B-样条")
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_BEZIER, "贝塞尔")
        self.SetInt32(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_BEZIER)
        
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_NONE, "无")
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_NATURAL, "自然")
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_UNIFORM, "统一")
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_ADAPTIVE, "自适应")
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_SUBDIV, "细分")
        self.SetInt32(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_UNIFORM)
        self.SetInt32(ID_SPL_SUB_VAL, 8, min=0, max=1000, step=1)
        self.SetBool(ID_SPL_CLOSE_CHK, True) 

        self.SetInt32(ID_CAP_SIDE_COMBO, 1)
        self._cap_mode = 1
        self.SetBool(ID_IMPORT_TO_NEW_DOC, False) 
        self.SetBool(ID_KEEP_LAYER, True)
        self.SetBool(ID_AUTO_CLOSE, True)
        self.SetBool(ID_IMPORT_COLOR, True) 
        self.SetBool(ID_SMART_STACK, True)
        self.SetFloat(ID_EXTRUDE_DEPTH, 20.0)
        self.SetFloat(ID_EXTRUDE_SLIDER, 20.0, min=0.0, max=200.0, step=1.0)
        
        self.SetBool(ID_DELETE_SPLINE, True)
        self.SetBool(ID_EXTRUDE_ENABLE, False)
        
        self.SetBool(ID_GAMMA_CORRECT, False)
    
        self.SetFloat(ID_MOVE_DIST_VAL, 10.0, 0.1, 10000.0, 1.0)
        
        self.SetFloat(ID_ACRY_DEPTH_INPUT, 0.3, min=0.0, step=0.1, format=c4d.FORMAT_FLOAT)
        self.SetInt32(ID_ACRY_DEPTH_DIR, 1)
        self.SetFloat(ID_ACRY_SHELL_INPUT, 0.3, min=0.0, step=0.1, format=c4d.FORMAT_FLOAT)
        self.SetBool(ID_ACRY_CHK_T, True)
        self.SetBool(ID_ACRY_CHK_B, False)
        self.SetBool(ID_ACRY_CHK_L, False)
        self.SetBool(ID_ACRY_CHK_R, False)
        
        self.SetInt32(ID_ASSET_SLIDER_SIZE, 130, min=50, max=300, step=10)
        self.SetBool(ID_ASSET_CHK_SIZE, True) 
        self.SetBool(ID_ASSET_CHK_ONLY_FAV, False)
        
        self.SetBool(ID_CHK_SURFACE_MODE, True)
        self.SetInt32(ID_AXIS_RADIO_Z, ID_AXIS_Z_MID)

        self.SetColorField(ID_SIGN_COLOR, c4d.Vector(1, 0.2, 0.2), 1.0, 1.0, c4d.DR_COLORFIELD_NO_BRIGHTNESS)
        self.SetFloat(ID_SIGN_THICK_F, 0.0) 
        self.SetFloat(ID_SIGN_THICK_B, 0.0)

        # [新增] 智能弯曲墙体选项初始化
        self.AddChild(ID_CURVED_WALL_MODE, 0, "匹配样条 (拉伸)")
        self.AddChild(ID_CURVED_WALL_MODE, 1, "保持长度 (不拉伸)")
        self.SetInt32(ID_CURVED_WALL_MODE, 1) # 默认保持长度

        self._load_json_watch_pref()
        self._update_json_watch_status()
        self._start_json_watch_timer()

        self.ScanAndLoad()
        self.ResetLoadProgress()
        self._update_ui_from_selection()
        self._admin_init_startup()
        return True

    def _admin_log(self, message):
        try:
            print("[Huahua Admin] " + str(message))
        except Exception:
            pass

    def _admin_platform(self):
        return "windows" if os.name == "nt" else "mac"

    def _admin_os_name(self):
        try:
            system = py_platform.system()
            release = py_platform.release()
            version = py_platform.mac_ver()[0] if system == "Darwin" else py_platform.version()
            if system == "Darwin":
                return "macOS " + (version or release or "")
            if system == "Windows":
                return "Windows " + (release or version or "")
            return self._admin_platform() + " " + (release or version or "")
        except Exception:
            return self._admin_platform()

    def _admin_device_name(self):
        try:
            name = socket.gethostname()
            if name:
                return name
        except Exception:
            pass
        return "Windows PC" if self._admin_platform() == "windows" else "Mac"

    def _admin_load_config(self):
        try:
            if os.path.exists(ADMIN_CONFIG_FILE):
                with open(ADMIN_CONFIG_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.admin_config = data
                        return
        except Exception as e:
            self._admin_log("读取本地配置失败: " + str(e))
        self.admin_config = {}

    def _admin_save_config(self):
        try:
            if not os.path.isdir(ADMIN_CONFIG_DIR):
                os.makedirs(ADMIN_CONFIG_DIR)
            self.admin_config["API_BASE_URL"] = API_BASE_URL
            self.admin_config["pluginCode"] = PLUGIN_CODE
            self.admin_config["clientCode"] = CLIENT_CODE
            self.admin_config["platform"] = self.device_info.get("platform", self._admin_platform())
            self.admin_config["os"] = self.device_info.get("os", self._admin_os_name())
            self.admin_config["deviceName"] = self.device_info.get("deviceName", self._admin_device_name())
            self.admin_config["deviceId"] = self.device_info.get("deviceId", self.admin_config.get("deviceId", ""))
            self.admin_config["machineId"] = self.device_info.get("machineId", self.machine_id or self.admin_config.get("machineId", ""))
            with open(ADMIN_CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.admin_config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self._admin_log("保存本地配置失败: " + str(e))

    def _admin_handle_api_base_change(self):
        saved_api_base_url = str(self.admin_config.get("API_BASE_URL") or "").strip()
        if not saved_api_base_url or saved_api_base_url == API_BASE_URL:
            return False
        self._admin_log("检测到授权后台地址变更: " + saved_api_base_url + " -> " + API_BASE_URL)
        for key in ("token", "user", "license", "lastLoginAt", "lastVerifiedAt", "lastHeartbeatAt", "licenseInvalidAt"):
            self.admin_config.pop(key, None)
        self.admin_token = ""
        self.admin_user = None
        self.admin_license = None
        self.admin_config["API_BASE_URL"] = API_BASE_URL
        self.admin_config["pluginCode"] = PLUGIN_CODE
        self.admin_config["clientCode"] = CLIENT_CODE
        self._admin_save_config()
        self._admin_set_message("授权后台已切换为云端，请重新登录。")
        return True

    def _admin_init_device_info(self):
        device_id = str(self.admin_config.get("deviceId") or "").strip()
        machine_id = get_or_create_machine_id(str(self.admin_config.get("machineId") or "").strip())
        platform_value = self._admin_platform()
        device_name = self._admin_device_name()
        os_name = self._admin_os_name()
        if not device_id:
            try:
                raw = "|".join([
                    socket.gethostname(),
                    getpass.getuser(),
                    platform_value,
                    DEVICE_ID_SALT
                ])
                device_id = hashlib.sha256(raw.encode("utf-8")).hexdigest()
            except Exception:
                device_id = str(uuid.uuid4())
        self.device_info = {
            "deviceId": device_id,
            "machineId": machine_id,
            "deviceName": device_name,
            "platform": platform_value,
            "os": os_name
        }
        self.machine_id = machine_id
        self.admin_config["deviceId"] = device_id
        self.admin_config["machineId"] = machine_id
        self.admin_config["deviceName"] = device_name
        self.admin_config["platform"] = platform_value
        self.admin_config["os"] = os_name
        self.admin_config["API_BASE_URL"] = API_BASE_URL
        self.admin_config["pluginCode"] = PLUGIN_CODE
        self.admin_config["clientCode"] = CLIENT_CODE
        self._admin_save_config()
        try:
            self._admin_log("machineId 已加载: " + self._admin_machine_id_prefix())
        except Exception:
            pass

    def _admin_result_body(self, data):
        if isinstance(data, dict) and isinstance(data.get("data"), dict):
            return data.get("data")
        return data if isinstance(data, dict) else {}

    def _admin_message_from_data(self, data, default=""):
        if isinstance(data, dict):
            body = self._admin_result_body(data)
            return str(data.get("message") or data.get("error") or body.get("message") or body.get("error") or default)
        return default

    def _admin_status_from_data(self, data):
        body = self._admin_result_body(data)
        if isinstance(data, dict):
            return str(body.get("reason") or body.get("status") or data.get("reason") or data.get("status") or "").strip().lower()
        return ""

    def _admin_reason_to_message(self, reason, message=""):
        if message:
            return str(message)
        reason = str(reason or "").strip().lower()
        mapping = {
            "no_license": "当前账号暂无授权，请联系管理员开通。",
            "license_expired": "授权已到期，请联系管理员续费。",
            "expired": "授权已到期，请联系管理员续费。",
            "license_disabled": "授权已被禁用，请联系管理员。",
            "disabled": "授权已被禁用，请联系管理员。",
            "user_disabled": "账号已被禁用，请联系管理员。",
            "plugin_disabled": "插件服务已被禁用，请联系管理员。",
            "session_replaced": "账号已在其他设备登录，请重新登录。",
            "machine_replaced": "账号已在其他电脑登录，请重新登录。",
            "unauthorized": "登录已失效，请重新登录。",
            "forbidden": "登录已失效，请重新登录。",
            "token_invalid": "登录已失效，请重新登录。",
            "device_limit_exceeded": "设备数量限制，请联系管理员。",
            "device_limit": "设备数量限制，请联系管理员。",
            "cdk_not_found": "兑换码不存在。",
            "cdk_used": "兑换码已被使用。",
            "cdk_disabled": "兑换码已被禁用，请联系管理员。",
            "cdk_expired": "兑换码已过期，请联系管理员。",
            "unknown": "兑换失败，请稍后重试。"
        }
        return mapping.get(reason, "授权校验失败，请重新登录或联系管理员。")

    def _admin_is_session_replaced(self, data):
        if not isinstance(data, dict):
            return False
        status = self._admin_status_from_data(data)
        message = self._admin_message_from_data(data, "").lower()
        return status == "session_replaced" or "session_replaced" in message or "账号已在其他设备登录" in message

    def _admin_is_machine_replaced(self, data):
        if not isinstance(data, dict):
            return False
        status = self._admin_status_from_data(data)
        message = self._admin_message_from_data(data, "").lower()
        return status == "machine_replaced" or "machine_replaced" in message or "账号已在其他电脑登录" in message

    def _admin_now_iso(self):
        return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

    def _admin_parse_time(self, value):
        text = str(value or "").strip()
        if not text:
            return 0.0
        try:
            if text.endswith("Z"):
                text = text[:-1] + "+00:00"
            dt = datetime.datetime.fromisoformat(text)
            if dt.tzinfo is not None:
                return dt.timestamp()
            return time.mktime(dt.timetuple())
        except Exception:
            pass
        try:
            return time.mktime(time.strptime(text, "%Y-%m-%d %H:%M:%S"))
        except Exception:
            return 0.0

    def _admin_seconds_since_last_verified(self):
        ts = self._admin_parse_time(self.admin_config.get("lastVerifiedAt"))
        if ts <= 0:
            return None
        return time.time() - ts

    def _admin_is_explicit_rejection(self, data):
        if self._admin_is_session_replaced(data) or self._admin_is_machine_replaced(data):
            return True
        body = self._admin_result_body(data)
        http_code = int(data.get("_http_code", 0)) if isinstance(data, dict) else 0
        if http_code in (401, 403):
            return True
        status = str(body.get("status") or data.get("status") or "").strip().lower()
        if status in AUTH_REJECT_STATUSES:
            return True
        message = self._admin_message_from_data(data, "").lower()
        rejection_words = [
            "unauthorized", "forbidden", "token invalid", "invalid token",
            "license_disabled", "license_expired", "user_disabled",
            "plugin_disabled", "device_limit", "device limit",
            "session_replaced", "账号已在其他设备登录",
            "machine_replaced", "账号已在其他电脑登录",
            "未登录", "登录已过期", "授权已过期", "授权被禁用",
            "用户被禁用", "插件被禁用", "设备数量"
        ]
        for word in rejection_words:
            if word and word in message:
                return True
        if isinstance(data, dict) and data.get("success") is False and data:
            return True
        if body.get("allowed") is False or data.get("allowed") is False:
            return True
        return False

    def _admin_offline_grace_available(self):
        age = self._admin_seconds_since_last_verified()
        return age is not None and age <= OFFLINE_GRACE_SECONDS and bool(self.admin_config.get("license"))

    def _admin_apply_offline_grace(self, message):
        if self._admin_offline_grace_available():
            self.admin_license = self.admin_config.get("license") if isinstance(self.admin_config.get("license"), dict) else self.admin_license
            if isinstance(self.admin_license, dict):
                self.admin_license["allowed"] = True
            self._set_core_enabled(True, "")
            self._admin_set_message("离线授权中：网络异常，使用最近一次授权。")
            return True
        if self._admin_seconds_since_last_verified() is None:
            final_message = "授权服务器无法连接，请先联网登录并验证授权。"
        else:
            final_message = "授权服务器无法连接，已超过离线宽限时间，请联网验证授权。"
        self._set_core_enabled(False, final_message)
        return False

    def _admin_handle_session_replaced(self):
        message = "账号已在其他设备登录，请重新登录。"
        self._admin_clear_login()
        self.admin_last_heartbeat_at = 0.0
        self._admin_set_message(message)
        self._set_core_enabled(False, message)
        return False

    def _admin_handle_machine_replaced(self):
        message = "账号已在其他电脑登录，请重新登录。"
        self._admin_clear_login()
        self.admin_last_heartbeat_at = 0.0
        self._admin_set_message(message)
        self._set_core_enabled(False, message)
        return False

    def _admin_handle_auth_failure(self, data, msg, default_message):
        if self._admin_is_machine_replaced(data):
            return self._admin_handle_machine_replaced()
        if self._admin_is_session_replaced(data):
            return self._admin_handle_session_replaced()
        if self._admin_is_explicit_rejection(data):
            status = self._admin_status_from_data(data)
            if not status and int(data.get("_http_code", 0)) in (401, 403):
                status = "unauthorized"
            message = self._admin_reason_to_message(status, self._admin_message_from_data(data, msg or ""))
            if not message:
                message = default_message
            if status in ("unauthorized", "forbidden", "token_invalid") or int(data.get("_http_code", 0)) in (401, 403):
                self._admin_clear_login()
            self.admin_config["licenseInvalidAt"] = self._admin_now_iso()
            self._admin_save_config()
            self._set_core_enabled(False, message)
            return False
        return self._admin_apply_offline_grace(msg or default_message)

    def _admin_ensure_fresh_license(self):
        if DEV_DISABLE_AUTH_GATE:
            return True
        if not self.admin_token:
            self._set_core_enabled(False, "未登录：请输入后台账号密码")
            return False
        age = self._admin_seconds_since_last_verified()
        if self.core_enabled and age is not None and age <= AUTH_REFRESH_INTERVAL_SECONDS:
            return True
        self._admin_set_message("正在刷新授权...")
        return self._admin_check_license()

    def _admin_maybe_heartbeat(self):
        if DEV_DISABLE_AUTH_GATE or not self.admin_token or not self.core_enabled:
            return
        now = time.time()
        if now - self.admin_last_heartbeat_at < HEARTBEAT_INTERVAL_SECONDS:
            return
        self.admin_last_heartbeat_at = now
        self._admin_heartbeat()

    def _admin_request(self, method, path, data=None, token=None, timeout=8):
        url = API_BASE_URL.rstrip("/") + path
        body = None
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "HuahuaC4DPlugin/" + CURRENT_VERSION
        }
        if token:
            headers["Authorization"] = "Bearer " + token
        if data is not None:
            body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=headers, method=method.upper())
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8", "replace")
                parsed = json.loads(raw) if raw.strip() else {}
                if isinstance(parsed, dict) and parsed.get("success") is False:
                    return False, parsed, self._admin_message_from_data(parsed, "请求失败")
                return True, parsed, ""
        except urllib.error.HTTPError as e:
            raw = ""
            parsed = {}
            try:
                raw = e.read().decode("utf-8", "replace")
                parsed = json.loads(raw) if raw.strip() else {}
            except Exception:
                parsed = {}
            parsed["_http_code"] = e.code
            msg = self._admin_message_from_data(parsed, "HTTP " + str(e.code))
            self._admin_log(method + " " + path + " failed: " + msg)
            return False, parsed, msg
        except Exception as e:
            self._admin_log(method + " " + path + " exception: " + type(e).__name__ + ": " + str(e))
            traceback.print_exc()
            return False, {}, str(e)

    def _admin_set_message(self, text):
        self.admin_message = str(text or "")
        try:
            self.SetString(ID_ADMIN_MESSAGE_TEXT, self.admin_message)
        except Exception:
            pass
        self._refresh_admin_dialog()

    def _admin_account_label(self):
        user = self.admin_user or {}
        return str(user.get("nickname") or user.get("email") or user.get("account") or "未登录")

    def _admin_auth_status_text(self):
        if DEV_DISABLE_AUTH_GATE:
            return "开发模式"
        if not self.admin_token:
            return "未登录"
        reason = str(self.core_disabled_reason or "")
        license_info = self.admin_license or {}
        if self.core_enabled and bool(license_info.get("allowed")):
            return "已授权"
        if "其他电脑" in reason or "machine_replaced" in reason.lower():
            return "需重新登录"
        if "其他设备" in reason or "session_replaced" in reason.lower():
            return "需重新登录"
        if "强制更新" in reason or "需更新" in reason:
            return "需更新"
        if "设备" in reason or "超限" in reason:
            return "设备限制"
        if "过期" in reason or "expired" in reason.lower():
            return "已过期"
        if "禁用" in reason or "disabled" in reason.lower():
            return "已禁用"
        if license_info and not bool(license_info.get("allowed")):
            return "未授权"
        return "授权异常"

    def _admin_top_button_text(self):
        if DEV_DISABLE_AUTH_GATE:
            return "开发模式"
        if not self.admin_token:
            return "登录"
        return self._admin_auth_status_text()

    def _admin_machine_id_prefix(self):
        machine_id = str(self.machine_id or self.device_info.get("machineId") or self.admin_config.get("machineId") or "").strip()
        return machine_id[:8] if machine_id else "-"

    def _format_remaining_time(self, expires_at):
        text = str(expires_at or "").strip()
        if not text or text == "-":
            return "-"
        try:
            if text.endswith("Z"):
                expires = datetime.datetime.fromisoformat(text[:-1] + "+00:00")
            else:
                expires = datetime.datetime.fromisoformat(text)
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=datetime.timezone.utc)
            now = datetime.datetime.now(datetime.timezone.utc)
            seconds = (expires.astimezone(datetime.timezone.utc) - now).total_seconds()
            if seconds <= 0:
                return "已过期"
            days = int(seconds // 86400)
            if days >= 1:
                return "剩余 " + str(days) + " 天"
            hours = max(1, int(seconds // 3600))
            return "剩余 " + str(hours) + " 小时"
        except Exception:
            return "-"

    def _refresh_admin_dialog(self):
        try:
            if self.admin_dialog:
                self.admin_dialog.RefreshValues()
        except Exception as e:
            self._admin_log("刷新账号授权弹窗失败: " + str(e))

    def _open_admin_auth_dialog(self):
        try:
            if self.admin_dialog is None:
                self.admin_dialog = AdminAuthDialog(self)
            opened = self.admin_dialog.Open(
                dlgtype=c4d.DLG_TYPE_ASYNC,
                pluginid=ADMIN_AUTH_DIALOG_ID,
                defaultw=420,
                defaulth=360
            )
            self._refresh_admin_dialog()
            return opened
        except Exception as e:
            self._admin_log("打开账号授权弹窗失败: " + str(e))
            traceback.print_exc()
            gui.MessageDialog("打开账号授权窗口失败:\n" + str(e))
            return False

    def _open_admin_register_dialog(self):
        try:
            if self.admin_register_dialog is None:
                self.admin_register_dialog = AdminRegisterDialog(self)
            return self.admin_register_dialog.Open(
                dlgtype=c4d.DLG_TYPE_ASYNC,
                pluginid=ADMIN_REGISTER_DIALOG_ID,
                defaultw=420,
                defaulth=260
            )
        except Exception as e:
            self._admin_log("打开注册账号弹窗失败: " + str(e))
            traceback.print_exc()
            gui.MessageDialog("打开注册账号窗口失败:\n" + str(e))
            return False

    def _open_admin_redeem_dialog(self):
        if not self.admin_token:
            gui.MessageDialog("请先登录后兑换 CDK。")
            self._admin_set_message("请先登录后兑换 CDK。")
            return False
        try:
            if self.admin_redeem_dialog is None:
                self.admin_redeem_dialog = RedeemCdkDialog(self)
            return self.admin_redeem_dialog.Open(
                dlgtype=c4d.DLG_TYPE_ASYNC,
                pluginid=ADMIN_REDEEM_CDK_DIALOG_ID,
                defaultw=420,
                defaulth=170
            )
        except Exception as e:
            self._admin_log("打开 CDK 兑换弹窗失败: " + str(e))
            traceback.print_exc()
            gui.MessageDialog("打开 CDK 兑换窗口失败:\n" + str(e))
            return False

    def _admin_clear_password_field(self):
        try:
            self.SetString(ID_ADMIN_PASSWORD, "")
        except Exception:
            pass
        try:
            if self.admin_dialog:
                self.admin_dialog.SetString(ID_ADMIN_PASSWORD, "")
        except Exception as e:
            self._admin_log("清空密码输入框失败: " + str(e))

    def _admin_update_ui(self):
        try:
            self.SetString(ID_ADMIN_OPEN_DIALOG_BTN, self._admin_top_button_text())
        except Exception as e:
            self._admin_log("更新右上角授权按钮失败: " + str(e))
        self._refresh_admin_dialog()

    def _set_core_enabled(self, enabled, reason=""):
        if DEV_DISABLE_AUTH_GATE:
            if not enabled:
                self._admin_log("DEV_DISABLE_AUTH_GATE=True，开发模式：忽略核心功能禁用请求。")
            self.core_enabled = True
            self.core_disabled_reason = ""
            self.admin_message = "当前为本地开发模式，已临时跳过授权限制。"
            for cid in CORE_BUTTON_IDS:
                try:
                    self.Enable(cid, True)
                except Exception:
                    pass
            self._admin_update_ui()
            return
        self.core_enabled = bool(enabled)
        self.core_disabled_reason = str(reason or "")
        for cid in CORE_BUTTON_IDS:
            try:
                self.Enable(cid, self.core_enabled)
            except Exception:
                pass
        if not self.core_enabled and self.core_disabled_reason:
            self._admin_set_message(self.core_disabled_reason)
        self._admin_update_ui()

    def _admin_clear_login(self):
        self.admin_token = ""
        self.admin_user = None
        self.admin_license = None
        self.admin_config.pop("token", None)
        self.admin_config.pop("user", None)
        self.admin_config.pop("license", None)
        self.admin_config.pop("lastLoginAt", None)
        self.admin_config.pop("lastVerifiedAt", None)
        self.admin_config.pop("lastHeartbeatAt", None)
        self._admin_save_config()

    def _admin_register_account(self, email, password, nickname=""):
        payload = {
            "email": email,
            "password": password,
            "machineId": self.device_info.get("machineId") or self.machine_id
        }
        if nickname:
            payload["nickname"] = nickname
        ok, data, msg = self._admin_request("POST", "/api/auth/register", payload)
        if ok:
            self._admin_set_message("注册成功，请登录。")
            return True
        message = self._admin_reason_to_message(self._admin_status_from_data(data), self._admin_message_from_data(data, msg or "注册失败"))
        self._admin_set_message(message)
        gui.MessageDialog(message)
        return False

    def _admin_redeem_cdk(self, code):
        code = str(code or "").strip()
        if not code:
            gui.MessageDialog("请输入 CDK 兑换码。")
            return False
        if not self.admin_token:
            gui.MessageDialog("请先登录后兑换 CDK。")
            self._admin_set_message("请先登录后兑换 CDK。")
            return False
        payload = {
            "code": code,
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE
        }
        self._admin_set_message("正在兑换 CDK...")
        ok, data, msg = self._admin_request("POST", "/api/cdk/redeem", payload, token=self.admin_token, timeout=8)
        if not ok:
            http_code = int(data.get("_http_code", 0)) if isinstance(data, dict) else 0
            status = self._admin_status_from_data(data)
            if not status and http_code in (401, 403):
                status = "unauthorized"
            if not data:
                message = "无法连接授权服务器，请检查网络。"
            else:
                message = self._admin_reason_to_message(status or "unknown", self._admin_message_from_data(data, msg or ""))
            if not message or message == "授权校验失败，请重新登录或联系管理员。":
                if msg:
                    message = "无法连接授权服务器，请检查网络。"
                else:
                    message = "兑换失败，请稍后重试。"
            if status in ("unauthorized", "forbidden", "token_invalid") or http_code in (401, 403):
                self._admin_clear_login()
                self._set_core_enabled(False, "登录已失效，请重新登录。")
            self._admin_set_message(message)
            gui.MessageDialog(message)
            return False
        gui.MessageDialog("兑换成功，正在刷新授权。")
        self._admin_set_message("兑换成功，正在刷新授权。")
        if self._admin_check_license():
            self._admin_register_device()
            self._admin_check_update(show_dialog=False)
            self._admin_heartbeat()
            if not self.core_disabled_reason.startswith("检测到强制更新"):
                self._set_core_enabled(True, "")
                self._admin_set_message("授权通过")
        self._admin_update_ui()
        return True

    def _admin_login(self, account, password):
        ok, data, msg = self._admin_request("POST", "/api/auth/login", {
            "account": account,
            "password": password,
            "machineId": self.device_info.get("machineId") or self.machine_id,
            "deviceId": self.device_info.get("deviceId"),
            "clientCode": CLIENT_CODE,
            "pluginCode": PLUGIN_CODE
        })
        if not ok:
            message = self._admin_reason_to_message(self._admin_status_from_data(data), self._admin_message_from_data(data, msg or "登录失败"))
            self._admin_set_message(message)
            self._set_core_enabled(False, message)
            return False
        body = self._admin_result_body(data)
        token = body.get("token") or data.get("token")
        user = body.get("user") or data.get("user") or {}
        if not token:
            self._admin_set_message("登录失败：后台未返回 token")
            self._set_core_enabled(False, "登录失败：后台未返回 token")
            return False
        self.admin_token = str(token)
        self.admin_user = user if isinstance(user, dict) else {}
        self.admin_config["token"] = self.admin_token
        self.admin_config["user"] = self.admin_user
        self.admin_config["lastLoginAt"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._admin_save_config()
        self._admin_clear_password_field()
        self._admin_set_message("登录成功，正在校验授权...")
        return self._admin_authorize_after_login()

    def _admin_get_me(self):
        ok, data, msg = self._admin_request("GET", "/api/auth/me", token=self.admin_token)
        if not ok:
            if self._admin_is_machine_replaced(data):
                return self._admin_handle_machine_replaced()
            if self._admin_is_session_replaced(data):
                return self._admin_handle_session_replaced()
            if self._admin_is_explicit_rejection(data):
                return self._admin_handle_auth_failure(data, msg, "登录状态已失效，请重新登录")
            if not self._admin_is_explicit_rejection(data) and self._admin_offline_grace_available():
                self._admin_apply_offline_grace(msg or "网络异常，使用最近一次授权")
                return True
            self._admin_clear_login()
            self._admin_set_message(msg or "登录状态已失效，请重新登录")
            self._set_core_enabled(False, msg or "登录状态已失效，请重新登录")
            return False
        body = self._admin_result_body(data)
        user = body.get("user") or body or {}
        self.admin_user = user if isinstance(user, dict) else {}
        self.admin_config["user"] = self.admin_user
        self._admin_save_config()
        return True

    def _admin_check_license(self):
        payload = {
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE,
            "version": PLUGIN_VERSION,
            "platform": self.device_info.get("platform"),
            "deviceId": self.device_info.get("deviceId"),
            "machineId": self.device_info.get("machineId") or self.machine_id,
            "deviceName": self.device_info.get("deviceName"),
            "os": self.device_info.get("os")
        }
        ok, data, msg = self._admin_request("POST", "/api/plugin/check-license", payload, token=self.admin_token)
        self.admin_last_check_license_result = {"success": ok, "data": data, "message": msg}
        if not ok:
            return self._admin_handle_auth_failure(data, msg, "授权校验失败")
        body = self._admin_result_body(data)
        allowed = bool(body.get("allowed", data.get("allowed", False)))
        if "license" in body and isinstance(body.get("license"), dict):
            license_info = body.get("license")
        else:
            license_info = body
        license_info["allowed"] = allowed
        self.admin_license = license_info
        self.admin_config["license"] = license_info
        self.admin_config["lastVerifiedAt"] = self._admin_now_iso()
        self.admin_config.pop("licenseInvalidAt", None)
        self._admin_save_config()
        if not allowed:
            return self._admin_handle_auth_failure(data, self._admin_message_from_data(data, body.get("message") or ""), "插件未授权")
        return True

    def _admin_register_device(self):
        payload = {
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE,
            "deviceId": self.device_info.get("deviceId"),
            "machineId": self.device_info.get("machineId") or self.machine_id,
            "deviceName": self.device_info.get("deviceName"),
            "os": self.device_info.get("os"),
            "platform": self.device_info.get("platform")
        }
        ok, data, msg = self._admin_request("POST", "/api/plugin/register-device", payload, token=self.admin_token)
        self.admin_last_register_device_result = {"success": ok, "data": data, "message": msg}
        if not ok:
            return self._admin_handle_auth_failure(data, msg, "设备注册失败")
        body = self._admin_result_body(data)
        allowed = bool(body.get("allowed", data.get("allowed", True)))
        if not allowed:
            return self._admin_handle_auth_failure(data, self._admin_message_from_data(data, body.get("message") or ""), "设备注册失败")
        return True

    def _format_update_notes(self, notes):
        if isinstance(notes, list):
            return "\n".join(["- " + str(item) for item in notes]) if notes else "- 暂无版本说明"
        text = str(notes or "").strip()
        return text if text else "- 暂无版本说明"

    def _format_update_file_size(self, file_size):
        if file_size is None or file_size == "":
            return ""
        try:
            size = float(file_size)
            if size >= 1024 * 1024:
                return str(round(size / 1024.0 / 1024.0, 1)) + " MB"
            if size >= 1024:
                return str(round(size / 1024.0, 1)) + " KB"
            return str(int(size)) + " B"
        except Exception:
            return str(file_size)

    def _download_source_label(self, url):
        text = str(url or "")
        if "43.155.144.82" in text or "/downloads/" in text:
            return "服务器镜像下载，推荐"
        if text:
            return "后台下载地址"
        return "暂无下载地址"

    def _open_update_download_url(self, url):
        url = str(url or "").strip()
        if not url:
            self._update_log("下载地址为空")
            gui.MessageDialog("暂无可用下载地址，请联系管理员。")
            return False
        self._update_log("打开后台返回下载地址: " + url)
        try:
            webbrowser.open(url)
            return True
        except Exception as e:
            self._update_log("打开下载地址失败: " + str(e))
            gui.MessageDialog("主下载地址不可用，请尝试备用下载。")
            return False

    def _show_backend_update_dialog(self, latest, note_text, download_url, fallback_url, file_size="", sha256=""):
        lines = [
            "检测到新版本：v" + str(latest),
            "当前版本：v" + CURRENT_VERSION,
            "下载来源：" + self._download_source_label(download_url),
        ]
        formatted_size = self._format_update_file_size(file_size)
        if formatted_size:
            lines.append("文件大小：" + formatted_size)
        if sha256:
            lines.append("SHA256：" + str(sha256))
        lines.extend(["", "版本说明：", str(note_text or "- 暂无版本说明")])

        if download_url:
            message = "\n".join(lines) + "\n\n是否立即下载？"
            if gui.QuestionDialog(message):
                if self._open_update_download_url(download_url):
                    return
                if fallback_url and gui.QuestionDialog("主下载地址不可用，是否打开备用下载？"):
                    self._open_update_download_url(fallback_url)
            elif fallback_url and gui.QuestionDialog("是否打开备用下载？"):
                self._open_update_download_url(fallback_url)
            return

        if fallback_url:
            message = "\n".join(lines) + "\n\n暂无主下载地址，是否打开备用下载？"
            if gui.QuestionDialog(message):
                self._open_update_download_url(fallback_url)
            return

        gui.MessageDialog("\n".join(lines) + "\n\n暂无可用下载地址，请联系管理员。")

    def _admin_check_update(self, show_dialog=False):
        payload = {
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE,
            "currentVersion": PLUGIN_VERSION,
            "version": PLUGIN_VERSION,
            "platform": self.device_info.get("platform", self._admin_platform()),
            "os": self.device_info.get("os", self._admin_os_name()),
            "appVersion": PLUGIN_VERSION,
            "deviceId": self.device_info.get("deviceId"),
            "machineId": self.device_info.get("machineId") or self.machine_id
        }
        self._update_log("请求后台 check-update: " + API_BASE_URL.rstrip("/") + "/api/plugin/check-update")
        self._update_log("请求字段: pluginCode=" + PLUGIN_CODE + ", clientCode=" + CLIENT_CODE + ", currentVersion=" + PLUGIN_VERSION)
        ok, data, msg = self._admin_request("POST", "/api/plugin/check-update", payload, token=self.admin_token)
        self.admin_last_check_update_result = {"success": ok, "data": data, "message": msg}
        if not ok:
            self._admin_log("检查后台更新失败: " + (msg or "未知错误"))
            if show_dialog:
                gui.MessageDialog("检查更新失败，请稍后重试。")
            return False
        body = self._admin_result_body(data)
        self.admin_update_info = body
        self._admin_update_ui()
        has_update_value = body.get("hasUpdate", data.get("hasUpdate", body.get("updateAvailable", data.get("updateAvailable", None))))
        force_update = bool(body.get("forceUpdate", data.get("forceUpdate", False)))
        latest = body.get("latestVersion") or body.get("latest_version") or body.get("version") or data.get("version") or CURRENT_VERSION
        compare_result = self._compare_versions(CURRENT_VERSION, latest)
        has_update = bool(has_update_value) if has_update_value is not None else compare_result > 0
        notes = body.get("releaseNotes") or body.get("release_notes") or body.get("notes") or body.get("changelog") or data.get("notes") or []
        note_text = self._format_update_notes(notes)
        download_url = str(body.get("downloadUrl") or body.get("mirrorDownloadUrl") or data.get("downloadUrl") or data.get("mirrorDownloadUrl") or "").strip()
        fallback_url = str(body.get("fallbackUrl") or body.get("originalDownloadUrl") or data.get("fallbackUrl") or data.get("originalDownloadUrl") or "").strip()
        file_size = body.get("fileSize", data.get("fileSize", ""))
        sha256 = body.get("sha256", data.get("sha256", ""))
        if force_update:
            self._set_core_enabled(False, "检测到强制更新版本：v" + str(latest))
        if show_dialog:
            if has_update:
                self._show_backend_update_dialog(str(latest), note_text, download_url, fallback_url, file_size, sha256)
            else:
                gui.MessageDialog("当前已经是最新版本：v" + CURRENT_VERSION)
        return True

    def _admin_heartbeat(self):
        payload = {
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE,
            "deviceId": self.device_info.get("deviceId"),
            "machineId": self.device_info.get("machineId") or self.machine_id,
            "version": PLUGIN_VERSION,
            "platform": self.device_info.get("platform")
        }
        ok, data, msg = self._admin_request("POST", "/api/plugin/heartbeat", payload, token=self.admin_token)
        self.admin_last_heartbeat_result = {"success": ok, "data": data, "message": msg}
        if not ok:
            self._admin_log("heartbeat 失败: " + (msg or "未知错误"))
            self._admin_handle_auth_failure(data, msg, "heartbeat 失败")
            return False
        body = self._admin_result_body(data)
        if self._admin_is_explicit_rejection(data) or body.get("allowed") is False:
            return self._admin_handle_auth_failure(data, self._admin_message_from_data(data, body.get("message") or ""), "授权已失效")
        self.admin_config["lastHeartbeatAt"] = self._admin_now_iso()
        self._admin_save_config()
        return ok

    def _admin_authorize_after_login(self):
        if not self._admin_get_me():
            return False
        if not self._admin_check_license():
            return False
        if not self._admin_register_device():
            return False
        self._admin_check_update(show_dialog=False)
        self._admin_heartbeat()
        if self.core_disabled_reason.startswith("检测到强制更新"):
            return False
        self._set_core_enabled(True, "")
        self._admin_set_message("授权通过")
        return True

    def _admin_init_startup(self):
        self._admin_load_config()
        api_base_changed = self._admin_handle_api_base_change()
        self._admin_init_device_info()
        self.admin_token = str(self.admin_config.get("token") or "")
        self.admin_user = self.admin_config.get("user") if isinstance(self.admin_config.get("user"), dict) else None
        self.admin_license = self.admin_config.get("license") if isinstance(self.admin_config.get("license"), dict) else None
        if DEV_DISABLE_AUTH_GATE:
            self._admin_log("DEV_DISABLE_AUTH_GATE=True，已跳过授权拦截，仅用于本地测试。")
            self._set_core_enabled(True, "")
            if not self.admin_token:
                self._admin_set_message("当前为本地开发模式，已临时跳过授权限制。")
                return
        self._admin_update_ui()
        if not self.admin_token:
            reason = "授权后台已切换为云端，请重新登录。" if api_base_changed else "未登录：请输入后台账号密码"
            self._set_core_enabled(False, reason)
            return
        self._admin_set_message("正在校验后台登录和授权...")
        self._admin_authorize_after_login()
        self.SetTimer(JSON_WATCH_INTERVAL_MS)

    def _admin_logout(self):
        self._admin_clear_login()
        self._admin_clear_password_field()
        self._set_core_enabled(False, "已退出登录")
        self._admin_update_ui()

    def _admin_handle_login_click(self):
        self._open_admin_auth_dialog()
        return True

    def _load_json_watch_pref(self):
        self.json_watch_dir = ""
        try:
            bc = plugins.GetWorldPluginData(PLUGIN_ID)
            if bc:
                path = bc.GetString(JSON_WATCH_PREF_PATH)
                if path and os.path.isdir(path):
                    self.json_watch_dir = path
                    self._snapshot_json_watch_dir()
                    self._json_watch_log("已读取监听目录偏好: " + path)
        except Exception as e:
            self._json_watch_log("读取监听目录偏好失败: " + str(e))

    def _save_json_watch_pref(self):
        try:
            bc = plugins.GetWorldPluginData(PLUGIN_ID)
            if bc is None:
                bc = c4d.BaseContainer()
            bc.SetString(JSON_WATCH_PREF_PATH, self.json_watch_dir or "")
            plugins.SetWorldPluginData(PLUGIN_ID, bc, True)
            self._json_watch_log("已保存监听目录: " + (self.json_watch_dir or ""))
        except Exception as e:
            self._json_watch_log("保存监听目录失败: " + str(e))

    def _update_json_watch_status(self, text=None):
        try:
            if text:
                self.SetString(ID_JSON_WATCH_STATUS, text)
            elif self.json_watch_dir:
                self.SetString(ID_JSON_WATCH_STATUS, "正在监听：" + self.json_watch_dir)
            else:
                self.SetString(ID_JSON_WATCH_STATUS, "未选择监听目录")
        except Exception as e:
            self._json_watch_log("更新监听状态失败: " + str(e))

    def _json_watch_log(self, message):
        try:
            print("[JSON Watch] " + str(message))
        except Exception:
            pass

    def _list_json_watch_files(self):
        files = set()
        if not self.json_watch_dir or not os.path.isdir(self.json_watch_dir):
            return files
        try:
            for name in os.listdir(self.json_watch_dir):
                if not name.lower().endswith(".json"):
                    continue
                path = os.path.join(self.json_watch_dir, name)
                if os.path.isfile(path):
                    files.add(os.path.abspath(path))
        except Exception as e:
            self._json_watch_log("扫描监听目录失败: " + str(e))
        return files

    def _snapshot_json_watch_dir(self):
        files = self._list_json_watch_files()
        self.json_watch_seen = set(files)
        self.json_watch_processed = set(files)
        self.json_watch_candidates = {}
        self._json_watch_log("baseline 已记录现有 JSON 数量: " + str(len(files)))

    def _start_json_watch_timer(self):
        self.SetTimer(JSON_WATCH_INTERVAL_MS)
        self._json_watch_log("Timer 已启动: " + str(JSON_WATCH_INTERVAL_MS) + "ms")
        self._update_json_watch_status()

    def _select_json_watch_dir(self):
        folder = storage.LoadDialog(title="选择 JSON 监听文件夹", flags=c4d.FILESELECT_DIRECTORY)
        if not folder:
            self._json_watch_log("用户取消选择监听目录")
            return
        self.json_watch_dir = folder
        self._json_watch_log("选择的监听目录: " + folder)
        self._save_json_watch_pref()
        self._snapshot_json_watch_dir()
        self._update_json_watch_status()
        self._start_json_watch_timer()

    def Timer(self, msg):
        self._run_json_watch_check("Timer")
        return True

    def Message(self, msg, result):
        try:
            timer_id = getattr(c4d, "BFM_TIMER", None)
            if timer_id is not None and msg and msg.GetId() == timer_id:
                self._run_json_watch_check("Message.BFM_TIMER")
                return True
        except Exception as e:
            self._json_watch_log("Timer Message 处理失败: " + str(e))
        return gui.GeDialog.Message(self, msg, result)

    def _run_json_watch_check(self, source):
        now = time.time()
        self._admin_maybe_heartbeat()
        if now - self.json_watch_last_check_time < 1.0:
            return
        self.json_watch_last_check_time = now
        self._json_watch_log("检查监听目录 source=" + source + " time=" + time.strftime("%H:%M:%S"))
        try:
            self._check_json_watch_folder()
        except Exception as e:
            self._json_watch_log("监听检查异常: " + str(e))
            traceback.print_exc()

    def _check_json_watch_folder(self):
        if not self.json_watch_dir:
            return
        if not os.path.isdir(self.json_watch_dir):
            self._json_watch_log("监听目录不存在: " + self.json_watch_dir)
            self._update_json_watch_status("监听目录不存在：" + self.json_watch_dir)
            return

        current_files = self._list_json_watch_files()
        for path in list(self.json_watch_candidates.keys()):
            if path not in current_files:
                self.json_watch_candidates.pop(path, None)

        now = time.time()
        for path in sorted(current_files):
            if path in self.json_watch_processed:
                continue
            try:
                stat_info = os.stat(path)
                size = stat_info.st_size
                mtime = stat_info.st_mtime
            except Exception as e:
                self._json_watch_log("读取文件状态失败: " + path + " / " + str(e))
                continue

            prev = self.json_watch_candidates.get(path)
            if prev and prev[0] == size and prev[1] == mtime:
                self.json_watch_seen.add(path)
                self.json_watch_processed.add(path)
                self.json_watch_candidates.pop(path, None)
                file_name = os.path.basename(path)
                self._json_watch_log("文件稳定，准备弹窗: " + file_name)
                self._update_json_watch_status("已检测到新 JSON：" + file_name)
                should_import = gui.QuestionDialog("检测到新的 JSON 文件：" + file_name + "\n是否导入？")
                if should_import:
                    self._json_watch_log("用户确认导入: " + file_name)
                    self._update_json_watch_status("正在导入：" + file_name)
                    self._json_watch_log("调用导入函数: _do_import(file_path_override=path)")
                    self._do_import(file_path_override=path)
                    self._update_json_watch_status("已导入：" + file_name)
                else:
                    self._json_watch_log("用户取消导入: " + file_name)
                    self._update_json_watch_status("已取消导入：" + file_name)
                break

            if not prev or prev[0] != size or prev[1] != mtime:
                self.json_watch_candidates[path] = (size, mtime, now)
                self._json_watch_log("发现新的 json 文件，等待稳定: " + os.path.basename(path) + " size=" + str(size))

    def _update_log(self, message):
        try:
            print("[Update Check] " + str(message))
        except Exception:
            pass

    def _parse_version(self, version_text):
        parts = []
        for part in str(version_text or "").strip().lstrip("vV").split("."):
            digits = ""
            for ch in part:
                if ch.isdigit():
                    digits += ch
                else:
                    break
            parts.append(int(digits) if digits else 0)
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:3])

    def _compare_versions(self, local_version, remote_version):
        local_tuple = self._parse_version(local_version)
        remote_tuple = self._parse_version(remote_version)
        if remote_tuple > local_tuple:
            return 1
        if remote_tuple < local_tuple:
            return -1
        return 0

    def _action_check_update(self):
        self._update_log("点击了检查更新")
        self._update_log("当前版本 CURRENT_VERSION: " + CURRENT_VERSION)
        self._admin_check_update(show_dialog=True)
        return True

    def CoreMessage(self, id, msg):
        if id == c4d.EVMSG_CHANGE:
            self._update_ui_from_selection()
        return gui.GeDialog.CoreMessage(self, id, msg)

    # --- UI Helper Functions ---
    def SetLoadProgress(self, percent, message):
        percent = max(0, min(100, int(percent)))
        text = str(message or "")
        try:
            self.load_progress_area.SetProgress(percent)
            self.SetString(ID_LOAD_PROGRESS_TEXT, text)
            self.LayoutChanged(ID_LOAD_PROGRESS_GROUP)
            c4d.StatusSetText(text)
            c4d.EventAdd()
            if hasattr(c4d, "GeSyncMessage"):
                c4d.GeSyncMessage(c4d.EVMSG_CHANGE)
        except Exception as e:
            print("[Load Progress] 更新失败: " + str(e))

    def ResetLoadProgress(self):
        self.SetLoadProgress(0, "等待选择文件")

    def FinishLoadProgress(self):
        self.SetLoadProgress(100, "导入完成")

    def FailLoadProgress(self, error_message):
        msg = str(error_message).strip() or "未知错误"
        self.SetLoadProgress(0, f"导入失败：{msg}")

    def _get_target_spline(self, obj):
        if not obj: return None
        if obj.CheckType(c4d.Ospline): return obj
        if obj.CheckType(c4d.Oextrude) or obj.GetType() == C4D_EXTRUDE_TYPEID:
            child = obj.GetDown()
            if child and child.CheckType(c4d.Ospline): return child
        return None

    def _update_ui_from_selection(self):
        doc = documents.GetActiveDocument()
        if not doc: return
        obj = doc.GetActiveObject()
        if not obj: return
        
        if obj.CheckType(c4d.Oextrude) or obj.GetType() == C4D_EXTRUDE_TYPEID:
            current_depth = 0.0
            try: current_depth = abs(obj[C4D_EXTRUDE_OFFSET_ID])
            except:
                try:
                    vec = obj[c4d.EXTRUDEOBJECT_MOVE]
                    current_depth = vec.GetLength()
                except: pass
            
            ui_val = self.GetFloat(ID_EXTRUDE_DEPTH)
            if abs(ui_val - current_depth) > 0.001:
                 self.SetFloat(ID_EXTRUDE_DEPTH, current_depth)
                 self.SetFloat(ID_EXTRUDE_SLIDER, current_depth)
    
        target_spline = self._get_target_spline(obj)
        if target_spline:
            try:
                self.SetInt32(ID_SPL_TYPE_COMBO, target_spline[c4d.SPLINEOBJECT_TYPE])
                self.SetBool(ID_SPL_CLOSE_CHK, target_spline[c4d.SPLINEOBJECT_CLOSED])
                inter = target_spline[c4d.SPLINEOBJECT_INTERPOLATION]
                self.SetInt32(ID_SPL_INTER_COMBO, inter)
                if inter != c4d.SPLINEOBJECT_INTERPOLATION_ADAPTIVE:
                    self.SetInt32(ID_SPL_SUB_VAL, target_spline[c4d.SPLINEOBJECT_SUB])
            except: pass
    
    def _action_update_spline_param(self, param_id, value):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel: return
        doc.StartUndo()
        changed = False
        for obj in sel:
            target = self._get_target_spline(obj)
            if target:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, target)
                target[param_id] = value
                target.Message(c4d.MSG_UPDATE)
                changed = True
        doc.EndUndo()
        if changed: c4d.EventAdd()

    def _collect_valid_objects(self, start_nodes):
        targets =[]
        if not start_nodes: return[]
        def recurse(op):
            if not op: return
            targets.append(op)
            child = op.GetDown()
            while child:
                recurse(child)
                child = child.GetNext()
        for node in start_nodes: recurse(node)
        seen = set()
        unique =[]
        for t in targets:
            guid = t.GetGUID()
            if guid not in seen:
                unique.append(t)
                seen.add(guid)
        return unique

    def _get_real_world_bounds(self, obj):
        min_x = min_y = min_z = float('inf')
        max_x = max_y = max_z = float('-inf')
        has_points = False
        def traverse_points(op):
            nonlocal min_x, min_y, min_z, max_x, max_y, max_z, has_points
            points = None
            if op.CheckType(c4d.Opoint): points = op.GetAllPoints()
            if points:
                mg = op.GetMg()
                for p in points:
                    wp = mg * p 
                    if wp.x < min_x: min_x = wp.x
                    if wp.x > max_x: max_x = wp.x
                    if wp.y < min_y: min_y = wp.y
                    if wp.y > max_y: max_y = wp.y
                    if wp.z < min_z: min_z = wp.z
                    if wp.z > max_z: max_z = wp.z
                    has_points = True
            cache = op.GetCache()
            if cache: traverse_points(cache)
            child = op.GetDown()
            while child:
                traverse_points(child)
                child = child.GetNext()
        traverse_points(obj)
        if not has_points:
            pos = obj.GetMg().off
            return pos, pos, pos
        center = c4d.Vector((min_x + max_x)*0.5, (min_y + max_y)*0.5, (min_z + max_z)*0.5)
        min_vec = c4d.Vector(min_x, min_y, min_z)
        max_vec = c4d.Vector(max_x, max_y, max_z)
        return center, min_vec, max_vec

    def _center_axis(self, obj):
        center, _, _ = self._get_real_world_bounds(obj)
        old_mg = obj.GetMg()
        children = obj.GetChildren()
        child_mgs = [child.GetMg() for child in children]
        new_mg = c4d.Matrix(old_mg)
        new_mg.off = center
        obj.SetMg(new_mg)
        if obj.CheckType(c4d.Opoint):
            points = obj.GetAllPoints()
            inv_new_mg = ~new_mg
            new_points =[inv_new_mg * (old_mg * p) for p in points]
            obj.SetAllPoints(new_points)
            obj.Message(c4d.MSG_UPDATE)
        for child, mg in zip(children, child_mgs):
            child.SetMg(mg)

    def _action_select_hidden_objects(self):
        doc = documents.GetActiveDocument()
        if not doc: return
        c4d.CallCommand(12113) 
        found_count = 0
        def scan_hidden(op):
            nonlocal found_count
            if op is None: return
            if op.GetEditorMode() == c4d.MODE_OFF: 
                op.SetBit(c4d.BIT_ACTIVE)
                found_count += 1
            child = op.GetDown()
            while child is not None:
                next_child = child.GetNext()
                scan_hidden(child)
                child = next_child
        root_obj = doc.GetFirstObject()
        while root_obj is not None:
            next_root = root_obj.GetNext()
            scan_hidden(root_obj)
            root_obj = next_root
        c4d.EventAdd()
        if found_count > 0: c4d.StatusSetText(f"已选中 {found_count} 个隐藏对象")
        else: gui.MessageDialog("当前场景中没有找到被隐藏（红点/Off）的对象。")

    def _action_select_textured_objects(self):
        doc = documents.GetActiveDocument()
        if not doc: return
        c4d.CallCommand(12113)
        found_count = 0
        def scan_textured(op):
            nonlocal found_count
            if not op: return
            has_texture = False
            tags = op.GetTags()
            for t in tags:
                if t.CheckType(c4d.Ttexture):
                    mat = t.GetMaterial()
                    if mat:
                        if mat[c4d.MATERIAL_USE_COLOR]:
                            shader = mat[c4d.MATERIAL_COLOR_SHADER]
                            if shader: has_texture = True
                        if not has_texture and mat[c4d.MATERIAL_USE_LUMINANCE]:
                            shader = mat[c4d.MATERIAL_LUMINANCE_SHADER]
                            if shader: has_texture = True
                        if has_texture: break
            if has_texture:
                op.SetBit(c4d.BIT_ACTIVE)
                found_count += 1
            child = op.GetDown()
            while child:
                scan_textured(child)
                child = child.GetNext()
        root_obj = doc.GetFirstObject()
        while root_obj:
            scan_textured(root_obj)
            root_obj = root_obj.GetNext()
        c4d.EventAdd()
        if found_count > 0: c4d.StatusSetText(f"已选中 {found_count} 个带贴图的对象")
        else: gui.MessageDialog("未找到带有纹理贴图的对象。")

    def _action_drop_to_floor(self):
        try:
            doc = documents.GetActiveDocument()
            sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if not sel: return
            doc.StartUndo()
            for obj in sel:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                _, min_vec, _ = self._get_real_world_bounds(obj)
                diff_y = -min_vec.y
                mg = obj.GetMg()
                mg.off = c4d.Vector(mg.off.x, mg.off.y + diff_y, mg.off.z)
                obj.SetMg(mg)
            doc.EndUndo()
            c4d.EventAdd()
        except Exception as e: gui.MessageDialog(f"执行出错: {e}")

    def _action_center_x(self):
        try:
            doc = documents.GetActiveDocument()
            sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if not sel: return
            doc.StartUndo()
            for obj in sel:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                center, _, _ = self._get_real_world_bounds(obj)
                diff_x = -center.x
                mg = obj.GetMg()
                mg.off = c4d.Vector(mg.off.x + diff_x, mg.off.y, mg.off.z)
                obj.SetMg(mg)
            doc.EndUndo()
            c4d.EventAdd()
        except Exception as e: gui.MessageDialog(f"执行出错: {e}")

    def _action_stand_up(self):
        try:
            doc = documents.GetActiveDocument()
            sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if not sel: return
            doc.StartUndo()
            for obj in sel:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                rot = obj.GetRelRot()
                rot.x = c4d.utils.Rad(-90)
                obj.SetRelRot(rot)
                obj.Message(c4d.MSG_UPDATE)
                _, min_vec, _ = self._get_real_world_bounds(obj)
                mg = obj.GetMg()
                mg.off = c4d.Vector(mg.off.x, mg.off.y - min_vec.y, mg.off.z)
                obj.SetMg(mg)
            doc.EndUndo()
            c4d.EventAdd()
        except Exception as e: gui.MessageDialog(f"执行出错: {e}")

    def _action_reset_psr(self):
        try:
            doc = documents.GetActiveDocument()
            sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if not sel: return
            doc.StartUndo()
            for obj in sel:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                obj.SetAbsRot(c4d.Vector(0))
                obj.Message(c4d.MSG_UPDATE)
                self._center_axis(obj)
                obj.SetAbsPos(c4d.Vector(0))
            doc.EndUndo()
            c4d.EventAdd()
        except Exception as e: gui.MessageDialog(f"执行出错: {e}")

    def _action_move_selection(self, vector):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
        if not sel: return
        doc.StartUndo()
        for obj in sel:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
            mg = obj.GetMg()
            move_m = c4d.utils.MatrixMove(vector)
            new_mg = mg * move_m 
            obj.SetMg(new_mg)
        doc.EndUndo()
        c4d.EventAdd()

    # =========================================================================
    #  全方位轴心工具 (XY + Z)
    # =========================================================================
    def _get_local_hierarchy_bounds_axis(self, obj, root_inv_mg):
        min_p = c4d.Vector(1e15)
        max_p = c4d.Vector(-1e15)
        has_geometry = False

        def traverse(node):
            nonlocal min_p, max_p, has_geometry
            rad = node.GetRad()
            mp = node.GetMp()
            
            if rad.x != 0 or rad.y != 0 or rad.z != 0 or node.CheckType(c4d.Opoint):
                has_geometry = True
                corners =[
                    c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z - rad.z),
                    c4d.Vector(mp.x + rad.x, mp.y - rad.y, mp.z - rad.z),
                    c4d.Vector(mp.x - rad.x, mp.y + rad.y, mp.z - rad.z),
                    c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z - rad.z),
                    c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z + rad.z),
                    c4d.Vector(mp.x + rad.x, mp.y - rad.y, mp.z + rad.z),
                    c4d.Vector(mp.x - rad.x, mp.y + rad.y, mp.z + rad.z),
                    c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z + rad.z)
                ]
                
                node_mg = node.GetMg()
                for p in corners:
                    world_p = node_mg * p
                    root_local_p = root_inv_mg * world_p 
                    
                    if root_local_p.x < min_p.x: min_p.x = root_local_p.x
                    if root_local_p.y < min_p.y: min_p.y = root_local_p.y
                    if root_local_p.z < min_p.z: min_p.z = root_local_p.z
                    
                    if root_local_p.x > max_p.x: max_p.x = root_local_p.x
                    if root_local_p.y > max_p.y: max_p.y = root_local_p.y
                    if root_local_p.z > max_p.z: max_p.z = root_local_p.z

            for child in node.GetChildren():
                traverse(child)

        traverse(obj)
        if not has_geometry: return c4d.Vector(0), c4d.Vector(0)
        return min_p, max_p

    def _action_align_axis(self, direction):
        doc = documents.GetActiveDocument()
        doc.StartUndo() 

        selection = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not selection: 
            gui.MessageDialog("请先选中要调整轴心的对象！")
            return

        for obj in selection:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)

            mg = obj.GetMg()
            inv_mg = ~mg 

            min_local, max_local = self._get_local_hierarchy_bounds_axis(obj, inv_mg)
            size = max_local - min_local
            center = (max_local + min_local) * 0.5
            
            target_local_pos = c4d.Vector(
                center.x + (size.x * 0.5 * direction.x),
                center.y + (size.y * 0.5 * direction.y),
                center.z + (size.z * 0.5 * direction.z) 
            )
            
            offset = target_local_pos
            
            if obj.CheckType(c4d.Opoint):
                all_points = obj.GetAllPoints()
                new_points = [p - offset for p in all_points]
                obj.SetAllPoints(new_points)
                obj.Message(c4d.MSG_UPDATE)
            
            children = obj.GetChildren()
            for child in children:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, child)
                child_ml = child.GetMl()
                child_ml.off -= offset 
                child.SetMl(child_ml)

            global_offset = mg.MulV(offset)
            mg.off += global_offset
            obj.SetMg(mg)

        doc.EndUndo() 
        c4d.EventAdd() 
        c4d.StatusSetText("✅ 轴心对齐完成。")

    # =========================================================================
    #  花花智能建模-C4D端 v1.1 - Super Align 核心功能区
    # =========================================================================
    def _collect_sub_object_face_points(self, root_obj, axis, direction):
        points_list =[]
        stack = [root_obj]
        while stack:
            o = stack.pop()
            rad = o.GetRad()
            if rad.GetLengthSquared() > 1e-5:
                mg = o.GetMg()
                mp = o.GetMp()
                min_l = c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z - rad.z)
                max_l = c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z + rad.z)
                
                local_pts =[]
                if axis == 0:
                    x = max_l.x if direction > 0 else min_l.x
                    local_pts =[
                        c4d.Vector(x, mp.y, mp.z), c4d.Vector(x, max_l.y, max_l.z),
                        c4d.Vector(x, max_l.y, min_l.z), c4d.Vector(x, min_l.y, max_l.z),
                        c4d.Vector(x, min_l.y, min_l.z)
                    ]
                elif axis == 1:
                    y = max_l.y if direction > 0 else min_l.y
                    local_pts =[
                        c4d.Vector(mp.x, y, mp.z), c4d.Vector(max_l.x, y, max_l.z),
                        c4d.Vector(min_l.x, y, max_l.z), c4d.Vector(max_l.x, y, min_l.z),
                        c4d.Vector(min_l.x, y, min_l.z)
                    ]
                elif axis == 2:
                    z = max_l.z if direction > 0 else min_l.z
                    local_pts =[
                        c4d.Vector(mp.x, mp.y, z), c4d.Vector(max_l.x, max_l.y, z),
                        c4d.Vector(min_l.x, max_l.y, z), c4d.Vector(max_l.x, min_l.y, z),
                        c4d.Vector(min_l.x, min_l.y, z)
                    ]
                for lp in local_pts:
                    points_list.append(mg * lp)

            children = o.GetChildren()
            if children: stack.extend(children)
            cache = o.GetCache()
            if cache: stack.append(cache)
            deform = o.GetDeformCache()
            if deform: stack.append(deform)
            
        return points_list

    def _is_layer_visible_for_raycast(self, obj, doc):
        try:
            layer = obj.GetLayerObject(doc)
            if not layer:
                return True
            layer_data = layer.GetLayerData(doc)
            if not layer_data:
                return True
            for key in ("view", "render"):
                try:
                    if hasattr(layer_data, "get"):
                        value = layer_data.get(key, True)
                    else:
                        value = layer_data[key]
                    if value is False:
                        return False
                except Exception:
                    pass
        except Exception:
            pass
        return True

    def _collect_object_tree_ids(self, root_obj):
        ids = set()
        stack = [root_obj]
        while stack:
            obj = stack.pop()
            if not obj:
                continue
            try:
                ids.add(obj.GetGUID())
            except Exception:
                pass
            child = obj.GetDown()
            while child:
                stack.append(child)
                child = child.GetNext()
            cache = obj.GetCache()
            if cache:
                stack.append(cache)
            deform = obj.GetDeformCache()
            if deform:
                stack.append(deform)
        return ids

    def _is_object_in_guid_set(self, obj, guid_set):
        try:
            return obj.GetGUID() in guid_set
        except Exception:
            return False

    def _is_descendant_of(self, obj, parent):
        node = obj
        while node:
            if node == parent:
                return True
            node = node.GetUp()
        return False

    def _get_world_aabb_fast(self, obj, mg):
        rad = obj.GetRad()
        mp = obj.GetMp()
        if rad.GetLengthSquared() <= 1e-10 and not obj.CheckType(c4d.Opoint):
            return None
        pts = [
            c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z - rad.z),
            c4d.Vector(mp.x + rad.x, mp.y - rad.y, mp.z - rad.z),
            c4d.Vector(mp.x - rad.x, mp.y + rad.y, mp.z - rad.z),
            c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z - rad.z),
            c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z + rad.z),
            c4d.Vector(mp.x + rad.x, mp.y - rad.y, mp.z + rad.z),
            c4d.Vector(mp.x - rad.x, mp.y + rad.y, mp.z + rad.z),
            c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z + rad.z)
        ]
        world_pts = [mg * p for p in pts]
        min_v = c4d.Vector(
            min(p.x for p in world_pts),
            min(p.y for p in world_pts),
            min(p.z for p in world_pts)
        )
        max_v = c4d.Vector(
            max(p.x for p in world_pts),
            max(p.y for p in world_pts),
            max(p.z for p in world_pts)
        )
        return min_v, max_v

    def _candidate_passes_raycast_broadphase(self, obj, obj_mg, ray_dir_world, origin_min_proj, max_distance):
        aabb = self._get_world_aabb_fast(obj, obj_mg)
        if not aabb:
            return False
        min_v, max_v = aabb
        corners = [
            c4d.Vector(min_v.x, min_v.y, min_v.z),
            c4d.Vector(max_v.x, min_v.y, min_v.z),
            c4d.Vector(min_v.x, max_v.y, min_v.z),
            c4d.Vector(max_v.x, max_v.y, min_v.z),
            c4d.Vector(min_v.x, min_v.y, max_v.z),
            c4d.Vector(max_v.x, min_v.y, max_v.z),
            c4d.Vector(min_v.x, max_v.y, max_v.z),
            c4d.Vector(max_v.x, max_v.y, max_v.z)
        ]
        projections = [p * ray_dir_world for p in corners]
        cand_min = min(projections)
        cand_max = max(projections)
        if cand_max < origin_min_proj - 0.001:
            return False
        if cand_min > origin_min_proj + max_distance:
            return False
        return True

    def _get_collision_candidates(self, root, exclude_obj):
        candidates =[]
        doc = documents.GetActiveDocument()
        exclude_ids = self._collect_object_tree_ids(exclude_obj)
        def recurse(node, parent_mg, parent_visible=True):
            while node:
                if node == exclude_obj or self._is_object_in_guid_set(node, exclude_ids):
                    node = node.GetNext()
                    continue
                if self._is_descendant_of(exclude_obj, node):
                    current_mg = parent_mg * node.GetMl()
                    recurse(node.GetDown(), current_mg, parent_visible)
                    node = node.GetNext()
                    continue

                current_mg = parent_mg * node.GetMl()
                node_visible = parent_visible
                try:
                    if node.GetEditorMode() == c4d.MODE_OFF or node.GetRenderMode() == c4d.MODE_OFF:
                        node_visible = False
                except Exception as e:
                    print("[Raycast Move] visibility check skipped: " + str(e))
                if node_visible and not self._is_layer_visible_for_raycast(node, doc):
                    node_visible = False

                if not node_visible:
                    node = node.GetNext()
                    continue

                if node.IsInstanceOf(c4d.Opolygon):
                    candidates.append((node, current_mg))
                    
                cache = node.GetCache()
                if cache: recurse(cache, current_mg, node_visible)
                deform = node.GetDeformCache()
                if deform: recurse(deform, current_mg, node_visible)
                recurse(node.GetDown(), current_mg, node_visible)
                node = node.GetNext()
        recurse(root, c4d.Matrix())
        return candidates

    def _action_raycast_move(self, axis, direction):
        if not self.core_enabled:
            gui.MessageDialog(self.core_disabled_reason or "当前未授权，无法使用核心功能。")
            return
        start_time = time.time()
        doc = documents.GetActiveDocument()
        mover = doc.GetActiveObject() 
        if not mover: 
            gui.MessageDialog("请先选中一个要移动贴合的物体！")
            return

        candidates = self._get_collision_candidates(doc.GetFirstObject(), mover)
        candidates_total = len(candidates)
        if not candidates:
            print("[Raycast Move] candidates total: 0")
            gui.MessageDialog("场景里没有找到其他模型表面可供碰撞。")
            return

        ray_origins_world = self._collect_sub_object_face_points(mover, axis, direction)
        if not ray_origins_world:
            gui.MessageDialog("选中对象没有几何体数据（包围盒为0），无法探测。")
            return
        
        mover_mg = mover.GetMg()
        rot_only_mg = c4d.Matrix(mover_mg)
        rot_only_mg.off = c4d.Vector(0)
        
        local_dir_vec = c4d.Vector(0)
        local_dir_vec[axis] = direction
        ray_dir_world = rot_only_mg * local_dir_vec
        ray_dir_world.Normalize()
        
        safety_offset = 0.5 
        ray_origins_shifted =[p + ray_dir_world * safety_offset for p in ray_origins_world]
        origin_min_proj = min(p * ray_dir_world for p in ray_origins_shifted)

        filtered_candidates = []
        for obj, obj_mg in candidates:
            if self._candidate_passes_raycast_broadphase(obj, obj_mg, ray_dir_world, origin_min_proj, RAYCAST_MAX_DISTANCE):
                filtered_candidates.append((obj, obj_mg))

        print("[Raycast Move] candidates total: " + str(candidates_total))
        print("[Raycast Move] candidates after filter: " + str(len(filtered_candidates)))
        print("[Raycast Move] ray origins: " + str(len(ray_origins_shifted)))

        min_distance = float('inf')
        hit_detected = False
        collider = utils.GeRayCollider()
        max_ray_len = RAYCAST_MAX_DISTANCE 

        for obj, obj_mg in filtered_candidates:
            if not collider.Init(obj, True): continue 
            inv_mg = ~obj_mg
            for ray_origin in ray_origins_shifted:
                local_origin_target = inv_mg * ray_origin
                local_dir_target = (inv_mg * (ray_origin + ray_dir_world * max_ray_len)) - local_origin_target
                local_dir_target.Normalize()
                
                if collider.Intersect(local_origin_target, local_dir_target, max_ray_len):
                    intersection = collider.GetNearestIntersection()
                    hit_pos_world = obj_mg * intersection['hitpos']
                    vec_to_hit = hit_pos_world - ray_origin
                    dist = vec_to_hit * ray_dir_world
                    
                    if dist < 0.001: continue 
            
                    if dist < min_distance:
                        min_distance = dist
                        hit_detected = True

        if hit_detected:
            elapsed = time.time() - start_time
            print("[Raycast Move] hit distance: " + ("%.2f" % min_distance))
            print("[Raycast Move] elapsed: " + ("%.2fs" % elapsed))
            doc.StartUndo()
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, mover)
            real_move_dist = min_distance + safety_offset
            move_vec_world = ray_dir_world * real_move_dist
            mg = mover.GetMg()
            mg.off += move_vec_world
            mover.SetMg(mg)
            doc.EndUndo()
            c4d.EventAdd()
            c4d.StatusSetText(f"✅ 多点探测贴合完成！移动距离: {real_move_dist:.2f} cm")
        else:
            elapsed = time.time() - start_time
            print("[Raycast Move] hit distance: none")
            print("[Raycast Move] elapsed: " + ("%.2fs" % elapsed))
            gui.MessageDialog("🚫 该方向没有检测到任何墙体或模型表面。")

    def _get_hierarchy_boundaries_align(self, root, ref_mg=None):
        mn = c4d.Vector(1e15); mx = c4d.Vector(-1e15)
        inv_ref = ~ref_mg if ref_mg else c4d.Matrix()
        valid = False
        stack = [root]
        while stack:
            o = stack.pop()
            rad = o.GetRad()
            if rad.GetLengthSquared() > 1e-5:
                mg = o.GetMg(); mp = o.GetMp()
                pts =[mp + c4d.Vector(rad.x*x, rad.y*y, rad.z*z) 
                       for x in (-1,1) for y in (-1,1) for z in (-1,1)]
                for p in pts:
                    world_pt = mg * p 
                    local_pt = inv_ref * world_pt if ref_mg else world_pt
                    mn = c4d.Vector(min(mn.x, local_pt.x), min(mn.y, local_pt.y), min(mn.z, local_pt.z))
                    mx = c4d.Vector(max(mx.x, local_pt.x), max(mx.y, local_pt.y), max(mx.z, local_pt.z))
                valid = True
            children = o.GetChildren()
            if children: stack.extend(children)
            cache = o.GetCache()
            if cache: stack.append(cache)
            deform = o.GetDeformCache()
            if deform: stack.append(deform)

        if not valid:
            pos = root.GetMg().off
            if ref_mg: pos = inv_ref * pos
            return pos, pos, pos
        return mn, mx, (mn+mx)*0.5

    def _action_align_multi(self, x, y, z, surf):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_SELECTIONORDER)
        if len(sel) < 2:
            gui.MessageDialog("请先选中多个物体！\n注意：最后一个选中的将作为参考目标。")
            return

        doc.StartUndo()
        mst = sel[-1]
        sel.pop() 
        
        ref_mg = mst.GetMg()
        m_mn, m_mx, m_cn = self._get_hierarchy_boundaries_align(mst, ref_mg)
            
        for o in sel:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, o)
            o_mn, o_mx, o_cn = self._get_hierarchy_boundaries_align(o, ref_mg)
            shift = c4d.Vector(0)
            def calc(m, omn, omx, ocn, mmn, mmx, mcn):
                tar = 0.0; cur = 0.0
                if m == 0: tar = mcn
                else: tar = mmn if m == -1 else mmx
                
                if m == 0: cur = ocn
                else: cur = omn if m == -1 else omx 
                
                if surf and m != 0: cur = omx if m == -1 else omn
                return tar - cur

            if x is not None: shift.x = calc(x, o_mn.x, o_mx.x, o_cn.x, m_mn.x, m_mx.x, m_cn.x)
            if y is not None: shift.y = calc(y, o_mn.y, o_mx.y, o_cn.y, m_mn.y, m_mx.y, m_cn.y)
            if z is not None: shift.z = calc(z, o_mn.z, o_mx.z, o_cn.z, m_mn.z, m_mx.z, m_cn.z)
            
            rot_mg = c4d.Matrix(ref_mg)
            rot_mg.off = c4d.Vector(0)
            shift_world = rot_mg * shift
            mg = o.GetMg(); mg.off += shift_world
            o.SetMg(mg)
            
        doc.EndUndo()
        c4d.EventAdd()
        c4d.StatusSetText("✅ 多对象九宫格对齐完成。")

    # =========================================================================
    # 其它工具方法
    # =========================================================================
    def _apply_texture_manual(self):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        targets = self._collect_valid_objects(sel)
        if not targets:
            gui.MessageDialog("请先选择要贴图的对象。")
            return
        
        selection_string = "C1" if self._cap_mode == 1 else "C2"

        tex_path = storage.LoadDialog(type=c4d.FILESELECTTYPE_IMAGES, title="请选择贴图文件", flags=c4d.FILESELECT_LOAD)
        if not tex_path: return
        doc.StartUndo()
        count = 0
        for obj in targets:
            existing_tag = None
            existing_mat = None
            for t in obj.GetTags():
                if t.CheckType(c4d.Ttexture):
                    mat = t.GetMaterial()
                    if mat and mat[c4d.MATERIAL_USE_COLOR]:
                        shader = mat[c4d.MATERIAL_COLOR_SHADER]
                        if shader and (shader.CheckType(c4d.Xbitmap) or shader.CheckType(c4d.Xlayer)):
                            existing_tag = t
                            existing_mat = mat
                            break
            if existing_mat:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, existing_mat)
                existing_mat.SetName("Mat_" + os.path.splitext(os.path.basename(tex_path))[0])
                sh = existing_mat[c4d.MATERIAL_COLOR_SHADER]
                sh[c4d.BITMAPSHADER_FILENAME] = tex_path
                if tex_path.lower().endswith(".png"):
                    existing_mat[c4d.MATERIAL_USE_ALPHA] = True
                    ash = existing_mat[c4d.MATERIAL_ALPHA_SHADER]
                    if not ash or not ash.CheckType(c4d.Xbitmap):
                        ash = c4d.BaseShader(c4d.Xbitmap)
                        existing_mat.InsertShader(ash)
                    existing_mat[c4d.MATERIAL_ALPHA_SHADER] = ash
                    ash[c4d.BITMAPSHADER_FILENAME] = tex_path
                else:
                    if existing_mat[c4d.MATERIAL_USE_ALPHA]: existing_mat[c4d.MATERIAL_USE_ALPHA] = False
                existing_mat.Message(c4d.MSG_UPDATE)
            else:
                mat_name = "Mat_" + os.path.splitext(os.path.basename(tex_path))[0]
                mat = doc.SearchMaterial(mat_name)
                if not mat:
                    mat = c4d.BaseMaterial(c4d.Mmaterial)
                    mat.SetName(mat_name)
                    doc.InsertMaterial(mat)
                    doc.AddUndo(c4d.UNDOTYPE_NEW, mat)
                    bitmap = c4d.BaseShader(c4d.Xbitmap)
                    bitmap[c4d.BITMAPSHADER_FILENAME] = tex_path
                    mat.InsertShader(bitmap)
                    mat[c4d.MATERIAL_USE_COLOR] = True
                    mat[c4d.MATERIAL_COLOR_SHADER] = bitmap
                    mat[c4d.MATERIAL_USE_ALPHA] = False
                    if tex_path.lower().endswith(".png"):
                        mat[c4d.MATERIAL_USE_ALPHA] = True
                        bitmap_alpha = c4d.BaseShader(c4d.Xbitmap)
                        bitmap_alpha[c4d.BITMAPSHADER_FILENAME] = tex_path
                        mat.InsertShader(bitmap_alpha)
                        mat[c4d.MATERIAL_ALPHA_SHADER] = bitmap_alpha
                    mat.Message(c4d.MSG_UPDATE)
                last_tag = obj.GetLastTag()
                tex_tag = obj.MakeTag(c4d.Ttexture, pred=last_tag)
                doc.AddUndo(c4d.UNDOTYPE_NEW, tex_tag)
                tex_tag.SetMaterial(mat)
                tex_tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_CUBIC
                tex_tag[c4d.TEXTURETAG_TILE] = False
                try:
                    if obj.GetType() == C4D_EXTRUDE_TYPEID:
                        tex_tag[c4d.TEXTURETAG_RESTRICTION] = selection_string
                except: pass
                doc.SetActiveTag(tex_tag)
                c4d.CallCommand(12132) 
            count += 1
        doc.EndUndo()
        c4d.EventAdd()
        c4d.StatusSetText(f"已处理 {count} 个对象。")

    def _bake_uvw_for_selection(self):
        doc = documents.GetActiveDocument()
        doc.SetMode(c4d.Mmodel)
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        targets = self._collect_valid_objects(sel)
        if not targets:
            gui.MessageDialog("未找到可处理的对象。")
            return
        doc.StartUndo()
        for obj in targets:
            doc.SetActiveObject(obj)
            c4d.EventAdd() 
            if obj.GetType() == C4D_EXTRUDE_TYPEID:
                c4d.CallCommand(12236) 
                c4d.EventAdd()
                c4d.CallCommand(16768) 
                c4d.EventAdd()
        
            obj = doc.GetActiveObject()
            if not obj or not obj.CheckType(c4d.Opolygon): continue
            all_tags = obj.GetTags()
            tex_tags =[t for t in all_tags if t.CheckType(c4d.Ttexture)]
            mat_groups = {}
            tags_to_remove =[]
            for t in tex_tags:
                mat = t.GetMaterial()
                if not mat: continue
                m_name = mat.GetName()
                if m_name not in mat_groups:
                    mat_groups[m_name] = { "global": None, "restricted":[], "seen_res": set() }
                group = mat_groups[m_name]
                res = t[c4d.TEXTURETAG_RESTRICTION]
                if not res or res == "":
                    if group["global"] is None: group["global"] = t
                    else: tags_to_remove.append(t)
                else:
                    if res in group["seen_res"]: tags_to_remove.append(t)
                    else:
                        group["seen_res"].add(res)
                        group["restricted"].append(t)
            for m_name, group in mat_groups.items():
                if group["global"]:
                    for t in group["restricted"]: tags_to_remove.append(t)
            for t in tags_to_remove:
                t.Remove()
                doc.AddUndo(c4d.UNDOTYPE_DELETE, t)
            tags_now = obj.GetTags()
            for t in tags_now:
                if t.CheckType(c4d.Ttexture):
                    mat = t.GetMaterial()
                    has_bitmap = False
                    if mat:
                        shader = mat[c4d.MATERIAL_COLOR_SHADER]
                        if shader: has_bitmap = True
                    if has_bitmap:
                        t.Remove()
                        last = obj.GetLastTag()
                        obj.InsertTag(t, last) 
            for t in reversed(obj.GetTags()): 
                if t.CheckType(c4d.Tuvw): t.Remove()
            target_tag = None
            tags_final = obj.GetTags()
            for t in reversed(tags_final):
                if t.CheckType(c4d.Ttexture):
                    target_tag = t
                    break
            if target_tag:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, target_tag)
                target_tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_CUBIC
                target_tag[c4d.TEXTURETAG_OFFSETX] = 0.0
                target_tag[c4d.TEXTURETAG_OFFSETY] = 0.0
                target_tag[c4d.TEXTURETAG_LENGTHX] = 1.0
                target_tag[c4d.TEXTURETAG_LENGTHY] = 1.0
                target_tag[c4d.TEXTURETAG_TILE] = True
                doc.SetActiveObject(obj, mode=c4d.SELECTION_NEW)
                doc.SetActiveTag(target_tag, mode=c4d.SELECTION_NEW)
                c4d.EventAdd()
                c4d.CallCommand(12235) 
            obj.Message(c4d.MSG_UPDATE)
        doc.EndUndo()
        c4d.EventAdd()
        c4d.StatusSetText("烘焙完成！UVW 已强制生成。")

    def _action_run_acrylic_generate(self):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        targets = self._collect_valid_objects(sel)
        if not targets:
            gui.MessageDialog("请选中要处理的样条或挤压对象。")
            return
        depth = self.GetFloat(ID_ACRY_DEPTH_INPUT)
        direction_mode = self.GetInt32(ID_ACRY_DEPTH_DIR) 
        target_depth = depth if direction_mode == 0 else -depth
        side_cfg = {
            "dt": self.GetBool(ID_ACRY_CHK_T), "db": self.GetBool(ID_ACRY_CHK_B),
            "dl": self.GetBool(ID_ACRY_CHK_L), "dr": self.GetBool(ID_ACRY_CHK_R),
            "skip": False
        }
        if not (side_cfg["dt"] or side_cfg["db"] or side_cfg["dl"] or side_cfg["dr"]): side_cfg["skip"] = True
        shell = self.GetFloat(ID_ACRY_SHELL_INPUT)
        for obj in targets:
            if obj.CheckType(c4d.Ospline):
                RunGenerate(target_depth, side_cfg, shell)
            elif obj.CheckType(c4d.Oextrude) or obj.GetType() == C4D_EXTRUDE_TYPEID:
                child = obj.GetDown()
                if child and child.CheckType(c4d.Ospline):
                    doc.SetActiveObject(child)
                    RunGenerate(target_depth, side_cfg, shell)

    def _update_selected_spline_tension(self, tension):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel: return
        updated = False
        for obj in sel:
            bc = obj.GetDataInstance()
            json_str = bc.GetString(ID_STORED_JSON_DATA)
            scale = bc.GetFloat(ID_STORED_SCALE_VAL)
            if not json_str or not obj.CheckType(c4d.Ospline): continue
            try:
                segments = json.loads(json_str)
                factor = AI_PT_TO_CM * scale
                total_pts_json = sum(len(seg) for seg in segments)
                if obj.GetPointCount() != total_pts_json: continue
                global_pt_idx = 0
                for seg in segments:
                    for p in seg:
                        x, y = 0, 0
                        inx, iny = 0, 0
                        outx, outy = 0, 0
                        if isinstance(p, dict):
                            x, y = p["a"]
                            inx, iny = p["in"]
                            outx, outy = p["out"]
                        elif isinstance(p, list): continue 
                        wx, wy = x * factor, -y * factor
                        p_abs = c4d.Vector(wx, wy, 0)
                        v_in_abs = c4d.Vector(inx*factor, -iny*factor, 0)
                        v_out_abs = c4d.Vector(outx*factor, -outy*factor, 0)
                        base_tan_in = v_in_abs - p_abs
                        base_tan_out = v_out_abs - p_abs
                        new_tan_in = base_tan_in * tension
                        new_tan_out = base_tan_out * tension
                        obj.SetTangent(global_pt_idx, new_tan_in, new_tan_out)
                        global_pt_idx += 1
                obj.Message(c4d.MSG_UPDATE)
                updated = True
            except: pass
        if updated: c4d.EventAdd()

    # ==============================================================================
    # 核心：导入与生成
    # ==============================================================================
    def _create_extrude_object(self, depth, name="Extrude", bevel=False, radius=1.0):
        ex = c4d.BaseObject(c4d.Oextrude)
        ex.SetName(name)
        if hasattr(c4d, "EXTRUDEOBJECT_DIRECTION"): ex[c4d.EXTRUDEOBJECT_DIRECTION] = 3 
        ex[c4d.EXTRUDEOBJECT_MOVE] = c4d.Vector(0, 0, -abs(float(depth)))
        try: ex[C4D_EXTRUDE_OFFSET_ID] = -abs(float(depth))
        except: pass
        try: ex[c4d.EXTRUDEOBJECT_CAP_TYPE] = 2 
        except: pass
        return ex

    def _texture_log(self, message):
        try:
            print("[texture] " + str(message))
        except Exception:
            pass

    def _normalize_texture_path_text(self, value):
        text = str(value or "").strip()
        if not text:
            return ""
        return text.replace("\\", os.sep).replace("/", os.sep)

    def _texture_name_variants(self, value):
        text = str(value or "")
        values = set([text, text.strip()])
        try:
            values.add(urllib.parse.unquote(text))
            values.add(urllib.parse.unquote(text.strip()))
        except Exception:
            pass
        more = set()
        for v in values:
            try:
                more.add(unicodedata.normalize("NFC", v))
                more.add(unicodedata.normalize("NFD", v))
                more.add(unicodedata.normalize("NFC", v.strip()))
                more.add(unicodedata.normalize("NFD", v.strip()))
            except Exception:
                pass
        values.update(more)
        return set(v for v in values if v)

    def _texture_names_match(self, wanted, actual):
        wanted_set = self._texture_name_variants(wanted)
        actual_set = self._texture_name_variants(actual)
        return bool(wanted_set.intersection(actual_set))

    def _texture_path_exists(self, path):
        try:
            return bool(path) and os.path.isfile(path)
        except Exception:
            return False

    def _resolve_existing_texture_path(self, path):
        if self._texture_path_exists(path):
            return path, True
        for form in ("NFC", "NFD"):
            try:
                normalized = unicodedata.normalize(form, path)
                if normalized != path and self._texture_path_exists(normalized):
                    return normalized, True
            except Exception:
                pass
        try:
            dirname = os.path.dirname(path)
            basename = os.path.basename(path)
            if dirname and os.path.isdir(dirname) and basename:
                for existing_name in os.listdir(dirname):
                    if self._texture_names_match(basename, existing_name):
                        matched = os.path.join(dirname, existing_name)
                        if self._texture_path_exists(matched):
                            return matched, True
        except Exception as e:
            self._texture_log("directory normalized lookup failed: " + str(e))
        return path, False

    def _resolve_texture_candidate(self, raw_path, json_dir):
        raw_text = str(raw_path or "").strip()
        candidates = []
        for value in self._texture_name_variants(raw_text):
            text = self._normalize_texture_path_text(value)
            if not text:
                continue
            if os.path.isabs(text):
                candidates.append(text)
            else:
                candidates.append(os.path.normpath(os.path.join(json_dir, text)))
        seen = set()
        for candidate in candidates:
            if candidate in seen:
                continue
            seen.add(candidate)
            resolved, exists = self._resolve_existing_texture_path(candidate)
            if exists:
                return resolved, True
        first = candidates[0] if candidates else ""
        return first, False

    def _find_legacy_texture_path(self, item, json_dir):
        search_dirs = [json_dir, os.path.join(json_dir, "tex")]
        clean_name = re.sub(r"_d\d+", "", item.get("name", ""), flags=re.IGNORECASE).strip("_")
        raw_name = item.get("name", "")
        possible_names = []
        if clean_name:
            possible_names.append(clean_name)
        if raw_name and raw_name != clean_name:
            possible_names.append(raw_name)
        supported_exts = [".jpg", ".png", ".jpeg", ".tif", ".psd"]
        for d in search_dirs:
            if not os.path.exists(d):
                continue
            for fname in possible_names:
                for ext in supported_exts:
                    try_path = os.path.join(d, fname + ext)
                    try_path, try_exists = self._resolve_existing_texture_path(try_path)
                    if try_exists:
                        return try_path
                    try:
                        target_lower = (fname + ext).lower()
                        for existing_f in os.listdir(d):
                            if existing_f.lower() == target_lower:
                                matched_path = os.path.join(d, existing_f)
                                matched_path, _ = self._resolve_existing_texture_path(matched_path)
                                return matched_path
                    except Exception:
                        pass
        return None

    def _get_item_part_type_for_texture(self, item):
        text = str(item.get("partType") or item.get("part_type") or item.get("part") or item.get("shapePart") or item.get("sourcePart") or item.get("name") or "").lower()
        if "stroke" in text or "描边" in text:
            return "stroke"
        if "fill" in text or "填充" in text:
            return "fill"
        return ""

    def _texture_debug_item_fields(self, item):
        try:
            keys = sorted([str(k) for k in item.keys()])
        except Exception:
            keys = []
        self._texture_log("[texture-debug] item name=" + str(item.get("name", "")))
        self._texture_log("[texture-debug] item keys=" + ", ".join(keys))
        for key in ("texturePath", "textureRelPath", "texture", "imagePath", "textureFileName", "partType", "objectId", "itemId"):
            self._texture_log("[texture-debug] " + key + "=" + str(item.get(key, "")))

    def _collect_texture_field_candidates(self, item):
        candidates = []
        seen = set()
        def add(label, value):
            if value is None:
                return
            text = str(value).strip()
            if not text:
                return
            key = (label, text)
            if key in seen:
                return
            seen.add(key)
            candidates.append((label, text))

        part_type = self._get_item_part_type_for_texture(item)
        nested_order = []
        if part_type == "fill":
            nested_order.extend(["fill", "stroke"])
        elif part_type == "stroke":
            nested_order.extend(["stroke", "fill"])
        else:
            nested_order.extend(["fill", "stroke"])

        for key in ("texturePath", "textureRelPath", "texture", "imagePath"):
            add(key, item.get(key))

        for parent_key in nested_order:
            child = item.get(parent_key)
            if isinstance(child, dict):
                for key in ("texturePath", "textureRelPath", "texture", "imagePath"):
                    add(parent_key + "." + key, child.get(key))

        for parent_key, keys in (
            ("textureInfo", ("texturePath", "textureRelPath", "path", "texture", "imagePath")),
            ("material", ("texturePath", "textureRelPath", "path", "texture", "imagePath")),
        ):
            child = item.get(parent_key)
            if isinstance(child, dict):
                for key in keys:
                    add(parent_key + "." + key, child.get(key))

        for key in ("textureFileName",):
            add(key, item.get(key))
        for parent_key in nested_order + ["textureInfo", "material"]:
            child = item.get(parent_key)
            if isinstance(child, dict):
                add(parent_key + ".textureFileName", child.get("textureFileName") or child.get("fileName"))
        return candidates

    def _texture_dir_sample(self, dirname, limit=20):
        try:
            if not dirname or not os.path.isdir(dirname):
                return []
            return os.listdir(dirname)[:limit]
        except Exception:
            return []

    def _resolve_item_texture_path(self, item, json_file_path):
        json_dir = os.path.dirname(json_file_path)
        item_name = item.get("name", "")
        self._texture_debug_item_fields(item)
        candidates = self._collect_texture_field_candidates(item)
        explicit_candidates = []
        file_name_candidates = []
        for label, raw_value in candidates:
            if label.endswith("textureFileName"):
                file_name_candidates.append((label, raw_value))
            else:
                explicit_candidates.append((label, raw_value))

        checked = []
        for label, raw_value in explicit_candidates:
            resolved, exists = self._resolve_texture_candidate(raw_value, json_dir)
            checked.append((label, raw_value, resolved))
            self._texture_log("raw json path=" + str(raw_value))
            self._texture_log(label + " from json=" + str(raw_value))
            self._texture_log("resolved real path=" + str(resolved))
            self._texture_log("exists=" + str(bool(exists)).lower())
            if exists:
                return resolved, False

        for label, raw_file_name in file_name_candidates:
            file_name = self._normalize_texture_path_text(raw_file_name)
            if not file_name:
                continue
            file_name = os.path.basename(file_name)
            for candidate in (os.path.join(json_dir, "tex", file_name), os.path.join(json_dir, file_name)):
                candidate, exists = self._resolve_existing_texture_path(candidate)
                checked.append((label, raw_file_name, candidate))
                self._texture_log("textureFileName candidate=" + str(candidate))
                self._texture_log("exists=" + str(bool(exists)).lower())
                if exists:
                    return candidate, False

        if explicit_candidates or file_name_candidates:
            missing = {
                "item": item_name or "Obj",
                "wanted": explicit_candidates[0][1] if explicit_candidates else file_name_candidates[0][1],
                "resolved": checked[0][2] if checked else "",
                "checked": checked,
                "json_dir": json_dir,
                "tex_dir": os.path.join(json_dir, "tex")
            }
            self._log_missing_texture_detail(missing)
            return None, missing

        fallback = self._find_legacy_texture_path(item, json_dir)
        self._texture_log("fallback path=" + str(fallback or ""))
        return fallback, bool(fallback is None)

    def _log_missing_texture_detail(self, missing):
        try:
            self._texture_log("[texture-missing] item=" + str(missing.get("item", "")))
            self._texture_log("[texture-missing] wanted raw=" + str(missing.get("wanted", "")))
            self._texture_log("[texture-missing] resolved=" + str(missing.get("resolved", "")))
            self._texture_log("[texture-missing] checked candidates:")
            for label, raw, resolved in missing.get("checked", []):
                self._texture_log("[texture-missing]   " + str(label) + " raw=" + str(raw) + " resolved=" + str(resolved))
            tex_dir = missing.get("tex_dir", "")
            self._texture_log("[texture-missing] tex dir exists=" + str(os.path.isdir(tex_dir)).lower())
            sample = self._texture_dir_sample(tex_dir)
            self._texture_log("[texture-missing] tex dir files sample=" + ", ".join([str(v) for v in sample]))
        except Exception as e:
            self._texture_log("[texture-missing] log failed: " + str(e))

    def _safe_texture_material_uid(self, texture_path, item, import_uid):
        base = os.path.splitext(os.path.basename(texture_path))[0]
        part = str(item.get("partType") or item.get("part_type") or item.get("part") or "").strip()
        item_id = str(item.get("itemId") or item.get("objectId") or item.get("id") or item.get("uuid") or item.get("name") or "").strip()
        raw = "_".join([v for v in (import_uid, item_id, part, base) if v])
        ascii_name = re.sub(r"[^0-9A-Za-z_\-]+", "_", raw)
        ascii_name = re.sub(r"_+", "_", ascii_name).strip("_")
        path_hash = hashlib.sha1(os.path.abspath(texture_path).encode("utf-8")).hexdigest()[:10]
        if ascii_name:
            return (ascii_name[:60] + "_" + path_hash)
        return "texture_" + path_hash

    def CreateTextureMaterial(self, doc, uid, path, material_cache=None):
        abs_path = os.path.abspath(path)
        if material_cache is not None and abs_path in material_cache:
            return material_cache[abs_path]
        n = "Mat_Tex_" + uid
        self._texture_log("material safe name=" + n)
        if material_cache is None:
            m = doc.SearchMaterial(n)
            if m: return m
        m = c4d.BaseMaterial(c4d.Mmaterial)
        m.SetName(n)
        m[c4d.MATERIAL_USE_REFLECTION] = True
        m[c4d.MATERIAL_USE_COLOR] = True
        s = c4d.BaseShader(c4d.Xbitmap)
        s[c4d.BITMAPSHADER_FILENAME] = abs_path
        m.InsertShader(s)
        m[c4d.MATERIAL_COLOR_SHADER] = s
        if abs_path.lower().endswith(".png"):
            m[c4d.MATERIAL_USE_ALPHA] = True
            ash = c4d.BaseShader(c4d.Xbitmap)
            ash[c4d.BITMAPSHADER_FILENAME] = abs_path
            m.InsertShader(ash)
            m[c4d.MATERIAL_ALPHA_SHADER] = ash
        doc.InsertMaterial(m)
        doc.AddUndo(c4d.UNDOTYPE_NEW, m)
        if material_cache is not None:
            material_cache[abs_path] = m
        return m

    def CreateColorMaterial(self, doc, r, g, b, apply_gamma=False):
        v_r = r / 255.0; v_g = g / 255.0; v_b = b / 255.0
        if apply_gamma:
            v_r = pow(v_r, 2.2); v_g = pow(v_g, 2.2); v_b = pow(v_b, 2.2)
        n = f"Mat_RGB_{int(r)}_{int(g)}_{int(b)}"
        m = doc.SearchMaterial(n)
        if m: return m
        m = c4d.BaseMaterial(c4d.Mmaterial)
        m.SetName(n)
        m[c4d.MATERIAL_USE_REFLECTION] = True
        m[c4d.MATERIAL_USE_COLOR] = True
        m[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(v_r, v_g, v_b)
        doc.InsertMaterial(m)
        doc.AddUndo(c4d.UNDOTYPE_NEW, m)
        return m

    def _create_spline_from_segments(self, segments, name, scale, auto_close, tension):
        if not segments: return None
        total_points = sum(len(seg) for seg in segments)
        segment_count = len(segments)
        if total_points == 0: return None

        sp = c4d.SplineObject(total_points, c4d.SPLINETYPE_BEZIER)
        sp.ResizeObject(total_points, segment_count) 
        sp[c4d.SPLINEOBJECT_CLOSED] = auto_close
        factor = AI_PT_TO_CM * scale
        
        min_x = min_y = float('inf')
        max_x = max_y = float('-inf')
        
        for seg in segments:
            for p in seg:
                wx, wy = p["a"][0] * factor, -p["a"][1] * factor
                if wx < min_x: min_x = wx
                if wx > max_x: max_x = wx
                if wy < min_y: min_y = wy
                if wy > max_y: max_y = wy
        
        center = c4d.Vector((min_x + max_x)*0.5, (min_y + max_y)*0.5, 0)
        has_curve = False
        global_pt_idx = 0
        
        for i, seg in enumerate(segments):
            sp.SetSegment(i, len(seg), auto_close)
            for p in seg:
                wx, wy = p["a"][0] * factor, -p["a"][1] * factor
                world_pos = c4d.Vector(wx, wy, 0)
                sp.SetPoint(global_pt_idx, world_pos - center)
                
                inx, iny = p.get("in", [p["a"][0], p["a"][1]]) 
                outx, outy = p.get("out", [p["a"][0], p["a"][1]])
                if isinstance(inx, list): inx, iny = inx[0], inx[1]
                if isinstance(outx, list): outx, outy = outx[0], outx[1]

                v_in_abs = c4d.Vector(inx*factor, -iny*factor, 0)
                v_out_abs = c4d.Vector(outx*factor, -outy*factor, 0)
                
                tan_in = (v_in_abs - world_pos) * tension
                tan_out = (v_out_abs - world_pos) * tension
                sp.SetTangent(global_pt_idx, tan_in, tan_out)
                
                if not has_curve and (tan_in.GetLengthSquared() > 1e-5 or tan_out.GetLengthSquared() > 1e-5):
                    has_curve = True
                global_pt_idx += 1
                
        sp[c4d.SPLINEOBJECT_INTERPOLATION] = c4d.SPLINEOBJECT_INTERPOLATION_ADAPTIVE
        sp[c4d.SPLINEOBJECT_ANGLE] = c4d.utils.Rad(5.0)

        sp.SetAbsPos(center)
        sp.SetName(name)
        
        try:
            json_str = json.dumps(segments)
            bc = sp.GetDataInstance()
            bc.SetString(ID_STORED_JSON_DATA, json_str)
            bc.SetFloat(ID_STORED_SCALE_VAL, float(scale))
        except: pass
        return sp

    def _is_valid_merge_identity_value(self, value):
        if value is None:
            return False
        if isinstance(value, (list, tuple)):
            return any(self._is_valid_merge_identity_value(v) for v in value)
        text = str(value).strip()
        return text not in ("", "null", "undefined", "[]")

    def _import_flag_enabled(self, item, key):
        value = item.get(key)
        if isinstance(value, bool):
            return value
        if value is None:
            return False
        text = str(value).strip().lower()
        return text in ("1", "true", "yes", "y", "on")

    def _should_keep_import_item_separate(self, item):
        return (
            self._import_flag_enabled(item, "preserveSeparateStrokeRing")
            or self._import_flag_enabled(item, "doNotMergeGeometry")
        )

    def _get_import_group_path_from_group_field(self, item):
        value = item.get("group")
        if self._is_valid_merge_identity_value(value):
            return str(value).strip()
        return None

    def _is_stroke_ring_item_for_group_merge_test(self, item, part_type):
        if part_type != "stroke":
            return False
        if not self._get_import_group_path_from_group_field(item):
            return False
        return (
            self._should_keep_import_item_separate(item)
            or self._is_valid_merge_identity_value(item.get("strokeSubPathIndex"))
            or self._is_valid_merge_identity_value(item.get("compoundPartIndex"))
        )

    def _safe_import_float(self, value, default=None):
        if not self._is_valid_merge_identity_value(value):
            return default
        try:
            return float(value)
        except Exception:
            return default

    def _get_ai_stack_sort_key(self, item):
        for key in ("sourceStackIndex", "sourceZOrderIndex", "importIndex", "_original_index"):
            value = self._safe_import_float(item.get(key), None)
            if value is not None:
                return value
        return 0.0

    def _has_ai_stack_sort_fields(self, groups):
        for group_items in groups:
            for item in group_items:
                if (
                    self._safe_import_float(item.get("sourceStackIndex"), None) is not None
                    or self._safe_import_float(item.get("sourceZOrderIndex"), None) is not None
                ):
                    return True
        return False

    def _get_part_order_value(self, item):
        return self._safe_import_float(item.get("partOrder"), 0.0) or 0.0

    def _get_source_stack_group_key(self, item):
        for key in ("sourceObjectId", "sourceItemId", "strokeCompoundGroupId", "objectId", "itemId", "name"):
            value = item.get(key)
            if self._is_valid_merge_identity_value(value):
                return str(value).strip()
        return "unknown"

    def _get_strong_source_key_for_smart_stack_skip(self, item):
        if not item:
            return None
        for key in ("sourceObjectId", "sourceItemId", "strokeCompoundGroupId", "objectId", "itemId"):
            value = item.get(key)
            if self._is_valid_merge_identity_value(value):
                return str(value).strip()
        return None

    def _is_split_part_for_same_source_skip(self, item):
        if not item:
            return False
        part_type = str(item.get("partType") or "").strip().lower()
        return (
            self._import_flag_enabled(item, "preserveSeparateStrokeRing")
            or self._import_flag_enabled(item, "doNotMergeGeometry")
            or self._is_valid_merge_identity_value(item.get("strokeSubPathIndex"))
            or self._is_valid_merge_identity_value(item.get("compoundPartIndex"))
            or self._is_valid_merge_identity_value(item.get("texturePath"))
            or self._is_valid_merge_identity_value(item.get("textureRelPath"))
            or (
                part_type in ("fill", "stroke")
                and (
                    self._is_valid_merge_identity_value(item.get("sourceObjectId"))
                    or self._is_valid_merge_identity_value(item.get("sourceItemId"))
                    or self._is_valid_merge_identity_value(item.get("strokeCompoundGroupId"))
                )
            )
        )

    def _should_skip_smart_stack_for_same_source(self, current_item, cache_item):
        current_key = self._get_strong_source_key_for_smart_stack_skip(current_item)
        cache_key = self._get_strong_source_key_for_smart_stack_skip(cache_item)
        if not current_key or not cache_key or current_key != cache_key:
            return False
        return (
            self._is_split_part_for_same_source_skip(current_item)
            or self._is_split_part_for_same_source_skip(cache_item)
        )

    def _print_smart_stack_overlap_debug(self, current_item, cache_item, current_key, cache_key, same_source_skip):
        try:
            print(
                "[SmartStack Overlap] current name=%s cache name=%s current strong source key=%s cache strong source key=%s same_source_skip=%s current group=%s cache group=%s current sourceObjectId=%s cache sourceObjectId=%s current objectId=%s cache objectId=%s current itemId=%s cache itemId=%s"
                % (
                    str(current_item.get("name", "")),
                    str(cache_item.get("name", "")),
                    str(current_key),
                    str(cache_key),
                    str(bool(same_source_skip)).lower(),
                    str(current_item.get("group", "")),
                    str(cache_item.get("group", "")),
                    str(current_item.get("sourceObjectId", "")),
                    str(cache_item.get("sourceObjectId", "")),
                    str(current_item.get("objectId", "")),
                    str(cache_item.get("objectId", "")),
                    str(current_item.get("itemId", "")),
                    str(cache_item.get("itemId", "")),
                )
            )
        except Exception as e:
            print("[SmartStack Overlap] debug print failed: " + str(e))

    def _print_ai_stack_smart_order_debug(self, groups, enabled, larger_front=True):
        try:
            print("[AI Stack Smart Order] enabled=%s sort direction=%s" % (str(bool(enabled)), "larger-front" if larger_front else "smaller-front"))
            if not enabled:
                return
            for idx, group_items in enumerate(groups[:20]):
                item = group_items[0] if group_items else {}
                print(
                    "[AI Stack Smart Order] #%d name=%s sourceStackIndex=%s sourceZOrderIndex=%s partOrder=%s _original_index=%s sourceKey=%s"
                    % (
                        idx + 1,
                        str(item.get("name", "")),
                        str(item.get("sourceStackIndex", "")),
                        str(item.get("sourceZOrderIndex", "")),
                        str(item.get("partOrder", "")),
                        str(item.get("_original_index", "")),
                        self._get_source_stack_group_key(item)
                    )
                )
        except Exception as e:
            print("[AI Stack Smart Order] debug print failed: " + str(e))

    def _get_real_group_key(self, item):
        for key in ("groupKey", "groupId"):
            value = item.get(key)
            if self._is_valid_merge_identity_value(value):
                return str(value).strip()

        group_path = item.get("groupPath")
        if isinstance(group_path, (list, tuple)):
            parts = [str(v).strip() for v in group_path if self._is_valid_merge_identity_value(v)]
            if parts:
                return "/".join(parts)
        elif self._is_valid_merge_identity_value(group_path):
            return str(group_path).strip()
        return None

    def _normalize_import_merge_color(self, value):
        if value is None:
            return None
        if isinstance(value, dict):
            try:
                return (
                    int(round(float(value.get("r", 0)))),
                    int(round(float(value.get("g", 0)))),
                    int(round(float(value.get("b", 0))))
                )
            except Exception:
                try:
                    return tuple(sorted((str(k), str(v)) for k, v in value.items()))
                except Exception:
                    return str(value)
        if isinstance(value, (list, tuple)) and len(value) >= 3:
            try:
                return (
                    int(round(float(value[0]))),
                    int(round(float(value[1]))),
                    int(round(float(value[2])))
                )
            except Exception:
                return tuple(str(v) for v in value)
        text = str(value).strip()
        return text.lower() if text else None

    def _get_import_part_type(self, item):
        part_type = item.get("partType") or item.get("part_type") or item.get("part") or item.get("shapePart") or item.get("sourcePart")
        if self._is_valid_merge_identity_value(part_type):
            text = str(part_type).strip().lower()
            if "stroke" in text or "描边" in text:
                return "stroke"
            if "fill" in text or "填充" in text:
                return "fill"
            return text

        name = item.get("name", "")
        match = re.search(r"_(fill|stroke)(?:_|$)", str(name), re.IGNORECASE)
        if match:
            return match.group(1).lower()
        return "path"

    def _get_import_color_key(self, item, part_type):
        if part_type == "stroke" and item.get("strokeColor") is not None:
            return self._normalize_import_merge_color(item.get("strokeColor"))
        if part_type == "fill" and item.get("fillColor") is not None:
            return self._normalize_import_merge_color(item.get("fillColor"))

        if item.get("color") is not None:
            return self._normalize_import_merge_color(item.get("color"))
        if item.get("fillColor") is not None or item.get("strokeColor") is not None:
            return (
                self._normalize_import_merge_color(item.get("fillColor")),
                self._normalize_import_merge_color(item.get("strokeColor"))
            )
        return None

    def _get_import_depth_key(self, item):
        for key in ("depthMm", "thickness", "depth"):
            value = item.get(key)
            if value is None:
                continue
            try:
                return round(float(value), 4)
            except Exception:
                text = str(value).strip()
                if text:
                    return text

        craft_params = item.get("craftParams")
        if isinstance(craft_params, dict):
            for key in ("depthMm", "thickness", "depth"):
                value = craft_params.get(key)
                if value is None:
                    continue
                try:
                    return round(float(value), 4)
                except Exception:
                    text = str(value).strip()
                    if text:
                        return text

        match = re.search(r"_d(\d+)", str(item.get("name", "")), re.IGNORECASE)
        if match:
            return int(match.group(1))
        return 0

    def _build_import_merge_key(self, item):
        part_type = self._get_import_part_type(item)
        color_key = self._get_import_color_key(item, part_type)
        depth_key = self._get_import_depth_key(item)

        group_path_from_group_field = self._get_import_group_path_from_group_field(item)
        if self._is_stroke_ring_item_for_group_merge_test(item, part_type):
            return ("stroke_ring_group_merge", group_path_from_group_field, part_type, color_key, depth_key)

        if self._should_keep_import_item_separate(item):
            separate_id = (
                item.get("itemId")
                or item.get("objectId")
                or item.get("importIndex", item.get("_original_index"))
                or item.get("name")
                or "unknown"
            )
            return ("separate", str(separate_id).strip(), part_type, color_key, depth_key)

        group_key = self._get_real_group_key(item)
        if group_key:
            return ("grp", group_key, part_type, color_key, depth_key)

        object_id = item.get("objectId")
        if self._is_valid_merge_identity_value(object_id):
            return ("obj", str(object_id).strip(), part_type, color_key, depth_key)

        item_id = item.get("itemId")
        if self._is_valid_merge_identity_value(item_id):
            return ("item", str(item_id).strip(), part_type, color_key, depth_key)

        import_index = item.get("importIndex", item.get("_original_index"))
        name = item.get("name") or item.get("group") or "unknown"
        return ("idx", import_index, name, part_type, color_key, depth_key)

    def _parse_json(self, filepath):
        try:
            self.SetLoadProgress(10, "正在读取文件...")
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.SetLoadProgress(25, "正在解析数据...")
        except:
            self.FailLoadProgress("文件格式错误")
            return []
        items = data.get("items", [])
        res =[]
        total_items = len(items)
        refresh_step = max(1, total_items // 20) if total_items else 1
        for idx, it in enumerate(items):
            segments_data = []
            raw_segs = it.get("segments",[])
            is_single = False
            if raw_segs and len(raw_segs) > 0:
                first = raw_segs[0]
                if isinstance(first, dict): is_single = True
                elif isinstance(first, list):
                    if len(first) > 0 and isinstance(first[0], (int, float)): is_single = True
            if is_single: raw_segs = [raw_segs]

            for seg in raw_segs:
                processed_seg =[]
                for p in seg:
                    if isinstance(p, dict):
                        ax, ay = p.get("a", (0,0))
                        ix, iy = p.get("inT", (ax, ay)) 
                        ox, oy = p.get("outT", (ax, ay))
                        processed_seg.append({"a": (float(ax), float(ay)), "in": (float(ix), float(iy)), "out": (float(ox), float(oy))})
                    elif isinstance(p, list) and len(p) >= 2:
                         x, y = float(p[0]), float(p[1])
                         processed_seg.append({"a": (x, y), "in": (x, y), "out": (x, y)})
                if processed_seg: segments_data.append(processed_seg)
            if segments_data:
                res.append({
                    "name": it.get("name") or "Obj", "layer": it.get("layer") or "Default",
                    "group": it.get("group") or "", "compound": it.get("compound") or "",
                    "closed": bool(it.get("closed", True)), "segments": segments_data, 
                    "color": it.get("color", None),
                    "texture": it.get("texture", None),
                    "texturePath": it.get("texturePath", None),
                    "textureRelPath": it.get("textureRelPath", None),
                    "textureFileName": it.get("textureFileName", None),
                    "imagePath": it.get("imagePath", None),
                    "objectId": it.get("objectId", None),
                    "itemId": it.get("itemId", None),
                    "importIndex": it.get("importIndex", idx),
                    "sourceStackIndex": it.get("sourceStackIndex", None),
                    "sourceZOrderIndex": it.get("sourceZOrderIndex", None),
                    "sourceLayerIndex": it.get("sourceLayerIndex", None),
                    "sourceLayerName": it.get("sourceLayerName", None),
                    "partOrder": it.get("partOrder", None),
                    "partType": it.get("partType", None),
                    "part": it.get("part", None),
                    "part_type": it.get("part_type", None),
                    "groupId": it.get("groupId", None),
                    "groupKey": it.get("groupKey", None),
                    "groupPath": it.get("groupPath", None),
                    "parentGroupId": it.get("parentGroupId", None),
                    "parentGroupKey": it.get("parentGroupKey", None),
                    "parentGroupPath": it.get("parentGroupPath", None),
                    "sourceObjectId": it.get("sourceObjectId", None),
                    "sourceItemId": it.get("sourceItemId", None),
                    "strokeCompoundGroupId": it.get("strokeCompoundGroupId", None),
                    "sourceGroupId": it.get("sourceGroupId", None),
                    "sourceGroupKey": it.get("sourceGroupKey", None),
                    "sourceGroupPath": it.get("sourceGroupPath", None),
                    "preserveSeparateStrokeRing": it.get("preserveSeparateStrokeRing", False),
                    "doNotMergeGeometry": it.get("doNotMergeGeometry", False),
                    "strokeSubPathIndex": it.get("strokeSubPathIndex", None),
                    "compoundPartIndex": it.get("compoundPartIndex", None),
                    "fillColor": it.get("fillColor", None),
                    "strokeColor": it.get("strokeColor", None),
                    "depthMm": it.get("depthMm", None),
                    "thickness": it.get("thickness", None),
                    "depth": it.get("depth", None),
                    "fill": it.get("fill", None),
                    "stroke": it.get("stroke", None),
                    "textureInfo": it.get("textureInfo", None),
                    "material": it.get("material", None),
                    "hasTexture": it.get("hasTexture", True),
                    "craftType": it.get("craftType", "none"),
                    "craftParams": it.get("craftParams", {})
                })
            if total_items and (idx % refresh_step == 0 or idx == total_items - 1):
                parse_percent = 25 + int(((idx + 1) / float(total_items)) * 20)
                self.SetLoadProgress(parse_percent, "正在解析数据...")
        return res

    def _get_or_create_layer_null(self, doc, layer_name, parent=None):
        if not layer_name: layer_name = "Default"
        name = LAYER_NULL_PREFIX + layer_name
        if parent:
            child = parent.GetDown()
            while child:
                if child.CheckType(c4d.Onull) and child.GetName() == name: return child
                child = child.GetNext()
        else:
            top = doc.GetFirstObject()
            while top:
                if top.CheckType(c4d.Onull) and top.GetName() == name: return top
                top = top.GetNext()
        null = c4d.BaseObject(c4d.Onull)
        null.SetName(name)
        if parent: null.InsertUnder(parent)
        else: doc.InsertObject(null)
        return null

    def _get_or_create_group_chain(self, doc, parent_obj, group_path):
        if not group_path: return parent_obj
        parts = group_path.split("/")
        current_parent = parent_obj
        for part in parts:
            if not part.strip(): continue
            group_name = GROUP_NULL_PREFIX + part
            found = None
            child = current_parent.GetDown()
            while child:
                if child.CheckType(c4d.Onull) and child.GetName() == group_name: 
                    found = child; break
                child = child.GetNext()
            if not found:
                new_group = c4d.BaseObject(c4d.Onull)
                new_group.SetName(group_name)
                new_group.InsertUnder(current_parent)
                current_parent = new_group
            else: current_parent = found
        return current_parent

    def _auto_craft_log(self, message):
        try:
            print("[Auto Craft] " + str(message))
        except Exception:
            pass

    def _extract_craft_info(self, item):
        if not isinstance(item, dict):
            return "none", {}
        craft_type = str(item.get("craftType") or "none").strip().lower()
        if not craft_type:
            craft_type = "none"
        craft_params = item.get("craftParams") or {}
        if not isinstance(craft_params, dict):
            craft_params = {}
        return craft_type, craft_params

    def _queue_auto_craft(self, pending_crafts, created_obj, item):
        craft_type, craft_params = self._extract_craft_info(item)
        if craft_type == "none":
            return
        if not created_obj:
            self._auto_craft_log("跳过无对象工艺: " + str(craft_type))
            return
        pending_crafts.append({
            "obj": created_obj,
            "craftType": craft_type,
            "craftParams": craft_params,
            "sourceName": item.get("name") or created_obj.GetName()
        })

    def _restore_selection(self, doc, selected_objects, active_obj):
        try:
            c4d.CallCommand(12113)
            if active_obj and active_obj.IsAlive():
                doc.SetActiveObject(active_obj, c4d.SELECTION_NEW)
                first_done = True
            else:
                first_done = False
            for obj in selected_objects or []:
                if obj and obj.IsAlive() and obj != active_obj:
                    mode = c4d.SELECTION_ADD if first_done else c4d.SELECTION_NEW
                    doc.SetActiveObject(obj, mode)
                    first_done = True
        except Exception as e:
            self._auto_craft_log("恢复选择失败: " + str(e))

    def _process_pending_crafts(self, pending_crafts):
        if not pending_crafts:
            return 0
        processed = 0
        for info in pending_crafts:
            obj = info.get("obj")
            craft_type = info.get("craftType")
            craft_params = info.get("craftParams") or {}
            source_name = info.get("sourceName") or ""
            if not obj or not obj.IsAlive():
                self._auto_craft_log("对象已失效，跳过: " + str(source_name))
                continue
            try:
                if self._apply_auto_craft(obj, craft_type, craft_params):
                    processed += 1
            except Exception as e:
                self._auto_craft_log("工艺处理失败 " + str(source_name) + " / " + str(craft_type) + ": " + str(e))
                traceback.print_exc()
        return processed

    def _apply_auto_craft(self, obj, craft_type, craft_params):
        if craft_type == "acrylic_slot":
            return self._apply_acrylic_slot_auto(obj, craft_params)
        if craft_type in ("sign_backlit", "sign_frontlit", "sign_crystal", "sign_dual_lit"):
            return self._apply_sign_craft_auto(obj, craft_type, craft_params)
        self._auto_craft_log("未知 craftType，已跳过: " + str(craft_type))
        return False

    def _float_param(self, params, key, default_value):
        try:
            value = params.get(key, default_value)
            if value is None or value == "":
                return float(default_value)
            return float(value)
        except Exception:
            return float(default_value)

    def _parse_hex_color(self, hex_string):
        if not hex_string:
            return None
        try:
            text = str(hex_string).strip()
            if text.startswith("#"):
                text = text[1:]
            if len(text) == 3:
                text = "".join([ch + ch for ch in text])
            if len(text) != 6:
                return None
            r = int(text[0:2], 16) / 255.0
            g = int(text[2:4], 16) / 255.0
            b = int(text[4:6], 16) / 255.0
            return c4d.Vector(r, g, b)
        except Exception:
            return None

    def _apply_acrylic_slot_auto(self, obj, params):
        doc = c4d.documents.GetActiveDocument()
        if not doc or not obj or not obj.IsAlive():
            return False
        selected = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
        active = doc.GetActiveObject()
        depth = self._float_param(params, "depthCm", 0.3)
        direction = str(params.get("direction", "Z+") or "Z+").upper().replace(" ", "")
        target_depth = -abs(depth) if direction == "Z-" else abs(depth)
        delete_sides = params.get("deleteSides", ["top"])
        if isinstance(delete_sides, str):
            delete_sides = [delete_sides]
        delete_sides = [str(v).strip().lower() for v in (delete_sides or [])]
        side_cfg = {
            "dt": "top" in delete_sides,
            "db": "bottom" in delete_sides,
            "dl": "left" in delete_sides,
            "dr": "right" in delete_sides,
            "skip": False
        }
        if not (side_cfg["dt"] or side_cfg["db"] or side_cfg["dl"] or side_cfg["dr"]):
            side_cfg["skip"] = True
        shell = self._float_param(params, "shellCm", 0.3)
        old_name = obj.GetName()
        self._auto_craft_log("生成亚克力插槽: " + old_name)
        try:
            c4d.CallCommand(12113)
            doc.SetActiveObject(obj, c4d.SELECTION_NEW)
            RunGenerate(target_depth, side_cfg, shell)
            generated = doc.GetActiveObject()
            if generated and generated.IsAlive():
                generated.SetName(old_name + "_亚克力插槽")
            return True
        finally:
            self._restore_selection(doc, selected, active)

    def _apply_sign_craft_auto(self, obj, craft_type, params):
        doc = c4d.documents.GetActiveDocument()
        if not doc or not obj or not obj.IsAlive():
            return False
        defaults = {
            "sign_backlit": (30.0, 10.0, "背发光", Gen_Backlit),
            "sign_frontlit": (5.0, 30.0, "正发光", Gen_Frontlit),
            "sign_crystal": (3.0, 10.0, "水晶字", Gen_Crystal),
            "sign_dual_lit": (5.0, 30.0, "正背发", Gen_DualLit)
        }
        if craft_type not in defaults:
            return False
        default_front_mm, default_back_mm, suffix, generator = defaults[craft_type]
        front_mm = self._float_param(params, "frontThicknessMm", default_front_mm)
        back_mm = self._float_param(params, "backThicknessMm", default_back_mm)
        if front_mm <= 0.001:
            front_mm = default_front_mm
        if back_mm <= 0.001:
            back_mm = default_back_mm
        front_cm = front_mm / 10.0
        back_cm = back_mm / 10.0
        color = self._parse_hex_color(params.get("color"))
        if color is None:
            color = Signage_GetObjColor(obj, c4d.Vector(1, 1, 1))
        selected = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
        active = doc.GetActiveObject()
        old_name = obj.GetName()
        self._auto_craft_log("生成广告字工艺: " + old_name + " -> " + suffix)
        try:
            c4d.CallCommand(12113)
            doc.SetActiveObject(obj, c4d.SELECTION_NEW)
            targets = Signage_GetTargets(doc)
            if not targets:
                self._auto_craft_log("未找到可用于广告字工艺的样条: " + old_name)
                return False
            doc.StartUndo()
            generator(doc, targets, front_cm, back_cm, color)
            doc.EndUndo()
            generated = doc.GetActiveObject()
            if generated and generated.IsAlive():
                generated.SetName(old_name + "_" + suffix)
            c4d.EventAdd()
            return True
        except Exception:
            try:
                doc.EndUndo()
            except Exception:
                pass
            raise
        finally:
            self._restore_selection(doc, selected, active)

    def _do_import(self, is_hot_replace=False, file_path_override=None):
        try:
            if not self._admin_ensure_fresh_license():
                msg = self.core_disabled_reason or "当前未授权，无法使用核心功能。"
                self.FailLoadProgress(msg)
                gui.MessageDialog(msg)
                return True
            self.ResetLoadProgress()
            doc = documents.GetActiveDocument()
            old_op = None
            
            if file_path_override:
                file_path = file_path_override
            # 如果是点击了替换按钮，走临时缓存，并强制关闭导入到新文件
            elif is_hot_replace:
                old_op = doc.GetActiveObject()
                if not old_op:
                    self.FailLoadProgress("未选择要替换的旧模型")
                    gui.MessageDialog("请先在 C4D 中选中你要替换的旧模型！")
                    return True
                file_path = os.path.join(tempfile.gettempdir(), "hh_c4d_hot_update.json")
                if not os.path.exists(file_path):
                    self.FailLoadProgress("找不到热更缓存数据")
                    gui.MessageDialog("找不到缓存数据！请先在 AI 中点击【⚡ 发送更新 (热更)】。")
                    return True
                self.SetBool(ID_IMPORT_TO_NEW_DOC, False) 
            else:
                # 如果是正常点击导入按钮，依然弹窗让用户选
                file_path = storage.LoadDialog(title="选择 AI 导出的 JSON 文件")
                if not file_path:
                    self.ResetLoadProgress()
                    return True
                
            ratio = self.GetInt32(ID_RATIO_COMBO)
            scale = float(ratio) if ratio > 0 else 1.0
            tension = self.GetFloat(ID_TENSION_VAL)
            ui_auto_extrude = self.GetBool(ID_EXTRUDE_ENABLE)
            ui_depth = -abs(self.GetFloat(ID_EXTRUDE_DEPTH))
            use_groups = self.GetBool(ID_KEEP_LAYER)
            import_color = self.GetBool(ID_IMPORT_COLOR)
            auto_close = self.GetBool(ID_AUTO_CLOSE)
            import_to_new = self.GetBool(ID_IMPORT_TO_NEW_DOC)
            do_smart_stack = self.GetBool(ID_SMART_STACK)
            apply_gamma = self.GetBool(ID_GAMMA_CORRECT)

            path_data = self._parse_json(file_path)
            if not path_data:
                self.FailLoadProgress("文件格式错误或无可导入数据")
                return True
            self.SetLoadProgress(45, "数据解析完成，开始创建对象...")

            if import_to_new:
                doc = c4d.documents.BaseDocument()
                c4d.documents.InsertBaseDocument(doc)
                c4d.documents.SetActiveDocument(doc)
            else: doc = documents.GetActiveDocument()

            doc.StartUndo()
            file_name = os.path.splitext(os.path.basename(file_path))[0]
            main_container = c4d.BaseObject(c4d.Onull)
            main_container.SetName(f"Import_{file_name}")
            doc.InsertObject(main_container)
            doc.AddUndo(c4d.UNDOTYPE_NEW, main_container)

            created_cnt = 0
            for idx, item in enumerate(path_data): item['_original_index'] = idx

            merged_db = {}
            for item in path_data:
                full_key = self._build_import_merge_key(item)
                if full_key not in merged_db:
                    merged_db[full_key] = []
                merged_db[full_key].append(item)

            all_groups = list(merged_db.values())
            has_ai_stack_sort = self._has_ai_stack_sort_fields(all_groups)
            if has_ai_stack_sort:
                all_groups.sort(
                    key=lambda g: (
                        self._get_ai_stack_sort_key(g[0]),
                        self._get_source_stack_group_key(g[0]),
                        self._get_part_order_value(g[0]),
                        self._safe_import_float(g[0].get("_original_index"), 0.0)
                    ),
                    reverse=True
                )
            else:
                all_groups.sort(key=lambda g: g[0]['_original_index'], reverse=True)
            self._print_ai_stack_smart_order_debug(all_groups, has_ai_stack_sort, larger_front=True)
            
            placed_cache = []; fit_targets =[]
            pending_crafts = []
            total_groups = len(all_groups)
            refresh_step = max(1, total_groups // 25) if total_groups else 1
            import_uid = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff]+", "_", file_name) + "_" + time.strftime("%Y%m%d%H%M%S")
            texture_material_cache = {}
            missing_texture_items = []

            for group_index, group_items in enumerate(all_groups):
                sp = None
                main_item = group_items[0]
                d_val_override = 0.0
                match = re.search(r"_d(\d+)", main_item["name"], re.IGNORECASE)
                if match: d_val_override = float(match.group(1)) / 10.0 

                all_segs =[]
                for it in group_items: all_segs.extend(it["segments"])
                
                sp = self._create_spline_from_segments(all_segs, main_item["name"], scale, auto_close, tension)
                if not sp: continue
                CenterAxis(sp)
                final_obj = sp
                
                color_vec = None
                raw_r, raw_g, raw_b = 255, 255, 255
                if import_color:
                    if main_item.get("color"):
                        c_data = main_item["color"]
                        if isinstance(c_data, dict):
                            raw_r = float(c_data.get('r', 0)); raw_g = float(c_data.get('g', 0)); raw_b = float(c_data.get('b', 0))
                        elif isinstance(c_data, list) and len(c_data) >= 3:
                             raw_r = float(c_data[0]); raw_g = float(c_data[1]); raw_b = float(c_data[2])
                        is_mask_grey = (50 < raw_r < 52 and 50 < raw_g < 52 and 50 < raw_b < 52)
                        if is_mask_grey: color_vec = c4d.Vector(1.0, 1.0, 1.0)
                        else:
                            v_r = raw_r / 255.0; v_g = raw_g / 255.0; v_b = raw_b / 255.0
                            if apply_gamma: v_r = pow(v_r, 2.2); v_g = pow(v_g, 2.2); v_b = pow(v_b, 2.2)
                            color_vec = c4d.Vector(v_r, v_g, v_b)
                    else: color_vec = c4d.Vector(1.0, 1.0, 1.0)

                tex_tag_to_fit = None
                found_tex_path = None
                has_tex_flag = main_item.get("hasTexture", True)
                if has_tex_flag:
                    found_tex_path, missing_texture = self._resolve_item_texture_path(main_item, file_path)
                    if missing_texture:
                        if isinstance(missing_texture, dict):
                            missing_texture_items.append(missing_texture)
                        else:
                            missing_texture_items.append({"item": main_item.get("name", "Obj"), "wanted": main_item.get("name", "Obj"), "resolved": ""})

                if color_vec:
                    mat_base = self.CreateColorMaterial(doc, raw_r, raw_g, raw_b, apply_gamma)
                    if mat_base:
                        tag_base = sp.MakeTag(c4d.Ttexture)
                        tag_base.SetMaterial(mat_base)
                        tag_base[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_UVW 

                if found_tex_path:
                    base_uid = self._safe_texture_material_uid(found_tex_path, main_item, import_uid)
                    mat = self.CreateTextureMaterial(doc, base_uid, found_tex_path, texture_material_cache)
                    last_tag = sp.GetLastTag()
                    tag = sp.MakeTag(c4d.Ttexture, pred=last_tag)
                    tag.SetMaterial(mat)
                    tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_CUBIC
                    tag[c4d.TEXTURETAG_TILE] = False
                    tag[c4d.TEXTURETAG_MIX] = False 
                    tex_tag_to_fit = tag
                
                sp[c4d.ID_BASEOBJECT_USECOLOR] = 0 
                if not found_tex_path and color_vec: sp.GetDataInstance().SetVector(AI_COLOR_DATA_ID, color_vec)

                current_depth = 0.0
                if d_val_override > 0.001: current_depth = -d_val_override
                elif ui_auto_extrude: current_depth = ui_depth 

                if abs(current_depth) > 0.001:
                    center, _, _ = self._get_real_world_bounds(sp)
                    new_mg = sp.GetMg(); new_mg.off = center
                    all_pts = sp.GetAllPoints()
                    inv_new_mg = ~new_mg
                    sp.SetAllPoints([inv_new_mg * (sp.GetMg() * p) for p in all_pts])
                    sp.SetMg(new_mg)
                
                    ex_name = sp.GetName().replace(SPLINE_NAME_PREFIX, EXTRUDE_NAME_PREFIX)
                    ex = self._create_extrude_object(current_depth, ex_name)
                    ex.SetMg(sp.GetMg())
                    sp.InsertUnder(ex)
                    sp.SetMl(c4d.Matrix()) 
                    
                    tags = sp.GetTags()
                    for t in tags:
                        if t.CheckType(c4d.Ttexture):
                            sp_mat = t.GetMaterial()
                            is_bitmap = False
                            if sp_mat and sp_mat[c4d.MATERIAL_COLOR_SHADER]: is_bitmap = True
                            t_clone = t.GetClone()
                            last_tag = ex.GetLastTag()
                            ex.InsertTag(t_clone, pred=last_tag)
                            if t == tex_tag_to_fit: tex_tag_to_fit = t_clone
                            t.Remove()
                            if is_bitmap: t_clone[c4d.TEXTURETAG_RESTRICTION] = "C2"
                            
                    final_obj = ex
                    if color_vec: 
                        ex[c4d.ID_BASEOBJECT_USECOLOR] = 0
                        ex.GetDataInstance().SetVector(AI_COLOR_DATA_ID, color_vec)

                if do_smart_stack:
                    spline_ref = sp
                    current_source_key = self._get_strong_source_key_for_smart_stack_skip(main_item)
                    deepest_hit_z = None
                    has_hit = False
                    for cache in placed_cache:
                        if CheckSplineOverlapHybrid(spline_ref, cache['spline']):
                            cache_item = cache.get('item') or {}
                            cache_source_key = cache.get('source_key')
                            same_source_skip = self._should_skip_smart_stack_for_same_source(main_item, cache_item)
                            self._print_smart_stack_overlap_debug(main_item, cache_item, current_source_key, cache_source_key, same_source_skip)
                            if same_source_skip:
                                continue
                            has_hit = True
                            cache_back_z = cache.get('back_z', cache.get('front_z', 0.0))
                            required_z = cache_back_z - AI_STACK_SAFETY_GAP
                            if deepest_hit_z is None or required_z < deepest_hit_z:
                                deepest_hit_z = required_z
                    
                    final_pos_z = deepest_hit_z if has_hit else 0.0
                    current_mg = final_obj.GetMg()
                    current_mg.off = c4d.Vector(current_mg.off.x, current_mg.off.y, final_pos_z)
                    final_obj.SetMg(current_mg)

                    obj_thickness = abs(current_depth) if abs(current_depth) > 0.001 else 0.0
                    my_back_z = final_pos_z - obj_thickness
                    current_rect = GetSplineGlobalAABB(spline_ref)
                    placed_cache.append({
                        'rect': current_rect,
                        'front_z': final_pos_z,
                        'back_z': my_back_z,
                        'thickness': obj_thickness,
                        'spline': spline_ref,
                        'source_key': current_source_key,
                        'item': main_item
                    })

                if tex_tag_to_fit and tex_tag_to_fit.IsAlive(): fit_targets.append((final_obj, tex_tag_to_fit))

                parent = None
                if use_groups:
                    layer_null = self._get_or_create_layer_null(doc, main_item.get("layer"), parent=main_container)
                    group_name = main_item.get("group")
                    parent = self._get_or_create_group_chain(doc, layer_null, group_name)
                
                if parent: final_obj.InsertUnder(parent)
                else: final_obj.InsertUnder(main_container)

                doc.AddUndo(c4d.UNDOTYPE_NEW, final_obj)
                craft_item = main_item
                for candidate_item in group_items:
                    candidate_type, _ = self._extract_craft_info(candidate_item)
                    if candidate_type != "none":
                        craft_item = candidate_item
                        break
                self._queue_auto_craft(pending_crafts, final_obj, craft_item)
                created_cnt += 1
                if total_groups and (group_index % refresh_step == 0 or group_index == total_groups - 1):
                    create_percent = 45 + int(((group_index + 1) / float(total_groups)) * 40)
                    self.SetLoadProgress(create_percent, f"正在创建样条/对象... {group_index + 1}/{total_groups}")

            self.SetLoadProgress(90, "正在整理层级/刷新场景...")
            c4d.EventAdd()
            all_objects =[]
            def collect_hierarchy(op):
                while op:
                    all_objects.append(op)
                    collect_hierarchy(op.GetDown())
                    op = op.GetNext()
            collect_hierarchy(main_container)
            
            for op in reversed(all_objects):
                if not op.IsAlive(): continue
                if op.CheckType(c4d.Onull) and op.GetName().startswith(GROUP_NULL_PREFIX):
                    children = op.GetChildren()
                    if len(children) == 1:
                        child = children[0]
                        parent = op.GetUp()
                        mat = child.GetMg()
                        child.Remove()
                        doc.InsertObject(child, pred=op) 
                        child.SetMg(mat)
                        doc.AddUndo(c4d.UNDOTYPE_CHANGE, child)
                        op.Remove()
                        doc.AddUndo(c4d.UNDOTYPE_DELETE, op)

            if fit_targets: BatchFitTextureTags(doc, fit_targets)
            RecenterGroupAxis(main_container)

           # =================[花花智能建模-C4D端 v1.1 - 夺舍替换逻辑 (完美组替换版)] =================
            if is_hot_replace and old_op and old_op.IsAlive():
                
                # 如果用户不小心选中的是样条，自动把目标换成它外层的挤压外壳
                if old_op.CheckType(c4d.Ospline) and old_op.GetUp() and old_op.GetUp().CheckType(c4d.Oextrude):
                    old_op = old_op.GetUp()

                # 提取旧物体的世界矩阵
                old_mg = old_op.GetMg()
                
                # 构造目标矩阵：继承位置和旋转，抛弃旧物体的缩放比例（强制重置比例，防止拉伸）
                target_mg = c4d.Matrix(old_mg)
                target_mg.v1 = target_mg.v1.GetNormalized()
                target_mg.v2 = target_mg.v2.GetNormalized()
                target_mg.v3 = target_mg.v3.GetNormalized()
                
                main_container.SetName(old_op.GetName())
                
                # 【关键修复 1】：先将新组放入旧物体的层级位置 
                main_container.Remove() 
                doc.InsertObject(main_container, parent=old_op.GetUp(), pred=old_op.GetPred())
                
                # 【关键修复 2】：放入层级后，再赋予世界坐标，把它死死钉在原地！
                main_container.SetMg(target_mg)
                
                # 删掉旧物体
                doc.AddUndo(c4d.UNDOTYPE_DELETE, old_op)
                old_op.Remove()
            # ========================================================

            doc.EndUndo()
            c4d.EventAdd()
            craft_cnt = self._process_pending_crafts(pending_crafts)
            self.FinishLoadProgress()
            if craft_cnt > 0:
                msg = f"成功处理 {created_cnt} 个对象，自动处理 {craft_cnt} 个工艺"
                self._auto_craft_log(msg)
                c4d.StatusSetText(msg)
            else:
                c4d.StatusSetText(f"成功处理 {created_cnt} 个对象")
            if missing_texture_items:
                preview_lines = []
                for idx, info in enumerate(missing_texture_items[:5]):
                    wanted = info.get("wanted") if isinstance(info, dict) else str(info)
                    preview_lines.append(str(idx + 1) + ". " + str(wanted))
                warn_msg = "部分贴图未找到，请检查 JSON 同级 tex 文件夹。\n缺失数量：" + str(len(missing_texture_items))
                if preview_lines:
                    warn_msg += "\n前几个：\n" + "\n".join(preview_lines)
                self._texture_log(warn_msg.replace("\n", " "))
                gui.MessageDialog(warn_msg)

        except Exception as e:
            self.FailLoadProgress(str(e))
            gui.MessageDialog(f"导入错误:\n{str(e)}\n{traceback.format_exc()}")
        return True

    def _action_simple_extrude_selected(self):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel:
            gui.MessageDialog("请先选中要挤压的样条对象。")
            return
        depth = -abs(self.GetFloat(ID_EXTRUDE_DEPTH))
        doc.StartUndo()
        for obj in sel:
            if obj.CheckType(c4d.Ospline):
                old_mg = obj.GetMg()
                ex_name = obj.GetName().replace(SPLINE_NAME_PREFIX, EXTRUDE_NAME_PREFIX)
                if ex_name == obj.GetName(): ex_name = "Extrude_" + obj.GetName()
                ex = self._create_extrude_object(depth, ex_name)
                ex.SetMg(old_mg)
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                obj.Remove()
                ex[c4d.ID_BASEOBJECT_USECOLOR] = 0
                if obj.GetUp(): doc.InsertObject(ex, pred=obj.GetUp())
                else: doc.InsertObject(ex)
                obj.InsertUnder(ex)
                obj.SetMl(c4d.Matrix())
                doc.AddUndo(c4d.UNDOTYPE_NEW, ex)
        doc.EndUndo()
        c4d.EventAdd()

    def _action_smart_merge_color(self):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel:
            gui.MessageDialog("请选中需要合并的样条。")
            return
        color_groups = {}
        for obj in sel:
            if not obj.CheckType(c4d.Ospline): continue
            found_color = None
            for t in obj.GetTags():
                if t.CheckType(c4d.Ttexture):
                    mat = t.GetMaterial()
                    if mat and mat.CheckType(c4d.Mmaterial): 
                        if mat[c4d.MATERIAL_USE_COLOR]:
                            found_color = mat[c4d.MATERIAL_COLOR_COLOR]
                            break
            if found_color is None: found_color = obj[c4d.ID_BASEOBJECT_COLOR]
            key = (round(found_color.x, 3), round(found_color.y, 3), round(found_color.z, 3))
            if (key[0] < 0.01 and key[1] < 0.01 and key[2] < 0.01) or \
               (0.19 < key[0] < 0.21 and 0.19 < key[1] < 0.21 and 0.19 < key[2] < 0.21):
                key = (1.0, 1.0, 1.0)
            if key not in color_groups: color_groups[key] = []
            color_groups[key].append(obj)

        if not color_groups: return
        depth = -abs(self.GetFloat(ID_EXTRUDE_DEPTH))
        doc.StartUndo()
        for key, objects in color_groups.items():
            if not objects: continue
            res = utils.SendModelingCommand(command=c4d.MCOMMAND_JOIN, list=objects, mode=c4d.MODELINGCOMMANDMODE_ALL, doc=doc, flags=c4d.MODELINGCOMMANDFLAGS_NONE)
            if res and res[0]:
                merged_spline = res[0]
                r_inv = int(key[0] * 255); g_inv = int(key[1] * 255); b_inv = int(key[2] * 255)
                merged_spline.SetName(f"Merged_Spline_{r_inv}_{g_inv}_{b_inv}")
                vec_color = c4d.Vector(key[0], key[1], key[2])
                merged_spline[c4d.ID_BASEOBJECT_USECOLOR] = 0
                doc.InsertObject(merged_spline)
                doc.AddUndo(c4d.UNDOTYPE_NEW, merged_spline)
                
                ex = self._create_extrude_object(depth, merged_spline.GetName().replace("Merged_Spline", "Extrude"))
                ex.SetMg(merged_spline.GetMg())
                ex[c4d.ID_BASEOBJECT_USECOLOR] = 0
                mat = self.CreateColorMaterial(doc, r_inv, g_inv, b_inv, False)
                if mat:
                    tex = ex.MakeTag(c4d.Ttexture)
                    tex.SetMaterial(mat)
                    tex[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_UVW
                
                merged_spline.InsertUnder(ex)
                merged_spline.SetMl(c4d.Matrix())
                doc.InsertObject(ex)
                doc.AddUndo(c4d.UNDOTYPE_NEW, ex)
                for old_obj in objects:
                    doc.AddUndo(c4d.UNDOTYPE_DELETE, old_obj)
                    old_obj.Remove()
        doc.EndUndo()
        c4d.EventAdd()

    def _action_apply_depth_to_selected(self):
        ui_val = self.GetFloat(ID_EXTRUDE_DEPTH)
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel: return
        doc.StartUndo()
        changed = False
        for obj in sel:
            if obj.CheckType(c4d.Oextrude) or obj.GetType() == C4D_EXTRUDE_TYPEID:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                try:
                    curr_offset = obj[C4D_EXTRUDE_OFFSET_ID]
                    new_offset_val = abs(ui_val)
                    if curr_offset < 0: new_offset_val = -new_offset_val
                    elif curr_offset == 0: new_offset_val = -new_offset_val
                    obj[C4D_EXTRUDE_OFFSET_ID] = new_offset_val
                except: pass
                try:
                    current_vec = obj[c4d.EXTRUDEOBJECT_MOVE]
                    length = current_vec.GetLength()
                    if length > 0.0001:
                        direction = current_vec.GetNormalized()
                        obj[c4d.EXTRUDEOBJECT_MOVE] = direction * abs(ui_val)
                    else:
                        obj[c4d.EXTRUDEOBJECT_MOVE] = c4d.Vector(0, 0, -abs(ui_val))
                except: pass
            
                obj.Message(c4d.MSG_UPDATE)
                changed = True
        doc.EndUndo()
        if changed: c4d.EventAdd()


    # ==============================================================================
    # 资产库逻辑
    # ==============================================================================

    # ==============================================================================
    # 吊顶生成逻辑 (Action)
    # ==============================================================================
    def _add_stair_segment(self, gen, number, steps=8, include_walls=True, include_windows=True):
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
        bc[c4d.DESC_NAME] = "第 %d 段楼梯" % number
        bc[c4d.DESC_SHORT_NAME] = "HH_STAIR_SEGMENT_V2"
        bc[c4d.DESC_TITLEBAR] = True
        group = gen.AddUserData(bc)
        for label, dtype, value, minimum, maximum in (
                ("台阶数量", c4d.DTYPE_LONG, steps, 1, 1000),
                ("平台后转向", c4d.DTYPE_LONG, 0, 0, 4),
                ("平台深度 (cm，0=楼梯宽度)", c4d.DTYPE_REAL, 0.0, 0, 100000),
                ("折返梯段间距 (cm)", c4d.DTYPE_REAL, 0.0, 0, 100000),
                ("楼梯底部造型", c4d.DTYPE_LONG, 0, 0, 1),
                ("底部厚度 (cm，实心向下延伸/斜底板厚)", c4d.DTYPE_REAL, 15.0, 0.01, 100000),
                ("平台厚度 (cm，0=跟随梯段)", c4d.DTYPE_REAL, 0.0, 0, 100000),
                ("平台左侧扶手", c4d.DTYPE_BOOL, True, 0, 1),
                ("平台右侧扶手", c4d.DTYPE_BOOL, True, 0, 1),
                ("平台前侧扶手（远端）", c4d.DTYPE_BOOL, True, 0, 1),
                ("平台后侧扶手（入口侧）", c4d.DTYPE_BOOL, True, 0, 1)):
            bc = c4d.GetCustomDataTypeDefault(dtype)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_PARENTGROUP] = group
            bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = minimum, maximum, 1
            if label == "平台后转向":
                cycle = c4d.BaseContainer()
                for key, text in enumerate(("直行", "左转 90°", "右转 90°", "左折返 180°", "右折返 180°")):
                    cycle.SetString(key, text)
                bc[c4d.DESC_CYCLE] = cycle
                bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_CYCLE
            elif label == "楼梯底部造型":
                cycle = c4d.BaseContainer()
                cycle.SetString(0, "实心填充底")
                cycle.SetString(1, "斜平底")
                bc[c4d.DESC_CYCLE] = cycle
                bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_CYCLE
            gen[gen.AddUserData(bc)] = value

        # Old scene-embedded generators still expect the original 11 fields.
        if not include_walls:
            return
        for label, dtype, value, minimum, maximum in (
                ("生成梯段墙体", c4d.DTYPE_BOOL, False, 0, 1),
                ("墙体位置", c4d.DTYPE_LONG, 0, 0, 2),
                ("墙高（高于梯段顶线 cm）", c4d.DTYPE_REAL, 120.0, 0.01, 100000),
                ("墙体厚度 (cm)", c4d.DTYPE_REAL, 15.0, 0.01, 100000),
                ("墙体与楼梯间距 (cm)", c4d.DTYPE_REAL, 0.0, 0, 100000),
                ("墙顶造型", c4d.DTYPE_LONG, 0, 0, 1),
                ("平台左侧墙", c4d.DTYPE_BOOL, True, 0, 1),
                ("平台右侧墙", c4d.DTYPE_BOOL, True, 0, 1),
                ("平台前侧墙（远端）", c4d.DTYPE_BOOL, True, 0, 1),
                ("平台后侧墙（入口侧）", c4d.DTYPE_BOOL, True, 0, 1)):
            bc = c4d.GetCustomDataTypeDefault(dtype)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_PARENTGROUP] = group
            bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = minimum, maximum, 1
            choices = {"墙体位置": ("左侧", "右侧", "双侧"),
                       "墙顶造型": ("斜顶跟随楼梯", "水平墙顶")}.get(label)
            if choices:
                cycle = c4d.BaseContainer()
                for key, text in enumerate(choices):
                    cycle.SetString(key, text)
                bc[c4d.DESC_CYCLE] = cycle
                bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_CYCLE
            gen[gen.AddUserData(bc)] = value

        if not include_windows:
            return
        for label, dtype, value, minimum in (
                ("生成本段平台墙（独立开关）", c4d.DTYPE_BOOL, False, 0),
                ("平台墙高（高于平台 cm）", c4d.DTYPE_REAL, 120.0, 0.01),
                ("平台墙厚 (cm)", c4d.DTYPE_REAL, 15.0, 0.01),
                ("平台墙间距 (cm)", c4d.DTYPE_REAL, 0.0, 0),
                ("平台前侧外墙生成窗户", c4d.DTYPE_BOOL, False, 0),
                ("窗户宽度 (cm)", c4d.DTYPE_REAL, 80.0, 0.01),
                ("窗户高度 (cm)", c4d.DTYPE_REAL, 60.0, 0.01),
                ("窗台高度（相对平台 cm）", c4d.DTYPE_REAL, 30.0, 0),
                ("窗户左右偏移 (cm)", c4d.DTYPE_REAL, 0.0, -100000),
                ("窗框宽度 (cm)", c4d.DTYPE_REAL, 4.0, 0.01)):
            bc = c4d.GetCustomDataTypeDefault(dtype)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_PARENTGROUP] = group
            bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = minimum, 100000, 1
            gen[gen.AddUserData(bc)] = value

        for label, dtype, value in (("窗户样式", c4d.DTYPE_LONG, 0),
                                    ("上亮窗高度比例 (%)", c4d.DTYPE_REAL, 25.0)):
            bc = c4d.GetCustomDataTypeDefault(dtype)
            bc[c4d.DESC_NAME], bc[c4d.DESC_PARENTGROUP] = label, group
            if label == "窗户样式":
                cycle = c4d.BaseContainer()
                cycle.SetString(0, "双扇推拉窗")
                cycle.SetString(1, "上亮窗 + 双扇推拉窗")
                bc[c4d.DESC_CYCLE] = cycle
                bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_CYCLE
            else:
                bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = 15.0, 45.0, 1.0
            gen[gen.AddUserData(bc)] = value

    def _action_edit_stair_segments(self, remove=False):
        doc = c4d.documents.GetActiveDocument()
        gen = doc.GetActiveObject() if doc else None
        if gen is None or not gen.CheckType(c4d.Opython) or "HH_STAIR_SEGMENTS_V5" not in str(gen[c4d.OPYTHON_CODE]):
            gui.MessageDialog("请先选中新版花花楼梯对象；旧版楼梯请重新生成后编辑梯段。")
            return
        data = list(gen.GetUserDataContainer())
        if any(bc[c4d.DESC_SHORT_NAME] == "HH_STAIR_FLOOR_MASTER_V2" for key, bc in data):
            gui.MessageDialog("当前为楼层总控模式，请调整总控中的生成层数。")
            return
        master_group = next((key for key, bc in data if bc[c4d.DESC_SHORT_NAME] == "HH_STAIR_FLOOR_MASTER"), None)
        if master_group is not None:
            master_fields = [key for key, bc in data if bc[c4d.DESC_PARENTGROUP] == master_group]
            if master_fields and gen[master_fields[0]]:
                gui.MessageDialog("当前为楼层总控模式，请调整总控中的生成层数；手动分段模式可添加或删除梯段。")
                return
        groups = [key for key, bc in data if bc[c4d.DESC_SHORT_NAME] == "HH_STAIR_SEGMENT_V2"]
        if (remove and len(groups) <= 1) or (not remove and len(groups) >= 100):
            gui.MessageDialog("楼梯支持 1-100 段。")
            return
        doc.StartUndo()
        try:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, gen)
            if remove:
                last = groups[-1]
                for key, bc in reversed(data):
                    if bc[c4d.DESC_PARENTGROUP] == last:
                        gen.RemoveUserData(key)
                gen.RemoveUserData(last)
            else:
                last = groups[-1]
                group_bc = c4d.BaseContainer(next(bc for key, bc in data if key == last))
                group_bc[c4d.DESC_NAME] = "第 %d 段楼梯" % (len(groups) + 1)
                group = gen.AddUserData(group_bc)
                for key, original_bc in data:
                    if original_bc[c4d.DESC_PARENTGROUP] != last:
                        continue
                    bc = c4d.BaseContainer(original_bc)
                    bc[c4d.DESC_PARENTGROUP] = group
                    gen[gen.AddUserData(bc)] = gen[key]
            gen.SetDirty(c4d.DIRTYFLAGS_DATA)
            gen.Message(c4d.MSG_UPDATE)
        finally:
            doc.EndUndo()
        c4d.EventAdd()

    def _get_opening_shared_materials(self, doc, preset):
        # Read saved generator links, not names: renamed/customized materials still work.
        pending = list(reversed(doc.GetObjects()))
        labels = tuple(label for label, color in GetOpeningMaterialSpecs(preset))
        while pending:
            obj = pending.pop()
            pending.extend(reversed(obj.GetChildren()))
            if not obj.CheckType(c4d.Opython) or "HH_SMART_OPENING_V1" not in str(obj[c4d.OPYTHON_CODE]):
                continue
            fields = list(obj.GetUserDataContainer())
            preset_key = next((key for key, bc in fields if bc[c4d.DESC_NAME] == "门窗预设"), None)
            if preset_key is None or obj[preset_key] != preset:
                continue
            material_group = next((key for key, bc in fields if bc[c4d.DESC_NAME] == "门窗材质"), None)
            if material_group is None:
                continue
            shared = {}
            for key, bc in fields:
                label = bc[c4d.DESC_NAME]
                if bc[c4d.DESC_PARENTGROUP] != material_group or label not in labels:
                    continue
                mat = obj[key]
                if isinstance(mat, c4d.BaseMaterial) and mat.GetDocument() == doc:
                    shared[label] = mat
            if shared:
                return shared
        return {}

    def _action_generate_opening(self):
        doc = documents.GetActiveDocument()
        if doc is None:
            return
        preset = self.GetInt32(ID_OPENING_PRESET)
        if preset not in range(len(OPENING_PRESETS)):
            return
        defaults = [self.GetFloat(cid) for cid in
                    (ID_OPENING_WIDTH,ID_OPENING_HEIGHT,ID_OPENING_DEPTH)]
        sources = list(doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)) if self.GetBool(ID_OPENING_USE_SELECTION) else []
        sources = sources or [None]
        independent = self.GetBool(ID_OPENING_NEW_MATERIALS)
        shared = {} if independent else self._get_opening_shared_materials(doc, preset)
        prepared, skipped = [], []
        # Validate the complete selection before hiding or changing any source object.
        for source in sources:
            width,height,depth = defaults
            matrix = c4d.Matrix()
            try:
                if source is not None:
                    if source.CheckType(c4d.Opython) and "HH_SMART_OPENING_V1" in str(source[c4d.OPYTHON_CODE]):
                        raise ValueError("已经是智能门窗，请在用户数据中调整")
                    width,height,source_depth,matrix = GetOpeningFit(source,self.GetInt32(ID_OPENING_PLANE))
                    if source_depth >= 1.0:
                        depth = min(source_depth,30.0 if preset < 4 else 40.0)
                if any(not math.isfinite(v) or v < 1 or v > 100000 for v in (width,height,depth)):
                    raise ValueError("门窗尺寸必须在 1-100000 cm 内")
                gen, materials = self._create_opening_generator(preset, width, height, depth, {} if independent else shared)
            except ValueError as exc:
                skipped.append((source.GetName() if source is not None else "默认门窗") + "：" + str(exc))
                continue
            prepared.append((source, gen, materials, matrix))
            if not independent:
                shared = {label: mat for mat, key, label in materials}
        if not prepared:
            gui.MessageDialog("没有生成门窗，原对象保持不变。\n" + "\n".join(skipped))
            return

        def hide_original(obj):
            doc.AddUndo(c4d.UNDOTYPE_CHANGE,obj)
            obj.SetEditorMode(c4d.OBJECT_OFF)
            obj.SetRenderMode(c4d.OBJECT_OFF)
            for child in obj.GetChildren(): hide_original(child)

        doc.StartUndo()
        try:
            for index, (source, gen, materials, matrix) in enumerate(prepared):
                for mat,key,label in materials:
                    if mat.GetDocument() is None:
                        doc.InsertMaterial(mat)
                        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ,mat)
                doc.InsertObject(gen,parent=source.GetUp() if source is not None else None,pred=source)
                doc.AddUndo(c4d.UNDOTYPE_NEWOBJ,gen)
                for mat,key,label in materials:
                    gen[key] = mat
                InstallMaterialReferences(gen, [key[1].id for mat,key,label in materials])
                gen.SetMg(matrix)
                if source is not None:
                    hide_original(source)
                gen.Message(c4d.MSG_UPDATE)
                doc.SetActiveObject(gen,c4d.SELECTION_NEW if index == 0 else c4d.SELECTION_ADD)
        finally:
            doc.EndUndo()
        c4d.EventAdd()
        if skipped:
            gui.MessageDialog("已生成 %d 个门窗，跳过 %d 个对象：\n%s" % (len(prepared),len(skipped),"\n".join(skipped)))

    def _create_opening_generator(self, preset, width, height, depth, shared_materials):
        is_cabinet = preset in (13,14,15,16)
        gen = c4d.BaseObject(c4d.Opython)
        gen.SetName("花花智能门窗 · " + OPENING_PRESETS[preset])
        ids,materials,material_ids = [],[],[]

        def group(label):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
            bc[c4d.DESC_NAME],bc[c4d.DESC_TITLEBAR] = label,True
            if is_cabinet and label not in ("消火栓柜参数", "门窗材质"):
                bc[c4d.DESC_HIDE] = True
            return gen.AddUserData(bc)

        def parameter(label,value,minimum,maximum,parent=None,choices=None):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_LONG if choices else c4d.DTYPE_REAL)
            bc[c4d.DESC_NAME] = bc[c4d.DESC_SHORT_NAME] = label
            if is_cabinet and parent is None and label not in ("门窗预设", "宽度 (cm)", "高度 (cm)", "柜深 (cm，自动保留器件空间)"):
                bc[c4d.DESC_HIDE] = True
            bc[c4d.DESC_MIN],bc[c4d.DESC_MAX],bc[c4d.DESC_STEP] = minimum,maximum,1
            if parent is not None: bc[c4d.DESC_PARENTGROUP] = parent
            if choices:
                cycle = c4d.BaseContainer()
                for index,text in enumerate(choices): cycle.SetString(index,text)
                bc[c4d.DESC_CYCLE] = cycle
                bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_CYCLE
            key = gen.AddUserData(bc)
            gen[key] = value
            ids.append(key[1].id)

        parameter("门窗预设",preset,0,len(OPENING_PRESETS)-1,choices=OPENING_PRESETS)
        # Cabinet materials have different roles; do not reinterpret existing door links.
        preset_key, preset_bc = gen.GetUserDataContainer()[0]
        cycle = c4d.BaseContainer()
        for index in (range(13,17) if is_cabinet else range(13)):
            cycle.SetString(index, OPENING_PRESETS[index])
        preset_bc[c4d.DESC_CYCLE] = cycle
        gen.SetUserDataContainer(preset_key, preset_bc)
        if is_cabinet:
            depth=max(depth,24*min(width/80,height/(200 if preset in (13,16) else 138.5)))
        depth_label="柜深 (cm，自动保留器件空间)" if is_cabinet else "框深 (cm)"
        for label,value in (("宽度 (cm)",width),("高度 (cm)",height),(depth_label,depth),
                            ("型材 / 门套宽度 (cm)",min(5.0,width*.04,height*.025))):
            parameter(label,value,.01,100000)
        window_group = group("推拉窗参数")
        parameter("上亮高度比例 (%)",25.0,15,45,window_group)
        parameter("窗扇滑动 (%)",0.0,0,100,window_group)
        door_group = group("平开门参数")
        parameter("顶部封板高度 (cm，0=关闭)",height*.18,0,100000,door_group)
        parameter("门扇开启角度 (°)",0.0,0,150,door_group)
        parameter("单开门合页侧",0,0,1,door_group,("左侧","右侧"))
        parameter("门扇厚度 (cm)",min(4.0,depth*.5),.01,10000,door_group)
        parameter("把手高度 (cm)",min(100.0,height*.42),0,100000,door_group)
        detail_group = group("窄玻璃门 / 玻璃门细节")
        parameter("观察窗宽度 / 门扇宽度 (%)",23.0,10,35,detail_group)
        parameter("观察窗高度 / 门扇高度 (%)",48.0,20,55,detail_group)
        parameter("子母门主扇比例 (%)",70.0,55,80,detail_group)
        parameter("固定侧玻璃比例 (%)",25.0 if preset==12 else 18.0,10,25,detail_group)
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BOOL)
        bc[c4d.DESC_NAME] = "窄玻璃门闭门器"
        bc[c4d.DESC_PARENTGROUP] = detail_group
        key = gen.AddUserData(bc)
        gen[key] = True
        ids.append(key[1].id)
        small_window_group = group("普通门玻璃小窗（白色 / 木色门）")
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BOOL)
        bc[c4d.DESC_NAME] = bc[c4d.DESC_SHORT_NAME] = "添加玻璃小窗"
        bc[c4d.DESC_PARENTGROUP] = small_window_group
        key = gen.AddUserData(bc)
        gen[key] = False
        ids.append(key[1].id)
        parameter("小窗宽度 (cm)",30.0,.1,100000,small_window_group)
        parameter("小窗高度 (cm)",50.0,.1,100000,small_window_group)
        parameter("小窗水平偏移 (cm)",0.0,-100000,100000,small_window_group)
        parameter("小窗中心离地 (cm，0=自动)",0.0,0,100000,small_window_group)
        if is_cabinet:
            cabinet_group = group("消火栓柜参数")
            parameter("上层柜门开启角度 (°)",0.0,0,150,cabinet_group)
            parameter("下层柜门开启角度 (°)",0.0,0,150,cabinet_group)
        material_group = group("门窗材质")
        for index,(label,color) in enumerate(GetOpeningMaterialSpecs(preset)):
            mat = shared_materials.get(label)
            is_new = mat is None
            if is_new:
                mat = c4d.BaseMaterial(c4d.Mmaterial)
                mat.SetName("智能门窗_"+label)
                mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(*color)
            if is_new and index == 2 and not is_cabinet:
                shader = c4d.BaseShader(c4d.Xnoise)
                shader[c4d.SLA_NOISE_COLOR1] = c4d.Vector(.32,.20,.105)
                shader[c4d.SLA_NOISE_COLOR2] = c4d.Vector(.56,.4,.25)
                shader[c4d.SLA_NOISE_GLOBAL_SCALE] = .08
                shader[c4d.SLA_NOISE_SCALE] = c4d.Vector(.15,12,.15)
                shader[c4d.SLA_NOISE_SPACE] = c4d.SLA_NOISE_SPACE_OBJECT
                mat.InsertShader(shader)
                mat[c4d.MATERIAL_COLOR_SHADER] = shader
            if is_new and index == 3:
                mat[c4d.MATERIAL_USE_TRANSPARENCY] = True
                mat[c4d.MATERIAL_TRANSPARENCY_BRIGHTNESS] = .98 if is_cabinet else .95
                mat[c4d.MATERIAL_TRANSPARENCY_REFRACTION] = 1.5
            if is_new:
                mat.Message(c4d.MSG_UPDATE)
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BASELISTLINK)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_PARENTGROUP] = material_group
            key = gen.AddUserData(bc)
            # Set links after insertion so they also resolve in saved documents.
            materials.append((mat,key,label))
            material_ids.append(key[1].id)
        code = OPENING_GENERATOR_SCRIPT.replace("__PARAMS__",repr(tuple(ids))).replace("__MATS__",repr(tuple(material_ids)))
        if is_cabinet:
            try:
                path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "res", "fire_cabinet_signs.json")
                with open(path, "r", encoding="utf-8") as handle:
                    signs = json.load(handle)
                if not all(label in signs for label in ("消火栓", "火警119", "灭火器",
                                                       "FIRE HYDRANT", "FIRE EMERGENCY 119", "FIRE EXTINGUISHERS")):
                    raise ValueError("消防柜文字资源不完整")
            except (OSError, ValueError) as exc:
                raise ValueError("无法加载消防柜文字资源：%s" % exc)
            code = code.replace("FIRE_SIGN_MESHES = {}", "FIRE_SIGN_MESHES = " + repr(signs))
        gen[c4d.OPYTHON_CODE] = code
        preflight = {"op":gen}
        exec(compile(code,"<HuahuaSmartOpening>","exec"),preflight)
        preview = preflight["main"]()
        if preview is None or preview.GetDown() is None:
            raise ValueError("门窗参数无法生成有效模型")
        return gen, materials

    def _action_generate_stairs(self):
        values = (self.GetFloat(ID_STAIR_HEIGHT), self.GetFloat(ID_STAIR_DEPTH),
                  self.GetFloat(ID_STAIR_WIDTH), self.GetInt32(ID_STAIR_COUNT))
        if any(not math.isfinite(float(v)) or v <= 0 for v in values) or values[3] > 1000:
            gui.MessageDialog("请输入有效的正数尺寸，台阶数量为 1-1000。")
            return
        doc = c4d.documents.GetActiveDocument()
        if doc is None:
            return
        gen = c4d.BaseObject(c4d.Opython)
        gen.SetName("花花楼梯")
        floor_mode = self.GetBool(ID_STAIR_FLOOR_MODE)
        floor_count = self.GetInt32(ID_STAIR_FLOORS)
        if floor_mode and (not 1 <= floor_count <= 20 or floor_count*values[3]*2 > 1000):
            gui.MessageDialog("生成层数为 1-20，总台阶不超过 1000。")
            return
        def settings_group(label, marker, fields, parent=None):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
            bc[c4d.DESC_NAME], bc[c4d.DESC_SHORT_NAME], bc[c4d.DESC_TITLEBAR] = label, marker, True
            if parent is not None:
                bc[c4d.DESC_PARENTGROUP] = parent
            group = gen.AddUserData(bc)
            for name, dtype, value, minimum, maximum, choices in fields:
                bc = c4d.GetCustomDataTypeDefault(dtype)
                bc[c4d.DESC_NAME], bc[c4d.DESC_PARENTGROUP] = name, group
                bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = minimum, maximum, 1
                if choices:
                    cycle = c4d.BaseContainer()
                    for key, text in enumerate(choices): cycle.SetString(key, text)
                    bc[c4d.DESC_CYCLE], bc[c4d.DESC_CUSTOMGUI] = cycle, c4d.CUSTOMGUI_CYCLE
                gen[gen.AddUserData(bc)] = value
        if floor_mode:
            settings_group("楼层总控", "HH_STAIR_FLOOR_MASTER_V2", (
            ("生成层数（每层两个梯段）", c4d.DTYPE_LONG, floor_count, 1, 20, None),
            ("每层上半段台阶数", c4d.DTYPE_LONG, values[3], 1, 500, None),
            ("每层下半段台阶数", c4d.DTYPE_LONG, values[3], 1, 500, None),
            ("半层平台深度 (cm)", c4d.DTYPE_REAL, values[2], 1, 10000, None),
            ("到层平台深度 (cm)", c4d.DTYPE_REAL, values[2], 1, 10000, None),
            ("折返梯段间距 (cm)", c4d.DTYPE_REAL, 20.0, 0, 10000, None),
            ("首段折返方向", c4d.DTYPE_LONG, 0, 0, 1, ("右折返", "左折返")),
            ("生成外围墙", c4d.DTYPE_BOOL, True, 0, 1, None),
            ("墙顶高度（高于梯段/平台 cm）", c4d.DTYPE_REAL, 120.0, 1, 10000, None),
            ("墙厚 (cm)", c4d.DTYPE_REAL, 15.0, 0.1, 1000, None),
            ("半层平台外墙窗户", c4d.DTYPE_BOOL, False, 0, 1, None),
            ))
            settings_group("总控梯段与平台底部", "HH_STAIR_MASTER_SHAPE", (
                ("楼梯底部造型", c4d.DTYPE_LONG, 1, 0, 1, ("实心填充底", "斜平底")),
                ("底部厚度 (cm)", c4d.DTYPE_REAL, 15.0, 0.01, 100000, None),
                ("平台厚度 (cm，0=跟随梯段)", c4d.DTYPE_REAL, 0.0, 0, 100000, None),
            ))
            settings_group("每层两段墙面", "HH_STAIR_MASTER_FLIGHT_WALLS", (
                ("下半段墙面", c4d.DTYPE_LONG, 0, 0, 3, ("外侧", "内侧", "双侧", "不生成")),
                ("上半段墙面", c4d.DTYPE_LONG, 0, 0, 3, ("外侧", "内侧", "双侧", "不生成")),
            ))
            settings_group("楼梯顶部封顶", "HH_STAIR_MASTER_ROOF", (
                ("生成顶部封顶", c4d.DTYPE_BOOL, False, 0, 1, None),
                ("顶板厚度 (cm)", c4d.DTYPE_REAL, 15.0, 0.1, 1000, None),
            ))
            for label, marker, edges in (
                    ("半层平台围栏", "HH_STAIR_MASTER_RAIL_HALF", ("左侧", "右侧", "前侧（远端）", "后侧（入口侧）")),
                    ("到层平台围栏", "HH_STAIR_MASTER_RAIL_FLOOR", ("左侧", "右侧", "前侧（走廊出口）", "后侧（入口侧）"))):
                settings_group(label, marker, tuple(
                    (edge+"围栏", c4d.DTYPE_BOOL,
                     not (marker == "HH_STAIR_MASTER_RAIL_FLOOR" and index == 2), 0, 1, None)
                    for index, edge in enumerate(edges)))
            settings_group("半层平台窗户参数", "HH_STAIR_MASTER_WINDOW", (
                ("窗户宽度 (cm)", c4d.DTYPE_REAL, 80.0, 0.01, 100000, None),
                ("窗户高度 (cm)", c4d.DTYPE_REAL, 60.0, 0.01, 100000, None),
                ("窗台高度 (cm)", c4d.DTYPE_REAL, 30.0, 0, 100000, None),
                ("窗户左右偏移 (cm)", c4d.DTYPE_REAL, 0.0, -100000, 100000, None),
                ("窗框宽度 (cm)", c4d.DTYPE_REAL, 4.0, 0.01, 100000, None),
                ("窗户样式", c4d.DTYPE_LONG, 0, 0, 1, ("双扇推拉窗", "上亮窗 + 双扇推拉窗")),
                ("上亮窗高度比例 (%)", c4d.DTYPE_REAL, 25.0, 15, 45, None),
            ))
        settings_group("墙脚踢脚线", "HH_STAIR_SKIRTING", (
            ("生成踢脚线", c4d.DTYPE_BOOL, True, 0, 1, None),
            ("踢脚线高度 (cm)", c4d.DTYPE_REAL, 10.0, 0.1, 100, None),
            ("踢脚线厚度 (cm)", c4d.DTYPE_REAL, 1.0, 0.01, 20, None),
        ))
        ids = []
        for index, (label, value) in enumerate(zip(
                ("每级高度 (cm)", "每级深度 (cm)", "楼梯宽度 (cm)"), values[:3])):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_LONG if index == 3 else c4d.DTYPE_REAL)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_MIN] = 1 if index == 3 else 0.01
            bc[c4d.DESC_MAX] = 1000 if index == 3 else 100000.0
            bc[c4d.DESC_STEP] = 1
            desc_id = gen.AddUserData(bc)
            gen[desc_id] = value
            ids.append(desc_id[1].id)
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BOOL)
        bc[c4d.DESC_NAME] = "生成末段平台"
        if floor_mode:
            bc[c4d.DESC_HIDE] = True
        desc_id = gen.AddUserData(bc)
        gen[desc_id] = False
        ids.append(desc_id[1].id)
        for label, marker in (() if floor_mode else (("添加一段楼梯", "HH_STAIR_ADD"), ("删除最后一段", "HH_STAIR_REMOVE"))):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BUTTON)
            bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_BUTTON
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_SHORT_NAME] = label
            gen.AddUserData(bc)
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
        bc[c4d.DESC_NAME] = "楼梯扶手"
        bc[c4d.DESC_TITLEBAR] = True
        rail_group = gen.AddUserData(bc)
        for label, dtype, value, minimum, maximum in (
                ("生成扶手", c4d.DTYPE_BOOL, floor_mode, 0, 1),
                ("梯段扶手侧边", c4d.DTYPE_LONG, 2, 0, 2),
                ("扶手高度 (cm)", c4d.DTYPE_REAL, 90.0, 1, 10000),
                ("主扶手直径 (cm)", c4d.DTYPE_REAL, 4.0, 0.1, 100),
                ("主立柱间隔 (台阶数)", c4d.DTYPE_LONG, 3, 1, 100),
                ("细竖杆直径 (cm)", c4d.DTYPE_REAL, 1.4, 0.1, 20),
                ("细竖杆间距 (cm)", c4d.DTYPE_REAL, 14.0, 5, 100)):
            bc = c4d.GetCustomDataTypeDefault(dtype)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_PARENTGROUP] = rail_group
            bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = minimum, maximum, 1
            if label == "梯段扶手侧边":
                cycle = c4d.BaseContainer()
                for key, text in enumerate(("左侧", "右侧", "双侧")):
                    cycle.SetString(key, text)
                bc[c4d.DESC_CYCLE] = cycle
                bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_CYCLE
            desc_id = gen.AddUserData(bc)
            gen[desc_id] = value
            ids.append(desc_id[1].id)
        settings_group("扶手样式与玻璃", "HH_STAIR_RAIL_STYLE", (
            ("扶手样式", c4d.DTYPE_LONG, 0, 0, 1, ("金属竖杆", "木扶手 + 玻璃栏板")),
            ("玻璃厚度 (cm)", c4d.DTYPE_REAL, 1.2, 0.1, 5.0, None),
            ("木扶手宽度 (cm)", c4d.DTYPE_REAL, 6.0, 1.0, 20.0, None),
            ("木扶手厚度 (cm)", c4d.DTYPE_REAL, 3.5, 0.5, 15.0, None),
        ), rail_group)
        if not floor_mode:
            self._add_stair_segment(gen, 1, values[3])
        tread_ids = []
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
        bc[c4d.DESC_NAME] = "踏面饰面板"
        bc[c4d.DESC_TITLEBAR] = True
        tread_group = gen.AddUserData(bc)
        for label, value in (("踏面板厚度 (cm，0=关闭)", 2.0),
                             ("踏面前沿出挑 (cm)", 1.0)):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_PARENTGROUP] = tread_group
            bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = 0.0, 1000.0, 0.1
            desc_id = gen.AddUserData(bc)
            gen[desc_id] = value
            tread_ids.append(desc_id[1].id)
        light_ids = []
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
        bc[c4d.DESC_NAME] = "踏面下灯带（需踏面厚度及出挑）"
        bc[c4d.DESC_TITLEBAR] = True
        light_group = gen.AddUserData(bc)
        for label, dtype, value, minimum in (
                ("生成踏面灯带", c4d.DTYPE_BOOL, False, 0),
                ("灯带宽度 (cm)", c4d.DTYPE_REAL, 0.5, 0.01),
                ("灯带距前沿内缩 (cm)", c4d.DTYPE_REAL, 0.2, 0.0),
                ("灯带左侧留边 (cm)", c4d.DTYPE_REAL, 2.0, 0.0),
                ("灯带右侧留边 (cm)", c4d.DTYPE_REAL, 2.0, 0.0)):
            bc = c4d.GetCustomDataTypeDefault(dtype)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_PARENTGROUP] = light_group
            bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = minimum, 1000.0, 0.1
            desc_id = gen.AddUserData(bc)
            gen[desc_id] = value
            light_ids.append(desc_id[1].id)
        materials, material_ids = [], []
        border_ids = []
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
        bc[c4d.DESC_NAME] = "踏步左右边带（宽度 0=关闭该侧）"
        bc[c4d.DESC_TITLEBAR] = True
        border_group = gen.AddUserData(bc)
        for label in ("左侧边带宽度 (cm)", "右侧边带宽度 (cm)"):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
            bc[c4d.DESC_NAME] = label
            bc[c4d.DESC_PARENTGROUP] = border_group
            bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = 0.0, 10000.0, 0.1
            desc_id = gen.AddUserData(bc)
            gen[desc_id] = 10.0
            border_ids.append(desc_id[1].id)
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
        bc[c4d.DESC_NAME] = "楼梯材质"
        bc[c4d.DESC_TITLEBAR] = True
        material_group = gen.AddUserData(bc)
        for label, color in (("扶手栏杆", (0.55, 0.58, 0.60)),
                             ("台阶踏面与正面", (0.35, 0.35, 0.35)),
                             ("楼梯侧面与底面", (0.8, 0.8, 0.8)),
                             ("踏面灯带", (1.0, 0.85, 0.6)),
                             ("踏步左右边带", (0.06, 0.06, 0.06)),
                             ("楼梯墙面", (0.85, 0.85, 0.82)),
                             ("平台窗框", (0.82, 0.84, 0.86)),
                             ("平台窗玻璃", (0.8, 0.92, 0.96)),
                             ("窗户密封条与五金", (0.035, 0.04, 0.045)),
                             ("墙脚踢脚线", (0.09, 0.09, 0.09)),
                             ("扶手木饰面", (0.28, 0.12, 0.055)),
                             ("扶手玻璃", (0.72, 0.88, 0.85))):
            mat = c4d.BaseMaterial(c4d.Mmaterial)
            mat.SetName("花花楼梯 - " + label)
            mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(*color)
            if label in ("平台窗玻璃", "扶手玻璃"):
                mat[c4d.MATERIAL_USE_TRANSPARENCY] = True
                mat[c4d.MATERIAL_TRANSPARENCY_BRIGHTNESS] = 0.95
            if label == "踏面灯带":
                mat[c4d.MATERIAL_USE_LUMINANCE] = True
                mat[c4d.MATERIAL_LUMINANCE_COLOR] = c4d.Vector(*color)
                mat[c4d.MATERIAL_LUMINANCE_BRIGHTNESS] = 2.0
            mat.Message(c4d.MSG_UPDATE)
            materials.append(mat)
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BASELISTLINK)
            bc[c4d.DESC_NAME] = label + "材质"
            bc[c4d.DESC_PARENTGROUP] = material_group
            desc_id = gen.AddUserData(bc)
            gen[desc_id] = mat
            material_ids.append(desc_id[1].id)
        # Store the generator code in the scene so saved stairs remain editable.
        gen[c4d.OPYTHON_CODE] = '''import c4d
import math

PARAM_IDS = %r
MATERIAL_IDS = %r
TREAD_IDS = %r
LIGHT_IDS = %r
BORDER_IDS = %r
# HH_STAIR_SEGMENTS_V5
# HH_STAIR_WALLS_V1
# HH_STAIR_WINDOWS_V1
# HH_STAIR_WINDOW_STYLES_V1

def settings(marker):
    entries = list(op.GetUserDataContainer())
    group = next((key for key, bc in entries if bc[c4d.DESC_SHORT_NAME] == marker), None)
    return [op[key] for key, bc in entries if group is not None and bc[c4d.DESC_PARENTGROUP] == group]

def message(mid, data):
    # Only mutate scene parameters from a main-thread button command, never main().
    if mid != c4d.MSG_DESCRIPTION_COMMAND or not isinstance(data, dict):
        return True
    if not c4d.threading.GeIsMainThread():
        return True
    sender = data.get("id")
    entries = list(op.GetUserDataContainer())
    marker = next((bc[c4d.DESC_SHORT_NAME] for key, bc in entries if key == sender), None)
    if marker not in ("添加一段楼梯", "删除最后一段"):
        return True
    master = settings("HH_STAIR_FLOOR_MASTER")
    if settings("HH_STAIR_FLOOR_MASTER_V2") or (master and master[0]):
        c4d.gui.MessageDialog("当前为楼层总控模式，请调整生成层数；手动分段模式可添加或删除梯段。")
        return True
    groups = [(key, bc) for key, bc in entries if bc[c4d.DESC_SHORT_NAME] == "HH_STAIR_SEGMENT_V2"]
    remove = marker == "删除最后一段"
    if not groups or (remove and len(groups) <= 1) or (not remove and len(groups) >= 100):
        c4d.gui.MessageDialog("楼梯支持 1-100 段，至少保留一段。")
        return True
    doc = op.GetDocument()
    if doc is None:
        return True
    last, group_bc = groups[-1]
    children = [(key, bc) for key, bc in entries if bc[c4d.DESC_PARENTGROUP] == last]
    doc.StartUndo()
    try:
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, op)
        if remove:
            for key, bc in reversed(children):
                op.RemoveUserData(key)
            op.RemoveUserData(last)
        else:
            # Copy the last segment's parameter definitions and values, not its geometry.
            group_bc = c4d.BaseContainer(group_bc)
            group_bc[c4d.DESC_NAME] = "第 " + str(len(groups) + 1) + " 段楼梯"
            group = op.AddUserData(group_bc)
            for key, bc in children:
                value = op[key]
                bc = c4d.BaseContainer(bc)
                bc[c4d.DESC_PARENTGROUP] = group
                op[op.AddUserData(bc)] = value
        op.SetDirty(c4d.DIRTYFLAGS_DATA)
        op.Message(c4d.MSG_UPDATE)
    finally:
        doc.EndUndo()
    c4d.EventAdd()
    return True

def apply_material(obj, slot, restriction=""):
    mat = op[c4d.ID_USERDATA, MATERIAL_IDS[slot]]
    if mat is None:
        return
    tag = c4d.TextureTag()
    tag.SetMaterial(mat)
    tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_CUBIC
    tag[c4d.TEXTURETAG_RESTRICTION] = restriction
    obj.InsertTag(tag, obj.GetLastTag())

def surface_mesh(faces, name, finish_slot=1):
    points, polygons, finish = [], [], []
    lookup = {}
    for vertices, is_finish in faces:
        ids = []
        for vertex in vertices:
            key = tuple(vertex)
            if key not in lookup:
                lookup[key] = len(points)
                points.append(c4d.Vector(*key))
            ids.append(lookup[key])
        if len(set(ids)) < 3:
            continue
        if (points[ids[1]]-points[ids[0]]).Cross(points[ids[2]]-points[ids[0]]).GetLength() < 1e-12:
            continue
        if is_finish:
            finish.append(len(polygons))
        polygons.append(c4d.CPolygon(*ids))
    obj = c4d.PolygonObject(len(points), len(polygons))
    obj.SetName(name)
    obj.SetAllPoints(points)
    for i, polygon in enumerate(polygons):
        obj.SetPolygon(i, polygon)
    selection = c4d.BaseTag(c4d.Tpolygonselection)
    selection.SetName("HH_Stair_Finish")
    for i in finish:
        selection.GetBaseSelect().Select(i)
    obj.InsertTag(selection)
    apply_material(obj, 2)
    apply_material(obj, finish_slot, "HH_Stair_Finish")
    obj.Message(c4d.MSG_UPDATE)
    return obj

def flight(h, d, w, count, bottom=0, slab=15.0, tread=0.0, nosing=0.0, lighting=None, border=(0.0, 0.0)):
    # Same stepped envelope as the extrusion, with explicit finish face selections.
    sloped = bottom == 1 and slab < count*h
    tread = min(tread, h*0.45, slab*0.5 if sloped else h*0.45)
    nosing = min(nosing, d*0.45) if tread > 0 else 0.0
    base_y = -slab if bottom == 0 else 0.0
    underside = lambda z: max(0.0, h*z/d-slab) if sloped else base_y
    faces = []
    for i in range(count):
        start, end, top = i*d, (i+1)*d, (i+1)*h-tread
        cuts = [start, end]
        clip = slab*d/h
        if sloped and start < clip < end:
            cuts.insert(1, clip)
        for a, b in zip(cuts, cuts[1:]):
            low_a, low_b = underside(a), underside(b)
            faces.append(([(0,top,a),(0,top,b),(w,top,b),(w,top,a)], True))
            faces.append(([(0,low_a,a),(w,low_a,a),(w,low_b,b),(0,low_b,b)], False))
            # Split the side at the previous tread height so adjacent bays share edges.
            prev = (base_y if i == 0 else i*h-tread) if a == start else top
            side = [(low_a,a),(prev,a),(top,a),(top,b),(low_b,b)]
            for j in range(3):
                tri = [side[-1], side[j], side[j+1]]
                faces.append(([(0,y,z) for y,z in reversed(tri)], False))
                faces.append(([(w,y,z) for y,z in tri], False))
        prev = base_y if i == 0 else i*h-tread
        faces.append(([(0,prev,start),(0,top,start),(w,top,start),(w,prev,start)], True))
    z, top = count*d, count*h-tread
    faces.append(([(0,underside(z),z),(w,underside(z),z),(w,top,z),(0,top,z)], False))
    # Separate closed strips, not coplanar overlays; keep a usable central region.
    left, right = (min(value, w*0.45) for value in border)
    zones = [(a, b, slot, label) for a,b,slot,label in (
        (0.0, left, 4, "左侧边带"),
        (left, w-right, 1, "中间踏步"),
        (w-right, w, 4, "右侧边带")) if b-a > 0.000001]
    group = c4d.BaseObject(c4d.Onull)
    group.SetName("楼梯实体与踏面板")
    for a,b,slot,label in zones:
        zone_faces = [([(a+x/w*(b-a), y, z) for x,y,z in vertices], finish)
                      for vertices,finish in faces]
        body = surface_mesh(zone_faces, label + "结构", slot)
        if tread <= 0 and len(zones) == 1:
            return body
        body.InsertUnderLast(group)
    if tread <= 0:
        return group
    for i in range(count):
        for a,b,slot,label in zones:
            plate = box_mesh(b-a, tread, d+nosing, True, slot)
            plate.SetName(label + "踏面板 " + str(i+1))
            plate.SetRelPos(c4d.Vector((a+b)/2, (i+1)*h-tread/2, i*d+(d-nosing)/2))
            plate.InsertUnderLast(group)
        if lighting and nosing > 0.000001:
            add_tread_light(group, w, h, (i+1)*h-tread, i*d-nosing, nosing, lighting, i+1)
    return group

def add_tread_light(parent, width, rise, underside_y, front_z, overhang, settings, number):
    requested_width, setback, left_margin, right_margin = settings
    setback = min(setback, overhang*0.8)
    # Keep the strip wholly under the exposed nosing, not inside the structural riser.
    strip_width = min(requested_width, (overhang-setback)*0.95)
    if strip_width <= 0.000001:
        return
    strip_height = min(0.15, rise*0.05)
    strip_length = width-left_margin-right_margin
    if strip_length <= 0.000001:
        return
    strip = c4d.BaseObject(c4d.Ocube)
    strip.SetName("踏面灯带 " + str(number))
    strip[c4d.PRIM_CUBE_LEN] = c4d.Vector(strip_length, strip_height, strip_width)
    strip.SetRelPos(c4d.Vector(left_margin+strip_length/2, underside_y-strip_height/2, front_z+setback+strip_width/2))
    apply_material(strip, 3)
    strip.InsertUnderLast(parent)

def box_mesh(width, thickness, length, all_finish=False, finish_slot=1):
    x, y, z = width/2, thickness/2, length/2
    points = [(-x,-y,-z),(x,-y,-z),(x,-y,z),(-x,-y,z),
              (-x,y,-z),(x,y,-z),(x,y,z),(-x,y,z)]
    faces = ((4,7,6,5),(0,1,2,3),(0,4,5,1),(3,2,6,7),(0,3,7,4),(1,5,6,2))
    return surface_mesh([([points[i] for i in f], all_finish or n == 0) for n,f in enumerate(faces)], "板体", finish_slot)

def landing_mesh(width, thickness, length, tread=0.0):
    tread = min(tread, thickness*0.5)
    if tread <= 0:
        return box_mesh(width, thickness, length)
    group = c4d.BaseObject(c4d.Onull)
    group.SetName("休息平台")
    body = box_mesh(width, thickness-tread, length)
    body.SetName("平台结构")
    body.SetRelPos(c4d.Vector(0, -tread/2, 0))
    body.InsertUnderLast(group)
    plate = box_mesh(width, tread, length, True)
    plate.SetName("平台饰面板")
    plate.SetRelPos(c4d.Vector(0, (thickness-tread)/2, 0))
    plate.InsertUnderLast(group)
    return group

def tube(parent, a, b, radius, name):
    if (b-a).GetLength() > 0.000001:
        parent.append((a, b, radius, name))

def emit_post(parent, a, b, radius, name):
    delta = b - a
    length = delta.GetLength()
    if length < 0.000001:
        return
    y = delta.GetNormalized()
    reference = c4d.Vector(0, 0, 1) if abs(y.z) < 0.9 else c4d.Vector(1, 0, 0)
    x = y.Cross(reference).GetNormalized()
    z = x.Cross(y).GetNormalized()
    obj = c4d.BaseObject(c4d.Ocylinder)
    obj.SetName(name)
    obj[c4d.PRIM_CYLINDER_RADIUS] = radius
    obj[c4d.PRIM_CYLINDER_HEIGHT] = length
    obj[c4d.PRIM_CYLINDER_SEG] = 24
    phong = c4d.BaseTag(c4d.Tphong)
    if phong:
        obj.InsertTag(phong)
    obj.SetMl(c4d.Matrix((a + b) * 0.5, x, y, z))
    obj.InsertUnderLast(parent)

def rail_key(p):
    return (round(p.x, 5), round(p.y, 5), round(p.z, 5))

def wood_rail_frames(points):
    frames = []
    for i,p in enumerate(points):
        before = (p-points[i-1]).GetNormalized() if i else (points[1]-p).GetNormalized()
        after = (points[i+1]-p).GetNormalized() if i+1 < len(points) else before
        along = before+after
        along = after if along.GetLength() < .000001 else along.GetNormalized()
        # Width stays horizontal; only the top face's pitch follows the flight.
        normal = along.Cross(c4d.Vector(0,1,0))
        normal = (frames[-1][0] if frames else c4d.Vector(1,0,0)) if normal.GetLength() < .000001 else normal.GetNormalized()
        frames.append((normal,normal.Cross(along).GetNormalized()))
    return frames

def framed_wood_mesh(parent, points, frames, profile, name, material):
    # normal/up/along form a left-handed basis; reverse the profile for outward faces.
    rings = [[p+n*x+u*y for x,y in reversed(profile)] for p,(n,u) in zip(points,frames)]
    faces = []
    def coords(vertices): return [(v.x,v.y,v.z) for v in vertices]
    for a,b in zip(rings,rings[1:]):
        for i in range(len(profile)):
            j = (i+1) %% len(profile)
            faces.append((coords([a[i],a[j],b[j],b[i]]),True))
    for ring,reverse in ((rings[0],True),(rings[-1],False)):
        center = c4d.Vector(0)
        for v in ring: center += v*(1.0/len(ring))
        for i in range(len(profile)):
            tri = [center,ring[i],ring[(i+1) %% len(profile)]]
            faces.append((coords(list(reversed(tri)) if reverse else tri),True))
    obj = surface_mesh(faces,name,material)
    obj.InsertTag(c4d.BaseTag(c4d.Tphong),obj.GetLastTag())
    obj.InsertUnderLast(parent)
    return obj

def wood_rail_sample(points, frames, distance):
    cursor = 0.0
    for i,(a,b) in enumerate(zip(points,points[1:])):
        length = (b-a).GetLength()
        if distance <= cursor+length or i == len(points)-2:
            t = max(0.0,min(1.0,(distance-cursor)/max(length,.000001)))
            n,u = frames[i];nn,uu = frames[i+1]
            return a+(b-a)*t,(n*(1-t)+nn*t,u*(1-t)+uu*t)
        cursor += length

def rounded_wood_path(points, wood, radius):
    # Keep turns in plan, with a separate smooth elevation curve. Collapsing a
    # tight U-turn to one 3D corner creates a vertical loop and rolls the profile.
    def flat(v): return c4d.Vector(v.x,0,v.z)
    clean = [points[0]]
    for p in points[1:]:
        if (p-clean[-1]).GetLength() > .000001:
            clean.append(p)
    extent = math.hypot(wood[0],wood[1])/2
    changed = True
    while changed and len(clean) > 2:
        changed = False
        for i in range(1,len(clean)-1):
            a,b = clean[i]-clean[i-1],clean[i+1]-clean[i]
            u,v = a.GetNormalized(),b.GetNormalized()
            straight_plan = (flat(a).GetNormalized()-flat(b).GetNormalized()).GetLength() < .00001
            if (u-v).GetLength() < .00001 or (straight_plan and min(a.GetLength(),b.GetLength()) < extent*4):
                del clean[i]; changed = True; break
    # A short cross-flight connector needs room for two full-width elbows.
    # Expand only this local connector; never collapse its two plan corners.
    for _ in range(3):
        for i in range(1,len(clean)-2):
            edge = flat(clean[i+1]-clean[i])
            length = edge.GetLength()
            if length < .000001 or length >= extent*4.2: continue
            direction = edge/length
            before = flat(clean[i]-clean[i-1]).GetNormalized()
            after = flat(clean[i+2]-clean[i+1]).GetNormalized()
            if min((before-direction).GetLength(),(after-direction).GetLength()) < .1: continue
            adjustment = direction*((extent*4.2-length)/2)
            clean[i] = clean[i]-adjustment
            clean[i+1] = clean[i+1]+adjustment
    rounded = [clean[0]]
    for i in range(1,len(clean)-1):
        a,p,b = clean[i-1:i+2]
        incoming,outgoing = p-a,b-p
        in_plan,out_plan = flat(incoming),flat(outgoing)
        in_length,out_length = in_plan.GetLength(),out_plan.GetLength()
        if min(in_length,out_length) > .000001:
            pu,pv = in_plan/in_length,out_plan/out_length
            plan_angle = math.acos(max(-1.0,min(1.0,pu.Dot(pv))))
            axis = pu.Cross(pv)
            if axis.GetLength() > .000001:
                tangent = math.tan(plan_angle/2)
                trim = min(max(radius*2.5,extent*1.75*tangent),in_length*.45,out_length*.45)
                bend_radius = trim/tangent
                start = p-pu*trim
                turn = axis.GetNormalized().Cross(pu)
                m0,m1 = incoming.y/in_length,outgoing.y/out_length
                y0,y1 = p.y-m0*trim,p.y+m1*trim
                arc = bend_radius*plan_angle
                steps = max(18,int(math.ceil(math.degrees(plan_angle)/4)))
                for j in range(steps+1):
                    t = j/float(steps)
                    q = start+(pu*math.sin(plan_angle*t)+turn*(1-math.cos(plan_angle*t)))*bend_radius
                    q.y = (2*t**3-3*t*t+1)*y0+(t**3-2*t*t+t)*arc*m0+(-2*t**3+3*t*t)*y1+(t**3-t*t)*arc*m1
                    rounded.append(q)
                continue
        u,v = incoming.GetNormalized(),outgoing.GetNormalized()
        angle = math.acos(max(-1.0,min(1.0,u.Dot(v))))
        axis = u.Cross(v)
        if axis.GetLength() < .000001:
            rounded.append(p); continue
        turn = axis.GetNormalized().Cross(u)
        tangent = math.tan(angle/2)
        trim = min(max(radius*2.5,extent*1.75*tangent),
                   incoming.GetLength()*.45,outgoing.GetLength()*.45)
        bend_radius = trim/tangent
        start = p-u*trim
        rounded.append(start)
        steps = max(12,int(math.ceil(math.degrees(angle)/5)))
        for j in range(1,steps+1):
            t = angle*j/steps
            rounded.append(start+(u*math.sin(t)+turn*(1-math.cos(t)))*bend_radius)
    rounded.append(clean[-1])
    return rounded

def continuous_pipe(parent, points, radius, name, wood=None):
    # Trim each corner and sample one continuous rounded centerline.
    rounded = [points[0]]
    for i in range(1, len(points)-1):
        a, p, b = points[i-1:i+2]
        incoming, outgoing = p-a, b-p
        if min(incoming.GetLength(), outgoing.GetLength()) < 0.000001:
            continue
        u, v = incoming.GetNormalized(), outgoing.GetNormalized()
        if (u-v).GetLength() < 0.00001:
            continue
        trim = min(radius*2.5, incoming.GetLength()*0.4, outgoing.GetLength()*0.4)
        start, end = p-u*trim, p+v*trim
        rounded.append(start)
        for j in range(1, 13):
            t = j/12.0
            rounded.append(start*((1-t)*(1-t)) + p*(2*t*(1-t)) + end*(t*t))
    rounded.append(points[-1])
    if wood:
        rounded = rounded_wood_path(points,wood,radius)
    path = c4d.SplineObject(len(rounded), c4d.SPLINETYPE_LINEAR)
    path.SetAllPoints(rounded)
    path.Message(c4d.MSG_UPDATE)
    profile = c4d.BaseObject(c4d.Osplinecircle)
    profile[c4d.PRIM_CIRCLE_RADIUS] = radius
    if wood:
        width, height = wood
        corner = min(width,height)*0.22
        vertices = []
        for cx,cy,start in ((width/2-corner,height/2-corner,0),
                            (-width/2+corner,height/2-corner,90),
                            (-width/2+corner,-height/2+corner,180),
                            (width/2-corner,-height/2+corner,270)):
            for j in range(7):
                angle = math.radians(start+j*15)
                vertices.append(c4d.Vector(cx+corner*math.cos(angle),cy+corner*math.sin(angle),0))
        # Explicit upright frames are shared with the saddles. A Sweep may roll
        # a rectangular profile on a 3D corner, exposing otherwise aligned seats.
        framed_wood_mesh(parent,rounded,wood_rail_frames(rounded),
                         [(v.x,v.y) for v in vertices],name,10)
        return rounded
    sweep = c4d.BaseObject(c4d.Osweep)
    sweep.SetName(name)
    phong = c4d.BaseTag(c4d.Tphong)
    if phong:
        sweep.InsertTag(phong)
    profile.InsertUnderLast(sweep)
    path.InsertUnderLast(sweep)
    sweep.InsertUnderLast(parent)
    return rounded

def infill_between_posts(a, b, radius, height, spacing, supports):
    delta = b-a
    length = math.hypot(delta.x, delta.z)
    if length < 0.000001:
        return []
    ux, uz = delta.x/length, delta.z/length
    low, high = c4d.Vector(0, height*0.22, 0), c4d.Vector(0, height*0.9, 0)
    blocked = []
    for base, top, post_radius, _ in supports:
        distance = (base.x-a.x)*ux + (base.z-a.z)*uz
        perpendicular = abs((base.x-a.x)*uz - (base.z-a.z)*ux)
        p = a + delta*(distance/length)
        if perpendicular >= post_radius+radius+0.3 or top.y <= p.y+low.y or base.y >= p.y+high.y:
            continue
        start, end = max(0.0, distance-post_radius), min(length, distance+post_radius)
        if start < end:
            blocked.append((start, end))
    # Main posts define the bays. Equalize clear gaps, including both end gaps.
    bays, cursor = [], 0.0
    for start, end in sorted(blocked):
        if start > cursor:
            bays.append((cursor, start))
        cursor = max(cursor, end)
    if cursor < length:
        bays.append((cursor, length))
    diameter = radius*2
    spacing = max(spacing, diameter+0.6, (length+diameter)/200.0)
    result = []
    for start, end in bays:
        clear = end-start
        count = max(0, min(199-len(result), int(math.ceil((clear+diameter)/spacing))-1))
        count = min(count, max(0, int((clear-0.6)/(diameter+0.6))))
        gap = (clear-count*diameter)/(count+1)
        for i in range(count):
            distance = start + gap + radius + i*(diameter+gap)
            p = a + delta*(distance/length)
            result.append((p+low, p+high, radius, "细竖杆"))
    return result

def glass_railing_infill(parent, a, b, height, thickness, supports, wood_height):
    delta = b-a
    length = math.hypot(delta.x,delta.z)
    if length < 12.0:
        return
    tangent = c4d.Vector(delta.x/length,0,delta.z/length)
    normal = tangent.Cross(c4d.Vector(0,1,0))
    blocked = []
    for base,top,r,_ in supports:
        t = (base-a).Dot(tangent)
        q = a+delta*(t/length)
        if abs((base-a).Dot(normal)) < r+0.5 and top.y > q.y+height*.22 and base.y < q.y+height:
            blocked.append((max(0.0,t-r),min(length,t+r)))
    bays, cursor = [],0.0
    for lo,hi in sorted(blocked):
        if hi <= lo: continue
        if lo > cursor: bays.append((cursor,lo))
        cursor = max(cursor,hi)
    if cursor < length: bays.append((cursor,length))
    low,high = height*.22,height-max(10.0,wood_height+4.0)
    if high-low < 8.0: return
    for lo,hi in bays:
        lo,hi = lo+1.2,hi-1.2
        if hi-lo < 8.0: continue
        p,q = a+delta*(lo/length),a+delta*(hi/length)
        rim = normal*(thickness/2)
        up = c4d.Vector(0,1,0)
        points = [p+up*low-rim,q+up*low-rim,q+up*high-rim,p+up*high-rim,
                  p+up*low+rim,q+up*low+rim,q+up*high+rim,p+up*high+rim]
        faces = ((0,3,2,1),(4,5,6,7),(0,1,5,4),(3,7,6,2),(0,4,7,3),(1,2,6,5))
        glass = surface_mesh([([(points[i].x,points[i].y,points[i].z) for i in face],True) for face in faces],"扶手夹胶玻璃",11)
        glass.InsertUnderLast(parent)
        # Two padded clamps at each supported edge, overlapping the glass rim
        # and the adjacent post so they cannot float in the clear opening.
        for t,sign in ((lo,-1),(hi,1)):
            edge = a+delta*(t/length)
            candidates = [(abs((base-edge).Dot(tangent)),base,r) for base,top,r,_ in supports
                          if abs((base-edge).Dot(normal)) < r+0.5 and
                          (base-edge).Dot(tangent)*sign > 0 and
                          top.y > edge.y+low and base.y < edge.y+high]
            if not candidates: continue
            distance,base,r = min(candidates,key=lambda item:item[0])
            if distance > r+3: continue
            for y in (low+min(8.0,(high-low)*.2),high-min(8.0,(high-low)*.2)):
                for side in (-1,1):
                    clamp = c4d.BaseObject(c4d.Onull)
                    clamp.SetName("玻璃夹具")
                    center = edge+tangent*(sign*(distance-1.2)/2)+up*y+normal*(side*(thickness/2+.25))
                    clamp.SetMl(c4d.Matrix(center,tangent,up,normal))
                    clamp.InsertUnderLast(parent)
                    half = (distance+1.2)/2
                    window_bar(clamp,"倒角夹片",-half,half,-1.5,1.5,-.25,.25,0)
                    window_bar(clamp,"玻璃防滑垫",-half,half,-1.25,1.25,
                               -.32 if side == 1 else .23,-.23 if side == 1 else .32,8)
                    emit_post(clamp,c4d.Vector(sign*distance*.2,0,side*.20),
                              c4d.Vector(sign*distance*.2,0,side*.38),.28,"夹具螺帽")

def glass_railing_post(parent, a, b, radius, wood, paths):
    up = c4d.Vector(0,1,0)
    tangent = c4d.Vector(1,0,0)
    slope = tangent
    best = float("inf")
    # Match the actual rounded handrail, including corner fillets, rather than
    # terminating a flat-topped post at the untrimmed rail centreline.
    for path in paths:
        cursor = 0.0
        for p,q in zip(path,path[1:]):
            delta = q-p
            horizontal = c4d.Vector(delta.x,0,delta.z)
            length = horizontal.GetLength()
            if length < .000001:
                cursor += delta.GetLength()
                continue
            direction = horizontal/length
            t = max(0.0,min(length,(b-p).Dot(direction)))
            target = p+delta*(t/length)
            distance = (b-target).GetLength()
            if distance < best:
                best,tangent,slope,contact = distance,direction,delta.GetNormalized(),target
                seat_path,seat_distance = path,cursor+delta.GetLength()*t/length
            cursor += delta.GetLength()
    if best == float("inf"): return
    frames = wood_rail_frames(seat_path)
    contact,(seat_normal,saddle_up) = wood_rail_sample(seat_path,frames,seat_distance)
    underside = 1.0 if saddle_up.y >= 0 else -1.0
    saddle_up = saddle_up*underside
    normal = tangent.Cross(up)
    saddle = contact-saddle_up*(wood[1]/2+.18)
    width = radius*2
    length = max(.1,saddle.y-a.y-4.0)
    assembly = c4d.BaseObject(c4d.Onull)
    assembly.SetName("木饰金属立柱")
    assembly.SetMl(c4d.Matrix(a,tangent,up,normal))
    assembly.InsertUnderLast(parent)
    for name,w,h,d,pos,slot in (
            ("金属立柱",width,length,width,c4d.Vector(0,length/2,0),0),
            ("木饰嵌条",width*.65,max(.01,length-3),.16,c4d.Vector(0,length/2,width/2),10),
            ("立柱底座",width*1.7,.6,width*1.7,c4d.Vector(0,.3,0),0)):
        window_bar(assembly,name,pos.x-w/2,pos.x+w/2,pos.y-h/2,pos.y+h/2,pos.z-d/2,pos.z+d/2,slot)
    stem_start = a+up*(length-.2)
    stem_end = saddle-saddle_up*.1
    emit_post(parent,stem_start,stem_end,min(radius*.4,.75),"扶手连接颈")
    seat = c4d.BaseObject(c4d.Onull)
    seat.SetName("随坡扶手托座")
    seat.InsertUnderLast(parent)
    # Keep a short curved pad within the flat central underside of the wood.
    total = sum((q-p).GetLength() for p,q in zip(seat_path,seat_path[1:]))
    half = min(width*.4,wood[0]*.2,1.2)
    start,stop = max(0.0,seat_distance-half),min(total,seat_distance+half)
    # At a near-vertical return, stop the pad before its underside turns upward.
    cursor = 0.0
    for i,(p,q) in enumerate(zip(seat_path,seat_path[1:])):
        length = (q-p).GetLength()
        y0,y1 = frames[i][1].y*underside,frames[i+1][1].y*underside
        if y0*y1 < 0:
            crossing = cursor+length*y0/(y0-y1)
            if crossing < seat_distance:
                start = max(start,crossing)
            else:
                stop = min(stop,crossing)
        cursor += length
    samples = [start];cursor = 0.0
    for p,q in zip(seat_path,seat_path[1:]):
        cursor += (q-p).GetLength()
        if start < cursor < stop: samples.append(cursor)
    samples.append(stop)
    records = [wood_rail_sample(seat_path,frames,t) for t in samples]
    records = [(p,(n*underside,u*underside)) for p,(n,u) in records]
    half_width = wood[0]*.24
    y0,y1 = -wood[1]/2-.38,-wood[1]/2+.02
    bevel = min(.06,half_width*.15)
    profile = [(-half_width+bevel,y0),(half_width-bevel,y0),(half_width,y0+bevel),
               (half_width,y1-bevel),(half_width-bevel,y1),(-half_width+bevel,y1),
               (-half_width,y1-bevel),(-half_width,y0+bevel)]
    framed_wood_mesh(seat,[p for p,f in records],[f for p,f in records],profile,"弧形内收托板",0)

def build_rails(root, pending):
    style = settings("HH_STAIR_RAIL_STYLE") or [0,1.2,6.0,3.5]
    glass_style = style[0] == 1
    group = c4d.BaseObject(c4d.Onull)
    group.SetName("连续扶手与栏杆")
    apply_material(group, 0)
    group.InsertUnderLast(root)
    posts, infills, horizontal = [], [], []
    for item in pending:
        if item[3] in ("梯段立柱", "平台立柱"):
            posts.append(item)
        elif item[3] == "栏杆填充区":
            infills.append(item)
        else:
            horizontal.append(item)
    def clashes(item, other):
        a, b, r, _ = item
        c, d, s, _ = other
        overlap = min(b.y, d.y) - max(a.y, c.y)
        return overlap > 0 and math.hypot(a.x-c.x, a.z-c.z) < r+s+0.3
    kept = []
    for item in sorted(posts, key=lambda p: -(p[1]-p[0]).GetLength()):
        if not any(clashes(item, other) for other in kept):
            kept.append(item)
    end_returns = {}
    wood_paths = []
    batches = {}
    for a, b, radius, name in horizontal:
        if glass_style and name != "主扶手":
            continue
        batches.setdefault((radius, name), []).append((a, b))
    for (radius, name), lines in batches.items():
        vertices, neighbors, edges = {}, {}, set()
        for a, b in lines:
            ka, kb = rail_key(a), rail_key(b)
            if ka == kb: continue
            vertices[ka], vertices[kb] = a, b
            edge = tuple(sorted((ka, kb)))
            if edge in edges: continue
            edges.add(edge)
            neighbors.setdefault(ka, set()).add(kb)
            neighbors.setdefault(kb, set()).add(ka)
        unused = set(edges)
        while unused:
            edge = next(iter(unused))
            start = next((k for k in edge if len(neighbors[k]) != 2), edge[0])
            # Find an endpoint of this chain before walking it.
            previous, current = None, start
            visited = set()
            while len(neighbors[current]) == 2 and current not in visited:
                visited.add(current)
                nxt = next(k for k in neighbors[current] if k != previous)
                previous, current = current, nxt
            start = current
            keys, current = [start], start
            while True:
                choices = [k for k in neighbors[current] if tuple(sorted((current, k))) in unused]
                if not choices: break
                nxt = choices[0]
                unused.remove(tuple(sorted((current, nxt))))
                keys.append(nxt)
                current = nxt
                if current == start or len(neighbors[current]) != 2: break
            if len(keys) < 2:
                unused.discard(edge)
                continue
            points = [vertices[k] for k in keys]
            returned = {}
            # Free ends stop at the nearest supporting post, not beyond it.
            for idx, adjacent in ((0, 1), (-1, -2)):
                if len(neighbors[keys[idx]]) != 1: continue
                p, q = points[idx], points[adjacent]
                delta = q-p
                horizontal_len = delta.x*delta.x + delta.z*delta.z
                if horizontal_len < 0.000001: continue
                candidates = []
                for post_index, (a, b, r, label) in enumerate(kept):
                    t = ((a.x-p.x)*delta.x+(a.z-p.z)*delta.z)/horizontal_len
                    target = p+delta*t
                    if 0 <= t < 0.45 and (target-p).GetLength() <= max(10.0, radius*5) and math.hypot(target.x-a.x, target.z-a.z) < 0.05 and a.y <= target.y <= b.y+radius:
                        if name != "主扶手" or abs(target.y-b.y) < 0.05:
                            candidates.append(((target-p).GetLength(), target, post_index))
                if candidates:
                    _, points[idx], post_index = min(candidates, key=lambda v:v[0])
                    if glass_style:
                        # Extend beyond the full post width instead of ending
                        # halfway across a post at a sloping exposed end cap.
                        direction = (points[adjacent]-points[idx]).GetNormalized()
                        horizontal = math.hypot(direction.x,direction.z)
                        extension = (kept[post_index][2]+.8)/max(horizontal,.1)
                        points[idx] = points[idx]-direction*extension
                    if name == "主扶手" and not glass_style:
                        # One constant-diameter sweep replaces the entire end post.
                        # This avoids a visible thick sleeve over a thinner cylinder.
                        base = kept[post_index][0]
                        returned[idx] = c4d.Vector(points[idx].x, base.y, points[idx].z)
                        end_returns[post_index] = radius
            if 0 in returned:
                points.insert(0, returned[0])
            if -1 in returned:
                points.append(returned[-1])
            path = continuous_pipe(group, points, radius, name,style[2:4] if glass_style else None)
            if glass_style: wood_paths.append(path)
    supports = [(a, b, end_returns.get(i, radius), name)
                for i, (a, b, radius, name) in enumerate(kept)]
    if glass_style:
        for a,b,_,_,height,_ in infills:
            glass_railing_infill(group,a,b,height,style[1],supports,style[3])
        for a,b,r,_ in supports:
            glass_railing_post(group,a,b,r,style[2:4],wood_paths)
        return
    bars = []
    for a, b, radius, _, height, spacing in infills:
        bars.extend(infill_between_posts(a, b, radius, height, spacing, supports))
    fine = []
    for item in bars:
        if not any(clashes(item, other) for other in supports+fine):
            fine.append(item)
            emit_post(group, *item)
    for i, item in enumerate(kept):
        if i not in end_returns:
            emit_post(group, *item)

def railing_panel(parent, a, b, height, radius, bar_radius, bar_spacing):
    if (b-a).GetLength() < 0.000001:
        return
    # Slim vertical infill between two rails; the handrail sits slightly above.
    low = c4d.Vector(0, height * 0.22, 0)
    high = c4d.Vector(0, height * 0.9, 0)
    top = c4d.Vector(0, height, 0)
    tube(parent, a + top, b + top, radius, "主扶手")
    tube(parent, a + high, b + high, radius * 0.55, "上横杆")
    tube(parent, a + low, b + low, radius * 0.55, "下横杆")
    # Defer infill until deduplicated main posts and terminal diameters are known.
    parent.append((a, b, bar_radius, "栏杆填充区", height, bar_spacing))

def railing_edge(parent, a, b, height, radius, spacing, bar_radius, bar_spacing):
    up = c4d.Vector(0, height, 0)
    railing_panel(parent, a, b, height, radius, bar_radius, bar_spacing)
    divisions = max(1, min(200, int(math.ceil((b-a).GetLength() / spacing))))
    for i in range(divisions + 1):
        p = a + (b-a) * (float(i) / divisions)
        tube(parent, p - c4d.Vector(0, 0.2, 0), p + up, radius * 0.75, "平台立柱")

def stair_wall(parent, origin, right, forward, x0, x1, z0, z1, floor, top0, top1, name, material=5, floor_end=None):
    floor_end = floor if floor_end is None else floor_end
    if x1-x0 <= 0.000001 or z1-z0 <= 0.000001 or min(top0-floor,top1-floor_end) <= 0.000001:
        return
    vertices = [(x0,floor,z0),(x1,floor,z0),(x1,floor_end,z1),(x0,floor_end,z1),
                (x0,top0,z0),(x1,top0,z0),(x1,top1,z1),(x0,top1,z1)]
    faces = ((4,7,6,5),(0,1,2,3),(0,4,5,1),(3,2,6,7),(0,3,7,4),(1,5,6,2))
    obj = surface_mesh([([vertices[i] for i in face], True) for face in faces], name, material)
    obj.SetMl(c4d.Matrix(origin, right, c4d.Vector(0,1,0), forward))
    obj.InsertUnderLast(parent)

def window_profile(parent, name, l, r, low, high, front, back, rim, material=6):
    # Closed mitred ring with small bevels on both outer and glazing edges.
    if min(r-l, high-low, back-front) <= 0.000001:
        return
    rim = min(rim, (r-l)*0.22, (high-low)*0.22)
    bevel = min(0.12, rim*0.12, (back-front)*0.12)
    def rectangle(a,b,c,d,z):
        return [(a,c,z),(b,c,z),(b,d,z),(a,d,z)]
    rings = [rectangle(l+bevel,r-bevel,low+bevel,high-bevel,front),
             rectangle(l,r,low,high,front+bevel),
             rectangle(l,r,low,high,back-bevel),
             rectangle(l+bevel,r-bevel,low+bevel,high-bevel,back),
             rectangle(l+rim-bevel,r-rim+bevel,low+rim-bevel,high-rim+bevel,back),
             rectangle(l+rim,r-rim,low+rim,high-rim,back-bevel),
             rectangle(l+rim,r-rim,low+rim,high-rim,front+bevel),
             rectangle(l+rim-bevel,r-rim+bevel,low+rim-bevel,high-rim+bevel,front)]
    faces = []
    for i, ring in enumerate(rings):
        following = rings[(i+1) %% len(rings)]
        for j in range(4):
            k = (j+1) %% 4
            faces.append(([ring[j],ring[k],following[k],following[j]],True))
    obj = surface_mesh(faces,name,material)
    obj.InsertUnderLast(parent)

def window_bar(parent, name, l, r, low, high, front, back, material=6):
    # Bevelled solid profile for rails, sill and recessed handle hardware.
    if min(r-l,high-low,back-front) <= 0.000001:
        return
    bevel = min(0.1, (r-l)*0.12, (high-low)*0.12, (back-front)*0.12)
    def loop(inset,z):
        a,b,c,d = l+inset,r-inset,low+inset,high-inset
        corner = bevel*0.5
        return [(a+corner,c,z),(b-corner,c,z),(b,c+corner,z),(b,d-corner,z),
                (b-corner,d,z),(a+corner,d,z),(a,d-corner,z),(a,c+corner,z)]
    rings = [loop(bevel,front),loop(0,front+bevel),loop(0,back-bevel),loop(bevel,back)]
    faces = []
    for ring, following in zip(rings,rings[1:]):
        for j in range(8):
            k = (j+1) %% 8
            faces.append(([ring[j],ring[k],following[k],following[j]],True))
    for ring,reverse in ((rings[0],True),(rings[-1],False)):
        center = ((l+r)/2,(low+high)/2,ring[0][2])
        for j in range(8):
            tri = [center,ring[j],ring[(j+1) %% 8]]
            faces.append((list(reversed(tri)) if reverse else tri,True))
    obj = surface_mesh(faces,name,material)
    obj.InsertUnderLast(parent)

def detailed_window(parent, origin, right, forward, a, b, sill, upper, z0, z1, frame, style, ratio, name):
    assembly = c4d.BaseObject(c4d.Onull)
    assembly.SetName(name + (" 上亮推拉窗" if style == 1 else " 双扇推拉窗"))
    assembly.SetMl(c4d.Matrix(origin,right,c4d.Vector(0,1,0),forward))
    assembly.InsertUnderLast(parent)
    width,height = b-a,upper-sill
    frame = min(frame,width*0.12,height*0.12)
    depth = min(10.0,z1-z0)
    mid = (z0+z1)/2
    front,back = mid-depth/2,mid+depth/2
    window_profile(assembly,"外框型材",a,b,sill,upper,front,back,frame)
    # A thin raised perimeter lip and inner reveal give the frame a stepped section.
    lip = frame*0.3
    window_profile(assembly,"室内框口压边",a,b,sill,upper,front-depth*0.04,front+depth*0.1,lip)
    window_profile(assembly,"室外框口压边",a,b,sill,upper,back-depth*0.1,back+depth*0.04,lip)
    l,r,low,high = a+frame,b-frame,sill+frame,upper-frame
    sash_rim = min(frame*0.65,(r-l)*0.08,(high-low)*0.08)
    def glazing(left,right,bottom,top,zc,bead):
        seal = bead*0.35
        window_profile(assembly,"玻璃密封胶条",left,right,bottom,top,zc-depth*.025,zc+depth*.025,seal,8)
        # Leave the clear opening inside the seal; the pane has real thickness.
        obj = box_mesh(right-left-2*seal,top-bottom-2*seal,depth*.035,True,7)
        obj.SetName("玻璃")
        obj.SetRelPos(c4d.Vector((left+right)/2,(bottom+top)/2,zc))
        obj.InsertUnderLast(assembly)
    if style == 1:
        divider = high-(high-low)*min(.45,max(.15,ratio/100.0))
        bar = min(frame*.7,(high-low)*.06)
        window_bar(assembly,"上亮窗横梁",l,r,divider-bar/2,divider+bar/2,front,back)
        transom_low = divider+bar/2
        window_profile(assembly,"上亮窗固定压条",l,r,transom_low,high,mid-depth*.18,mid+depth*.18,sash_rim)
        glazing(l+sash_rim,r-sash_rim,transom_low+sash_rim,high-sash_rim,mid,sash_rim)
        high = divider-bar/2
    sash_rim = min(sash_rim,(high-low)*.12)
    clearance = min(frame*.07,(high-low)*.015)
    sash_low,sash_high = low+clearance,high-clearance
    center = (l+r)/2
    overlap = sash_rim*.6
    for index,(left,right,zc) in enumerate(((l+clearance,center+overlap,mid-depth*.23),
                                           (center-overlap,r-clearance,mid+depth*.23))):
        half = depth*.18
        window_profile(assembly,("左" if index == 0 else "右")+"推拉窗扇",left,right,sash_low,sash_high,zc-half,zc+half,sash_rim)
        bead = sash_rim*.22
        window_profile(assembly,"窗扇玻璃压条",left+sash_rim*.72,right-sash_rim*.72,
                       sash_low+sash_rim*.72,sash_high-sash_rim*.72,zc-half-depth*.025,zc-half+depth*.06,bead)
        glazing(left+sash_rim,right-sash_rim,sash_low+sash_rim,sash_high-sash_rim,zc,sash_rim)
        # Recessed pull at each outer stile, away from the centre overlap.
        handle_x = left+sash_rim*.5 if index == 0 else right-sash_rim*.5
        handle_y = (sash_low+sash_high)/2
        handle_w = sash_rim*.45
        handle_h = min(12.0,(sash_high-sash_low)*.2)
        window_bar(assembly,"内嵌拉手座",handle_x-handle_w/2,handle_x+handle_w/2,
                   handle_y-handle_h/2,handle_y+handle_h/2,zc-half-depth*.045,zc-half,8)
        window_bar(assembly,"拉手拨片",handle_x-handle_w*.12,handle_x+handle_w*.12,
                   handle_y-handle_h*.3,handle_y+handle_h*.3,zc-half-depth*.065,zc-half-depth*.04)
        for y in (low,high-clearance*.45):
            window_bar(assembly,"推拉导轨",l,r,y,y+clearance*.45,zc-depth*.025,zc+depth*.025,8)
    window_bar(assembly,"窗台收口",a,b,sill,sill+frame*.3,front-depth*.09,front+depth*.04)

def platform_window(parent, origin, right, forward, x0, x1, z0, z1, top, settings, name, floor=None):
    # Build the wall around a real opening, without a boolean or an overlapping pane.
    floor = -origin.y if floor is None else floor
    width, height, sill, offset, frame = settings[:5]
    style, ratio = settings[5:] if len(settings) == 7 else (0,25.0)
    margin = min(5.0, (x1-x0)*0.1, top*0.1)
    width = min(width, x1-x0-2*margin)
    sill = min(max(sill, margin), top-2*margin)
    height = min(height, top-margin-sill)
    if min(width,height) <= 0.000001:
        stair_wall(parent,origin,right,forward,x0,x1,z0,z1,floor,top,top,name)
        return
    center = min(max((x0+x1)/2+offset, x0+margin+width/2), x1-margin-width/2)
    a,b,upper = center-width/2, center+width/2, sill+height
    for l,r,low,high in ((x0,a,floor,top),(b,x1,floor,top),
                          (a,b,floor,sill),(a,b,upper,top)):
        stair_wall(parent,origin,right,forward,l,r,z0,z1,low,high,high,name)
    detailed_window(parent,origin,right,forward,a,b,sill,upper,z0,z1,frame,style,ratio,name)

def wall_spans(lo, hi, cuts):
    spans = [(lo, hi)]
    for cut_lo, cut_hi in cuts:
        result = []
        for a,b in spans:
            if cut_hi <= a or cut_lo >= b:
                result.append((a,b))
            else:
                if cut_lo > a: result.append((a,cut_lo))
                if cut_hi < b: result.append((cut_hi,b))
        spans = result
    return spans

def main():
    h, d, w, end_platform, rails, side, rail_height, diameter, post_steps, bar_diameter, bar_spacing = [op[c4d.ID_USERDATA, key] for key in PARAM_IDS]
    master = settings("HH_STAIR_FLOOR_MASTER")
    master_v2 = settings("HH_STAIR_FLOOR_MASTER_V2")
    floor_mode = bool(master_v2 or (master and master[0]))
    rail_style = settings("HH_STAIR_RAIL_STYLE") or [0,1.2,6.0,3.5]
    if (len(rail_style) != 4 or rail_style[0] not in (0,1) or
        any(not math.isfinite(float(v)) or v <= 0 for v in rail_style[1:])):
        return None
    roof = settings("HH_STAIR_MASTER_ROOF") or [False,15.0]
    if len(roof) != 2 or not math.isfinite(float(roof[1])) or roof[1] <= 0:
        return None
    roof_on = bool(master_v2 and roof[0])
    skirting = settings("HH_STAIR_SKIRTING") or [False,10.0,1.0]
    if any(not math.isfinite(float(v)) for v in skirting) or min(skirting[1:]) <= 0:
        return None
    tread, nosing = [op[c4d.ID_USERDATA, key] for key in TREAD_IDS]
    light_enabled, light_width, light_setback, light_left, light_right = [op[c4d.ID_USERDATA, key] for key in LIGHT_IDS]
    if light_enabled and (not math.isfinite(float(light_width)) or light_width <= 0 or
                          any(not math.isfinite(float(v)) or v < 0 for v in (light_setback, light_left, light_right))):
        return None
    lighting = (light_width, light_setback, light_left, light_right) if light_enabled else None
    border = tuple(op[c4d.ID_USERDATA, key] for key in BORDER_IDS)
    if any(not math.isfinite(float(v)) or v < 0 for v in border):
        return None
    if any(not math.isfinite(float(v)) or v < 0 for v in (tread, nosing)):
        return None
    if any(not math.isfinite(float(v)) or v <= 0 for v in (h, d, w)):
        return None
    if rails and (side not in (0, 1, 2) or any(not math.isfinite(float(v)) or v <= 0 for v in (rail_height, diameter, post_steps, bar_diameter, bar_spacing))):
        return None
    post_steps = max(1, min(100, int(post_steps)))
    radius = min(diameter / 2.0, w / 8.0, d / 8.0)
    inset = min(radius + 1.0, w / 4.0, d / 4.0)
    bar_radius = min(bar_diameter / 2.0, radius * 0.7)
    bar_spacing = max(5.0, bar_spacing)
    data = list(op.GetUserDataContainer())
    groups = [key for key, bc in data if bc[c4d.DESC_SHORT_NAME] == "HH_STAIR_SEGMENT_V2"]
    segments = []
    for group in groups:
        values = [op[key] for key, bc in data if bc[c4d.DESC_PARENTGROUP] == group]
        if len(values) not in (11, 21, 31, 33) or any(not math.isfinite(float(v)) for v in values):
            return None
        steps, direction, landing, gap, bottom, slab, platform_depth = values[:7]
        if steps < 1 or steps > 1000 or direction not in range(5) or min(landing, gap, platform_depth) < 0 or bottom not in (0, 1) or slab <= 0:
            return None
        wall = values[11:21] if len(values) >= 21 else [False,0,120,15,0,0,True,True,True,True]
        if wall[1] not in (0,1,2) or min(wall[2:4]) <= 0 or wall[4] < 0 or wall[5] not in (0,1):
            return None
        platform_wall = values[21:] if len(values) >= 31 else [wall[0],wall[2],wall[3],wall[4],False,80,60,30,0,4]
        if len(platform_wall) == 10:
            platform_wall = platform_wall + [0,25.0]
        if platform_wall[10] not in (0,1) or not 15 <= platform_wall[11] <= 45:
            return None
        if min(platform_wall[1:3]) <= 0 or platform_wall[3] < 0 or min(platform_wall[5:7]) <= 0 or platform_wall[7] < 0 or platform_wall[9] <= 0:
            return None
        segments.append((int(steps), int(direction), landing, gap, int(bottom), slab, platform_depth, values[7:11], wall, platform_wall))
    if floor_mode:
        if master_v2:
            shape = settings("HH_STAIR_MASTER_SHAPE")
            window = settings("HH_STAIR_MASTER_WINDOW")
            half_rails = settings("HH_STAIR_MASTER_RAIL_HALF")
            floor_rails = settings("HH_STAIR_MASTER_RAIL_FLOOR")
            flight_walls = settings("HH_STAIR_MASTER_FLIGHT_WALLS") or [0,0]
            if (len(master_v2) != 11 or len(shape) != 3 or len(window) != 7 or
                len(half_rails) != 4 or len(floor_rails) not in (3,4) or
                len(flight_walls) != 2 or any(v not in (0,1,2,3) for v in flight_walls) or
                any(not math.isfinite(float(v)) for v in master_v2+shape+window)):
                return None
            floors, upper_steps, lower_steps, half_landing, floor_landing, stair_gap, turn, walls_on, wall_height, wall_thick, windows_on = master_v2
            if (shape[0] not in (0,1) or shape[1] <= 0 or shape[2] < 0 or
                min(window[:2]) <= 0 or window[2] < 0 or window[4] <= 0 or
                window[5] not in (0,1) or not 15 <= window[6] <= 45):
                return None
            storey_height = h*(int(upper_steps)+int(lower_steps))
            template = (None,None,None,None,shape[0],shape[1],shape[2],None,None,
                        [walls_on,wall_height,wall_thick,0,windows_on]+window)
            if len(floor_rails) == 3:
                floor_rails = [floor_rails[0],floor_rails[1],False,floor_rails[2]]
        else:
            if len(master) != 13 or not segments or any(not math.isfinite(float(v)) for v in master):
                return None
            _, floors, storey_height, upper_steps, lower_steps, half_landing, floor_landing, stair_gap, turn, walls_on, wall_height, wall_thick, windows_on = master
            template = segments[0]
            half_rails, floor_rails = [True,True,True,True], [True,True,False,True]
        if (not 1 <= floors <= 20 or turn not in (0,1) or
            min(storey_height,upper_steps,lower_steps,half_landing,floor_landing,wall_height,wall_thick) <= 0 or stair_gap < 0):
            return None
        upper_steps, lower_steps = int(upper_steps), int(lower_steps)
        if int(floors)*(upper_steps+lower_steps) > 1000:
            return None
        if not master_v2:
            h = storey_height/(upper_steps+lower_steps)
        run = max(upper_steps,lower_steps)*d
        roof_y = int(floors)*storey_height+wall_height
        segments = []
        for i in range(int(floors)*2):
            at_floor = i %% 2 == 1
            wall = [walls_on, (1 if turn == 0 else 0) if at_floor else (0 if turn == 0 else 1),
                    wall_height,wall_thick,0,0 if master_v2 else 1,True,True,not at_floor,True]
            if master_v2:
                # The local frame already rotates at the landing: the outside
                # remains the same local side on both flights of a U-shaped stair.
                outside = 0 if turn == 0 else 1
                wall_choice = flight_walls[1 if at_floor else 0]
                wall[0] = walls_on and wall_choice != 3
                wall[1] = (outside,1-outside,2,outside)[int(wall_choice)]
                # This is the open stairwell edge, not an enclosure wall.
                wall[9] = False
            platform_wall = list(template[9])
            platform_wall[:5] = [walls_on,wall_height,wall_thick,0,windows_on and not at_floor]
            segments.append((upper_steps if at_floor else lower_steps, 4 if turn == 0 else 3,
                             floor_landing if at_floor else half_landing, stair_gap,
                             template[4],template[5],template[6],
                             list(floor_rails if at_floor else half_rails),wall,platform_wall))
        end_platform = True
    if not segments or sum(s[0] for s in segments) > 1000:
        print("[Stairs] 总台阶数量必须为 1-1000。")
        return None
    if len(segments) == 1 and not end_platform and not rails and not segments[0][8][0]:
        return flight(h, d, w, segments[0][0], segments[0][4], segments[0][5], tread, nosing, lighting, border)
    root = c4d.BaseObject(c4d.Onull)
    root.SetName("花花转弯楼梯")
    origin = c4d.Vector(0)
    right, forward = c4d.Vector(1, 0, 0), c4d.Vector(0, 0, 1)
    up = c4d.Vector(0, 1, 0)
    rail_root = []
    for index, (steps, direction, landing, gap, bottom, slab, platform_depth, platform_sides, wall, platform_wall) in enumerate(segments):
        number = index + 1
        if floor_mode:
            d = run/steps
        at_floor = floor_mode and number %% 2 == 0
        storey_base = (index//2)*storey_height if floor_mode else 0.0
        section = flight(h, d, w, steps, bottom, slab, tread, nosing, lighting, border)
        section.SetName("梯段 " + str(number))
        section.SetMl(c4d.Matrix(origin, right, up, forward))
        section.InsertUnderLast(root)
        wall_on, wall_side, wall_height, wall_thickness, wall_gap, wall_top = wall[:6]
        if wall_on:
            top0 = wall_height if wall_top == 0 else steps*h+wall_height
            top1 = steps*h+wall_height
            previous_top0, previous_top1 = top0, top1
            if roof_on and index >= len(segments)-2:
                top0 = top1 = roof_y-origin.y
            if floor_mode and not master_v2:
                top0 = top1 = storey_base+wall_height-origin.y
                if number == len(segments) and skirting[0]:
                    top0 = top1 = max(top0,steps*h+skirting[1])
            for is_left in ((True,) if wall_side == 0 else (False,) if wall_side == 1 else (True,False)):
                x0 = -wall_gap-wall_thickness if is_left else w+wall_gap
                wall_floor = storey_base-origin.y
                wall_floor_end = wall_floor
                if master_v2 and index >= 2:
                    # Repeated flights share a footprint. Meet the previous
                    # storey's sloping wall top without a gap or overlapping band.
                    wall_floor = previous_top0-storey_height
                    wall_floor_end = previous_top1-storey_height
                stair_wall(root, origin, right, forward, x0, x0+wall_thickness,
                           0, steps*d, wall_floor, top0, top1,
                           "梯段墙 " + str(number) + (" 左" if is_left else " 右"),
                           floor_end=wall_floor_end)
                if skirting[0]:
                    sh, st = min(skirting[1],wall_height), min(skirting[2],w*0.1)
                    sx = -wall_gap if is_left else w+wall_gap-st
                    for step in range(steps):
                        y, z = (step+1)*h, step*d
                        cap = sh if floor_mode else min(sh, max(0.0, top0+(top1-top0)*(step+1)/steps-y))
                        stair_wall(root,origin,right,forward,sx,sx+st,z,z+d,y,y+cap,y+cap,
                                   "梯段踢脚线 " + str(number) + "-" + str(step+1),9)
                        if step > 0:
                            stair_wall(root,origin,right,forward,sx,sx+st,z,z+min(st,d*.1),
                                       step*h+sh,y,y,"踢脚竖边 " + str(number),9)
        if rails:
            for x in ((inset,) if side == 0 else (w-inset,) if side == 1 else (inset, w-inset)):
                start = origin + right * x
                finish = start + forward * (steps*d) + up * (steps*h)
                railing_panel(rail_root, start, finish, rail_height, radius, bar_radius, bar_spacing)
                for i in sorted(set(list(range(0, steps, post_steps)) + [steps-1])):
                    z = i*d + (d-inset if i == steps-1 else inset)
                    p = origin + right*x + forward*z + up*((i+1)*h)
                    top = origin + right*x + forward*z + up*(h*z/d + rail_height)
                    tube(rail_root, p - up*min(0.2, h*0.1, slab*0.1), top, radius * 0.75, "梯段立柱")
        is_last = number == len(segments)
        if is_last and not end_platform:
            break
        current_form, current_turn = (0, 0) if is_last and not floor_mode else ((0, 0), (1, 1), (1, 0), (2, 1), (2, 0))[direction]
        length = w if landing == 0 else landing
        if current_form == 1:
            length = max(w, length)
        end = origin + forward * (steps * d) + up * (steps * h)
        low, high = 0.0, w
        if current_form == 2:
            low, high = (0.0, 2 * w + gap) if current_turn == 0 else (-w - gap, w)
        platform_thickness = min(slab, steps * h) if bottom == 1 else h
        if platform_depth > 0:
            platform_thickness = platform_depth
        platform = landing_mesh(high-low, platform_thickness, length, min(tread, h*0.45))
        platform.SetName(("到层平台 " if at_floor else "休息平台 ") + str(number))
        platform.SetMl(c4d.Matrix(end + right * ((low + high) / 2.0) + forward * (length / 2.0) - up * (platform_thickness / 2.0), right, up, forward))
        platform.InsertUnderLast(root)
        platform_on, platform_height, platform_wall_thickness, platform_gap, window_on = platform_wall[:5]
        platform_floor = -end.y
        if floor_mode:
            platform_floor = 0.0 if at_floor else storey_base-end.y
            if not master_v2:
                platform_height = wall_height if at_floor else max(0.01,storey_base+wall_height-end.y)
            elif index >= 2:
                platform_floor = platform_height-storey_height
        if roof_on and index >= len(segments)-2:
            platform_height = roof_y-end.y
        if platform_on:
            cuts = {"near": [(0.0,w)], "far": [], "left": [], "right": []}
            if not is_last:
                if current_form == 0: cuts["far"].append((0.0,w))
                elif current_form == 1:
                    cuts["right" if current_turn == 0 else "left"].append((length-w,length))
                else:
                    cuts["near"].append((w+gap,2*w+gap) if current_turn == 0 else (-w-gap,-gap))
            enabled = dict(zip(("left","right","far","near"), wall[6:]))
            wall_gap, wall_thickness = platform_gap, platform_wall_thickness
            for edge in ("left","right","far","near"):
                if not enabled[edge]: continue
                horizontal = edge in ("near","far")
                lo,hi = (low,high) if horizontal else (0.0,length)
                for a,b in wall_spans(lo,hi,cuts[edge]):
                    if horizontal:
                        x0 = a-wall_gap-wall_thickness if a == low else a
                        x1 = b+wall_gap+wall_thickness if b == high else b
                        z0 = -wall_gap-wall_thickness if edge == "near" else length+wall_gap
                        z1 = z0+wall_thickness
                    else:
                        x0 = low-wall_gap-wall_thickness if edge == "left" else high+wall_gap
                        x1 = x0+wall_thickness
                        z0 = a-wall_gap if a == 0 else a
                        z1 = b+wall_gap if b == length else b
                    name = "平台墙 " + str(number) + " " + edge
                    if edge == "far" and window_on:
                        platform_window(root,end,right,forward,x0,x1,z0,z1,platform_height,platform_wall[5:],name,platform_floor)
                    else:
                        stair_wall(root,end,right,forward,x0,x1,z0,z1,platform_floor,
                                   platform_height,platform_height,name)
                    if skirting[0]:
                        sh,st = min(skirting[1],platform_height), min(skirting[2],w*.1,length*.1)
                        if edge == "far" and window_on:
                            sh = min(sh,max(0.0,platform_wall[7]))
                        if horizontal:
                            sx0,sx1 = a,b
                            sz0,sz1 = (z1,z1+st) if edge == "near" else (z0-st,z0)
                        else:
                            sx0,sx1 = (x1,x1+st) if edge == "left" else (x0-st,x0)
                            sz0,sz1 = a,b
                        stair_wall(root,end,right,forward,sx0,sx1,sz0,sz1,0,sh,sh,
                                   "平台踢脚线 " + str(number) + " " + edge,9)
        if rails:
            # Subtract incoming/outgoing stair openings from the platform perimeter.
            openings = {"near": [(0.0, w)], "far": [], "left": [], "right": []}
            if not is_last:
                if current_form == 0:
                    openings["far"].append((0.0, w))
                elif current_form == 1:
                    openings["right" if current_turn == 0 else "left"].append((length-w, length))
                else:
                    openings["near"].append((w+gap, 2*w+gap) if current_turn == 0 else (-w-gap, -gap))
            z_inset = min(inset, length / 4.0)
            enabled_edges = dict(zip(("left", "right", "far", "near"), platform_sides))
            platform_endpoints = set()
            edges = (("near", low+inset, high-inset), ("far", low+inset, high-inset), ("left", z_inset, length-z_inset), ("right", z_inset, length-z_inset))
            for edge, lo, hi in edges:
                if not enabled_edges[edge]:
                    continue
                spans = [(lo, hi)]
                for cut_lo, cut_hi in openings[edge]:
                    cut_lo += inset if edge in ("near", "far") else z_inset
                    cut_hi -= inset if edge in ("near", "far") else z_inset
                    result = []
                    for a, b in spans:
                        if cut_hi <= a or cut_lo >= b:
                            result.append((a, b))
                        else:
                            if cut_lo > a: result.append((a, cut_lo))
                            if cut_hi < b: result.append((cut_hi, b))
                    spans = result
                for a, b in spans:
                    if b-a < 0.000001: continue
                    if edge in ("near", "far"):
                        p = end + right*a + forward*(z_inset if edge == "near" else length-z_inset)
                        q = end + right*b + forward*(z_inset if edge == "near" else length-z_inset)
                    else:
                        p = end + right*(low+inset if edge == "left" else high-inset) + forward*a
                        q = end + right*(low+inset if edge == "left" else high-inset) + forward*b
                    platform_endpoints.update((rail_key(p), rail_key(q)))
                    railing_edge(rail_root, p, q, rail_height, radius, post_steps*d, bar_radius, bar_spacing)
            # A square 90-degree landing has no inner perimeter span, but still
            # needs its shared corner to join the incoming and outgoing rails.
            if current_form == 1 and abs(length-w) < 0.000001:
                inner_edge = "left" if current_turn == 1 else "right"
                if enabled_edges[inner_edge]:
                    x = inset if current_turn == 1 else w-inset
                    platform_endpoints.add(rail_key(end + right*x + forward*z_inset))
            # Bridge inset perimeter rails to the incoming flight at the same elevation.
            for x in ((inset,) if side == 0 else (w-inset,) if side == 1 else (inset, w-inset)):
                p = end + right*x
                if rail_key(p + forward*z_inset) in platform_endpoints:
                    railing_panel(rail_root, p, p + forward*z_inset, rail_height, radius, bar_radius, bar_spacing)
        if current_form == 0:
            origin = end + forward * length
        elif current_form == 1:
            if current_turn == 0:
                origin = end + right * w + forward * length
                right, forward = -forward, right
            else:
                origin = end + forward * (length - w)
                right, forward = forward, -right
        else:
            origin = end + right * (2 * w + gap if current_turn == 0 else -gap)
            right, forward = -right, -forward
        if rails and not is_last:
            distance = inset if current_form == 1 else z_inset
            for x in ((inset,) if side == 0 else (w-inset,) if side == 1 else (inset, w-inset)):
                p = origin + right*x
                if rail_key(p - forward*distance) in platform_endpoints:
                    railing_panel(rail_root, p - forward*distance, p, rail_height, radius, bar_radius, bar_spacing)
    if roof_on:
        # Cover both flights and both landing footprints. The underside meets
        # the levelled top-storey walls; thickness grows upwards only.
        roof_low, roof_high = (0.0,2*w+stair_gap) if turn == 0 else (-w-stair_gap,w)
        roof_front, roof_back = -floor_landing-wall_thick, run+half_landing+wall_thick
        roof_obj = box_mesh(roof_high-roof_low+2*wall_thick,roof[1],roof_back-roof_front,True,5)
        roof_obj.SetName("楼梯顶部封顶")
        roof_obj.SetRelPos(c4d.Vector((roof_low+roof_high)/2,roof_y+roof[1]/2,(roof_front+roof_back)/2))
        roof_obj.InsertUnderLast(root)
    if rails:
        build_rails(root, rail_root)
    return root
''' % (tuple(ids), tuple(material_ids), tuple(tread_ids), tuple(light_ids), tuple(border_ids))
        doc.StartUndo()
        try:
            for mat in materials:
                doc.InsertMaterial(mat)
                doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, mat)
            doc.InsertObject(gen)
            doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, gen)
            for uid, mat in zip(material_ids, materials):
                gen[c4d.ID_USERDATA, uid] = mat
            InstallMaterialReferences(gen, material_ids)
            doc.SetActiveObject(gen, c4d.SELECTION_NEW)
        finally:
            doc.EndUndo()
        c4d.EventAdd()

    def _action_room_ceiling(self, preview=False):
        doc = documents.GetActiveDocument()
        if doc is None:
            return
        selected = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
        if not selected:
            gui.MessageDialog("请选择两面平行墙、三面 U 形墙、围合房间墙体，或水平 XZ 平面的闭合直线样条。")
            return
        try:
            module_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "huahua_ceiling.py")
            with open(module_path, "r", encoding="utf-8") as handle:
                source = handle.read()
            with open(os.path.join(os.path.dirname(module_path), "huahua_polybool.py"), "r", encoding="utf-8") as handle:
                polygon_source = handle.read()
            with open(os.path.join(os.path.dirname(module_path), "huahua_polybool.LICENSE"), "r", encoding="utf-8") as handle:
                polygon_license = handle.read()
            scope = {"POLYBOOL_SOURCE": polygon_source}
            exec(compile(source, module_path, "exec"), scope)
            details = {}
            loops, low_top, high_top = scope["selection_boundary"](selected, details)
            scope["validate_loops"](loops)
            inferred_open_room = details.get("inferred", False)
            # A user-edited path retains its elevation; walls use the highest top.
            height = high_top
            if preview:
                boundary = scope["make_spline"](loops, height, "吊顶范围预览")
                boundary.SetRenderMode(c4d.MODE_OFF)
                doc.StartUndo()
                try:
                    doc.InsertObject(boundary)
                    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, boundary)
                    doc.SetActiveObject(boundary, c4d.SELECTION_NEW)
                finally:
                    doc.EndUndo()
                status = "已识别 %d 个闭合轮廓" % len(loops)
                if inferred_open_room:
                    status = "开放墙体范围已推定，请检查敞口端及墙间空隙"
                if high_top - low_top > .01:
                    status += "；墙顶不齐，采用最高墙顶"
                self.SetString(ID_ROOM_CEILING_STATUS, status)
                c4d.EventAdd()
                return

            if inferred_open_room and not gui.QuestionDialog(
                    "墙体未完整围合，吊顶将使用推定的内侧范围，可能包含墙间空隙。\n"
                    "确定生成？也可取消后先点击“识别 / 预览吊顶范围”。"):
                return
            values = [field[3] for field in ROOM_CEILING_FIELDS]
            values[1] = height
            # Validate the complete layout before adding anything to the document.
            scope["build"](loops, values, [None, None])
            gen = c4d.BaseObject(c4d.Opython)
            gen.SetName("花花墙体适配吊顶")
            gen[c4d.OPYTHON_OPTIMIZE] = True
            gen[c4d.OPYTHON_RESET] = False
            boundary = scope["make_spline"](loops, values[1], "吊顶范围（可编辑）")
            boundary.SetRenderMode(c4d.MODE_OFF)
            boundary.InsertUnderLast(gen)
            watcher = c4d.BaseTag(c4d.Tpython)
            watcher.SetName("吊顶范围更新检测")
            watcher[c4d.TPYTHON_CODE] = '''import c4d
def main():
    global _BOUNDARY_STATE
    generator = op.GetObject()
    boundary = generator.GetDown()
    state = None if boundary is None else (boundary,
        boundary.GetDirty(c4d.DIRTYFLAGS_DATA), boundary.GetMl())
    if globals().get('_BOUNDARY_STATE') != state:
        _BOUNDARY_STATE = state
        generator.SetDirty(c4d.DIRTYFLAGS_DATA)
'''
            gen.InsertTag(watcher)
            ids, material_ids, materials = [], [], []
            for field, value in zip(ROOM_CEILING_FIELDS, values):
                cid, label, kind, default, minimum, maximum = field
                dtype = c4d.DTYPE_BOOL if kind == "bool" else c4d.DTYPE_LONG if kind in ("choice", "integer") else c4d.DTYPE_REAL
                bc = c4d.GetCustomDataTypeDefault(dtype)
                bc[c4d.DESC_NAME] = bc[c4d.DESC_SHORT_NAME] = label
                if kind != "bool":
                    bc[c4d.DESC_MIN], bc[c4d.DESC_MAX], bc[c4d.DESC_STEP] = minimum, maximum, 1
                if kind == "choice":
                    cycle = c4d.BaseContainer()
                    cycle.SetString(0, "铝方通")
                    cycle.SetString(1, "平顶吊顶")
                    cycle.SetString(2, "方格板吊顶")
                    cycle.SetString(3, "跌级灯槽吊顶")
                    bc[c4d.DESC_CYCLE] = cycle
                    bc[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_CYCLE
                key = gen.AddUserData(bc)
                gen[key] = value
                ids.append(key[1].id)
            body_color = (.72, .74, .76) if values[0] == 0 else (.9, .9, .88)
            for name, color in (("吊顶主体", body_color), ("周边收口", (.88, .88, .88)),
                                ("吊顶细龙骨", (.48, .49, .5)), ("吊顶顶部封板", (.22, .23, .24)),
                                ("吊顶灯具外壳", (.15, .16, .17)), ("吊顶灯具发光面", (1.0, .92, .8))):
                mat = c4d.BaseMaterial(c4d.Mmaterial)
                mat.SetName(name)
                mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(*color)
                if name == "吊顶灯具发光面":
                    mat[c4d.MATERIAL_USE_LUMINANCE] = True
                    mat[c4d.MATERIAL_LUMINANCE_COLOR] = c4d.Vector(*color)
                mat.Message(c4d.MSG_UPDATE)
                bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BASELISTLINK)
                bc[c4d.DESC_NAME] = name + "材质"
                key = gen.AddUserData(bc)
                materials.append((mat, key))
                material_ids.append(key[1].id)
            code = "# Vendored pypolybool (MIT)\n" + "\n".join("# " + line for line in polygon_license.splitlines())
            code += "\nimport c4d\nPOLYBOOL_SOURCE = " + repr(polygon_source) + "\n" + source
            code += "\nPARAM_IDS = " + repr(tuple(ids)) + "\nMATERIAL_IDS = " + repr(tuple(material_ids))
            code += "\nBOUNDARY_BASE_HEIGHT = " + repr(float(values[1]))
            code += '''
def message(id, data):
    global _CEILING_UI_BUSY
    if not c4d.threading.GeIsMainThreadAndNoDrawThread() or globals().get('_CEILING_UI_BUSY'):
        return True
    _CEILING_UI_BUSY = True
    try:
        if sync_ceiling_ui(op, PARAM_IDS, MATERIAL_IDS):
            op.Message(c4d.MSG_CHANGE)
    finally:
        _CEILING_UI_BUSY = False
    return True

def main():
    global _LAST_CEILING_KEY
    try:
        boundary = op.GetDown()
        if boundary is None:
            raise ValueError("缺少吊顶范围子样条")
        loops, elevation = read_spline(boundary, local=True)
        values = [op[c4d.ID_USERDATA, i] for i in PARAM_IDS]
        values[1] += elevation - BOUNDARY_BASE_HEIGHT
        materials = [op[c4d.ID_USERDATA, i] for i in MATERIAL_IDS]
        key = (loops, values, materials)
        cache = op.GetCache()
        if cache is not None and globals().get('_LAST_CEILING_KEY') == key:
            return cache.GetClone()
        result = build(loops, values, materials)
        _LAST_CEILING_KEY = key
        return result
    except ValueError as exc:
        _LAST_CEILING_KEY = None
        result = c4d.BaseObject(c4d.Onull)
        result.SetName("吊顶参数无效：" + str(exc))
        return result
'''
            gen[c4d.OPYTHON_CODE] = code
            compile(code, "<HuahuaRoomCeiling>", "exec")
            scope["sync_ceiling_ui"](gen, ids, material_ids)
            doc.StartUndo()
            try:
                doc.InsertObject(gen)
                doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, gen)
                for mat, key in materials:
                    doc.InsertMaterial(mat)
                    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, mat)
                    gen[key] = mat
                InstallMaterialReferences(gen, material_ids)
                doc.SetActiveObject(gen, c4d.SELECTION_NEW)
            finally:
                doc.EndUndo()
            self.SetString(ID_ROOM_CEILING_STATUS, "吊顶已生成，范围子样条已关联")
            c4d.EventAdd()
        except (ValueError, OSError) as exc:
            self.SetString(ID_ROOM_CEILING_STATUS, "吊顶范围 / 参数不可用")
            gui.MessageDialog(str(exc))

    def _action_generate_ceiling(self):
        CheckAndCreateMaterials()
        doc = c4d.documents.GetActiveDocument()
        selection = doc.GetActiveObject()
        
        init_h = 260.0; init_d = 400.0; init_link = None
        if selection:
            size, _, _, _ = GetHierarchyLocalBounds_Gen(selection)
            if size.y > 1.0: init_h = size.y
            init_link = selection

        gen = c4d.BaseObject(c4d.Opython)
        gen.SetName("智能吊顶 花花智能建模-C4D端 v1.1 (按钮刷新+显隐优化)")
        
        def AddUD(obj, name, dtype, val, unit=0, cycle=None, min_val=None, max_val=None, step=None, parent_id=None):
            bc = c4d.GetCustomDataTypeDefault(dtype)
            bc[c4d.DESC_NAME] = name
            if unit: bc[c4d.DESC_UNIT] = unit
            if min_val is not None: bc[c4d.DESC_MIN] = min_val
            if max_val is not None: bc[c4d.DESC_MAX] = max_val
            if step is not None: bc[c4d.DESC_STEP] = step
            if cycle:
                cycle_bc = c4d.BaseContainer()
                for k, v in cycle.items(): cycle_bc.SetString(k, v)
                bc[c4d.DESC_CYCLE] = cycle_bc
            if parent_id is not None: bc[c4d.DESC_PARENTGROUP] = parent_id
            element = obj.AddUserData(bc)
            if dtype != c4d.DTYPE_BUTTON and dtype != c4d.DTYPE_SEPARATOR: obj[element] = val
            return element

        def AddGroup(obj, name, parent_id=None):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
            bc[c4d.DESC_NAME] = name
            bc[c4d.DESC_TITLEBAR] = 1 
            if parent_id is not None: bc[c4d.DESC_PARENTGROUP] = parent_id
            return obj.AddUserData(bc)

        AddUD(gen, "参考对象 (决定房宽/房高)", c4d.DTYPE_BASELISTLINK, init_link)
        AddUD(gen, "🔄 立即刷新 (点击)", c4d.DTYPE_BUTTON, 0) 
        AddUD(gen, "👁️ 自动隐藏源对象", c4d.DTYPE_BOOL, True) 
        AddUD(gen, "✅ 将模型自动靠墙放置 (保留原墙)", c4d.DTYPE_BOOL, True) 
        AddUD(gen, "房高 (吊顶下净高)", c4d.DTYPE_REAL, init_h, c4d.DESC_UNIT_METER)
        AddUD(gen, "房深 (侧墙长度)", c4d.DTYPE_REAL, init_d, c4d.DESC_UNIT_METER) 
        opts = {0:"默认", 1:"整体吊顶", 2:"平顶", 3:"跌级吊顶(推荐)"}
        AddUD(gen, "吊顶类型", c4d.DTYPE_LONG, 3, cycle=opts)
        AddUD(gen, "✅ 生成前墙 (封闭室内)", c4d.DTYPE_BOOL, False)
        gen.AddUserData(c4d.GetCustomDataTypeDefault(c4d.DTYPE_SEPARATOR))

        pose_opts = {0: "正常 (无需修正)", 1: "躺平了 (-90度)", 2: "趴着呢 (+90度)", 3: "倒立了 (180度)"}
        rot_opts = {0: "0 度", 1: "90 度", 2: "180 度", 3: "270 度"}

        AddUD(gen, ">> 替换窗户模型", c4d.DTYPE_BASELISTLINK, None)
        AddUD(gen, "   └ 窗-姿态修正", c4d.DTYPE_LONG, 1, cycle=pose_opts)
        AddUD(gen, "   └ 窗-方向修正", c4d.DTYPE_LONG, 0, cycle=rot_opts)
        grp_win = AddGroup(gen, "🔧 窗户详细参数 (可折叠)")
        AddUD(gen, "✅ 使用模型原生尺寸", c4d.DTYPE_BOOL, False, parent_id=grp_win)
        AddUD(gen, "[微调] 厚度缩放", c4d.DTYPE_REAL, 1.0, unit=c4d.DESC_UNIT_PERCENT, step=0.01, parent_id=grp_win)
        AddUD(gen, "[微调] 前后位移", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=0.1, parent_id=grp_win)
        AddUD(gen, "[尺寸] 窗户宽度", c4d.DTYPE_REAL, 174.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_win)
        AddUD(gen, "[尺寸] 窗户高度", c4d.DTYPE_REAL, 164.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_win)
        AddUD(gen, "[位置] 上下移动", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_win)
        AddUD(gen, "[位置] 左右移动", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_win)
        AddUD(gen, "[旋转] X轴 (俯仰)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_win)
        AddUD(gen, "[旋转] Y轴 (偏航)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_win)
        AddUD(gen, "[旋转] Z轴 (翻滚)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_win)
        
        gen.AddUserData(c4d.GetCustomDataTypeDefault(c4d.DTYPE_SEPARATOR))

        AddUD(gen, ">> 替换门模型", c4d.DTYPE_BASELISTLINK, None)
        AddUD(gen, "   └ 门-姿态修正", c4d.DTYPE_LONG, 1, cycle=pose_opts)
        AddUD(gen, "   └ 门-方向修正", c4d.DTYPE_LONG, 0, cycle=rot_opts)
        grp_door = AddGroup(gen, "🔧 门详细参数 (可折叠)")
        AddUD(gen, "✅ 使用模型原生尺寸", c4d.DTYPE_BOOL, False, parent_id=grp_door)
        AddUD(gen, "[微调] 左右位置修正 (正右负左)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=0.1, parent_id=grp_door)
        AddUD(gen, "[微调] 上下位置修正 (解决飞天)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=0.1, parent_id=grp_door)
        AddUD(gen, "[微调] 厚度缩放", c4d.DTYPE_REAL, 1.0, unit=c4d.DESC_UNIT_PERCENT, step=0.01, parent_id=grp_door)
        AddUD(gen, "[微调] 前后位移", c4d.DTYPE_REAL, 6.7, unit=c4d.DESC_UNIT_METER, step=0.1, parent_id=grp_door)
        AddUD(gen, "[尺寸] 门洞宽度", c4d.DTYPE_REAL, 100.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_door)
        AddUD(gen, "[尺寸] 门洞高度", c4d.DTYPE_REAL, 220.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_door)
        AddUD(gen, "[位置] 左右移动", c4d.DTYPE_REAL, 161.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_door)
        AddUD(gen, "[旋转] X轴 (俯仰)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_door)
        AddUD(gen, "[旋转] Y轴 (偏航)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_door)
        AddUD(gen, "[旋转] Z轴 (翻滚)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_door)
        
        gen.AddUserData(c4d.GetCustomDataTypeDefault(c4d.DTYPE_SEPARATOR))
        AddUD(gen, "射灯间距", c4d.DTYPE_REAL, 120.0, c4d.DESC_UNIT_METER) 
        AddUD(gen, "开启射灯", c4d.DTYPE_BOOL, True) 
        AddUD(gen, "   └ 开启两侧射灯", c4d.DTYPE_BOOL, False) 
        AddUD(gen, "显示灯光线框", c4d.DTYPE_BOOL, True) 
        AddUD(gen, "吊顶边距", c4d.DTYPE_REAL, 50.0, c4d.DESC_UNIT_METER) 
        AddUD(gen, "灯带数量", c4d.DTYPE_LONG, 3) 
        
        script_code = r"""
import c4d

RECESS_VAL = 10.0
OVERLAP = 2.0

def GetMat(name):
    doc = c4d.documents.GetActiveDocument()
    if not doc: return None
    return doc.SearchMaterial(name)

def GetHierarchyLocalBounds(obj):
    if not obj: return c4d.Vector(0), c4d.Vector(0), c4d.Vector(0), c4d.Vector(0)
    root_mg = obj.GetMg()
    inv_root_mg = ~root_mg
    min_p = c4d.Vector(float('inf'))
    max_p = c4d.Vector(float('-inf'))
    found = False
    
    def traverse(op):
        nonlocal min_p, max_p, found
        curr_mg = op.GetMg()
        local_to_root = inv_root_mg * curr_mg
        points = None
        if op.CheckType(c4d.Opoint):
            points = op.GetAllPoints()
        if points:
            found = True
            for p in points:
                p_rel = local_to_root * p
                if p_rel.x < min_p.x: min_p.x = p_rel.x
                if p_rel.x > max_p.x: max_p.x = p_rel.x
                if p_rel.y < min_p.y: min_p.y = p_rel.y
                if p_rel.y > max_p.y: max_p.y = p_rel.y
                if p_rel.z < min_p.z: min_p.z = p_rel.z
                if p_rel.z > max_p.z: max_p.z = p_rel.z
        else:
            cache = op.GetCache()
            if cache: traverse(cache)
            rad = op.GetRad()
            if rad.x > 0.001 or rad.y > 0.001 or rad.z > 0.001:
                found = True
                mp = op.GetMp()
                corners =[c4d.Vector(mp.x-rad.x, mp.y-rad.y, mp.z-rad.z), c4d.Vector(mp.x+rad.x, mp.y-rad.y, mp.z-rad.z), c4d.Vector(mp.x-rad.x, mp.y+rad.y, mp.z-rad.z), c4d.Vector(mp.x+rad.x, mp.y+rad.y, mp.z-rad.z), c4d.Vector(mp.x-rad.x, mp.y-rad.y, mp.z+rad.z), c4d.Vector(mp.x+rad.x, mp.y-rad.y, mp.z+rad.z), c4d.Vector(mp.x-rad.x, mp.y+rad.y, mp.z+rad.z), c4d.Vector(mp.x+rad.x, mp.y+rad.y, mp.z+rad.z)]
                for p in corners:
                    p_rel = local_to_root * p
                    if p_rel.x < min_p.x: min_p.x = p_rel.x
                    if p_rel.x > max_p.x: max_p.x = p_rel.x
                    if p_rel.y < min_p.y: min_p.y = p_rel.y
                    if p_rel.y > max_p.y: max_p.y = p_rel.y
                    if p_rel.z < min_p.z: min_p.z = p_rel.z
                    if p_rel.z > max_p.z: max_p.z = p_rel.z
        for child in op.GetChildren(): traverse(child)
    traverse(obj)
    if not found: return c4d.Vector(0), c4d.Vector(0), c4d.Vector(0), c4d.Vector(0)
    size = max_p - min_p
    center = (min_p + max_p) * 0.5
    return size, center, min_p, max_p

def MakeBox(name, size, pos, mat_name, parent, fillet=False):
    cube = c4d.BaseObject(c4d.Ocube)
    cube.SetName(name)
    cube[c4d.PRIM_CUBE_LEN] = size
    cube.SetAbsPos(pos)
    cube[c4d.PRIM_CUBE_DOFILLET] = False 
    mat = GetMat(mat_name)
    if mat:
        t = cube.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat)
        if "Floor" in name:
            t[c4d.TEXTURETAG_PROJECTION] = 6 
            t[c4d.TEXTURETAG_LENGTHX] = 500.0
            t[c4d.TEXTURETAG_LENGTHY] = 500.0
    if parent: cube.InsertUnderLast(parent)
    return cube

def MakeSpot(name, pos, mat_body_name, show_wireframe, parent):
    group = c4d.BaseObject(c4d.Onull)
    group.SetName(name)
    group.SetAbsPos(pos)
    casing = c4d.BaseObject(c4d.Ocylinder)
    casing.SetName("Casing")
    casing[c4d.PRIM_CYLINDER_RADIUS] = 4.0
    casing[c4d.PRIM_CYLINDER_HEIGHT] = 2.0
    casing[c4d.PRIM_AXIS] = 2 
    casing[c4d.PRIM_CYLINDER_SEG] = 48
    mat_body = GetMat(mat_body_name)
    if mat_body:
        t = casing.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat_body)
    casing.InsertUnder(group)
    bulb = c4d.BaseObject(c4d.Ocylinder)
    bulb.SetName("Bulb_Face")
    bulb[c4d.PRIM_CYLINDER_RADIUS] = 3.5
    bulb[c4d.PRIM_CYLINDER_HEIGHT] = 0.1
    bulb[c4d.PRIM_AXIS] = 2 
    bulb[c4d.PRIM_CYLINDER_SEG] = 48
    bulb.SetAbsPos(c4d.Vector(0, -1.0, 0))
    mat_light = GetMat("Pro_Light_Spot")
    if mat_light:
        t = bulb.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat_light)
    bulb.InsertUnder(group)
    real_light = c4d.BaseObject(c4d.Olight)
    real_light.SetName("Real_Light")
    real_light[c4d.LIGHT_TYPE] = c4d.LIGHT_TYPE_SPOT
    real_light[c4d.LIGHT_BRIGHTNESS] = 1.0
    real_light[c4d.LIGHT_DETAILS_OUTERANGLE] = 0.8
    real_light[c4d.LIGHT_SHADOWTYPE] = c4d.LIGHT_SHADOWTYPE_SOFT
    if show_wireframe:
        real_light[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_ON
    else:
        real_light[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
    real_light.SetAbsRot(c4d.Vector(0, -1.5708, 0)) 
    real_light.SetAbsPos(c4d.Vector(0, -1.5, 0))
    real_light.InsertUnder(group)
    if parent: group.InsertUnderLast(parent)
    return group

def PlaceLinkedModel(link_obj, target_size, target_pos_floor, pose_mode, rot_mode, custom_rot_vec, depth_scale, pos_offset, center_offset_x, center_offset_y, use_native_size, name, parent):
    if not link_obj: return False, target_size 
    container = c4d.BaseObject(c4d.Onull)
    container.SetName(name + "_Container")
    container.SetAbsPos(target_pos_floor)
    axis_corrector = c4d.BaseObject(c4d.Onull)
    axis_corrector.SetName("Axis_Corrector")
    axis_corrector.InsertUnder(container)
    axis_corrector.SetAbsPos(c4d.Vector(0,0,0))
    clone = link_obj.GetClone(0)
    clone.SetName(name)
    clone[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_ON
    clone[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_ON
    clone.InsertUnder(axis_corrector)
    vis_size, vis_center, min_p, max_p = GetHierarchyLocalBounds(link_obj)
    shift_x = -vis_center.x
    shift_z = -vis_center.z
    shift_y = -min_p.y
    if vis_size.x < 0.001 and vis_size.y < 0.001:
        shift_x = 0; shift_y = 0; shift_z = 0
    clone.SetAbsPos(c4d.Vector(shift_x, shift_y, shift_z))
    clone.SetAbsRot(c4d.Vector(0,0,0))
    t_thick = target_size.x; t_high  = target_size.y; t_wide  = target_size.z
    s_wide = vis_size.x if vis_size.x > 0.1 else 1.0
    s_high = vis_size.y if vis_size.y > 0.1 else 1.0
    s_thick= vis_size.z if vis_size.z > 0.1 else 1.0
    fac_x = t_wide / s_wide; fac_y = t_high / s_high; fac_z = t_thick / s_thick 
    if use_native_size:
        fac_x = 1.0 * depth_scale; fac_y = 1.0; fac_z = 1.0
    axis_corrector.SetRelScale(c4d.Vector(fac_x, fac_y, fac_z))
    final_rot = c4d.Vector(0,0,0)
    if pose_mode == 1: final_rot.x = -1.5708
    elif pose_mode == 2: final_rot.x = 1.5708
    elif pose_mode == 3: final_rot.x = 3.14159
    if rot_mode == 1: final_rot.y += 1.5708
    elif rot_mode == 2: final_rot.y += 3.14159
    elif rot_mode == 3: final_rot.y += 4.71239
    final_rot.x += custom_rot_vec.x; final_rot.y += custom_rot_vec.y; final_rot.z += custom_rot_vec.z
    axis_corrector.SetRelRot(final_rot)
    offset_vec = c4d.Vector(0,0,0)
    if rot_mode == 1 or rot_mode == 3: offset_vec.x = center_offset_x
    else: offset_vec.z = center_offset_x
    offset_vec.y = center_offset_y
    axis_corrector.SetRelPos(offset_vec)
    p = container.GetAbsPos()
    p.x += pos_offset
    container.SetAbsPos(p)
    if parent: container.InsertUnderLast(parent)
    ret_w = t_wide; ret_h = t_high
    if use_native_size:
        if rot_mode == 1 or rot_mode == 3: ret_w = s_wide
        else: ret_w = s_thick
        ret_h = s_high
    return True, c4d.Vector(target_size.x, ret_h, ret_w)

def CreateStepBorder(name, w, h, d, x, y, z, border_type, parent):
    M_WHITE = "Pro_Wall_White"
    M_LIGHT_COVE = "Pro_Light_Cove"
    h_lower = 8.0 
    h_upper = h - h_lower
    recess = RECESS_VAL 
    top_y = y + h/2
    y_upper = top_y - h_upper/2
    y_lower = top_y - h_upper - h_lower/2
    light_thick = 0.5          
    light_width = recess * 0.5 
    y_light = (y_lower + h_lower/2) + light_thick/2 
    extend_len = (recess * 2.0) + 20.0
    if border_type == "L": 
        MakeBox(name + "_Low", c4d.Vector(w, h_lower, d), c4d.Vector(x, y_lower, z), M_WHITE, parent)
        shift_x = -recess/2.0
        MakeBox(name + "_Up", c4d.Vector(w-recess, h_upper, d), c4d.Vector(x+shift_x, y_upper, z), M_WHITE, parent)
        lx = x + (w/2.0 - recess/2.0)
        MakeBox(name + "_Light", c4d.Vector(light_width, light_thick, d-2.0), c4d.Vector(lx, y_light, z), M_LIGHT_COVE, parent)
    elif border_type == "R": 
        MakeBox(name + "_Low", c4d.Vector(w, h_lower, d), c4d.Vector(x, y_lower, z), M_WHITE, parent)
        shift_x = +recess/2.0
        MakeBox(name + "_Up", c4d.Vector(w-recess, h_upper, d), c4d.Vector(x+shift_x, y_upper, z), M_WHITE, parent)
        lx = x - (w/2.0 - recess/2.0)
        MakeBox(name + "_Light", c4d.Vector(light_width, light_thick, d-2.0), c4d.Vector(lx, y_light, z), M_LIGHT_COVE, parent)
    elif border_type == "F": 
        MakeBox(name + "_Low", c4d.Vector(w, h_lower, d), c4d.Vector(x, y_lower, z), M_WHITE, parent)
        shift_z = -recess/2.0
        MakeBox(name + "_Up", c4d.Vector(w+extend_len, h_upper, d-recess), c4d.Vector(x, y_upper, z+shift_z), M_WHITE, parent)
        lz = z + (d/2.0 - recess/2.0)
        MakeBox(name + "_Light", c4d.Vector(w+extend_len, light_thick, light_width), c4d.Vector(x, y_light, lz), M_LIGHT_COVE, parent)
    elif border_type == "B": 
        MakeBox(name + "_Low", c4d.Vector(w, h_lower, d), c4d.Vector(x, y_lower, z), M_WHITE, parent)
        shift_z = +recess/2.0
        MakeBox(name + "_Up", c4d.Vector(w+extend_len, h_upper, d-recess), c4d.Vector(x, y_upper, z+shift_z), M_WHITE, parent)
        lz = z - (d/2.0 - recess/2.0)
        MakeBox(name + "_Light", c4d.Vector(w+extend_len, light_thick, light_width), c4d.Vector(x, y_light, lz), M_LIGHT_COVE, parent)

def main():
    def GetUD(id, default):
        try:
            val = op[c4d.ID_USERDATA, id]
            if val is None: return default
            return val
        except: return default
    link = GetUD(1, None)
    auto_hide = bool(GetUD(3, True)) 
    if link:
        if auto_hide:
            try:
                if link.GetEditorMode() != c4d.OBJECT_OFF:
                    link.SetEditorMode(c4d.OBJECT_OFF)
                    link.SetRenderMode(c4d.OBJECT_OFF)
            except: pass
    else:
            try:
                if link.GetEditorMode() == c4d.OBJECT_OFF:
                    link.SetEditorMode(c4d.OBJECT_UNDEF)
                    link.SetRenderMode(c4d.OBJECT_UNDEF)
            except: pass
    place_against_wall = bool(GetUD(4, False)) 
    clear_h = float(GetUD(5, 260.0)) 
    rd = float(GetUD(6, 400.0))
    ct = int(GetUD(7, 3))
    make_front_wall = bool(GetUD(8, False))
    win_link = GetUD(10, None)
    win_pose = int(GetUD(11, 1))
    win_rot  = int(GetUD(12, 0))
    win_native  = int(GetUD(14, 0)) 
    win_d_scale = float(GetUD(15, 1.0))
    win_offset  = float(GetUD(16, 0.0))
    win_w_usr = float(GetUD(17, 174.0)) 
    win_h_usr = float(GetUD(18, 164.0))
    win_move_y = float(GetUD(19, 0.0)) 
    win_move_z = float(GetUD(20, 0.0))
    wx = float(GetUD(21, 0.0)); wy = float(GetUD(22, 0.0)); wz = float(GetUD(23, 0.0))
    win_custom_vec = c4d.Vector(wx, wy, wz)
    door_link = GetUD(25, None)
    door_pose = int(GetUD(26, 1)) 
    door_rot  = int(GetUD(27, 0)) 
    door_native = int(GetUD(29, 0)) 
    door_center_x_fix = float(GetUD(30, 0.0))
    door_center_y_fix = float(GetUD(31, 0.0))
    door_d_scale = float(GetUD(32, 1.0))
    door_offset  = float(GetUD(33, 6.7)) 
    door_w_usr = float(GetUD(34, 100.0))
    door_h_usr = float(GetUD(35, 220.0))
    door_z_move = float(GetUD(36, 161.0)) 
    dx = float(GetUD(37, 0.0)); dy = float(GetUD(38, 0.0)); dz = float(GetUD(39, 0.0))
    door_custom_vec = c4d.Vector(dx, dy, dz)
    spot_dist = float(GetUD(41, 120.0)) 
    enable_spots = int(GetUD(42, 1))
    enable_side_spots = int(GetUD(43, 0))
    show_light_wire = int(GetUD(44, 1)) 
    manual_margin = float(GetUD(45, 50.0))
    light_strip_cnt = int(GetUD(46, 3))
    if link and isinstance(link, c4d.BaseObject):
        real_size, _, _, _ = GetHierarchyLocalBounds(link)
        if real_size.y > clear_h: clear_h = real_size.y
        real_w = real_size.x; rw = max(real_w, 100.0)
    else: rw = 500.0
    root = c4d.BaseObject(c4d.Onull)
    MakeBox("Floor", c4d.Vector(rw + 40.0, 10, rd), c4d.Vector(0,-5,0), "Pro_Floor_Wood", root)
    wall_h = clear_h
    MakeBox("Wall_Back", c4d.Vector(rw, wall_h, 20), c4d.Vector(0, wall_h/2, rd/2+10), "Pro_Wall_White", root)
    if make_front_wall: MakeBox("Wall_Front", c4d.Vector(rw, wall_h, 20), c4d.Vector(0, wall_h/2, -rd/2-10), "Pro_Wall_White", root)
    if link and place_against_wall and isinstance(link, c4d.BaseObject):
        container = c4d.BaseObject(c4d.Onull)
        container.SetName("Decor_Object_Placed")
        container.SetAbsPos(c4d.Vector(0, 0, 0)) 
        clone = link.GetClone(0)
        if clone:
            clone.SetAbsPos(c4d.Vector(0,0,0)); clone.SetAbsRot(c4d.Vector(0,0,0))
            clone[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_ON
            clone[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_ON
            clone.InsertUnder(container)
            _, _, min_p, max_p = GetHierarchyLocalBounds(link)
            min_y = min_p.y; move_y = 0.0 - min_y
            center_x = (min_p.x + max_p.x) * 0.5; move_x = 0.0 - center_x
            max_z = max_p.z; move_z = (rd / 2.0) - max_z
            clone.SetAbsPos(c4d.Vector(move_x, move_y, move_z))
            container.InsertUnderLast(root)
    ceil_drop = 30.0 
    if ct == 2: ceil_drop = 5.0 
    elif ct == 1: ceil_drop = 15.0 
    total_rh = clear_h + ceil_drop; side_wall_h = total_rh 
    L = c4d.BaseObject(c4d.Onull); L.SetAbsPos(c4d.Vector(-rw/2-10,0,0)); L.InsertUnderLast(root)
    ww_val = win_w_usr if win_w_usr > 1 else rd*0.5
    wh_val = win_h_usr if win_h_usr > 1 else side_wall_h*0.5
    wy_base = side_wall_h*0.55; wy = wy_base + win_move_y; wz = win_move_z
    has_win_model = False; actual_ww = ww_val; actual_wh = wh_val
    if win_link:
        success, actual_size_vec = PlaceLinkedModel(win_link, c4d.Vector(15, wh_val, ww_val), c4d.Vector(0, wy - wh_val/2, wz), win_pose, win_rot, win_custom_vec, win_d_scale, win_offset, 0.0, 0.0, win_native, "HighPoly_Window", L)
        if success: has_win_model = True; actual_wh = actual_size_vec.y; actual_ww = actual_size_vec.z
    if not has_win_model:
        MakeBox("Win_F", c4d.Vector(12, actual_wh, 6), c4d.Vector(0,wy,-actual_ww/2+wz), "Pro_Metal_Dark", L)
        MakeBox("Win_B", c4d.Vector(12, actual_wh, 6), c4d.Vector(0,wy,actual_ww/2+wz), "Pro_Metal_Dark", L)
        MakeBox("Win_T", c4d.Vector(12, 6, actual_ww), c4d.Vector(0,wy+actual_wh/2,wz), "Pro_Metal_Dark", L)
        MakeBox("Win_D", c4d.Vector(12, 6, actual_ww), c4d.Vector(0,wy-actual_wh/2,wz), "Pro_Metal_Dark", L)
        MakeBox("Glass", c4d.Vector(2, actual_wh-10, actual_ww-10), c4d.Vector(0,wy,wz), "Pro_Glass", L)
    h_bot = wy - actual_wh/2
    if h_bot > 0: MakeBox("W_Bot", c4d.Vector(20, h_bot, rd), c4d.Vector(0, h_bot/2, 0), "Pro_Wall_White", L)
    h_top = side_wall_h - (wy + actual_wh/2)
    if h_top > 0: MakeBox("W_Top", c4d.Vector(20, h_top, rd), c4d.Vector(0, side_wall_h - h_top/2, 0), "Pro_Wall_White", L)
    len_f = (wz - actual_ww/2) + rd/2
    if len_f > 0: pos_f = -rd/2 + len_f/2; MakeBox("W_F", c4d.Vector(20, actual_wh, len_f), c4d.Vector(0, wy, pos_f), "Pro_Wall_White", L)
    len_b = rd/2 - (wz + actual_ww/2)
    if len_b > 0: pos_b = rd/2 - len_b/2; MakeBox("W_B", c4d.Vector(20, actual_wh, len_b), c4d.Vector(0, wy, pos_b), "Pro_Wall_White", L)
    R = c4d.BaseObject(c4d.Onull); R.SetAbsPos(c4d.Vector(rw/2+10,0,0)); R.InsertUnderLast(root)
    dw = door_w_usr; dh = door_h_usr; dz = (-rd*0.2) + door_z_move; actual_dw = dw; actual_dh = dh
    bool_op = c4d.BaseObject(c4d.Oboole)
    bool_op[c4d.BOOLEOBJECT_SINGLE_OBJECT] = True; bool_op[c4d.BOOLEOBJECT_TYPE] = c4d.BOOLEOBJECT_TYPE_SUBTRACT 
    bool_op.InsertUnder(R)
    MakeBox("Wall_Solid", c4d.Vector(20, side_wall_h, rd), c4d.Vector(0,side_wall_h/2,0), "Pro_Wall_White", bool_op)
    has_door_model = False
    if door_link:
        success, actual_size_vec = PlaceLinkedModel(door_link, c4d.Vector(20, dh, dw), c4d.Vector(0, 0, dz), door_pose, door_rot, door_custom_vec, door_d_scale, door_offset, door_center_x_fix, door_center_y_fix, door_native, "HighPoly_Door", R)
        if success: has_door_model = True; actual_dh = actual_size_vec.y; actual_dw = actual_size_vec.z
    cutter_h = actual_dh + 10.0; cutter_y = (actual_dh / 2.0) - 5.0
    cutter = MakeBox("Cutter", c4d.Vector(40, cutter_h, actual_dw), c4d.Vector(0, cutter_y, dz), "Pro_Wall_White", bool_op)
    cutter[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = 1; cutter[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = 1 
    if not has_door_model:
        MakeBox("Door_F", c4d.Vector(24, actual_dh, 10), c4d.Vector(0,actual_dh/2,dz-actual_dw/2), "Pro_Metal_Dark", R)
        MakeBox("Door_B", c4d.Vector(24, actual_dh, 10), c4d.Vector(0,actual_dh/2,dz+actual_dw/2), "Pro_Metal_Dark", R)
        MakeBox("Door_T", c4d.Vector(24, 10, actual_dw), c4d.Vector(0,actual_dh,dz), "Pro_Metal_Dark", R)
        MakeBox("Panel", c4d.Vector(4, actual_dh, actual_dw), c4d.Vector(0,actual_dh/2,dz), "Pro_Door_Wood", R)
    if ct == 0: ct = 3
    if ct == 3:
        M_WHITE = "Pro_Wall_White"; M_BLACK = "Pro_Metal_Dark"; M_LIGHT_LINEAR = "Pro_Light_Linear"
        MakeBox("Structure_Slab", c4d.Vector(rw, 2, rd), c4d.Vector(0, total_rh+1.0, 0), M_BLACK, root)
        margin_x = manual_margin; margin_z = manual_margin
        drop_h = ceil_drop; drop_y = clear_h + drop_h / 2.0
        CreateStepBorder("Drop_L", margin_x, drop_h, rd, -rw/2.0+margin_x/2.0, drop_y, 0, "L", root)
        CreateStepBorder("Drop_R", margin_x, drop_h, rd, rw/2.0-margin_x/2.0, drop_y, 0, "R", root)
        in_w = rw - margin_x*2.0
        CreateStepBorder("Drop_F", in_w, drop_h, margin_z, 0, drop_y, -rd/2.0+margin_z/2.0, "F", root)
        CreateStepBorder("Drop_B", in_w, drop_h, margin_z, 0, drop_y, rd/2.0-margin_z/2.0, "B", root)
        if enable_spots:
            spot_y = clear_h; cx = rw/2.0 - margin_x/2.0; cz = rd/2.0 - margin_z/2.0
            MakeSpot("C_FL", c4d.Vector(-cx, spot_y, -cz), M_BLACK, show_light_wire, root)
            MakeSpot("C_FR", c4d.Vector(cx, spot_y, -cz), M_BLACK, show_light_wire, root)
            MakeSpot("C_BL", c4d.Vector(-cx, spot_y, cz), M_BLACK, show_light_wire, root)
            MakeSpot("C_BR", c4d.Vector(cx, spot_y, cz), M_BLACK, show_light_wire, root)
            if enable_side_spots:
                dist_z = cz - (-cz)
                if dist_z > 10:
                    seg_z = int(round(dist_z / spot_dist))
                    if seg_z >= 1:
                        step_z = dist_z / float(seg_z)
                        for i in range(1, seg_z): zp = -cz + step_z * i; MakeSpot("SL", c4d.Vector(-cx, spot_y, zp), M_BLACK, show_light_wire, root); MakeSpot("SR", c4d.Vector(cx, spot_y, zp), M_BLACK, show_light_wire, root)
            dist_x = cx - (-cx)
            if dist_x > 10:
                seg_x = int(round(dist_x / spot_dist))
                if seg_x >= 1:
                    step_x = dist_x / float(seg_x)
                    for i in range(1, seg_x): xp = -cx + step_x * i; MakeSpot("SF", c4d.Vector(xp, spot_y, -cz), M_BLACK, show_light_wire, root); MakeSpot("SB", c4d.Vector(xp, spot_y, cz), M_BLACK, show_light_wire, root)
        in_d_base = rd - margin_z*2.0
        in_d_extended = in_d_base + (RECESS_VAL * 2.0) + OVERLAP 
        light_count = light_strip_cnt; light_w = 8.0
        total_light_w = light_count * light_w; total_panel_w = in_d_extended - total_light_w
        panel_w = total_panel_w / float(light_count + 1)
        light_padding = 35.0; real_light_len = in_w - (light_padding * 2.0)
        if real_light_len < 10: real_light_len = 10
        curr_z = -in_d_extended/2.0; ceil_y_center = total_rh - 2.5; light_y_center = total_rh - 4.3; slot_back_y = total_rh - 1.0; panel_extend_w = in_w + (RECESS_VAL * 2.0) + OVERLAP 
        for i in range(light_count + 1):
            p_z = curr_z + panel_w/2.0
            MakeBox("Ceil_Panel", c4d.Vector(panel_extend_w, 5, panel_w), c4d.Vector(0, ceil_y_center, p_z), M_WHITE, root)
            curr_z += panel_w
            if i < light_count:
                l_z = curr_z + light_w/2.0
                MakeBox("Slot_Back", c4d.Vector(real_light_len + 2.0, 2, light_w), c4d.Vector(0, slot_back_y, l_z), M_BLACK, root)
                MakeBox("Light_Strip", c4d.Vector(real_light_len, 1, light_w), c4d.Vector(0, light_y_center, l_z), M_LIGHT_LINEAR, root)
                filler_w = light_padding + RECESS_VAL + OVERLAP
                fx_left = (-in_w/2.0 - RECESS_VAL) + filler_w/2.0 - (OVERLAP/2.0); fx_right = -fx_left 
                MakeBox("Filler_L", c4d.Vector(filler_w, 5, light_w), c4d.Vector(fx_left, ceil_y_center, l_z), M_WHITE, root)
                MakeBox("Filler_R", c4d.Vector(filler_w, 5, light_w), c4d.Vector(fx_right, ceil_y_center, l_z), M_WHITE, root)
                curr_z += light_w
    elif ct == 2: MakeBox("Top", c4d.Vector(rw,5,rd), c4d.Vector(0, clear_h + 2.5, 0), "Pro_Wall_White", root)
    elif ct == 1: MakeBox("Ceil", c4d.Vector(rw,10,rd), c4d.Vector(0, clear_h + 5.0, 0), "Pro_Wall_White", root)
    return root
"""
        gen[c4d.OPYTHON_CODE] = script_code
        doc.InsertObject(gen)
        c4d.EventAdd()

    def LoadFavorites(self):
        if os.path.exists(self.fav_file_path):
            try:
                with open(self.fav_file_path, 'r') as f:
                    self.favorites = set(json.load(f))
            except: pass

    def SaveFavorites(self):
        try:
            fav_dir = os.path.dirname(self.fav_file_path)
            if fav_dir and not os.path.isdir(fav_dir):
                os.makedirs(fav_dir)
            with open(self.fav_file_path, 'w') as f:
                json.dump(list(self.favorites), f)
        except: pass

    def _get_default_model_library_dir(self):
        return LIBRARY_PATH

    def _is_valid_model_library_path(self, path):
        if path is None:
            return False
        text = str(path).strip()
        return text not in ("", "null", "undefined", "None")

    def _ensure_model_library_dir(self, path, show_error=False):
        if not self._is_valid_model_library_path(path):
            return False
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
            return os.path.isdir(path) and os.access(path, os.R_OK | os.W_OK)
        except Exception as e:
            print("[Model Library] 目录不可用: %s, error=%s" % (str(path), str(e)))
            if show_error:
                gui.MessageDialog("模型库目录创建失败，请检查权限。")
            return False

    def _get_model_library_dir(self):
        custom_path = ""
        try:
            custom_path = str(self.admin_config.get("modelLibraryPath") or "").strip()
        except Exception:
            custom_path = ""
        if self._is_valid_model_library_path(custom_path):
            if self._ensure_model_library_dir(custom_path, show_error=False):
                return custom_path
            print("[Model Library] 自定义模型库路径不可用，回退默认目录: " + custom_path)
        return self._get_default_model_library_dir()

    def _set_model_library_dir(self, path, persist=False):
        self.asset_path = path
        self.fav_file_path = os.path.join(self.asset_path, FAV_FILE_NAME)
        self.favorites = set()
        self.LoadFavorites()
        if persist:
            self.admin_config["modelLibraryPath"] = path
            self._admin_save_config()
        self._update_model_library_path_text()

    def _update_model_library_path_text(self):
        try:
            self.SetString(ID_ASSET_PATH_TEXT, "当前模型库路径：" + str(self.asset_path))
        except Exception:
            pass

    def _update_model_library_count_text(self, count=None):
        if count is None:
            count = self.asset_display_count
        try:
            self.SetString(ID_ASSET_COUNT_TEXT, "模型数量：" + str(int(count)))
        except Exception:
            pass

    def _show_model_library_refresh_status(self):
        count = int(getattr(self, "asset_display_count", 0))
        if count > 0:
            c4d.StatusSetText("模型库刷新完成，共加载 " + str(count) + " 个模型")
        else:
            c4d.StatusSetText("模型库刷新完成，未发现模型")

    def _select_model_library_dir(self):
        folder = storage.LoadDialog(title="选择模型库位置", flags=c4d.FILESELECT_DIRECTORY)
        if not folder:
            print("[Model Library] 用户取消选择模型库位置")
            return
        if not self._ensure_model_library_dir(folder, show_error=True):
            return
        self._set_model_library_dir(folder, persist=True)
        self.ScanAndLoad()
        gui.MessageDialog("模型库位置已更新。")

    def _open_model_library_dir(self):
        path = self._get_model_library_dir()
        if not self._ensure_model_library_dir(path, show_error=True):
            return
        self._set_model_library_dir(path, persist=False)
        try:
            if sys.platform.startswith("win") and hasattr(os, "startfile"):
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as e:
            print("[Model Library] 打开文件夹失败: " + str(e))
            gui.MessageDialog("无法打开模型库文件夹，请检查路径。")

    def ToggleFavorite(self, index):
        if 0 <= index < len(self.user_area.assets):
            item = self.user_area.assets[index]
            fname = item['name']
            if fname in self.favorites:
                self.favorites.remove(fname)
                item['is_fav'] = False
            else:
                self.favorites.add(fname)
                item['is_fav'] = True
            self.SaveFavorites()
            self.user_area.Redraw()
            if self.GetBool(ID_ASSET_CHK_ONLY_FAV):
                self.ApplyAssetFilter()

    def ScanAndLoad(self):
        self.asset_path = self._get_model_library_dir()
        self.fav_file_path = os.path.join(self.asset_path, FAV_FILE_NAME)
        self._update_model_library_path_text()
        if not os.path.exists(self.asset_path):
            self.full_data_cache = []
            self.ApplyAssetFilter()
            return
        self.full_data_cache =[] 
        limit = 500; count = 0
        seen_model_dirs = set()

        def find_preview_image(root, files, model_name, c4d_filename):
            current_files_map = {f.lower(): f for f in files}
            candidates = []
            folder_base = str(model_name or "").lower()
            file_base = os.path.splitext(c4d_filename)[0].lower()
            for base_name in (folder_base, file_base):
                if not base_name:
                    continue
                candidates.extend([base_name + ".png", base_name + ".jpg", base_name + ".jpeg"])
            for candidate in candidates:
                if candidate in current_files_map:
                    return os.path.join(root, current_files_map[candidate])
            for f_lower, f_real in current_files_map.items():
                if f_lower.endswith(('.png', '.jpg', '.jpeg')):
                    return os.path.join(root, f_real)
            return None

        def add_model(root, files, filename, display_name):
            nonlocal count
            if count >= limit:
                return
            file_path = os.path.join(root, filename)
            img_path = find_preview_image(root, files, display_name, filename)
            bmp = None
            if img_path: bmp = SafeLoadBitmap(img_path)
            self.full_data_cache.append({
                "path": file_path,
                "bmp": bmp,
                "name": display_name,
                "is_fav": display_name in self.favorites
            })
            count += 1

        for root, dirs, files in os.walk(self.asset_path):
            c4d_files = sorted([f for f in files if f.lower().endswith('.c4d')], key=lambda x: x.lower())
            if not c4d_files:
                continue

            if os.path.abspath(root) == os.path.abspath(self.asset_path):
                for filename in c4d_files:
                    add_model(root, files, filename, filename)
                    if count >= limit: break
            else:
                dir_key = os.path.abspath(root)
                if dir_key not in seen_model_dirs:
                    seen_model_dirs.add(dir_key)
                    add_model(root, files, c4d_files[0], os.path.basename(root))
            if count >= limit: break
        self.ApplyAssetFilter()

    def ApplyAssetFilter(self):
        search_txt = self.GetString(ID_ASSET_TXT_SEARCH).lower()
        only_fav = self.GetBool(ID_ASSET_CHK_ONLY_FAV)
        filtered_data =[]
        for item in self.full_data_cache:
            if search_txt and search_txt not in item['name'].lower(): continue
            if only_fav and item['name'] not in self.favorites: continue
            item['is_fav'] = item['name'] in self.favorites
            filtered_data.append(item)
        self.asset_display_count = len(filtered_data)
        self._update_model_library_count_text(self.asset_display_count)
        self.user_area.UpdateAssets(filtered_data)
        self.LayoutChanged(ID_ASSET_SCROLL_GRP)

    def LoadAsset(self, path):
        doc = c4d.documents.GetActiveDocument()
        if not doc: return
        target_objs = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
        is_replace_mode = len(target_objs) > 0
        do_size_match = self.GetBool(ID_ASSET_CHK_SIZE)
        c4d.CallCommand(12113) 
        
        if not os.path.exists(path):
            gui.MessageDialog(f"文件不存在：{path}")
            return
        c4d.StatusSetText(f"正在读取... {os.path.basename(path)}")
        
        def RecursivelyRelink(op, old_mats_list, new_mats_list):
            if not op: return
            tags = op.GetTags()
            for t in tags:
                if t.CheckType(c4d.Ttexture):
                    used_mat = t.GetMaterial()
                    if used_mat:
                        try:
                            idx = old_mats_list.index(used_mat)
                            if 0 <= idx < len(new_mats_list):
                                t.SetMaterial(new_mats_list[idx])
                        except ValueError: pass
            for child in op.GetChildren():
                RecursivelyRelink(child, old_mats_list, new_mats_list)

        try:
            temp_doc = c4d.documents.LoadDocument(path, c4d.SCENEFILTER_OBJECTS | c4d.SCENEFILTER_MATERIALS)
            if not temp_doc: return
            source_objs = temp_doc.GetObjects()
            source_mats = temp_doc.GetMaterials()
            if not source_objs: return

            doc.StartUndo()
            cloned_mats =[]
            for mat in source_mats:
                new_mat = mat.GetClone()
                doc.InsertMaterial(new_mat)
                doc.AddUndo(c4d.UNDOTYPE_NEW, new_mat)
                cloned_mats.append(new_mat)
            if cloned_mats: FixTexturePaths(cloned_mats, path, self._get_model_library_dir())
                
            seed_obj = source_objs[0].GetClone()
            RecursivelyRelink(seed_obj, source_mats, cloned_mats)
            
            if is_replace_mode:
                for target in target_objs:
                    new_op = seed_obj.GetClone()
                    doc.InsertObject(new_op)
                    doc.AddUndo(c4d.UNDOTYPE_NEW, new_op)
                    ProcessReplacement(doc, new_op, target, do_size_match)
                    doc.AddUndo(c4d.UNDOTYPE_DELETE, target)
                    target.Remove()
                c4d.StatusSetText(f"成功替换 {len(target_objs)} 个对象")
            else:
                doc.InsertObject(seed_obj)
                doc.AddUndo(c4d.UNDOTYPE_NEW, seed_obj)
                mg = seed_obj.GetMg()
                mg.off = c4d.Vector(0, 0, 0)
                seed_obj.SetMg(mg)
                doc.SetActiveObject(seed_obj, c4d.SELECTION_NEW)
                c4d.StatusSetText("导入完成")
        except Exception as e:
            traceback.print_exc()
        finally:
            doc.EndUndo()
            c4d.EventAdd()
            if 'temp_doc' in locals() and temp_doc:
                c4d.documents.KillDocument(temp_doc)

    def Command(self, cid, msg):
        try:
            if cid == ID_ADMIN_OPEN_DIALOG_BTN:
                self._open_admin_auth_dialog()
                return True
            if cid == ID_ADMIN_LOGIN_BTN:
                return self._admin_handle_login_click()
            if cid == ID_ADMIN_LOGOUT_BTN:
                self._admin_logout()
                return True
            if cid == ID_ADMIN_RELOGIN_BTN:
                self._admin_logout()
                self._admin_set_message("请重新输入账号密码登录")
                return True

            if cid in CORE_BUTTON_IDS and not self._admin_ensure_fresh_license():
                gui.MessageDialog(self.core_disabled_reason or "当前未授权，无法使用核心功能。")
                return True

            # --- 基础与样条事件 ---
            if cid == ID_TENSION_VAL:
                t = self.GetFloat(ID_TENSION_VAL)
                self._update_selected_spline_tension(t)
                return True
            if cid == ID_SPL_TYPE_COMBO:
                self._action_update_spline_param(c4d.SPLINEOBJECT_TYPE, self.GetInt32(ID_SPL_TYPE_COMBO))
                return True
            if cid == ID_SPL_CLOSE_CHK:
                self._action_update_spline_param(c4d.SPLINEOBJECT_CLOSED, self.GetBool(ID_SPL_CLOSE_CHK))
                return True
            if cid == ID_SPL_INTER_COMBO:
                self._action_update_spline_param(c4d.SPLINEOBJECT_INTERPOLATION, self.GetInt32(ID_SPL_INTER_COMBO))
                return True
            if cid == ID_SPL_SUB_VAL:
                self._action_update_spline_param(c4d.SPLINEOBJECT_SUB, self.GetInt32(ID_SPL_SUB_VAL))
                return True
            if cid == ID_EXTRUDE_DEPTH:
                d = self.GetFloat(ID_EXTRUDE_DEPTH)
                slider_max = 200.0
                if d > slider_max: slider_max = d
                self.SetFloat(ID_EXTRUDE_SLIDER, d, min=0.0, max=slider_max, step=1.0)
                self._action_apply_depth_to_selected()
                return True
            if cid == ID_EXTRUDE_SLIDER:
                d = self.GetFloat(ID_EXTRUDE_SLIDER)
                self.SetFloat(ID_EXTRUDE_DEPTH, d)
                self._action_apply_depth_to_selected()
                return True
            if cid == ID_SPLINE_BTN:
                f = storage.LoadDialog(flags=c4d.FILESELECT_DIRECTORY)
                if f: self.SetString(ID_SPLINE_PATH, f)
                return True
            if cid == ID_TEX_BTN:
                f = storage.LoadDialog(flags=c4d.FILESELECT_DIRECTORY)
                if f: self.SetString(ID_TEX_PATH, f)
                return True
            if cid == ID_JSON_WATCH_BTN:
                self._select_json_watch_dir()
                return True
            if cid == ID_BTN_EXTRUDE_FLIP:
                doc = documents.GetActiveDocument()
                doc.StartUndo()
                for obj in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN):
                    if obj.GetType() == C4D_EXTRUDE_TYPEID:
                        doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                        try: 
                            cur = obj[C4D_EXTRUDE_OFFSET_ID]
                            obj[C4D_EXTRUDE_OFFSET_ID] = -cur
                        except: pass
                doc.EndUndo()
                c4d.EventAdd()
                return True

            # --- Super Align 事件绑定 ---
            # 独立多点射线探测
            if cid == ID_BTN_RAY_LEFT:    self._action_raycast_move(0, -1); return True
            if cid == ID_BTN_RAY_RIGHT:   self._action_raycast_move(0, 1); return True
            if cid == ID_BTN_RAY_UP:      self._action_raycast_move(1, 1); return True
            if cid == ID_BTN_RAY_DOWN:    self._action_raycast_move(1, -1); return True
            if cid == ID_BTN_RAY_FRONT:   self._action_raycast_move(2, -1); return True
            if cid == ID_BTN_RAY_BACK:    self._action_raycast_move(2, 1); return True

            # 九宫格多对象对齐
            if cid in[ID_BTN_NW, ID_BTN_N, ID_BTN_NE, ID_BTN_W, ID_BTN_C, ID_BTN_E, 
                       ID_BTN_SW, ID_BTN_S, ID_BTN_SE, ID_BTN_Z_FRONT, ID_BTN_Z_MID, ID_BTN_Z_BACK]:
                is_surface = self.GetBool(ID_CHK_SURFACE_MODE)
                if cid == ID_BTN_NW:   self._action_align_multi(-1, 1, None, is_surface)
                elif cid == ID_BTN_NE: self._action_align_multi(1, 1, None, is_surface)
                elif cid == ID_BTN_SW: self._action_align_multi(-1, -1, None, is_surface)
                elif cid == ID_BTN_SE: self._action_align_multi(1, -1, None, is_surface)
                elif cid == ID_BTN_N:  self._action_align_multi(0, 1, None, is_surface)
                elif cid == ID_BTN_S:  self._action_align_multi(0, -1, None, is_surface)
                elif cid == ID_BTN_W:  self._action_align_multi(-1, 0, None, is_surface)
                elif cid == ID_BTN_E:  self._action_align_multi(1, 0, None, is_surface)
                elif cid == ID_BTN_C:  self._action_align_multi(0, 0, None, False)
                elif cid == ID_BTN_Z_FRONT: self._action_align_multi(None, None, -1, is_surface)
                elif cid == ID_BTN_Z_MID:   self._action_align_multi(None, None, 0, False)
                elif cid == ID_BTN_Z_BACK:  self._action_align_multi(None, None, 1, is_surface)
                return True
                
            # --- 全方位轴心对齐 (独立轴心) 事件 ---
            if cid in[ID_AXIS_TL, ID_AXIS_TC, ID_AXIS_TR, 
                       ID_AXIS_ML, ID_AXIS_MC, ID_AXIS_MR, 
                       ID_AXIS_BL, ID_AXIS_BC, ID_AXIS_BR]:
                z_mode = self.GetInt32(ID_AXIS_RADIO_Z)
                z_val = 0.0
                if z_mode == ID_AXIS_Z_FRONT: z_val = 1.0
                elif z_mode == ID_AXIS_Z_BACK: z_val = -1.0
                
                direction = None
                if cid == ID_AXIS_TL:   direction = c4d.Vector(-1, 1, z_val)
                elif cid == ID_AXIS_TC: direction = c4d.Vector( 0, 1, z_val)
                elif cid == ID_AXIS_TR: direction = c4d.Vector( 1, 1, z_val)
                elif cid == ID_AXIS_ML: direction = c4d.Vector(-1, 0, z_val)
                elif cid == ID_AXIS_MC: direction = c4d.Vector( 0, 0, z_val)
                elif cid == ID_AXIS_MR: direction = c4d.Vector( 1, 0, z_val)
                elif cid == ID_AXIS_BL: direction = c4d.Vector(-1,-1, z_val)
                elif cid == ID_AXIS_BC: direction = c4d.Vector( 0,-1, z_val)
                elif cid == ID_AXIS_BR: direction = c4d.Vector( 1,-1, z_val)

                if direction is not None:
                    self._action_align_axis(direction)
                return True

            # 基础微调对齐
            if cid == ID_BTN_DROP_FLOOR:
                self._action_drop_to_floor()
                return True
            if cid == ID_BTN_STAND_UP:
                self._action_stand_up()
                return True
            if cid == ID_BTN_CENTER_X:
                self._action_center_x()
                return True
            if cid == ID_BTN_RESET_PSR:
                self._action_reset_psr()
                return True
            if cid == ID_BTN_MOV_X_ADD:
                self._action_move_selection(c4d.Vector(self.GetFloat(ID_MOVE_DIST_VAL), 0, 0))
                return True
            if cid == ID_BTN_MOV_X_SUB:
                self._action_move_selection(c4d.Vector(-self.GetFloat(ID_MOVE_DIST_VAL), 0, 0))
                return True
            if cid == ID_BTN_MOV_Y_ADD:
                self._action_move_selection(c4d.Vector(0, self.GetFloat(ID_MOVE_DIST_VAL), 0))
                return True
            if cid == ID_BTN_MOV_Y_SUB:
                self._action_move_selection(c4d.Vector(0, -self.GetFloat(ID_MOVE_DIST_VAL), 0))
                return True
            if cid == ID_BTN_MOV_Z_ADD:
                self._action_move_selection(c4d.Vector(0, 0, self.GetFloat(ID_MOVE_DIST_VAL)))
                return True
            if cid == ID_BTN_MOV_Z_SUB:
                self._action_move_selection(c4d.Vector(0, 0, -self.GetFloat(ID_MOVE_DIST_VAL)))
                return True
            
            # --- 场景与生成工具 ---
            if cid == ID_BTN_SEL_HIDDEN:
                self._action_select_hidden_objects()
                return True
            if cid == ID_BTN_SEL_TEXTURED:
                self._action_select_textured_objects()
                return True
            if cid == ID_BTN_SMART_MERGE:
                self._action_smart_merge_color()
                return True
            if cid == ID_BTN_SIMPLE_EXTRUDE:
                 self._action_simple_extrude_selected()
                 return True
            if cid == ID_BTN_CONNECT_DELETE:
                c4d.CallCommand(16768)
                return True
            if cid == ID_BTN_AXIS_CENTER:
                c4d.CallCommand(1011982)
                return True
            if cid == ID_BTN_APPLY_TEX:
                self._apply_texture_manual()
                return True
            if cid == ID_BTN_APPLY_DEPTH:
                self._action_apply_depth_to_selected()
                return True
            if cid == ID_BTN_BAKE_UVW:
                self._bake_uvw_for_selection()
                return True
            if cid == ID_BTN_ACRY_GENERATE:
                self._action_run_acrylic_generate()
                return True

            # 广告字事件
            if cid in[ID_BTN_SIGN_BACK, ID_BTN_SIGN_FRONT, ID_BTN_SIGN_CRYSTAL, ID_BTN_SIGN_DUAL]:
                doc = documents.GetActiveDocument()
                targets = Signage_GetTargets(doc)
                if not targets:
                    gui.MessageDialog("请先选中包含样条的对象！")
                    return True
                
                color_data = self.GetColorField(ID_SIGN_COLOR)
                col = color_data['color']
                
                # 读取输入(mm) 转 cm
                raw_f = self.GetFloat(ID_SIGN_THICK_F)
                raw_b = self.GetFloat(ID_SIGN_THICK_B)
                user_f = raw_f / 10.0
                user_b = raw_b / 10.0
                
                doc.StartUndo()
                if cid == ID_BTN_SIGN_BACK: # 背发光 (默认: 前3cm 后1cm)
                    f = user_f if user_f > 0.001 else 3.0
                    b = user_b if user_b > 0.001 else 1.0
                    Gen_Backlit(doc, targets, f, b, col)
                    
                elif cid == ID_BTN_SIGN_FRONT: # 正发光 (默认: 前0.5cm 后3cm)
                    f = user_f if user_f > 0.001 else 0.5
                    b = user_b if user_b > 0.001 else 3.0
                    Gen_Frontlit(doc, targets, f, b, col)
                    
                elif cid == ID_BTN_SIGN_CRYSTAL: # 水晶字 (默认: 前0.3cm 后1cm)
                    f = user_f if user_f > 0.001 else 0.3
                    b = user_b if user_b > 0.001 else 1.0
                    Gen_Crystal(doc, targets, f, b, col)
                    
                elif cid == ID_BTN_SIGN_DUAL: # 正背发 (默认: 前0.5cm 中3cm)
                    f = user_f if user_f > 0.001 else 0.5
                    b = user_b if user_b > 0.001 else 3.0
                    Gen_DualLit(doc, targets, f, b, col)
                
                doc.EndUndo()
                c4d.EventAdd()
                return True

            if cid == ID_BTN_OPEN_GROOVE:
                open_groove_dialog()
                return True
        
            if cid == ID_CAP_SIDE_COMBO:
                self._cap_mode = 2 if self._cap_mode == 1 else 1
                new_sel_name = "C1" if self._cap_mode == 1 else "C2"
                self.SetString(ID_CAP_SIDE_COMBO, f"{new_sel_name} ({'前' if self._cap_mode == 1 else '后'}封盖)")
                doc = documents.GetActiveDocument()
                sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
                if sel:
                    doc.StartUndo()
                    for obj in sel:
                        for tag in obj.GetTags():
                            if tag.CheckType(c4d.Ttexture):
                                if obj.GetType() == C4D_EXTRUDE_TYPEID:
                                    doc.AddUndo(c4d.UNDOTYPE_CHANGE, tag)
                                    tag[c4d.TEXTURETAG_RESTRICTION] = new_sel_name
                                    tag.Message(c4d.MSG_UPDATE)
                    doc.EndUndo()
                    c4d.EventAdd()
                return True
            
            # --- 主功能与生成器事件 ---
            if cid == ID_IMPORT_BTN:
                self._do_import()
                return True

            if cid == ID_REPLACE_BTN:
                self._do_import(is_hot_replace=True)
                return True

            if cid == ID_CHECK_UPDATE_BTN:
                self._action_check_update()
                return True

            if cid in (ID_ROOM_CEILING_PREVIEW, ID_ROOM_CEILING_GENERATE):
                self._action_room_ceiling(preview=cid == ID_ROOM_CEILING_PREVIEW)
                return True
            if cid == ID_BTN_GEN_CEILING:
             self._action_generate_ceiling()
             return True
            if cid in (ID_STAIR_ADD, ID_STAIR_REMOVE):
                self._action_edit_stair_segments(remove=cid == ID_STAIR_REMOVE)
                return True
            if cid == ID_BTN_GEN_STAIRS:
                self._action_generate_stairs()
                return True
            if cid == ID_BTN_GEN_OPENING:
                self._action_generate_opening()
                return True
            if cid == ID_OPENING_PRESET:
                preset = self.GetInt32(ID_OPENING_PRESET)
                if preset not in range(len(OPENING_PRESETS)):
                    return True
                width,height = GetOpeningDefaultSize(preset)
                self.SetFloat(ID_OPENING_WIDTH,width)
                self.SetFloat(ID_OPENING_HEIGHT,height)
                if preset in (13,14,15,16):
                    self.SetFloat(ID_OPENING_DEPTH,24.0)
                self.opening_preview.SetPreset(preset)
                return True
            
            # [触发] 智能展厅生成
            if cid == ID_BTN_GEN_SMART_ROOM:
                doc = c4d.documents.GetActiveDocument()
                CreateSmartRoom(doc)
                return True

# ==========================================
            #[新增触发] 智能弯曲墙体生成
            # ==========================================
            if cid == ID_BTN_CURVED_WALL:
                doc = c4d.documents.GetActiveDocument()
                sel = doc.GetActiveObjects(0) 
                
                if len(sel) < 2: 
                    gui.MessageDialog("请至少选择 2 个对象！\n1. 样条线\n2. 墙体/挤压对象")
                    return True
                
                spline = None
                # 使用 list() 绕过系统截断 Bug
                wall_parts = list() 
                
                for obj in sel:
                    if obj.GetInfo() & c4d.OBJECT_ISSPLINE:
                        if spline is None: 
                            spline = obj
                        else: 
                            wall_parts.append(obj)
                    else:
                        wall_parts.append(obj)
                
                if not spline:
                    gui.MessageDialog("未找到样条线！")
                    return True
                
                if len(wall_parts) == 0:
                    gui.MessageDialog("未找到墙体对象！")
                    return True
                
                mode = self.GetInt32(ID_CURVED_WALL_MODE)
                doc.StartUndo()
                CreateCurvedWall(doc, wall_parts, spline, mode)
                doc.EndUndo()
                c4d.EventAdd()
                return True

            # --- 资产库事件 ---
            if cid == ID_ASSET_BTN_CHOOSE_DIR:
                self._select_model_library_dir()
                return True
            if cid == ID_ASSET_BTN_OPEN_DIR:
                self._open_model_library_dir()
                return True
            if cid == ID_ASSET_BTN_REFRESH: 
                self.ScanAndLoad()
                self._show_model_library_refresh_status()
                return True
            if cid == ID_ASSET_SLIDER_SIZE:
                size = self.GetInt32(ID_ASSET_SLIDER_SIZE)
                self.user_area.UpdateScale(size); self.LayoutChanged(ID_ASSET_SCROLL_GRP)
                return True
            if cid == ID_ASSET_BTN_LOAD:
                idx = self.user_area.GetSelectedIndex()
                if idx != -1: self.LoadAsset(self.user_area.GetAssetPath(idx))
                return True
            if cid == ID_ASSET_TXT_SEARCH:
                self.ApplyAssetFilter()
                return True
            if cid == ID_ASSET_CHK_ONLY_FAV:
                self.ApplyAssetFilter()
                return True
            if cid == ID_CLOSE_BTN:
                self.Close()
                return True

        except Exception as e:
            gui.MessageDialog(f"未知错误:\n{str(e)}\n\n{traceback.format_exc()}")
        return False

# ==============================================================================
# 花花智能建模-C4D端 v1.1 - 内置灯槽模块
# ==============================================================================

GROOVE_DIALOG_ID = 1061042
GROOVE_PLUGIN_NAME = "智能灯槽生成器"
EMISSIVE_SELECTION_NAME = "灯槽发光面"
EMISSIVE_MATERIAL_NAME = "灯槽发光材质"


class GrooveSettingsDialog(gui.GeDialog):
    ID_PERCENT_LABEL = 1001
    ID_PERCENT = 1002
    ID_DEPTH_LABEL = 1003
    ID_DEPTH = 1004
    ID_SIDE_LABEL = 1005
    ID_SIDE = 10054
    ID_ALIGN_LABEL = 1006
    ID_ALIGN_GROUP = 1007
    ID_ALIGN_CENTER = 10050
    ID_ALIGN_FRONT = 10051
    ID_ALIGN_BACK = 10052
    ID_DIR_LABEL = 10060
    ID_DIR_UP = 10061
    ID_DIR_DOWN = 10062
    ID_DIR_LEFT = 10063
    ID_DIR_RIGHT = 10064
    ID_HINT = 10067
    ID_APPLY = 10068
    ID_CURVE_MODE_LABEL = 10069
    ID_CURVE_MODE = 10070
    ID_SIDE_MODE_LABEL = 10071
    ID_SIDE_MODE = 10072
    def __init__(self):
        self.percentage = 30.0
        self.groove_depth = 5.0
        self.side_margin = 10.0
        self.align_mode = 0
        self.dir_up = True
        self.dir_down = False
        self.dir_left = False
        self.dir_right = False
        self.curve_mode = 0
        self.surface_mode = 0

    def CreateLayout(self):
        self.SetTitle("智能灯槽生成器 花花智能建模-C4D端 v1.1")
        self.GroupBegin(id=1000, flags=c4d.BFH_SCALEFIT, cols=1, rows=9)
        self.GroupBorderSpace(15, 15, 15, 15)

        self.GroupBegin(id=1100, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_PERCENT_LABEL, flags=c4d.BFH_LEFT, name="槽边宽度占对象厚度 (%):")
        self.AddEditNumberArrows(id=self.ID_PERCENT, flags=c4d.BFH_SCALEFIT)
        self.GroupEnd()

        self.GroupBegin(id=1101, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_DEPTH_LABEL, flags=c4d.BFH_LEFT, name="灯槽向里开多深 (cm):")
        self.AddEditNumberArrows(id=self.ID_DEPTH, flags=c4d.BFH_SCALEFIT)
        self.GroupEnd()

        self.GroupBegin(id=1102, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_SIDE_LABEL, flags=c4d.BFH_LEFT, name="两端各保留槽口长度 (%):")
        self.AddEditNumberArrows(id=self.ID_SIDE, flags=c4d.BFH_SCALEFIT)
        self.GroupEnd()

        self.GroupBegin(id=1103, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_ALIGN_LABEL, flags=c4d.BFH_LEFT | c4d.BFV_TOP, name="边界计算基准:")
        self.GroupBegin(id=self.ID_ALIGN_GROUP, flags=c4d.BFH_LEFT, cols=1, rows=3)
        self.AddRadioButton(id=self.ID_ALIGN_CENTER, flags=c4d.BFH_LEFT, name="居中 (前后等宽槽)")
        self.AddRadioButton(id=self.ID_ALIGN_FRONT, flags=c4d.BFH_LEFT, name="以前面为基准 (开口向后)")
        self.AddRadioButton(id=self.ID_ALIGN_BACK, flags=c4d.BFH_LEFT, name="以后面为基准 (开口向前)")
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(id=1104, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_DIR_LABEL, flags=c4d.BFH_LEFT | c4d.BFV_TOP, name="灯槽方向:")
        self.GroupBegin(id=10065, flags=c4d.BFH_LEFT, cols=2, rows=2)
        self.GroupBorderSpace(0, 0, 0, 0)
        self.AddButton(id=self.ID_DIR_UP, flags=c4d.BFH_LEFT, initw=120, inith=0, name="上")
        self.AddButton(id=self.ID_DIR_DOWN, flags=c4d.BFH_LEFT, initw=120, inith=0, name="下")
        self.AddButton(id=self.ID_DIR_LEFT, flags=c4d.BFH_LEFT, initw=120, inith=0, name="左")
        self.AddButton(id=self.ID_DIR_RIGHT, flags=c4d.BFH_LEFT, initw=120, inith=0, name="右")
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(id=1105, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_CURVE_MODE_LABEL, flags=c4d.BFH_LEFT, name="模型识别模式:")
        self.AddComboBox(id=self.ID_CURVE_MODE, flags=c4d.BFH_SCALEFIT)
        self.AddChild(self.ID_CURVE_MODE, 0, "标准模式")
        self.AddChild(self.ID_CURVE_MODE, 1, "自动曲面识别")
        self.AddChild(self.ID_CURVE_MODE, 2, "强制曲面模式")
        self.GroupEnd()

        self.GroupBegin(id=1106, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_SIDE_MODE_LABEL, flags=c4d.BFH_LEFT, name="表面选择:")
        self.AddComboBox(id=self.ID_SIDE_MODE, flags=c4d.BFH_SCALEFIT)
        self.AddChild(self.ID_SIDE_MODE, 0, "自动")
        self.AddChild(self.ID_SIDE_MODE, 1, "外侧")
        self.AddChild(self.ID_SIDE_MODE, 2, "内侧")
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(id=10066, flags=c4d.BFH_CENTER, cols=2, rows=1)
        self.AddButton(id=self.ID_APPLY, flags=c4d.BFH_CENTER, initw=160, inith=0, name="执行灯槽")
        self.AddButton(id=c4d.DLG_CANCEL, flags=c4d.BFH_CENTER, initw=100, inith=0, name="关闭")
        self.GroupEnd()

        self.AddStaticText(
            id=self.ID_HINT,
            flags=c4d.BFH_LEFT,
            initw=0,
            inith=0,
            name="平面常用“上”；拱形/弧形顶部常用“上+左+右”。",
        )
        self.GroupEnd()
        return True

    def InitValues(self):
        self.SetFloat(id=self.ID_PERCENT, value=self.percentage, min=1.0, max=99.0, step=1.0)
        self.SetFloat(id=self.ID_DEPTH, value=self.groove_depth, min=0.1, max=1000.0, step=0.5)
        self.SetFloat(id=self.ID_SIDE, value=self.side_margin, min=0.0, max=45.0, step=1.0)
        self.SetBool(self.ID_ALIGN_CENTER, self.align_mode == 0)
        self.SetBool(self.ID_ALIGN_FRONT, self.align_mode == 1)
        self.SetBool(self.ID_ALIGN_BACK, self.align_mode == 2)
        self.SetInt32(self.ID_CURVE_MODE, self.curve_mode)
        self.SetInt32(self.ID_SIDE_MODE, self.surface_mode)
        self._refresh_direction_labels()
        return True

    def _refresh_direction_labels(self):
        self.SetString(self.ID_DIR_UP, ("[x] " if self.dir_up else "[ ] ") + "上")
        self.SetString(self.ID_DIR_DOWN, ("[x] " if self.dir_down else "[ ] ") + "下")
        self.SetString(self.ID_DIR_LEFT, ("[x] " if self.dir_left else "[ ] ") + "左")
        self.SetString(self.ID_DIR_RIGHT, ("[x] " if self.dir_right else "[ ] ") + "右")

    def Command(self, cid, msg):
        if cid == self.ID_ALIGN_CENTER:
            self.SetBool(self.ID_ALIGN_CENTER, True)
            self.SetBool(self.ID_ALIGN_FRONT, False)
            self.SetBool(self.ID_ALIGN_BACK, False)
        elif cid == self.ID_ALIGN_FRONT:
            self.SetBool(self.ID_ALIGN_CENTER, False)
            self.SetBool(self.ID_ALIGN_FRONT, True)
            self.SetBool(self.ID_ALIGN_BACK, False)
        elif cid == self.ID_ALIGN_BACK:
            self.SetBool(self.ID_ALIGN_CENTER, False)
            self.SetBool(self.ID_ALIGN_FRONT, False)
            self.SetBool(self.ID_ALIGN_BACK, True)
        elif cid == self.ID_DIR_UP:
            self.dir_up = not self.dir_up
            self._refresh_direction_labels()
            return True
        elif cid == self.ID_DIR_DOWN:
            self.dir_down = not self.dir_down
            self._refresh_direction_labels()
            return True
        elif cid == self.ID_DIR_LEFT:
            self.dir_left = not self.dir_left
            self._refresh_direction_labels()
            return True
        elif cid == self.ID_DIR_RIGHT:
            self.dir_right = not self.dir_right
            self._refresh_direction_labels()
            return True

        if cid == self.ID_APPLY:
            self.percentage = self.GetFloat(self.ID_PERCENT)
            self.groove_depth = self.GetFloat(self.ID_DEPTH)
            self.side_margin = self.GetFloat(self.ID_SIDE)
            self.curve_mode = self.GetInt32(self.ID_CURVE_MODE)
            self.surface_mode = self.GetInt32(self.ID_SIDE_MODE)

            if self.GetBool(self.ID_ALIGN_CENTER):
                self.align_mode = 0
            elif self.GetBool(self.ID_ALIGN_FRONT):
                self.align_mode = 1
            elif self.GetBool(self.ID_ALIGN_BACK):
                self.align_mode = 2

            if not any((self.dir_up, self.dir_down, self.dir_left, self.dir_right)):
                gui.MessageDialog("请至少选择一个方向：上 / 下 / 左 / 右。")
                return True
            apply_groove_from_dialog(self)
            return True
        elif cid == c4d.DLG_CANCEL:
            self.Close()
        return True


def clean_useless_selections(op):
    tags = op.GetTags()
    used_selections = set()

    for tag in tags:
        if tag.GetType() == c4d.Ttexture:
            restriction = tag[c4d.TEXTURETAG_RESTRICTION]
            if restriction:
                for part in restriction.split(","):
                    used_selections.add(part.strip())

    for tag in reversed(op.GetTags()):
        if tag.GetType() == c4d.Tpolygonselection:
            name = tag.GetName()
            sel = tag.GetBaseSelect()
            if sel.GetCount() == 0 or name not in used_selections:
                if name != EMISSIVE_SELECTION_NAME:
                    tag.Remove()


def remove_previous_groove_tags(op):
    for tag in reversed(op.GetTags()):
        if tag.GetType() == c4d.Ttexture and tag[c4d.TEXTURETAG_RESTRICTION] == EMISSIVE_SELECTION_NAME:
            tag.Remove()
        elif tag.GetType() == c4d.Tpolygonselection and tag.GetName() == EMISSIVE_SELECTION_NAME:
            tag.Remove()


def get_polygon_center(poly, points):
    corners = [poly.a, poly.b, poly.c]
    if poly.c != poly.d:
        corners.append(poly.d)
    center = c4d.Vector(0)
    count = 0
    for idx in corners:
        if 0 <= idx < len(points):
            center += points[idx]
            count += 1
    return center / float(count) if count else c4d.Vector(0)


def get_selection_point_bounds(op, sel):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    xs = []
    ys = []
    zs = []

    for index, poly in enumerate(polys):
        if not sel.IsSelected(index):
            continue
        for point_index in (poly.a, poly.b, poly.c, poly.d):
            if 0 <= point_index < len(points):
                point = points[point_index]
                xs.append(point.x)
                ys.append(point.y)
                zs.append(point.z)

    if not xs:
        return None

    return {
        "x": (min(xs), max(xs)),
        "y": (min(ys), max(ys)),
        "z": (min(zs), max(zs)),
    }


def get_local_plane_axes(local_dir_vec):
    abs_components = [
        ("x", abs(local_dir_vec.x)),
        ("y", abs(local_dir_vec.y)),
        ("z", abs(local_dir_vec.z)),
    ]
    abs_components.sort(key=lambda item: item[1], reverse=True)
    normal_axis = abs_components[0][0]
    plane_axes = [axis for axis in ("x", "y", "z") if axis != normal_axis]
    return plane_axes


def get_axis_vector(axis_name):
    if axis_name == "x":
        return c4d.Vector(1, 0, 0)
    if axis_name == "y":
        return c4d.Vector(0, 1, 0)
    return c4d.Vector(0, 0, 1)


def get_object_bounds(op):
    points = op.GetAllPoints()
    if not points:
        return None

    xs = [point.x for point in points]
    ys = [point.y for point in points]
    zs = [point.z for point in points]
    return {
        "x": (min(xs), max(xs)),
        "y": (min(ys), max(ys)),
        "z": (min(zs), max(zs)),
    }


def get_object_center(op):
    bounds = get_object_bounds(op)
    if not bounds:
        return c4d.Vector(0)
    return c4d.Vector(
        (bounds["x"][0] + bounds["x"][1]) * 0.5,
        (bounds["y"][0] + bounds["y"][1]) * 0.5,
        (bounds["z"][0] + bounds["z"][1]) * 0.5,
    )


def get_side_margin_scale(op, sel, local_dir_vec, side_margin_percent):
    bounds = get_object_bounds(op)
    if not bounds:
        return None

    plane_axes = get_local_plane_axes(local_dir_vec)
    spans = []
    for axis in plane_axes:
        min_v, max_v = bounds[axis]
        spans.append((axis, max_v - min_v))

    if not spans:
        return None

    spans.sort(key=lambda item: item[1], reverse=True)
    major_axis, major_span = spans[0]
    if major_span <= 0.001:
        return None

    clamped_percent = max(0.0, min(side_margin_percent, 45.0))
    scale = max(0.05, 1.0 - (clamped_percent * 2.0 / 100.0))
    return major_axis, scale


def get_bounds_for_selected_polygons(op, sel):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    xs = []
    ys = []
    zs = []

    for index, poly in enumerate(polys):
        if not sel.IsSelected(index):
            continue
        for point_index in (poly.a, poly.b, poly.c, poly.d):
            if 0 <= point_index < len(points):
                point = points[point_index]
                xs.append(point.x)
                ys.append(point.y)
                zs.append(point.z)

    if not xs:
        return None

    return {
        "x": (min(xs), max(xs)),
        "y": (min(ys), max(ys)),
        "z": (min(zs), max(zs)),
    }


def get_side_margin_axis_for_selection(op, sel, local_dir_vec):
    bounds = get_bounds_for_selected_polygons(op, sel)
    if not bounds:
        return None

    plane_axes = get_local_plane_axes(local_dir_vec)
    spans = []
    for axis in plane_axes:
        min_v, max_v = bounds[axis]
        spans.append((axis, max_v - min_v))

    if not spans:
        return None

    spans.sort(key=lambda item: item[1], reverse=True)
    major_axis, major_span = spans[0]
    if major_span <= 0.001:
        return None
    return major_axis


def trim_selection_by_length(op, sel, local_dir_vec, side_margin_percent):
    original = c4d.BaseSelect()
    sel.CopyTo(original)

    if side_margin_percent <= 0.0:
        return original

    scaled = get_side_margin_scale(op, sel, local_dir_vec, side_margin_percent)
    if not scaled:
        return original

    trimmed = c4d.BaseSelect()
    axis_name, _ = scaled
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    trim_ratio = max(0.0, min(side_margin_percent, 45.0)) / 100.0

    for component in get_polygon_components(op):
        centers = []
        for index in component:
            if not sel.IsSelected(index):
                continue
            center = get_polygon_center(polys[index], points)
            centers.append((index, getattr(center, axis_name)))

        if not centers:
            continue

        values = [value for _, value in centers]
        min_v = min(values)
        max_v = max(values)
        span = max(max_v - min_v, 0.001)
        trim_len = span * trim_ratio

        if trim_len <= 0.0001:
            for index, _ in centers:
                trimmed.Select(index)
            continue

        lower = min_v + trim_len
        upper = max_v - trim_len

        for index, value in centers:
            if lower <= value <= upper:
                trimmed.Select(index)

    if trimmed.GetCount() > 0:
        return trimmed
    return original


def is_curved_multi_direction_selection(op, sel, selected_dirs):
    direction_targets = get_direction_targets(selected_dirs)
    if len(direction_targets) <= 1:
        return False

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    adjacency = build_polygon_adjacency(op)
    considered = 0
    strong = 0
    mid = 0
    smooth_pairs = 0

    for index, poly in enumerate(polys):
        if not sel.IsSelected(index):
            continue
        normal = get_local_polygon_normal(poly, points)
        if normal is None:
            continue

        best_dot = max((normal.Dot(axis) for _, axis in direction_targets), default=-1.0)
        considered += 1
        if best_dot >= 0.78:
            strong += 1
        elif best_dot >= 0.2:
            mid += 1

        for neighbor in adjacency.get(index, ()):
            if neighbor <= index or not sel.IsSelected(neighbor):
                continue
            neighbor_normal = get_local_polygon_normal(polys[neighbor], points)
            if neighbor_normal is None:
                continue
            continuity = normal.Dot(neighbor_normal)
            if 0.2 <= continuity <= 0.98:
                smooth_pairs += 1

    if considered < 6:
        return False
    if smooth_pairs >= max(3, considered // 6):
        return True
    return mid >= max(3, strong // 3)


def trim_selection_by_length_grouped(op, sel, local_dir_vec, side_margin_percent, selected_dirs):
    original = c4d.BaseSelect()
    sel.CopyTo(original)

    if side_margin_percent <= 0.0:
        return original

    direction_groups = classify_selected_polygons(op, sel, selected_dirs)
    non_empty_groups = [indices for indices in direction_groups.values() if indices]
    if len(non_empty_groups) <= 1:
        return trim_selection_by_length(op, sel, local_dir_vec, side_margin_percent)

    # 曲面模型里会有大量法线处于过渡区的面，无法被明确归到上/左/右单一方向。
    # 这时如果强行按方向分组裁切，会把连续灯槽切断，所以回退到整体裁切。
    if is_curved_multi_direction_selection(op, sel, selected_dirs):
        return trim_selection_by_length(op, sel, local_dir_vec, side_margin_percent)

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    trimmed = c4d.BaseSelect()
    trim_ratio = max(0.0, min(side_margin_percent, 45.0)) / 100.0

    for indices in non_empty_groups:
        group_sel = c4d.BaseSelect()
        for index in indices:
            group_sel.Select(index)

        axis_name = get_side_margin_axis_for_selection(op, group_sel, local_dir_vec)
        if axis_name is None:
            for index in indices:
                trimmed.Select(index)
            continue

        values = []
        for index in indices:
            center = get_polygon_center(polys[index], points)
            values.append((index, getattr(center, axis_name)))

        if not values:
            continue

        raw_values = [value for _, value in values]
        min_v = min(raw_values)
        max_v = max(raw_values)
        span = max(max_v - min_v, 0.001)
        trim_len = span * trim_ratio

        if trim_len <= 0.0001:
            for index, _ in values:
                trimmed.Select(index)
            continue

        lower = min_v + trim_len
        upper = max_v - trim_len
        for index, value in values:
            if lower <= value <= upper:
                trimmed.Select(index)

    if trimmed.GetCount() > 0:
        return trimmed
    return original


def get_local_polygon_normal(poly, points):
    if poly.a >= len(points) or poly.b >= len(points) or poly.c >= len(points):
        return None
    v1 = points[poly.b] - points[poly.a]
    v2 = points[poly.c] - points[poly.a]
    cross = v1.Cross(v2)
    if cross.GetLengthSquared() <= 1e-8:
        return None
    return cross.GetNormalized()


def get_direction_targets(selected_dirs):
    targets = []
    if selected_dirs["up"]:
        targets.append(("up", c4d.Vector(0, 1, 0)))
    if selected_dirs["down"]:
        targets.append(("down", c4d.Vector(0, -1, 0)))
    if selected_dirs["left"]:
        targets.append(("left", c4d.Vector(-1, 0, 0)))
    if selected_dirs["right"]:
        targets.append(("right", c4d.Vector(1, 0, 0)))
    return targets


def get_single_selected_direction(selected_dirs):
    targets = get_direction_targets(selected_dirs)
    if len(targets) != 1:
        return None
    return targets[0]


def classify_selected_polygons(op, base_sel, selected_dirs):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    direction_targets = get_direction_targets(selected_dirs)
    grouped = {name: [] for name, _ in direction_targets}

    for index, poly in enumerate(polys):
        if not base_sel.IsSelected(index):
            continue
        normal = get_local_polygon_normal(poly, points)
        if normal is None:
            continue

        best_name = None
        best_dot = 0.0
        for name, axis in direction_targets:
            dot = normal.Dot(axis)
            if dot > best_dot:
                best_dot = dot
                best_name = name

        if best_name and best_dot >= 0.65:
            grouped[best_name].append(index)

    return grouped


def auto_select_polygon_faces(op, world_dir_vec, selected_dirs):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    auto_sel = c4d.BaseSelect()
    direction_targets = get_direction_targets(selected_dirs)
    local_dir_vec = (~op.GetMg()).MulV(world_dir_vec).GetNormalized()

    for index, poly in enumerate(polys):
        normal = get_local_polygon_normal(poly, points)
        if normal is None:
            continue

        # 先排除前后盖帽，只处理真正的四周表面。
        if abs(normal.Dot(local_dir_vec)) > 0.22:
            continue

        for _, axis in direction_targets:
            if normal.Dot(axis) >= 0.42:
                auto_sel.Select(index)
                break

    return auto_sel


def auto_select_polygon_faces_by_position(op, selected_dirs, world_dir_vec=None):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    local_dir_vec = None
    if world_dir_vec is not None:
        local_dir_vec = (~op.GetMg()).MulV(world_dir_vec).GetNormalized()
    auto_sel = c4d.BaseSelect()
    for component in get_polygon_components(op):
        centers = []

        for index in component:
            poly = polys[index]
            if local_dir_vec is not None:
                normal = get_local_polygon_normal(poly, points)
                if normal is None:
                    continue
                if abs(normal.Dot(local_dir_vec)) > 0.22:
                    continue
            center = get_polygon_center(poly, points)
            centers.append((index, center))

        if not centers:
            continue

        xs = [center.x for _, center in centers]
        ys = [center.y for _, center in centers]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        span_x = max(max_x - min_x, 0.001)
        span_y = max(max_y - min_y, 0.001)

        # 曲面/弧面模型通常无法用单一法线阈值识别边缘面，这里退化为按位置带宽来抓边。
        band_x = span_x * 0.28
        band_y = span_y * 0.28

        for index, center in centers:
            matched = False
            if selected_dirs["up"] and center.y >= max_y - band_y:
                matched = True
            if selected_dirs["down"] and center.y <= min_y + band_y:
                matched = True
            if selected_dirs["left"] and center.x <= min_x + band_x:
                matched = True
            if selected_dirs["right"] and center.x >= max_x - band_x:
                matched = True
            if matched:
                auto_sel.Select(index)

    return auto_sel


def get_top_seed_selection(op, selected_dirs):
    direction = get_single_selected_direction(selected_dirs)
    if direction is None:
        return c4d.BaseSelect()

    direction_name, _ = direction
    if direction_name != "up":
        return auto_select_polygon_faces_by_position(op, selected_dirs)

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    if not points or not polys:
        return c4d.BaseSelect()

    centers = [(index, get_polygon_center(poly, points)) for index, poly in enumerate(polys)]
    max_y = max(center.y for _, center in centers)
    min_y = min(center.y for _, center in centers)
    span_y = max(max_y - min_y, 0.001)
    threshold = max_y - (span_y * 0.18)

    seed = c4d.BaseSelect()
    for index, center in centers:
        if center.y >= threshold:
            seed.Select(index)
    return seed


def grow_curve_region_by_crease(op, seed_sel, selected_dirs):
    direction = get_single_selected_direction(selected_dirs)
    if direction is None or seed_sel.GetCount() == 0:
        return seed_sel

    direction_name, axis = direction
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    adjacency = build_polygon_adjacency(op)
    expanded = c4d.BaseSelect()
    normals = {}

    for index, poly in enumerate(polys):
        normals[index] = get_local_polygon_normal(poly, points)
        if seed_sel.IsSelected(index):
            expanded.Select(index)

    frontier = [index for index in range(len(polys)) if seed_sel.IsSelected(index)]
    selected_set = set(frontier)
    # 只有遇到接近 90 度的明显折角才停止，把整条连续曲面尽量吃全。
    crease_limit = 0.0

    while frontier:
        next_frontier = []
        for source in frontier:
            source_normal = normals.get(source)
            if source_normal is None:
                continue

            for neighbor in adjacency.get(source, ()):
                if neighbor in selected_set:
                    continue

                neighbor_normal = normals.get(neighbor)
                if neighbor_normal is None:
                    continue

                continuity = source_normal.Dot(neighbor_normal)
                if continuity >= crease_limit:
                    expanded.Select(neighbor)
                    selected_set.add(neighbor)
                    next_frontier.append(neighbor)
        frontier = next_frontier

    return expanded


def grow_curve_region_multi(op, seed_sel, selected_dirs, world_dir_vec):
    if seed_sel.GetCount() == 0:
        return seed_sel

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    adjacency = build_polygon_adjacency(op)
    direction_targets = get_direction_targets(selected_dirs)
    local_dir_vec = (~op.GetMg()).MulV(world_dir_vec).GetNormalized()
    expanded = c4d.BaseSelect()
    normals = {}

    for index, poly in enumerate(polys):
        normals[index] = get_local_polygon_normal(poly, points)
        if seed_sel.IsSelected(index):
            expanded.Select(index)

    frontier = [index for index in range(len(polys)) if seed_sel.IsSelected(index)]
    selected_set = set(frontier)
    crease_limit = 0.2

    while frontier:
        next_frontier = []
        for source in frontier:
            source_normal = normals.get(source)
            if source_normal is None:
                continue

            for neighbor in adjacency.get(source, ()):
                if neighbor in selected_set:
                    continue

                neighbor_normal = normals.get(neighbor)
                if neighbor_normal is None:
                    continue

                if abs(neighbor_normal.Dot(local_dir_vec)) > 0.22:
                    continue

                best_dot = max((neighbor_normal.Dot(axis) for _, axis in direction_targets), default=-1.0)
                if best_dot < -0.05:
                    continue

                continuity = source_normal.Dot(neighbor_normal)
                if continuity >= crease_limit:
                    expanded.Select(neighbor)
                    selected_set.add(neighbor)
                    next_frontier.append(neighbor)
        frontier = next_frontier

    return expanded


def should_use_curve_mode(op, selected_dirs, auto_detect, force_curve_mode):
    if force_curve_mode:
        return True
    if not auto_detect:
        return False

    direction = get_single_selected_direction(selected_dirs)
    if direction is None:
        return False

    _, axis = direction
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    pos_sel = auto_select_polygon_faces_by_position(op, selected_dirs)
    dots = []

    for index, poly in enumerate(polys):
        if not pos_sel.IsSelected(index):
            continue
        normal = get_local_polygon_normal(poly, points)
        if normal is None:
            continue
        dots.append(normal.Dot(axis))

    if len(dots) < 6:
        return False

    strong = sum(1 for value in dots if value >= 0.72)
    mid = sum(1 for value in dots if 0.12 <= value < 0.72)
    weak = sum(1 for value in dots if value < 0.12)

    # 顶部/侧部同时存在大量中间法线时，通常就是曲面或不规则过渡面。
    return strong > 0 and mid >= max(4, strong // 2) and weak < len(dots)


def get_polygon_edge_keys(poly):
    corners = [poly.a, poly.b, poly.c]
    if poly.c != poly.d:
        corners.append(poly.d)

    edge_keys = []
    count = len(corners)
    for i in range(count):
        a = corners[i]
        b = corners[(i + 1) % count]
        if a == b:
            continue
        edge_keys.append(tuple(sorted((a, b))))
    return edge_keys


def build_polygon_adjacency(op):
    polys = op.GetAllPolygons()
    edge_to_polys = {}
    adjacency = {index: set() for index in range(len(polys))}

    for index, poly in enumerate(polys):
        for edge_key in get_polygon_edge_keys(poly):
            edge_to_polys.setdefault(edge_key, []).append(index)

    for poly_indices in edge_to_polys.values():
        if len(poly_indices) < 2:
            continue
        for source in poly_indices:
            for target in poly_indices:
                if source != target:
                    adjacency[source].add(target)

    return adjacency


def get_polygon_components(op):
    polys = op.GetAllPolygons()
    adjacency = build_polygon_adjacency(op)
    components = []
    visited = set()

    for start in range(len(polys)):
        if start in visited:
            continue
        stack = [start]
        component = []
        visited.add(start)

        while stack:
            current = stack.pop()
            component.append(current)
            for neighbor in adjacency.get(current, ()):
                if neighbor in visited:
                    continue
                visited.add(neighbor)
                stack.append(neighbor)

        components.append(component)

    return components


def get_component_bounds(points, polys, poly_indices):
    xs = []
    ys = []
    zs = []

    for poly_index in poly_indices:
        poly = polys[poly_index]
        for point_index in (poly.a, poly.b, poly.c, poly.d):
            if 0 <= point_index < len(points):
                point = points[point_index]
                xs.append(point.x)
                ys.append(point.y)
                zs.append(point.z)

    if not xs:
        return None

    return {
        "x": (min(xs), max(xs)),
        "y": (min(ys), max(ys)),
        "z": (min(zs), max(zs)),
    }


def get_component_center(points, polys, poly_indices):
    bounds = get_component_bounds(points, polys, poly_indices)
    if not bounds:
        return c4d.Vector(0)
    return c4d.Vector(
        (bounds["x"][0] + bounds["x"][1]) * 0.5,
        (bounds["y"][0] + bounds["y"][1]) * 0.5,
        (bounds["z"][0] + bounds["z"][1]) * 0.5,
    )


def filter_selection_by_surface_mode(op, sel, surface_mode):
    if surface_mode == 0 or sel.GetCount() == 0:
        return sel

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    filtered = c4d.BaseSelect()
    inward_count = 0
    outward_count = 0

    for component in get_polygon_components(op):
        component_center = get_component_center(points, polys, component)

        for index in component:
            if not sel.IsSelected(index):
                continue

            poly = polys[index]
            normal = get_local_polygon_normal(poly, points)
            if normal is None:
                continue

            center = get_polygon_center(poly, points)
            radial = center - component_center
            if radial.GetLengthSquared() <= 1e-8:
                continue

            facing = normal.Dot(radial.GetNormalized())
            if facing > 0.05:
                outward_count += 1
                if surface_mode == 1:
                    filtered.Select(index)
            elif facing < -0.05:
                inward_count += 1
                if surface_mode == 2:
                    filtered.Select(index)

    if filtered.GetCount() == 0:
        return sel
    if surface_mode == 2 and inward_count == 0:
        return sel
    if surface_mode == 1 and outward_count == 0:
        return sel

    return filtered


def expand_selection_for_curved_surfaces(op, base_sel, selected_dirs):
    if base_sel.GetCount() == 0:
        return base_sel

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    direction_targets = get_direction_targets(selected_dirs)
    adjacency = build_polygon_adjacency(op)
    expanded = c4d.BaseSelect()

    for index in range(len(polys)):
        if base_sel.IsSelected(index):
            expanded.Select(index)

    frontier = [index for index in range(len(polys)) if base_sel.IsSelected(index)]
    visited = set(frontier)

    for _ in range(2):
        next_frontier = []
        for source in frontier:
            for neighbor in adjacency.get(source, ()):
                if neighbor in visited:
                    continue
                visited.add(neighbor)

                normal = get_local_polygon_normal(polys[neighbor], points)
                if normal is None:
                    continue

                include = False
                for _, axis in direction_targets:
                    if normal.Dot(axis) >= 0.18:
                        include = True
                        break

                if include:
                    expanded.Select(neighbor)
                    next_frontier.append(neighbor)
        frontier = next_frontier
        if not frontier:
            break

    return expanded


def shrink_selection_to_direction_bands(op, sel, selected_dirs):
    selected_indices = []
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    centers = []

    for index, poly in enumerate(polys):
        if sel.IsSelected(index):
            center = get_polygon_center(poly, points)
            centers.append((index, center))
            selected_indices.append(index)

    if not centers:
        return sel

    xs = [center.x for _, center in centers]
    ys = [center.y for _, center in centers]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    span_x = max(max_x - min_x, 0.001)
    span_y = max(max_y - min_y, 0.001)

    new_sel = c4d.BaseSelect()
    band_x = span_x * 0.35
    band_y = span_y * 0.35

    for index, center in centers:
        matched = False
        if selected_dirs["up"] and center.y >= max_y - band_y:
            matched = True
        if selected_dirs["down"] and center.y <= min_y + band_y:
            matched = True
        if selected_dirs["left"] and center.x <= min_x + band_x:
            matched = True
        if selected_dirs["right"] and center.x >= max_x - band_x:
            matched = True
        if matched:
            new_sel.Select(index)

    if new_sel.GetCount() > 0:
        return new_sel
    return sel


def build_target_selection(op, world_dir_vec, selected_dirs, auto_curve_detect, force_curve_mode, surface_mode):
    dir_count = sum(1 for value in selected_dirs.values() if value)

    auto_sel = auto_select_polygon_faces(op, world_dir_vec, selected_dirs)
    pos_sel = auto_select_polygon_faces_by_position(op, selected_dirs, world_dir_vec)

    # 单方向时优先信任法线识别，避免位置回退把高位侧面也一起吞进去。
    if dir_count == 1:
        if should_use_curve_mode(op, selected_dirs, auto_curve_detect, force_curve_mode):
            seed_sel = get_top_seed_selection(op, selected_dirs)
            curve_sel = grow_curve_region_by_crease(op, seed_sel, selected_dirs)
            if curve_sel.GetCount() > 0:
                return filter_selection_by_surface_mode(op, curve_sel, surface_mode), False
        if auto_sel.GetCount() > 0:
            return filter_selection_by_surface_mode(op, expand_selection_for_curved_surfaces(op, auto_sel, selected_dirs), surface_mode), False
        return filter_selection_by_surface_mode(op, pos_sel, surface_mode), False

    if (
        selected_dirs.get("up")
        and not selected_dirs.get("down")
        and (selected_dirs.get("left") or selected_dirs.get("right"))
    ):
        combined_probe = c4d.BaseSelect()
        polys = op.GetAllPolygons()
        for index in range(len(polys)):
            if auto_sel.IsSelected(index) or pos_sel.IsSelected(index):
                combined_probe.Select(index)

        curve_sel = grow_curve_region_multi(op, combined_probe, selected_dirs, world_dir_vec)
        if curve_sel.GetCount() > 0:
            # 曲面上+左+右时，如果连续生长后的选区明显大于原始并集，
            # 说明中间过渡带被补出来了，这时必须和整体裁切绑定使用。
            if curve_sel.GetCount() > combined_probe.GetCount() or is_curved_multi_direction_selection(op, curve_sel, selected_dirs):
                return filter_selection_by_surface_mode(op, curve_sel, surface_mode), True

    combined = c4d.BaseSelect()
    polys = op.GetAllPolygons()
    for index in range(len(polys)):
        if auto_sel.IsSelected(index) or pos_sel.IsSelected(index):
            combined.Select(index)

    if combined.GetCount() > 0:
        return filter_selection_by_surface_mode(op, combined, surface_mode), False
    if auto_sel.GetCount() > 0:
        return filter_selection_by_surface_mode(op, auto_sel, surface_mode), False
    return filter_selection_by_surface_mode(op, pos_sel, surface_mode), False


def process_single_object(
    op,
    doc,
    percentage,
    groove_depth,
    side_margin,
    align_mode,
    selected_dirs,
    surface_mode,
    emissive_mat,
    auto_curve_detect,
    force_curve_mode,
):
    is_extrude = op.IsInstanceOf(c4d.Oextrude)
    orig_mg = op.GetMg()
    orig_name = op.GetName()

    world_dir_vec = orig_mg.MulV(c4d.Vector(0, 0, 1)).GetNormalized()

    if is_extrude:
        local_dir = c4d.Vector(0, 0, 1)
        if hasattr(c4d, "EXTRUDEOBJECT_DIRECTION"):
            direction = op[c4d.EXTRUDEOBJECT_DIRECTION]
            if direction == getattr(c4d, "EXTRUDEOBJECT_DIRECTION_X", 1):
                local_dir = c4d.Vector(1, 0, 0)
            elif direction == getattr(c4d, "EXTRUDEOBJECT_DIRECTION_Y", 2):
                local_dir = c4d.Vector(0, 1, 0)
        try:
            move_vec = op[c4d.EXTRUDEOBJECT_MOVE]
            if move_vec is not None and move_vec.GetLength() > 0.001:
                local_dir = move_vec.GetNormalized()
        except Exception:
            pass
        world_dir_vec = orig_mg.MulV(local_dir).GetNormalized()

    if not op.IsInstanceOf(c4d.Opolygon):
        orig_mats = doc.GetMaterials()
        orig_tex_tags = [tag.GetClone() for tag in op.GetTags() if tag.GetType() == c4d.Ttexture]

        result = c4d.utils.SendModelingCommand(
            command=c4d.MCOMMAND_CURRENTSTATETOOBJECT,
            list=[op],
            mode=c4d.MODELINGCOMMANDMODE_ALL,
            doc=doc,
        )
        if not result:
            return False, "无法将对象转换为多边形。"

        new_op = result[0]
        if not new_op.IsInstanceOf(c4d.Opolygon):
            join_result = c4d.utils.SendModelingCommand(
                command=c4d.MCOMMAND_JOIN,
                list=[new_op],
                mode=c4d.MODELINGCOMMANDMODE_ALL,
                doc=doc,
            )
            if join_result:
                new_op = join_result[0]
            else:
                return False, "转换后的对象无法合并为多边形。"

        if not new_op or not new_op.IsInstanceOf(c4d.Opolygon):
            return False, "转换后不是多边形对象。"

        current_mg = new_op.GetMg()
        inv_orig_mg = ~orig_mg
        pts = new_op.GetAllPoints()
        for i in range(len(pts)):
            world_p = current_mg * pts[i]
            pts[i] = inv_orig_mg * world_p

        new_op.SetAllPoints(pts)
        new_op.SetMg(orig_mg)
        new_op.InsertAfter(op)
        new_op.SetName(orig_name)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, new_op)
        doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, op)
        op.Remove()
        op = new_op

        for tag in reversed(op.GetTags()):
            if tag.GetType() == c4d.Ttexture:
                tag.Remove()

        for tag in reversed(orig_tex_tags):
            op.InsertTag(tag)

        current_mats = doc.GetMaterials()
        for mat in current_mats:
            if mat not in orig_mats:
                doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, mat)
                mat.Remove()

        bc_opt = c4d.BaseContainer()
        bc_opt[c4d.MDATA_OPTIMIZE_TOLERANCE] = 0.01
        bc_opt[c4d.MDATA_OPTIMIZE_POINTS] = True
        c4d.utils.SendModelingCommand(c4d.MCOMMAND_OPTIMIZE, [op], c4d.MODELINGCOMMANDMODE_ALL, bc_opt, doc)
        c4d.utils.SendModelingCommand(c4d.MCOMMAND_ALIGNNORMALS, [op], c4d.MODELINGCOMMANDMODE_ALL, c4d.BaseContainer(), doc)

    target_sel, force_overall_trim = build_target_selection(op, world_dir_vec, selected_dirs, auto_curve_detect, force_curve_mode, surface_mode)
    if target_sel.GetCount() == 0:
        return False, "没有找到符合方向条件的面。请检查模型朝向，或先手动选面后再运行。"

    doc.AddUndo(c4d.UNDOTYPE_CHANGE, op)
    live_sel = op.GetPolygonS()
    live_sel.DeselectAll()
    target_sel.CopyTo(live_sel)

    pts = op.GetAllPoints()
    polys = op.GetAllPolygons()
    local_dir_vec = (~op.GetMg()).MulV(world_dir_vec).GetNormalized()
    use_full_loop = all(selected_dirs.values())
    min_proj = float("inf")
    max_proj = float("-inf")
    has_pts = False

    for index, poly in enumerate(polys):
        if live_sel.IsSelected(index):
            for idx in (poly.a, poly.b, poly.c, poly.d):
                if idx < len(pts):
                    proj = pts[idx].Dot(local_dir_vec)
                    min_proj = min(min_proj, proj)
                    max_proj = max(max_proj, proj)
                    has_pts = True

    total_depth = (max_proj - min_proj) if has_pts else 10.0
    if total_depth < 0.01:
        total_depth = 10.0

    dynamic_margin = total_depth * (percentage / 2.0)
    bc_inner = c4d.BaseContainer()
    bc_inner[c4d.MDATA_EXTRUDEINNER_OFFSET] = dynamic_margin
    bc_inner[c4d.MDATA_EXTRUDEINNER_PRESERVEGROUPS] = True
    angle_id_inner = getattr(c4d, "MDATA_EXTRUDEINNER_ANGLE", getattr(c4d, "MDATA_EXTRUDEINNER_MAXANGLE", 1134))
    bc_inner[angle_id_inner] = c4d.utils.Rad(181)

    res_inner = c4d.utils.SendModelingCommand(
        command=c4d.ID_MODELING_EXTRUDE_INNER_TOOL,
        list=[op],
        mode=c4d.MODELINGCOMMANDMODE_POLYGONSELECTION,
        bc=bc_inner,
        doc=doc,
    )
    if not res_inner:
        return False, "内挤压失败。"

    if align_mode != 0:
        pts = op.GetAllPoints()
        polys = op.GetAllPolygons()
        live_sel = op.GetPolygonS()
        modified_pts = set()

        shift_vec = -local_dir_vec * dynamic_margin if align_mode == 1 else local_dir_vec * dynamic_margin
        for index, poly in enumerate(polys):
            if live_sel.IsSelected(index):
                for idx in (poly.a, poly.b, poly.c, poly.d):
                    if idx not in modified_pts and idx < len(pts):
                        pts[idx] = pts[idx] + shift_vec
                        modified_pts.add(idx)
        op.SetAllPoints(pts)
        op.Message(c4d.MSG_UPDATE)

    # 四方向全选时默认做完整回形灯槽，不启用两端保留长度。
    if not use_full_loop:
        if force_overall_trim:
            live_sel = trim_selection_by_length(op, op.GetPolygonS(), local_dir_vec, side_margin)
        else:
            live_sel = trim_selection_by_length_grouped(op, op.GetPolygonS(), local_dir_vec, side_margin, selected_dirs)
        op.GetPolygonS().DeselectAll()
        live_sel.CopyTo(op.GetPolygonS())

    bc_extrude = c4d.BaseContainer()
    bc_extrude[c4d.MDATA_EXTRUDE_OFFSET] = -groove_depth
    bc_extrude[c4d.MDATA_EXTRUDE_PRESERVEGROUPS] = True
    angle_id_extrude = getattr(c4d, "MDATA_EXTRUDE_ANGLE", getattr(c4d, "MDATA_EXTRUDE_MAXANGLE", 1144))
    bc_extrude[angle_id_extrude] = c4d.utils.Rad(181)

    res_extrude = c4d.utils.SendModelingCommand(
        command=c4d.ID_MODELING_EXTRUDE_TOOL,
        list=[op],
        mode=c4d.MODELINGCOMMANDMODE_POLYGONSELECTION,
        bc=bc_extrude,
        doc=doc,
    )
    if not res_extrude:
        return False, "开槽挤压失败。"

    bc_opt_final = c4d.BaseContainer()
    bc_opt_final[c4d.MDATA_OPTIMIZE_TOLERANCE] = 0.01
    bc_opt_final[c4d.MDATA_OPTIMIZE_POINTS] = True
    bc_opt_final[c4d.MDATA_OPTIMIZE_POLYGONS] = True
    c4d.utils.SendModelingCommand(c4d.MCOMMAND_OPTIMIZE, [op], c4d.MODELINGCOMMANDMODE_ALL, bc_opt_final, doc)

    remove_previous_groove_tags(op)
    clean_useless_selections(op)

    selection_tag = c4d.BaseTag(c4d.Tpolygonselection)
    selection_tag.SetName(EMISSIVE_SELECTION_NAME)
    tags = op.GetTags()
    last_tag = tags[-1] if tags else None
    op.InsertTag(selection_tag, last_tag)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, selection_tag)

    live_sel = op.GetPolygonS()
    tag_sel = selection_tag.GetBaseSelect()
    live_sel.CopyTo(tag_sel)

    tex_tag = c4d.BaseTag(c4d.Ttexture)
    tex_tag[c4d.TEXTURETAG_MATERIAL] = emissive_mat
    tex_tag[c4d.TEXTURETAG_RESTRICTION] = EMISSIVE_SELECTION_NAME
    tags = op.GetTags()
    last_tag = tags[-1] if tags else None
    op.InsertTag(tex_tag, last_tag)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, tex_tag)
    op.Message(c4d.MSG_UPDATE)
    return True, ""


def get_or_create_emissive_material(doc):
    for mat in doc.GetMaterials():
        if mat.GetName() == EMISSIVE_MATERIAL_NAME:
            return mat

    emissive_mat = c4d.BaseMaterial(c4d.Mmaterial)
    emissive_mat.SetName(EMISSIVE_MATERIAL_NAME)
    emissive_mat[c4d.MATERIAL_USE_COLOR] = False
    emissive_mat[c4d.MATERIAL_USE_LUMINANCE] = True
    emissive_mat[c4d.MATERIAL_LUMINANCE_COLOR] = c4d.Vector(1.0, 0.95, 0.8)
    emissive_mat[c4d.MATERIAL_LUMINANCE_BRIGHTNESS] = 2.0
    doc.InsertMaterial(emissive_mat)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, emissive_mat)
    return emissive_mat


def apply_groove_from_dialog(dialog):
    doc = c4d.documents.GetActiveDocument()
    if doc is None:
        gui.MessageDialog("当前没有活动文档。")
        return False

    objects = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
    if not objects:
        gui.MessageDialog("请先在场景里选中至少一个模型，然后再点“执行灯槽”。")
        return False

    user_percentage = dialog.percentage / 100.0
    user_depth = dialog.groove_depth
    user_side_margin = dialog.side_margin
    user_mode = dialog.align_mode
    selected_dirs = {
        "up": dialog.dir_up,
        "down": dialog.dir_down,
        "left": dialog.dir_left,
        "right": dialog.dir_right,
    }
    surface_mode = dialog.surface_mode
    auto_curve_detect = dialog.curve_mode == 1
    force_curve_mode = dialog.curve_mode == 2

    doc.StartUndo()
    try:
        emissive_mat = get_or_create_emissive_material(doc)
        success_count = 0
        messages = []

        for op in list(objects):
            ok, message = process_single_object(
                op,
                doc,
                user_percentage,
                user_depth,
                user_side_margin,
                user_mode,
                selected_dirs,
                surface_mode,
                emissive_mat,
                auto_curve_detect,
                force_curve_mode,
            )
            if ok:
                success_count += 1
            else:
                messages.append(f"{op.GetName()}: {message}")

        doc.EndUndo()
        c4d.EventAdd()

        if success_count:
            c4d.StatusSetText(f"成功为 {success_count} 个对象生成灯槽。")
        if messages:
            gui.MessageDialog("部分对象未处理成功：\n\n" + "\n".join(messages[:10]))
        return success_count > 0
    except Exception as exc:
        doc.EndUndo()
        gui.MessageDialog(f"执行出错：\n{exc}\n\n详细信息：\n{traceback.format_exc()}")
        return False

_groove_dialog_instance = None

def open_groove_dialog():
    global _groove_dialog_instance
    if _groove_dialog_instance is None:
        _groove_dialog_instance = GrooveSettingsDialog()
    return _groove_dialog_instance.Open(dlgtype=c4d.DLG_TYPE_ASYNC, pluginid=GROOVE_DIALOG_ID, defaultw=560, defaulth=420)


# ==============================================================================
# 插件注册
# ==============================================================================
class HHImportCommand(plugins.CommandData):
    dialog = None
    def Execute(self, doc):
        if self.dialog is None: self.dialog = HHImportDialog()
        return self.dialog.Open(dlgtype=c4d.DLG_TYPE_ASYNC, pluginid=PLUGIN_ID, defaultw=400, defaulth=500)
    def RestoreLayout(self, sec_ref):
        if self.dialog is None: self.dialog = HHImportDialog()
        return self.dialog.Restore(pluginid=PLUGIN_ID, secret=sec_ref)

if __name__ == "__main__":
    plugins.RegisterCommandPlugin(
        id=PLUGIN_ID, 
        str=PLUGIN_DISPLAY_NAME + " v" + CURRENT_VERSION,
        info=0, 
        icon=None, 
        help=PLUGIN_DISPLAY_NAME + " - AI JSON 导入 / 智能建模 / 模型库", 
        dat=HHImportCommand()
    )
