# Vendored Polygon Clipping

`huahua_polybool.py` is the unmodified single-file Python port of PolyBool.

- Upstream: https://github.com/KaivnD/pypolybool
- Revision: `6836f997d774c43d55ad09b8f7be65d95b8021d1`
- License: MIT, included in `huahua_polybool.LICENSE`
- Runtime: Python standard library only; no binary modules or pip installation.

Used only by `huahua_ceiling.py` for irregular ceiling boundaries and clipping.
The source and license are embedded in saved ceiling generators. Local plugin
installation must include this module and its LICENSE beside `plugin_main.pyp`.
