# -*- coding: utf-8 -*-
import c4d
from c4d import gui, plugins, storage, documents, utils, bitmaps
import os
import json
import traceback
import re
import math
import shutil
import tempfile
import time
import ssl
import urllib.request
import urllib.error
import webbrowser
import socket
import getpass
import uuid
import hashlib
import platform as py_platform
import datetime

# ==============================================================================
# 全局配置
# ==============================================================================
LIBRARY_PATH = r"D:\C4D_Auto_Assets" 
FAV_FILE_NAME = "my_favorites.json"
CURRENT_VERSION = "1.2.0"
UPDATE_JSON_URL = "https://raw.githubusercontent.com/luxianghou123-boop/Huahua-C4D-Plugin-Release/main/update.json"
UPDATE_JSON_FALLBACK_URL = "https://github.com/luxianghou123-boop/Huahua-C4D-Plugin-Release/raw/main/update.json"
API_BASE_URL = "http://43.155.144.82"
# 仅本地开发测试时可设 True；正式云端授权测试和发布前必须保持 False。
DEV_DISABLE_AUTH_GATE = False
PLUGIN_CODE = "hh_ai_c4d"
CLIENT_CODE = "c4d_python"
PLUGIN_VERSION = CURRENT_VERSION
ADMIN_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".huahua_c4d_plugin")
ADMIN_CONFIG_FILE = os.path.join(ADMIN_CONFIG_DIR, "config.json")
SHARED_MACHINE_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".huahua_plugin")
SHARED_MACHINE_CONFIG_FILE = os.path.join(SHARED_MACHINE_CONFIG_DIR, "machine_id.json")
DEVICE_ID_SALT = "huahua-c4d-plugin-device-v1"
AUTH_REFRESH_INTERVAL_SECONDS = 10 * 60
HEARTBEAT_INTERVAL_SECONDS = 10 * 60
OFFLINE_GRACE_SECONDS = 24 * 60 * 60
AUTH_REJECT_STATUSES = set([
    "license_disabled",
    "license_expired",
    "expired",
    "disabled",
    "user_disabled",
    "plugin_disabled",
    "device_limit_exceeded",
    "device_limit",
    "session_replaced",
    "machine_replaced",
    "unauthorized",
    "forbidden",
    "no_license",
    "plugin_not_found",
    "token_invalid"
])

# ==============================================================================
# 花花广告设计 v1.2.0
# ==============================================================================

def get_machine_id_file_path():
    try:
        if py_platform.system() == "Windows":
            appdata = os.environ.get("APPDATA")
            if appdata:
                return os.path.join(appdata, "HuahuaPlugin", "machine_id.json")
        return SHARED_MACHINE_CONFIG_FILE
    except Exception:
        return SHARED_MACHINE_CONFIG_FILE

def read_machine_id_file():
    path = get_machine_id_file_path()
    try:
        if not os.path.exists(path):
            return {}
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception as e:
        try:
            print("[Admin Auth] 读取公共 machineId 失败: " + str(e))
        except Exception:
            pass
        return {}

def write_machine_id_file(machine_id, created_at=None):
    path = get_machine_id_file_path()
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        data = {
            "machineId": str(machine_id),
            "createdAt": str(created_at or datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z")
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        try:
            print("[Admin Auth] 写入公共 machineId 失败: " + str(e))
        except Exception:
            pass
        return False

def generate_uuid():
    return str(uuid.uuid4())

def get_or_create_machine_id(fallback_machine_id=""):
    data = read_machine_id_file()
    machine_id = str(data.get("machineId") or "").strip()
    created_at = str(data.get("createdAt") or "").strip()
    if machine_id:
        return machine_id
    machine_id = str(fallback_machine_id or "").strip() or generate_uuid()
    write_machine_id_file(machine_id, created_at or None)
    return machine_id

PLUGIN_ID = 1060004 
ADMIN_AUTH_DIALOG_ID = PLUGIN_ID + 101
ADMIN_REGISTER_DIALOG_ID = PLUGIN_ID + 102
AI_COLOR_DATA_ID = 10599999 
ID_STORED_JSON_DATA = 1060005 
ID_STORED_SCALE_VAL = 1060006

C4D_EXTRUDE_TYPEID    = 5116
C4D_EXTRUDE_OFFSET_ID = 1009
AI_PT_TO_CM = 0.03527778

ID_SPLINEWRAP = 1019221 # 样条约束变形器ID

# --- UI IDs ---
ID_GRP_MAIN            = 1000
ID_RATIO_LABEL         = 1001
ID_RATIO_COMBO         = 1002
ID_KEEP_LAYER          = 1003
ID_AUTO_CLOSE          = 1004
ID_SMART_STACK         = 1005
ID_SPLINE_PATH         = 1006
ID_SPLINE_BTN          = 1007
ID_TEX_PATH            = 1008
ID_TEX_BTN             = 1009
ID_EXTRUDE_ENABLE      = 1010
ID_EXTRUDE_DEPTH       = 1011
ID_EXTRUDE_SLIDER      = 1012
ID_DELETE_SPLINE       = 1013
ID_IMPORT_BTN          = 1014
ID_CLOSE_BTN           = 1015
ID_CHECK_UPDATE_BTN    = 1093
ID_REPLACE_BTN         = 1019
ID_LOAD_PROGRESS_GROUP = 1040
ID_LOAD_PROGRESS_BAR   = 1041
ID_LOAD_PROGRESS_TEXT  = 1042
ID_IMPORT_TO_NEW_DOC   = 1060 
ID_BEVEL_ENABLE        = 1080
ID_BEVEL_RADIUS        = 1081
ID_Z_STAGGER_ENABLE    = 1082
ID_Z_STEP_VAL          = 1083
ID_SPL_TYPE_COMBO      = 1100
ID_SPL_CLOSE_CHK       = 1101
ID_SPL_INTER_COMBO     = 1102
ID_SPL_SUB_VAL         = 1103

# 亚克力部分 IDs
ID_ACRY_DEPTH_LABEL    = 1104
ID_ACRY_DEPTH_INPUT    = 1105
ID_ACRY_DEPTH_DIR      = 1106
ID_ACRY_SIDE_GROUP     = 1110
ID_ACRY_CHK_T          = 1111
ID_ACRY_CHK_B          = 1112
ID_ACRY_CHK_L          = 1113
ID_ACRY_CHK_R          = 1114
ID_ACRY_SHELL_LABEL    = 1120
ID_ACRY_SHELL_INPUT    = 1121
ID_BTN_ACRY_GENERATE   = 1130

# 广告字工艺 IDs
ID_SIGN_GRP_MAIN       = 5100
ID_SIGN_COLOR          = 5101
ID_SIGN_THICK_F        = 5102
ID_SIGN_THICK_B        = 5103
ID_BTN_SIGN_BACK       = 5104
ID_BTN_SIGN_FRONT      = 5105
ID_BTN_SIGN_CRYSTAL    = 5106
ID_BTN_SIGN_DUAL       = 5107
ID_BTN_OPEN_GROOVE     = 5108

ID_BTN_SMART_MERGE     = 1016 
ID_BTN_SIMPLE_EXTRUDE  = 1027 
ID_BTN_CONNECT_DELETE  = 1017
ID_BTN_APPLY_DEPTH     = 1018
ID_BTN_AXIS_CENTER     = 1020
ID_BTN_APPLY_TEX       = 1021
ID_CAP_SIDE_COMBO      = 1022
ID_BTN_EXTRUDE_FLIP    = 1023
ID_BTN_BAKE_UVW        = 1024
ID_IMPORT_COLOR        = 1025
ID_BTN_APPLY_COLOR_DATA = 1026 
ID_BTN_SEL_HIDDEN      = 1061 
ID_BTN_SEL_TEXTURED    = 1062 
ID_TENSION_VAL         = 1070
ID_BTN_DROP_FLOOR      = 1030 
ID_BTN_STAND_UP        = 1031 
ID_BTN_CENTER_X        = 1032 
ID_BTN_RESET_PSR       = 1033 

ID_MOVE_DIST_VAL       = 1050
ID_BTN_MOV_X_SUB       = 1051 
ID_BTN_MOV_X_ADD       = 1052 
ID_BTN_MOV_Y_SUB       = 1053 
ID_BTN_MOV_Y_ADD       = 1054 
ID_BTN_MOV_Z_SUB       = 1055 
ID_BTN_MOV_Z_ADD       = 1056
ID_GAMMA_CORRECT       = 1090
ID_JSON_WATCH_BTN      = 1091
ID_JSON_WATCH_STATUS   = 1092

ID_ADMIN_GROUP         = 12000
ID_ADMIN_ACCOUNT       = 12001
ID_ADMIN_PASSWORD      = 12002
ID_ADMIN_LOGIN_BTN     = 12003
ID_ADMIN_LOGOUT_BTN    = 12004
ID_ADMIN_RELOGIN_BTN   = 12005
ID_ADMIN_BACKEND_TEXT  = 12006
ID_ADMIN_USER_TEXT     = 12007
ID_ADMIN_LICENSE_TEXT  = 12008
ID_ADMIN_PLAN_TEXT     = 12009
ID_ADMIN_DEVICE_TEXT   = 12010
ID_ADMIN_MESSAGE_TEXT  = 12011
ID_ADMIN_UPDATE_TEXT   = 12012
ID_ADMIN_OPEN_DIALOG_BTN = 12013
ID_ADMIN_REMAINING_TEXT  = 12014
ID_ADMIN_AUTH_TITLE_TEXT = 12015
ID_ADMIN_AUTH_CLOSE_BTN  = 12016
ID_ADMIN_REGISTER_OPEN_BTN = 12017
ID_ADMIN_REGISTER_EMAIL = 12018
ID_ADMIN_REGISTER_PASSWORD = 12019
ID_ADMIN_REGISTER_PASSWORD_CONFIRM = 12020
ID_ADMIN_REGISTER_NICKNAME = 12021
ID_ADMIN_REGISTER_SUBMIT_BTN = 12022
ID_ADMIN_REGISTER_CANCEL_BTN = 12023
ID_ADMIN_MACHINE_TEXT = 12024

JSON_WATCH_INTERVAL_MS = 2000
JSON_WATCH_PREF_PATH   = 1

# Tab IDs
ID_TAB_MAIN            = 9000
ID_TAB_GRP_BASIC       = 9001
ID_TAB_GRP_ALIGN       = 9002
ID_TAB_GRP_SCENE       = 9003
ID_TAB_GRP_ACRYLIC     = 9004
ID_TAB_GRP_SMART_SCENE = 9005 
ID_TAB_GRP_ASSETS      = 9006 

# --- Asset Manager IDs ---
ID_ASSET_USER_AREA   = 20001
ID_ASSET_SLIDER_SIZE = 20002
ID_ASSET_BTN_REFRESH = 20003
ID_ASSET_SCROLL_GRP  = 20004
ID_ASSET_BTN_LOAD    = 20005
ID_ASSET_CHK_SIZE    = 20007 
ID_ASSET_TXT_SEARCH  = 20008
ID_ASSET_CHK_ONLY_FAV= 20009

# --- Scene Generator IDs ---
ID_BTN_GEN_CEILING     = 21001
ID_BTN_GEN_SMART_ROOM  = 21002 
ID_CURVED_WALL_MODE    = 21003 
ID_BTN_CURVED_WALL     = 21004

# --- Super Align IDs ---
ID_BTN_NW = 4101; ID_BTN_N = 4102; ID_BTN_NE = 4103
ID_BTN_W = 4104; ID_BTN_C = 4105; ID_BTN_E = 4106
ID_BTN_SW = 4107; ID_BTN_S = 4108; ID_BTN_SE = 4109
ID_BTN_Z_FRONT = 4110; ID_BTN_Z_MID = 4111; ID_BTN_Z_BACK = 4112
ID_CHK_SURFACE_MODE = 4113
ID_BTN_RAY_UP = 4114; ID_BTN_RAY_DOWN = 4115
ID_BTN_RAY_LEFT = 4116; ID_BTN_RAY_RIGHT = 4117
ID_BTN_RAY_FRONT = 4118; ID_BTN_RAY_BACK = 4119
RAYCAST_MAX_DISTANCE = 20000.0

# --- 全方位轴心工具 IDs ---
ID_AXIS_TL = 4201; ID_AXIS_TC = 4202; ID_AXIS_TR = 4203 
ID_AXIS_ML = 4204; ID_AXIS_MC = 4205; ID_AXIS_MR = 4206 
ID_AXIS_BL = 4207; ID_AXIS_BC = 4208; ID_AXIS_BR = 4209 
ID_AXIS_RADIO_Z = 4210
ID_AXIS_Z_FRONT = 4211; ID_AXIS_Z_MID = 4212; ID_AXIS_Z_BACK = 4213

EXTRUDE_NAME_PREFIX = "AI_Extrude_"
SPLINE_NAME_PREFIX  = "AI_Path_"
LAYER_NULL_PREFIX   = "AI_Layer_"
GROUP_NULL_PREFIX   = "AI_Group_"

CORE_BUTTON_IDS = [
    ID_IMPORT_BTN, ID_REPLACE_BTN, ID_JSON_WATCH_BTN,
    ID_BTN_RAY_UP, ID_BTN_RAY_DOWN, ID_BTN_RAY_LEFT, ID_BTN_RAY_RIGHT, ID_BTN_RAY_FRONT, ID_BTN_RAY_BACK,
    ID_BTN_SMART_MERGE, ID_BTN_SIMPLE_EXTRUDE, ID_BTN_CONNECT_DELETE, ID_BTN_AXIS_CENTER,
    ID_BTN_APPLY_TEX, ID_BTN_APPLY_DEPTH, ID_BTN_BAKE_UVW,
    ID_BTN_ACRY_GENERATE, ID_BTN_SIGN_BACK, ID_BTN_SIGN_FRONT, ID_BTN_SIGN_CRYSTAL, ID_BTN_SIGN_DUAL,
    ID_BTN_OPEN_GROOVE, ID_BTN_GEN_CEILING, ID_BTN_GEN_SMART_ROOM, ID_BTN_CURVED_WALL
]

# ==============================================================================
# Helper Functions (Global)
# ==============================================================================
def CenterAxis(obj):
    if not obj: return
    points = obj.GetAllPoints()
    if not points: return
    min_x = min([p.x for p in points])
    max_x = max([p.x for p in points])
    min_y = min([p.y for p in points])
    max_y = max([p.y for p in points])
    min_z = min([p.z for p in points])
    max_z = max([p.z for p in points])
    center = c4d.Vector((min_x+max_x)*0.5, (min_y+max_y)*0.5, (min_z+max_z)*0.5)
    if center.GetLength() < 0.001: return
    mg = obj.GetMg()
    new_axis_world_pos = mg * center
    new_points = [p - center for p in points]
    obj.SetAllPoints(new_points)
    obj.Message(c4d.MSG_UPDATE)
    mg.off = new_axis_world_pos
    obj.SetMg(mg)

def RecenterGroupAxis(group_null):
    if not group_null: return
    all_points_global =[]
    def collect_points(op):
        if not op: return
        mg = op.GetMg()
        if op.CheckType(c4d.Opoint):
            pts = op.GetAllPoints()
            for p in pts:
                all_points_global.append(mg * p)
        child = op.GetDown()
        while child:
            collect_points(child)
            child = child.GetNext()
    collect_points(group_null)
    if not all_points_global: return
    min_x = min_y = min_z = float('inf')
    max_x = max_y = max_z = float('-inf')
    for p in all_points_global:
        if p.x < min_x: min_x = p.x
        if p.x > max_x: max_x = p.x
        if p.y < min_y: min_y = p.y
        if p.y > max_y: max_y = p.y
        if p.z < min_z: min_z = p.z
        if p.z > max_z: max_z = p.z
    center_global = c4d.Vector((min_x + max_x) * 0.5, (min_y + max_y) * 0.5, (min_z + max_z) * 0.5)
    doc = documents.GetActiveDocument()
    if doc: doc.AddUndo(c4d.UNDOTYPE_CHANGE, group_null)
    old_mg = group_null.GetMg()
    new_mg = c4d.Matrix(old_mg)
    new_mg.off = center_global
    children = group_null.GetChildren()
    child_mgs = [child.GetMg() for child in children]
    group_null.SetMg(new_mg)
    for child, mg in zip(children, child_mgs):
        if doc: doc.AddUndo(c4d.UNDOTYPE_CHANGE, child)
        child.SetMg(mg)

def GetSplineSegmentBoxes(spline_obj):
    points = spline_obj.GetAllPoints()
    if not points: return[]
    mg = spline_obj.GetMg()
    seg_count = spline_obj.GetSegmentCount()
    if seg_count <= 0: 
        bb = GetSplineGlobalAABB(spline_obj)
        return [bb] if bb else []
    boxes =[]
    p_idx = 0
    for i in range(seg_count):
        cnt = spline_obj.GetSegment(i)['cnt']
        if cnt < 1: continue
        seg_points = points[p_idx : p_idx+cnt]
        p_idx += cnt
        if cnt < 2: continue
        min_x = float('inf'); max_x = float('-inf')
        min_y = float('inf'); max_y = float('-inf')
        for p in seg_points:
            gp = mg * p
            if gp.x < min_x: min_x = gp.x
            if gp.x > max_x: max_x = gp.x
            if gp.y < min_y: min_y = gp.y
            if gp.y > max_y: max_y = gp.y
        boxes.append((min_x, max_x, min_y, max_y))
    return boxes

def GetSplineGlobalAABB(spline_obj):
    points = spline_obj.GetAllPoints()
    if not points: return None
    mg = spline_obj.GetMg()
    min_x = float('inf'); max_x = float('-inf')
    min_y = float('inf'); max_y = float('-inf')
    for p in points:
        gp = mg * p 
        if gp.x < min_x: min_x = gp.x
        if gp.x > max_x: max_x = gp.x
        if gp.y < min_y: min_y = gp.y
        if gp.y > max_y: max_y = gp.y
    return (min_x, max_x, min_y, max_y)

def RayCastPolygon(x, y, poly_points):
    inside = False
    n = len(poly_points)
    p1x, p1y = poly_points[0].x, poly_points[0].y
    for i in range(n + 1):
        p2x, p2y = poly_points[i % n].x, poly_points[i % n].y
        if y > min(p1y, p2y):
            if y <= max(p1y, p2y):
                if x <= max(p1x, p2x):
                    if p1y != p2y:
                        xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                    if p1x == p2x or x <= xinters:
                        inside = not inside
        p1x, p1y = p2x, p2y
    return inside

def IsPointInSpline(check_x, check_y, spline_obj):
    if not spline_obj: return False
    mg = spline_obj.GetMg()
    all_points = spline_obj.GetAllPoints()
    seg_count = spline_obj.GetSegmentCount()
    
    if seg_count == 0:
        if not all_points: return False
        points = [mg * p for p in all_points]
        return RayCastPolygon(check_x, check_y, points)
    
    current_pt_index = 0
    hit_count = 0
    for i in range(seg_count):
        cnt = spline_obj.GetSegment(i)['cnt']
        if cnt < 3: 
            current_pt_index += cnt
            continue
        segment_points_local = all_points[current_pt_index : current_pt_index + cnt]
        current_pt_index += cnt
        segment_points_world = [mg * p for p in segment_points_local]
        if RayCastPolygon(check_x, check_y, segment_points_world):
            hit_count += 1
            
    return (hit_count % 2 == 1)

def CheckSplineOverlapHybrid(source_spline, target_spline):
    if not source_spline or not target_spline: return False
    bb_s = GetSplineGlobalAABB(source_spline)
    bb_t = GetSplineGlobalAABB(target_spline)
    if not bb_s or not bb_t: return False
    shrink = 0.05
    s_min_x, s_max_x, s_min_y, s_max_y = bb_s
    t_min_x, t_max_x, t_min_y, t_max_y = bb_t
    if (s_max_x - s_min_x) > 0.2: s_min_x += shrink; s_max_x -= shrink
    if (s_max_y - s_min_y) > 0.2: s_min_y += shrink; s_max_y -= shrink
    if (t_max_x - t_min_x) > 0.2: t_min_x += shrink; t_max_x -= shrink
    if (t_max_y - t_min_y) > 0.2: t_min_y += shrink; t_max_y -= shrink
    if s_max_x <= t_min_x or s_min_x >= t_max_x: return False
    if s_max_y <= t_min_y or s_min_y >= t_max_y: return False

    min_x, max_x, min_y, max_y = bb_s
    w = max_x - min_x
    h = max_y - min_y
    if w <= 0.001 or h <= 0.001: return False
    
    sample_res = 32
    step_x = w / float(sample_res)
    step_y = h / float(sample_res)
    start_x = min_x + step_x * 0.5
    start_y = min_y + step_y * 0.5
    if step_x < 0.005: step_x = 0.005
    if step_y < 0.005: step_y = 0.005

    valid_source_points = 0
    hits_in_target = 0
    for i in range(sample_res):
        for j in range(sample_res):
            px = start_x + i * step_x
            py = start_y + j * step_y
            if IsPointInSpline(px, py, source_spline):
                valid_source_points += 1
                if IsPointInSpline(px, py, target_spline):
                    hits_in_target += 1
    
    area_ratio = 0.0
    if valid_source_points > 0: area_ratio = float(hits_in_target) / float(valid_source_points)
    if area_ratio > 0.30: return True 

    real_points = source_spline.GetAllPoints()
    total_pts = len(real_points)
    if total_pts == 0: return False
    step_v = 1
    if total_pts > 80: step_v = int(total_pts / 40)
    mg = source_spline.GetMg()
    checked_v = 0
    hits_v = 0
    for k in range(0, total_pts, step_v):
        pt_world = mg * real_points[k]
        checked_v += 1
        if IsPointInSpline(pt_world.x, pt_world.y, target_spline): hits_v += 1
            
    if checked_v == 0: return False
    if float(hits_v) / float(checked_v) > 0.85: return True
    return False

FIT_CMD_ID = None
def FindFitToObjectCommand():
    global FIT_CMD_ID
    if FIT_CMD_ID is not None: return FIT_CMD_ID
    for cid in range(1000, 200000):
        name = c4d.GetCommandName(cid)
        if not name: continue
        if ("Fit to Object" in name) or (u"适合对象" in name):
            FIT_CMD_ID = cid
            return FIT_CMD_ID
    return 100004766 

def BatchFitTextureTags(doc, obj_tag_pairs):
    if not obj_tag_pairs: return
    cmd_id = FindFitToObjectCommand()
    c4d.CallCommand(12113) 
    has_items = False
    for obj, tag in obj_tag_pairs:
        if not obj or not tag or not tag.IsAlive(): continue
        obj.SetBit(c4d.BIT_ACTIVE)
        tag.SetBit(c4d.BIT_ACTIVE)
        has_items = True
    if has_items and c4d.IsCommandEnabled(cmd_id):
        c4d.CallCommand(cmd_id)
    c4d.CallCommand(12113)

# ==============================================================================
# 建模辅助函数
# ==============================================================================
def SetupSplineParams(spline):
    if not spline or not spline.CheckType(c4d.Ospline): return
    spline[c4d.SPLINEOBJECT_TYPE] = c4d.SPLINETYPE_BEZIER
    spline[c4d.SPLINEOBJECT_CLOSED] = True
    spline[c4d.SPLINEOBJECT_INTERPOLATION] = c4d.SPLINEOBJECT_INTERPOLATION_ADAPTIVE
    spline[c4d.SPLINEOBJECT_ANGLE] = utils.Rad(5.0)
    spline[c4d.SPLINEOBJECT_MAXIMUMLENGTH] = 5.0
    spline.Message(c4d.MSG_UPDATE)

def GetPolyNormal(obj, poly):
    pts = obj.GetAllPoints()
    return (pts[poly.b]-pts[poly.a]).Cross(pts[poly.c]-pts[poly.a]).GetNormalized()

def CreateOrGetTransparentMaterial(doc):
    for m in doc.GetMaterials() or[]:
        if m.GetName() == "Acrylic_Transparent": return m
    mat = c4d.BaseMaterial(c4d.Mmaterial)
    mat.SetName("Acrylic_Transparent")
    mat[c4d.MATERIAL_USE_COLOR] = False
    mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(1.0, 1.0, 1.0)
    mat[c4d.MATERIAL_USE_TRANSPARENCY] = True
    mat[c4d.MATERIAL_TRANSPARENCY_BRIGHTNESS] = 1.0
    if hasattr(c4d, "MATERIAL_TRANSPARENCY_REFRACTION"):
        mat[c4d.MATERIAL_TRANSPARENCY_REFRACTION] = 1.49 
    doc.InsertMaterial(mat)
    doc.AddUndo(c4d.UNDOTYPE_NEW, mat)
    return mat

def ProcessOneSpline(doc, spline, target_depth, side_cfg, shell_thickness):
    if not spline or not spline.CheckType(c4d.Ospline): return None
    extrude = c4d.BaseObject(5116)
    extrude.SetName("Standard_Base")
    if hasattr(c4d, "EXTRUDEOBJECT_DIRECTION"): extrude[c4d.EXTRUDEOBJECT_DIRECTION] = 3 
    extrude[c4d.EXTRUDEOBJECT_MOVE] = c4d.Vector(0, 0, -abs(float(target_depth)))
    try: extrude[C4D_EXTRUDE_OFFSET_ID] = -abs(float(target_depth))
    except: pass
    
    doc.InsertObject(extrude, pred=spline)
    doc.AddUndo(c4d.UNDOTYPE_NEW, extrude)
    extrude.SetMg(spline.GetMg())
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, spline)
    spline.Remove()
    spline.InsertUnder(extrude)
    spline.SetMl(c4d.Matrix())
    doc.SetActiveObject(extrude, c4d.SELECTION_NEW)
    c4d.CallCommand(12236)
    new_op = doc.GetActiveObject()
    if not new_op or not new_op.CheckType(c4d.Opolygon): return None

    tags = new_op.GetTags()
    c1_tag = next((t for t in tags if t.CheckType(c4d.Tpolygonselection) and t.GetName() == "C1"), None)
    if c1_tag:
        bs = new_op.GetPolygonS()
        bs.DeselectAll()
        c1_tag.GetBaseSelect().CopyTo(bs)
        bc_del_c1 = c4d.BaseContainer()
        utils.SendModelingCommand(c4d.MCOMMAND_DELETE, [new_op], c4d.MODELINGCOMMANDMODE_POLYGONSELECTION, bc_del_c1, doc)
        c1_tag.Remove()
        utils.SendModelingCommand(c4d.MCOMMAND_OPTIMIZE, [new_op], c4d.MODELINGCOMMANDMODE_ALL, c4d.BaseContainer(), doc)

    if not side_cfg["skip"]:
        polys = new_op.GetAllPolygons()
        pts = new_op.GetAllPoints()
        bs_del = c4d.BaseSelect()
        center = new_op.GetMp()
        rad = new_op.GetRad()
        min_x, max_x = center.x - rad.x, center.x + rad.x
        min_y, max_y = center.y - rad.y, center.y + rad.y
        total_h, total_w = max_y - min_y, max_x - min_x
        band_y, band_x = total_h * 0.30, total_w * 0.30
        top_start, bottom_end = max_y - band_y, min_y + band_y
        left_end, right_start = min_x + band_x, max_x - band_x

        for i, p in enumerate(polys):
            pa, pb, pc, pd = pts[p.a], pts[p.b], pts[p.c], pts[p.d]
            poly_center = (pa + pb + pc + pd) * 0.25
            n = GetPolyNormal(new_op, p)
            is_cap = abs(n.z) > 0.9
            del_flag = False
            if side_cfg["dt"] and poly_center.y >= top_start: del_flag = True
            if side_cfg["db"] and poly_center.y <= bottom_end: del_flag = True
            if side_cfg["dl"] and poly_center.x <= left_end: del_flag = True
            if side_cfg["dr"] and poly_center.x >= right_start: del_flag = True
            if del_flag and not is_cap: bs_del.Select(i)

        if bs_del.GetCount() > 0:
            bs = new_op.GetPolygonS()
            bs.DeselectAll()
            bs_del.CopyTo(bs)
            utils.SendModelingCommand(c4d.MCOMMAND_DELETE, [new_op], c4d.MODELINGCOMMANDMODE_POLYGONSELECTION, c4d.BaseContainer(), doc)
            utils.SendModelingCommand(c4d.MCOMMAND_OPTIMIZE,[new_op], c4d.MODELINGCOMMANDMODE_ALL, c4d.BaseContainer(), doc)

    if shell_thickness is not None and shell_thickness > 0.0:
        target_obj = new_op
        if target_obj.CheckType(c4d.Opolygon):
            bs = target_obj.GetPolygonS()
            bs.DeselectAll()
            for i in range(target_obj.GetPolygonCount()): bs.Select(i)
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, target_obj)
            bc_ex = c4d.BaseContainer()
            bc_ex[c4d.MDATA_EXTRUDE_OFFSET] = shell_thickness
            bc_ex[c4d.MDATA_EXTRUDE_PRESERVEGROUPS] = True
            bc_ex[c4d.MDATA_EXTRUDE_ANGLE] = utils.Rad(180.0)
            if hasattr(c4d, "MDATA_EXTRUDE_CREATECAPS"): bc_ex[c4d.MDATA_EXTRUDE_CREATECAPS] = True
            utils.SendModelingCommand(c4d.ID_MODELING_EXTRUDE_TOOL,[target_obj], c4d.MODELINGCOMMANDMODE_POLYGONSELECTION, bc_ex, doc, c4d.MODELINGCOMMANDFLAGS_CREATEUNDO)
    return new_op

def RunGenerate(target_depth, side_cfg, shell_thickness):
    doc = c4d.documents.GetActiveDocument()
    c4d.CallCommand(16768) 
    c4d.EventAdd()
    op = doc.GetActiveObject()
    if not op:
        gui.MessageDialog("未选中对象，或合并失败。")
        return
    doc.StartUndo()
    
    targets =[]
    if op.CheckType(c4d.Ospline) and op.GetSegmentCount() > 1:
        utils.SendModelingCommand(c4d.MCOMMAND_EXPLODESEGMENTS, list=[op], mode=c4d.MODELINGCOMMANDMODE_ALL, doc=doc)
        c4d.EventAdd()
        group_null = doc.GetActiveObject()
        if group_null and group_null.GetDown():
            targets = group_null.GetChildren()
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, group_null)
    else:
        targets = [op]
        
    for t_obj in targets:
        doc.AddUndo(c4d.UNDOTYPE_CHANGE, t_obj)
        if t_obj.CheckType(c4d.Ospline): SetupSplineParams(t_obj)
        poly = ProcessOneSpline(doc, t_obj, target_depth, side_cfg, shell_thickness)
        if poly and poly.CheckType(c4d.Opolygon):
            mat = CreateOrGetTransparentMaterial(doc)
            if mat:
                tex = c4d.BaseTag(c4d.Ttexture)
                tex[c4d.TEXTURETAG_MATERIAL] = mat
                poly.InsertTag(tex)
                doc.AddUndo(c4d.UNDOTYPE_NEW, tex)
    doc.EndUndo()
    c4d.EventAdd()

# ==============================================================================
# 花花广告设计 v1.1 - 广告字工艺核心逻辑
# ==============================================================================
def Signage_GetObjColor(obj, default_color):
    if not obj: return default_color
    tags = obj.GetTags()
    for t in tags:
        if t.CheckType(c4d.Ttexture):
            mat = t.GetMaterial()
            if mat and mat[c4d.MATERIAL_USE_COLOR]:
                return mat[c4d.MATERIAL_COLOR_COLOR]
    if obj[c4d.ID_BASEOBJECT_USECOLOR] > 0:
        return obj[c4d.ID_BASEOBJECT_COLOR]
    return default_color

def Signage_CreateMat(doc, name, color, type_mode):
    col_suffix = f"{int(color.x*255)}_{int(color.y*255)}_{int(color.z*255)}"
    if type_mode == 2: mat_name = "Mat_Crystal_Clear" 
    elif type_mode == 1 and name == "Back_Light": mat_name = "Mat_Light_White"   
    elif type_mode == 3 and name == "Case_Metal": mat_name = "Mat_Case_Dark"     
    else: mat_name = f"Mat_{name}_{col_suffix}"

    mat = doc.SearchMaterial(mat_name)
    if mat: return mat
    
    mat = c4d.BaseMaterial(c4d.Mmaterial)
    mat.SetName(mat_name)
    vec_col = c4d.Vector(color.x, color.y, color.z)
    
    if type_mode == 0: # 面板
        mat[c4d.MATERIAL_USE_COLOR] = True
        mat[c4d.MATERIAL_COLOR_COLOR] = vec_col
        mat[c4d.MATERIAL_USE_REFLECTION] = True
    elif type_mode == 1: # 发光
        mat[c4d.MATERIAL_USE_COLOR] = False
        mat[c4d.MATERIAL_USE_LUMINANCE] = True
        if name == "Back_Light": mat[c4d.MATERIAL_LUMINANCE_COLOR] = c4d.Vector(1,1,1)
        else: mat[c4d.MATERIAL_LUMINANCE_COLOR] = vec_col
        mat[c4d.MATERIAL_LUMINANCE_BRIGHTNESS] = 1.5
    elif type_mode == 2: # 透明
        mat[c4d.MATERIAL_USE_COLOR] = False
        mat[c4d.MATERIAL_USE_TRANSPARENCY] = True
        mat[c4d.MATERIAL_TRANSPARENCY_BRIGHTNESS] = 0.95
        mat[c4d.MATERIAL_TRANSPARENCY_REFRACTION] = 1.49
        mat[c4d.MATERIAL_USE_REFLECTION] = True
    elif type_mode == 3: # 金属
        mat[c4d.MATERIAL_USE_COLOR] = True
        if name == "Shell_Metal": mat[c4d.MATERIAL_COLOR_COLOR] = vec_col
        else: mat[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(0.2, 0.2, 0.2)
        mat[c4d.MATERIAL_USE_REFLECTION] = True
    
    doc.InsertMaterial(mat)
    return mat

def Signage_SetupExtrude(extrude_obj, depth_val):
    if hasattr(c4d, "EXTRUDEOBJECT_DIRECTION"): extrude_obj[c4d.EXTRUDEOBJECT_DIRECTION] = 3
    else:
        try: extrude_obj[2003] = 3 
        except: pass
    neg_depth = -abs(float(depth_val))
    if hasattr(c4d, "EXTRUDEOBJECT_MOVE"): extrude_obj[c4d.EXTRUDEOBJECT_MOVE] = c4d.Vector(0, 0, neg_depth)
    offset_id = 1009
    try: extrude_obj[offset_id] = neg_depth
    except: pass

def Signage_FindSpline(obj):
    if not obj: return None
    if obj.CheckType(c4d.Ospline): return obj
    child = obj.GetDown()
    while child:
        res = Signage_FindSpline(child)
        if res: return res
        child = child.GetNext()
    return None

def Signage_GetTargets(doc):
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
    targets =[]
    for obj in sel:
        data = {'spline': None, 'parent': None, 'mg': obj.GetMg(), 'origin_obj': obj}
        if obj.CheckType(c4d.Ospline):
            data['spline'] = obj
            targets.append(data)
        else:
            found_spline = Signage_FindSpline(obj)
            if found_spline:
                data['spline'] = found_spline
                data['parent'] = obj
                targets.append(data)
    return targets

def Signage_Finalize(doc, new_obj, target_data):
    parent_to_delete = target_data['parent']
    if parent_to_delete:
        doc.InsertObject(new_obj, pred=parent_to_delete)
        new_obj.SetMg(target_data['mg']) # 【关键修复】放入层级后再赋予世界坐标
        doc.AddUndo(c4d.UNDOTYPE_DELETE, parent_to_delete)
        parent_to_delete.Remove()
    else:
        ref_spline = target_data['spline']
        doc.InsertObject(new_obj, pred=ref_spline)
        new_obj.SetMg(target_data['mg']) # 【关键修复】放入层级后再赋予世界坐标
    doc.AddUndo(c4d.UNDOTYPE_NEW, new_obj)

def Gen_Backlit(doc, data_list, front_val, back_val, default_color):
    mat_shell = Signage_CreateMat(doc, "Metal_Shell", default_color, 3) 
    mat_light = Signage_CreateMat(doc, "Back_Light", c4d.Vector(1,1,1), 1)
    for data in data_list:
        sp = data['spline']
        use_col = Signage_GetObjColor(data['origin_obj'], default_color)
        mat_shell = Signage_CreateMat(doc, "Shell_Metal", use_col, 3)
        root = c4d.BaseObject(c4d.Onull); root.SetName(f"BackLit_{sp.GetName()}")
        
        shell = c4d.BaseObject(c4d.Oextrude); shell.SetName("1_Shell_Metal")
        shell.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_val)))) 
        Signage_SetupExtrude(shell, front_val)
        sp_shell = sp.GetClone(); sp_shell.InsertUnder(shell); sp_shell.SetMl(c4d.Matrix())
        t1 = shell.MakeTag(c4d.Ttexture); t1.SetMaterial(mat_shell)
        shell.InsertUnder(root)
        
        light = c4d.BaseObject(c4d.Oextrude); light.SetName("2_Back_Light")
        light.SetAbsPos(c4d.Vector(0, 0, 0)) 
        Signage_SetupExtrude(light, back_val)
        sp_light = sp.GetClone(); sp_light.InsertUnder(light); sp_light.SetMl(c4d.Matrix())
        t2 = light.MakeTag(c4d.Ttexture); t2.SetMaterial(mat_light)
        light.InsertUnder(root)
        Signage_Finalize(doc, root, data)

def Gen_Frontlit(doc, data_list, front_val, back_val, default_color):
    for data in data_list:
        sp = data['spline']
        use_col = Signage_GetObjColor(data['origin_obj'], default_color)
        mat_face = Signage_CreateMat(doc, "Face_Acrylic", use_col, 1)
        mat_case = Signage_CreateMat(doc, "Case_Metal", c4d.Vector(0.2,0.2,0.2), 3)
        root = c4d.BaseObject(c4d.Onull); root.SetName(f"FrontLit_{sp.GetName()}")
        
        face = c4d.BaseObject(c4d.Oextrude); face.SetName("1_Face_Acrylic")
        face.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_val)))) 
        Signage_SetupExtrude(face, front_val)
        sp_face = sp.GetClone(); sp_face.InsertUnder(face); sp_face.SetMl(c4d.Matrix())
        t1 = face.MakeTag(c4d.Ttexture); t1.SetMaterial(mat_face)
        face.InsertUnder(root)
        
        case = c4d.BaseObject(c4d.Oextrude); case.SetName("2_Case_Metal")
        case.SetAbsPos(c4d.Vector(0, 0, 0)) 
        Signage_SetupExtrude(case, back_val)
        case[c4d.CAP_START] = False 
        sp_case = sp.GetClone(); sp_case.InsertUnder(case); sp_case.SetMl(c4d.Matrix())
        t2 = case.MakeTag(c4d.Ttexture); t2.SetMaterial(mat_case)
        case.InsertUnder(root)
        Signage_Finalize(doc, root, data)

def Gen_Crystal(doc, data_list, front_val, back_val, default_color):
    mat_bot = Signage_CreateMat(doc, "Crystal_Clear", c4d.Vector(1,1,1), 2) 
    for data in data_list:
        sp = data['spline']
        use_col = Signage_GetObjColor(data['origin_obj'], default_color)
        mat_top = Signage_CreateMat(doc, "Crystal_Color", use_col, 0)
        root = c4d.BaseObject(c4d.Onull); root.SetName(f"Crystal_{sp.GetName()}")
        
        top = c4d.BaseObject(c4d.Oextrude); top.SetName("1_Color_Face")
        top.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_val))))
        Signage_SetupExtrude(top, front_val)
        sp_top = sp.GetClone(); sp_top.InsertUnder(top); sp_top.SetMl(c4d.Matrix())
        t1 = top.MakeTag(c4d.Ttexture); t1.SetMaterial(mat_top)
        top.InsertUnder(root)
        
        bot = c4d.BaseObject(c4d.Oextrude); bot.SetName("2_Clear_Base")
        bot.SetAbsPos(c4d.Vector(0, 0, 0)) 
        Signage_SetupExtrude(bot, back_val)
        bot[c4d.CAP_START] = False
        sp_bot = sp.GetClone(); sp_bot.InsertUnder(bot); sp_bot.SetMl(c4d.Matrix())
        t2 = bot.MakeTag(c4d.Ttexture); t2.SetMaterial(mat_bot)
        bot.InsertUnder(root)
        Signage_Finalize(doc, root, data)

def Gen_DualLit(doc, data_list, front_val, back_val, default_color):
    back_plate_thick = 1.0 
    mat_case = Signage_CreateMat(doc, "Case_Metal", c4d.Vector(0.2,0.2,0.2), 3) 
    mat_back = Signage_CreateMat(doc, "Back_Light", c4d.Vector(1,1,1), 1) 
    for data in data_list:
        sp = data['spline']
        use_col = Signage_GetObjColor(data['origin_obj'], default_color)
        mat_face = Signage_CreateMat(doc, "Face_Acrylic", use_col, 1)
        root = c4d.BaseObject(c4d.Onull); root.SetName(f"DualLit_{sp.GetName()}")
        
        face = c4d.BaseObject(c4d.Oextrude); face.SetName("1_Face_Lit")
        face.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_val + back_plate_thick)))) 
        Signage_SetupExtrude(face, front_val)
        sp_face = sp.GetClone(); sp_face.InsertUnder(face); sp_face.SetMl(c4d.Matrix())
        t1 = face.MakeTag(c4d.Ttexture); t1.SetMaterial(mat_face)
        face.InsertUnder(root)
        
        case = c4d.BaseObject(c4d.Oextrude); case.SetName("2_Case_Metal")
        case.SetAbsPos(c4d.Vector(0, 0, -abs(float(back_plate_thick)))) 
        Signage_SetupExtrude(case, back_val)
        case[c4d.CAP_START] = False 
        sp_case = sp.GetClone(); sp_case.InsertUnder(case); sp_case.SetMl(c4d.Matrix())
        t2 = case.MakeTag(c4d.Ttexture); t2.SetMaterial(mat_case)
        case.InsertUnder(root)
        
        back = c4d.BaseObject(c4d.Oextrude); back.SetName("3_Back_Lit")
        back.SetAbsPos(c4d.Vector(0, 0, 0)) 
        Signage_SetupExtrude(back, back_plate_thick)
        sp_back = sp.GetClone(); sp_back.InsertUnder(back); sp_back.SetMl(c4d.Matrix())
        t3 = back.MakeTag(c4d.Ttexture); t3.SetMaterial(mat_back)
        back.InsertUnder(root)
        Signage_Finalize(doc, root, data)


# ==============================================================================
# 资产库辅助函数
# ==============================================================================
def FixTexturePaths(materials, asset_file_path):
    asset_dir = os.path.dirname(asset_file_path) 
    parent_dir = os.path.dirname(asset_dir)      
    search_dirs =[
        asset_dir,
        os.path.join(asset_dir, "tex"),
        parent_dir,
        os.path.join(parent_dir, "tex"),
        os.path.join(LIBRARY_PATH, "tex")
    ]
    count = 0
    def ScanAndFixShader(shader):
        nonlocal count
        while shader:
            if shader.CheckType(c4d.Xbitmap):
                old_path = shader[c4d.BITMAPSHADER_FILENAME]
                if old_path:
                    file_name = os.path.basename(old_path)
                    found_new_path = None
                    for search_path in search_dirs:
                        if not os.path.exists(search_path): continue
                        potential_file = os.path.join(search_path, file_name)
                        if os.path.exists(potential_file):
                            found_new_path = potential_file; break
                    if found_new_path:
                        if str(old_path) != str(found_new_path):
                            shader[c4d.BITMAPSHADER_FILENAME] = str(found_new_path)
                            count += 1
            if shader.GetDown(): ScanAndFixShader(shader.GetDown())
            shader = shader.GetNext()

    for mat in materials:
        first_shader = mat.GetFirstShader()
        if first_shader: ScanAndFixShader(first_shader)
        mat.Message(c4d.MSG_UPDATE)
        mat.Update(True, True)
    if count > 0: print(f"   ✅ 成功链接 {count} 张贴图")

def GetBoundsInfo(op):
    min_v = c4d.Vector(1e10); max_v = c4d.Vector(-1e10)
    found_geo = False
    root_mg_inv = ~op.GetMg()
    def Traverse(obj):
        nonlocal min_v, max_v, found_geo
        if isinstance(obj, c4d.PointObject): 
            found_geo = True
            mg = obj.GetMg(); points = obj.GetAllPoints()
            for p in points:
                local_p = root_mg_inv * (mg * p)
                min_v.x, min_v.y, min_v.z = min(min_v.x, local_p.x), min(min_v.y, local_p.y), min(min_v.z, local_p.z)
                max_v.x, max_v.y, max_v.z = max(max_v.x, local_p.x), max(max_v.y, local_p.y), max(max_v.z, local_p.z)
        for child in obj.GetChildren(): Traverse(child)
    Traverse(op)
    if not found_geo:
        rad = op.GetRad(); scale = op.GetAbsScale()
        size = c4d.Vector(abs(rad.x*scale.x*2), abs(rad.y*scale.y*2), abs(rad.z*scale.z*2))
        return size, -size/2, size/2
    size = max_v - min_v
    size.x = max(0.001, abs(size.x)); size.y = max(0.001, abs(size.y)); size.z = max(0.001, abs(size.z))
    return size, min_v, max_v

def ProcessReplacement(doc, asset_obj, target_obj, do_size_match):
    asset_obj.Remove()
    asset_obj.InsertAfter(target_obj) 
    target_mg = target_obj.GetMg()
    asset_obj.SetMg(target_mg) 

    if do_size_match:
        target_size, _, _ = GetBoundsInfo(target_obj)
        new_size, new_min, _ = GetBoundsInfo(asset_obj)
        if new_size.GetLength() > 0.001:
            size_map =[{'val': new_size.x, 'idx': 0}, {'val': new_size.y, 'idx': 1}, {'val': new_size.z, 'idx': 2}]
            size_map.sort(key=lambda x: x['val'])
            thickness_axis_idx = size_map[0]['idx']
            ratio_y = target_size.y / new_size.y if new_size.y != 0 else 1.0
            target_width = max(target_size.x, target_size.z)
            asset_width = max(new_size.x, new_size.z)
            ratio_width = target_width / asset_width if asset_width != 0 else 1.0
            scale_matrix = c4d.utils.MatrixScale(c4d.Vector(1,1,1))
            if thickness_axis_idx == 0: scale_matrix = c4d.utils.MatrixScale(c4d.Vector(1.0, ratio_y, ratio_width))
            elif thickness_axis_idx == 2: scale_matrix = c4d.utils.MatrixScale(c4d.Vector(ratio_width, ratio_y, 1.0))
            else: scale_matrix = c4d.utils.MatrixScale(c4d.Vector(ratio_width, 1.0, ratio_y))
            asset_obj.SetMg(asset_obj.GetMg() * scale_matrix)
            
            _, new_min_scaled, _ = GetBoundsInfo(asset_obj)
            _, target_min, _ = GetBoundsInfo(target_obj)
            target_bottom_world_y = (target_obj.GetMg() * c4d.Vector(0, target_min.y, 0)).y
            new_bottom_world_y = (asset_obj.GetMg() * c4d.Vector(0, new_min_scaled.y, 0)).y
            shift_y = target_bottom_world_y - new_bottom_world_y
            asset_obj.SetMg(c4d.utils.MatrixMove(c4d.Vector(0, shift_y, 0)) * asset_obj.GetMg())
            
    doc.AddUndo(c4d.UNDOTYPE_NEW, asset_obj)

def SafeLoadBitmap(path):
    if not path or not os.path.exists(path): return None
    bmp = bitmaps.BaseBitmap()
    try:
        bmp.InitWith(path)
        if bmp.GetBw() > 0: return bmp
        temp_dir = tempfile.gettempdir()
        ext = os.path.splitext(path)[1]
        temp_path = os.path.join(temp_dir, "c4d_asset_temp" + ext)
        shutil.copy2(path, temp_path)
        bmp_temp = bitmaps.BaseBitmap()
        bmp_temp.InitWith(temp_path)
        if bmp_temp.GetBw() > 0: return bmp_temp
    except: pass
    return None

def GetLocalCursorPos(ua, msg):
    mx = msg.GetLong(c4d.BFM_INPUT_X); my = msg.GetLong(c4d.BFM_INPUT_Y)
    off_x, off_y = 0, 0
    try:
        res = ua.Local2Global()
        if isinstance(res, dict): off_x, off_y = res['x'], res['y']
        elif isinstance(res, c4d.Vector): off_x, off_y = res.x, res.y
        elif isinstance(res, tuple): off_x, off_y = res[0], res[1]
    except: pass
    return mx - off_x, my - off_y

# ------------------------------------------------------------------------------
# 智能场景/吊顶辅助函数
# ------------------------------------------------------------------------------
def GetHierarchyLocalBounds_Gen(obj):
    if not obj: return c4d.Vector(0), c4d.Vector(0), c4d.Vector(0), c4d.Vector(0)
    root_mg = obj.GetMg()
    inv_root_mg = ~root_mg
    min_p = c4d.Vector(float('inf')); max_p = c4d.Vector(float('-inf'))
    found = False
    
    def traverse(op):
        nonlocal min_p, max_p, found
        curr_mg = op.GetMg()
        local_to_root = inv_root_mg * curr_mg
        points = None
        if op.CheckType(c4d.Opoint): points = op.GetAllPoints()
        if points:
            found = True
            for p in points:
                p_rel = local_to_root * p
                if p_rel.x < min_p.x: min_p.x = p_rel.x
                if p_rel.x > max_p.x: max_p.x = p_rel.x
                if p_rel.y < min_p.y: min_p.y = p_rel.y
                if p_rel.y > max_p.y: max_p.y = p_rel.y
                if p_rel.z < min_p.z: min_p.z = p_rel.z
                if p_rel.z > max_p.z: max_p.z = p_rel.z
        else:
            cache = op.GetCache()
            if cache: traverse(cache)
            rad = op.GetRad()
            if rad.x > 0.001 or rad.y > 0.001 or rad.z > 0.001:
                found = True
                mp = op.GetMp()
                corners =[
                    c4d.Vector(mp.x-rad.x, mp.y-rad.y, mp.z-rad.z), c4d.Vector(mp.x+rad.x, mp.y-rad.y, mp.z-rad.z),
                    c4d.Vector(mp.x-rad.x, mp.y+rad.y, mp.z-rad.z), c4d.Vector(mp.x+rad.x, mp.y+rad.y, mp.z-rad.z),
                    c4d.Vector(mp.x-rad.x, mp.y-rad.y, mp.z+rad.z), c4d.Vector(mp.x+rad.x, mp.y-rad.y, mp.z+rad.z),
                    c4d.Vector(mp.x-rad.x, mp.y+rad.y, mp.z+rad.z), c4d.Vector(mp.x+rad.x, mp.y+rad.y, mp.z+rad.z)
                ]
                for p in corners:
                    p_rel = local_to_root * p
                    if p_rel.x < min_p.x: min_p.x = p_rel.x
                    if p_rel.x > max_p.x: max_p.x = p_rel.x
                    if p_rel.y < min_p.y: min_p.y = p_rel.y
                    if p_rel.y > max_p.y: max_p.y = p_rel.y
                    if p_rel.z < min_p.z: min_p.z = p_rel.z
                    if p_rel.z > max_p.z: max_p.z = p_rel.z
        for child in op.GetChildren(): traverse(child)

    traverse(obj)
    if not found: return c4d.Vector(0), c4d.Vector(0), c4d.Vector(0), c4d.Vector(0)
    size = max_p - min_p
    center = (min_p + max_p) * 0.5
    return size, center, min_p, max_p

def CheckAndCreateMaterials(doc=None):
    if not doc: doc = c4d.documents.GetActiveDocument()
    if not doc: return
    try:
        materials_data =[
            ("Pro_Wall_White", c4d.Vector(0.9, 0.9, 0.92), False, False, False),
            ("Pro_Floor_Wood", c4d.Vector(0.45, 0.3, 0.15), False, False, False),
            ("Pro_Metal_Dark", c4d.Vector(0.15, 0.15, 0.15), False, False, True),
            ("Pro_Glass", c4d.Vector(0.9, 0.95, 1.0), False, True, False),
            ("Pro_Door_Wood", c4d.Vector(0.3, 0.15, 0.05), False, False, False),
            ("Pro_Light_Spot", c4d.Vector(1.0, 0.95, 0.9), True, False, False),
            ("Pro_Light_Cove", c4d.Vector(1.0, 0.9, 0.8), True, False, False),
            ("Pro_Light_Linear", c4d.Vector(1.0, 1.0, 1.0), True, False, False),
        ]
        for name, color, is_lum, is_trans, is_metal in materials_data:
            mat = doc.SearchMaterial(name)
            if not mat:
                mat = c4d.BaseMaterial(c4d.Mmaterial)
                mat.SetName(name)
                mat[c4d.MATERIAL_COLOR_COLOR] = color
                if is_lum:
                    mat[c4d.MATERIAL_USE_LUMINANCE] = True
                    mat[c4d.MATERIAL_LUMINANCE_COLOR] = color
                    mat[c4d.MATERIAL_LUMINANCE_BRIGHTNESS] = 2.0 
                if is_trans:
                    mat[c4d.MATERIAL_USE_TRANSPARENCY] = True
                    mat[c4d.MATERIAL_TRANSPARENCY_BRIGHTNESS] = 0.9
                    mat[c4d.MATERIAL_USE_COLOR] = False
                    mat[c4d.MATERIAL_USE_REFLECTION] = True
                if is_metal: mat[c4d.MATERIAL_USE_REFLECTION] = True
                doc.InsertMaterial(mat)
    except: pass
    c4d.EventAdd()

# ==============================================================================
# 花花广告设计 v1.1 - 智能展厅核心功能库 (Smart Room Builder)
# ==============================================================================
def GetGlobalGeometryBounds(obj):
    min_v = c4d.Vector(1e20)
    max_v = c4d.Vector(-1e20)
    found = False
    
    def traverse(node, current_min, current_max, has_data):
        mg = node.GetMg()
        points =[]
        if node.CheckType(c4d.Opoint) or node.CheckType(c4d.Ospline):
            points = node.GetAllPoints()
        
        if points:
            has_data = True
            for p in points:
                global_p = mg * p
                if global_p.x < current_min.x: current_min.x = global_p.x
                if global_p.x > current_max.x: current_max.x = global_p.x
                if global_p.y < current_min.y: current_min.y = global_p.y
                if global_p.y > current_max.y: current_max.y = global_p.y
                if global_p.z < current_min.z: current_min.z = global_p.z
                if global_p.z > current_max.z: current_max.z = global_p.z
        
        cache = node.GetCache()
        if cache:
            c_min, c_max, c_found = traverse(cache, current_min, current_max, has_data)
            if c_found: has_data = True

        child = node.GetDown()
        while child:
            c_min, c_max, c_found = traverse(child, current_min, current_max, has_data)
            if c_found: has_data = True
            child = child.GetNext()
            
        return current_min, current_max, has_data

    min_v, max_v, found = traverse(obj, min_v, max_v, found)
    return min_v, max_v, found

def SmartWrapper(doc, obj, name_suffix):
    min_v, max_v, success = GetGlobalGeometryBounds(obj)
    if not success:
        mg = obj.GetMg()
        rad = obj.GetRad()
        center = obj.GetMp()
        world_center = mg * center
        min_v = world_center - rad
        max_v = world_center + rad

    size_v = max_v - min_v
    flat_size =[size_v.x, size_v.z]
    length_real = max(flat_size)
    thickness_real = min(flat_size)
    if thickness_real < 0.1: thickness_real = 20.0
    if length_real < 1.0: length_real = 200.0

    # 轴心: Z轴最大值 (背面)
    pivot_pos = c4d.Vector(
        (min_v.x + max_v.x) * 0.5, 
        min_v.y, 
        max_v.z 
    )

    container = c4d.BaseObject(c4d.Onull)
    container.SetName(obj.GetName() + name_suffix)
    
    # 避免受原群组坐标影响
    container.SetAbsPos(pivot_pos) 
    container.SetAbsRot(c4d.Vector(0,0,0)) 
    
    ud_len = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
    ud_len[c4d.DESC_NAME] = "Baked_Length"
    container.AddUserData(ud_len)
    container[c4d.ID_USERDATA, 1] = length_real
    
    ud_thk = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
    ud_thk[c4d.DESC_NAME] = "Baked_Thickness"
    container.AddUserData(ud_thk)
    container[c4d.ID_USERDATA, 2] = thickness_real
    
    ud_h = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
    ud_h[c4d.DESC_NAME] = "Baked_Height"
    container.AddUserData(ud_h)
    container[c4d.ID_USERDATA, 3] = size_v.y
    
    obj_mg = obj.GetMg()
    
    # 插入到文档根目录，确保坐标纯净
    doc.InsertObject(container) 
    
    obj.Remove()
    obj.InsertUnder(container)
    obj.SetMg(obj_mg)
    
    return container, size_v.y

ROOM_GENERATOR_SCRIPT = r"""
import c4d
from c4d import utils

RECESS_VAL = 10.0
OVERLAP = 2.0

def GetMat(name):
    try:
        doc = c4d.documents.GetActiveDocument()
        return doc.SearchMaterial(name)
    except: return None

def MakeBox(name, size, pos, mat_name, parent):
    cube = c4d.BaseObject(c4d.Ocube)
    cube.SetName(name)
    cube[c4d.PRIM_CUBE_LEN] = size
    cube.SetAbsPos(pos)
    mat = GetMat(mat_name)
    if mat: 
        t = cube.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat)
    if parent: cube.InsertUnderLast(parent)
    return cube

def MakeSpot(name, pos, mat_body_name, show_wireframe, parent):
    group = c4d.BaseObject(c4d.Onull)
    group.SetName(name)
    group.SetAbsPos(pos)
    casing = c4d.BaseObject(c4d.Ocylinder)
    casing[c4d.PRIM_CYLINDER_RADIUS] = 4.0
    casing[c4d.PRIM_CYLINDER_HEIGHT] = 2.0
    casing[c4d.PRIM_AXIS] = 2 
    casing.InsertUnder(group)
    bulb = c4d.BaseObject(c4d.Ocylinder)
    bulb[c4d.PRIM_CYLINDER_RADIUS] = 3.5
    bulb[c4d.PRIM_CYLINDER_HEIGHT] = 0.1
    bulb[c4d.PRIM_AXIS] = 2 
    bulb.SetAbsPos(c4d.Vector(0, -1.0, 0))
    mat_spot = GetMat("Pro_Light_Spot")
    if mat_spot:
        t = bulb.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat_spot)
    bulb.InsertUnder(group)
    if show_wireframe:
        real_light = c4d.BaseObject(c4d.Olight)
        real_light[c4d.LIGHT_TYPE] = c4d.LIGHT_TYPE_SPOT
        real_light[c4d.LIGHT_BRIGHTNESS] = 1.0
        real_light[c4d.LIGHT_DETAILS_OUTERANGLE] = 0.8
        real_light.SetAbsRot(c4d.Vector(0, -1.5708, 0)) 
        real_light.SetAbsPos(c4d.Vector(0, -1.5, 0))
        real_light.InsertUnder(group)
    if parent: group.InsertUnderLast(parent)
    return group

def CreateStepBorder(name, w, h, d, x, y, z, border_type, parent):
    M_WHITE = "Pro_Wall_White"
    M_LIGHT_COVE = "Pro_Light_Cove"
    h_lower = 8.0; h_upper = h - h_lower; recess = RECESS_VAL
    top_y = y + h/2.0
    y_upper = top_y - h_upper/2.0
    y_lower = top_y - h_upper - h_lower/2.0
    light_thick = 0.5; light_width = recess * 0.5; y_light = (y_lower + h_lower/2.0) + light_thick/2.0
    extend_len = (recess * 2.0) + 20.0
    
    if border_type == "L": 
        MakeBox(name+"_Low", c4d.Vector(w,h_lower,d), c4d.Vector(x,y_lower,z), M_WHITE, parent)
        MakeBox(name+"_Up", c4d.Vector(w-recess,h_upper,d), c4d.Vector(x-recess/2.0,y_upper,z), M_WHITE, parent)
        MakeBox(name+"_Light", c4d.Vector(light_width,light_thick,d-2.0), c4d.Vector(x+w/2.0-recess/2.0,y_light,z), M_LIGHT_COVE, parent)
    elif border_type == "R": 
        MakeBox(name+"_Low", c4d.Vector(w,h_lower,d), c4d.Vector(x,y_lower,z), M_WHITE, parent)
        MakeBox(name+"_Up", c4d.Vector(w-recess,h_upper,d), c4d.Vector(x+recess/2.0,y_upper,z), M_WHITE, parent)
        MakeBox(name+"_Light", c4d.Vector(light_width,light_thick,d-2.0), c4d.Vector(x-w/2.0+recess/2.0,y_light,z), M_LIGHT_COVE, parent)
    elif border_type == "F": 
        MakeBox(name+"_Low", c4d.Vector(w,h_lower,d), c4d.Vector(x,y_lower,z), M_WHITE, parent)
        MakeBox(name+"_Up", c4d.Vector(w+extend_len,h_upper,d-recess), c4d.Vector(x,y_upper,z-recess/2.0), M_WHITE, parent)
        MakeBox(name+"_Light", c4d.Vector(w+extend_len,light_thick,light_width), c4d.Vector(x,y_light,z+d/2.0-recess/2.0), M_LIGHT_COVE, parent)
    elif border_type == "B": 
        MakeBox(name+"_Low", c4d.Vector(w,h_lower,d), c4d.Vector(x,y_lower,z), M_WHITE, parent)
        MakeBox(name+"_Up", c4d.Vector(w+extend_len,h_upper,d-recess), c4d.Vector(x,y_upper,z+recess/2.0), M_WHITE, parent)
        MakeBox(name+"_Light", c4d.Vector(w+extend_len,light_thick,light_width), c4d.Vector(x,y_light,z-d/2.0+recess/2.0), M_LIGHT_COVE, parent)

def main():
    try:
        parent = op.GetUp()
        if not parent: return c4d.BaseObject(c4d.Onull)

        try: room_w = op[c4d.ID_USERDATA, 1]; room_d = op[c4d.ID_USERDATA, 2]
        except: room_w = 500.0; room_d = 400.0

        def GetP(id, default):
            try: 
                val = parent[c4d.ID_USERDATA, id]
                if val is None: return default
                return val
            except: return default

        # ID Mapping
        enable_ceil_sys = GetP(6, True)
        custom_ceil_obj = GetP(7, None)
        
        if not enable_ceil_sys:
            return c4d.BaseObject(c4d.Onull)
            
        clear_h = GetP(10, 260.0)
        
        if custom_ceil_obj:
            if isinstance(custom_ceil_obj, c4d.BaseObject):
                if custom_ceil_obj.GetEditorMode() != c4d.OBJECT_OFF:
                    custom_ceil_obj.SetEditorMode(c4d.OBJECT_OFF)
                    custom_ceil_obj.SetRenderMode(c4d.OBJECT_OFF)
                
                clone = custom_ceil_obj.GetClone()
                wrapper = c4d.BaseObject(c4d.Onull)
                wrapper.SetName("Custom_Ceiling_Rotator")
                
                custom_off_y = GetP(9, 0.0)
                wrapper.SetAbsPos(c4d.Vector(0, clear_h + custom_off_y, 0))
                
                rot_vec = GetP(8, c4d.Vector(0))
                wrapper.SetAbsRot(rot_vec)
                
                clone.SetAbsPos(c4d.Vector(0,0,0))
                clone.SetAbsRot(c4d.Vector(0,0,0))
                clone.InsertUnder(wrapper)
                clone.SetEditorMode(c4d.OBJECT_ON)
                clone.SetRenderMode(c4d.OBJECT_ON)
                return wrapper
            else:
                return c4d.BaseObject(c4d.Onull)

        ct = GetP(11, 3)
        master_light = GetP(13, True)
        spot_dist = GetP(14, 120.0)
        expand_x = GetP(15, -12.0)
        expand_z = GetP(16, -12.0)
        
        enable_spots = GetP(17, True) and master_light
        enable_side = GetP(18, True)
        show_wire = GetP(19, True)
        margin = GetP(20, 60.0)
        strip_cnt = GetP(21, 3)
        enable_strips = master_light

        root = c4d.BaseObject(c4d.Onull)
        rw = room_w; rd = room_d; total_rh = clear_h + 30.0
        M_WHITE = "Pro_Wall_White"; M_BLACK = "Pro_Metal_Dark"; M_LIGHT_LINEAR = "Pro_Light_Cove"
        
        if ct == 3: # 跌级
            drop_h = 30.0; drop_y = clear_h + drop_h/2.0
            CreateStepBorder("DL", margin, drop_h, rd, -rw/2.0+margin/2.0, drop_y, 0, "L", root)
            CreateStepBorder("DR", margin, drop_h, rd, rw/2.0-margin/2.0, drop_y, 0, "R", root)
            in_w = rw - margin*2.0
            CreateStepBorder("DF", in_w, drop_h, margin, 0, drop_y, -rd/2.0+margin/2.0, "F", root)
            CreateStepBorder("DB", in_w, drop_h, margin, 0, drop_y, rd/2.0-margin/2.0, "B", root)
            MakeBox("TopSlab", c4d.Vector(rw, 2, rd), c4d.Vector(0, total_rh+1.0, 0), M_BLACK, root)
            
            light_w = 8.0 
            light_padding = 35.0 
            in_d_base = rd - margin*2.0
            in_d_extended = in_d_base + (RECESS_VAL * 2.0) + OVERLAP
            if strip_cnt < 1: strip_cnt = 1
            total_light_w = strip_cnt * light_w
            total_panel_w = in_d_extended - total_light_w
            panel_w = total_panel_w / float(strip_cnt + 1)
            real_light_len = in_w - (light_padding * 2.0)
            if real_light_len < 10: real_light_len = 10
            filler_w = light_padding + RECESS_VAL + OVERLAP
            curr_z = -in_d_extended/2.0
            ceil_y_center = total_rh - 2.5
            light_y_center = total_rh - 4.3
            slot_back_y = total_rh - 1.0
            panel_extend_w = in_w + (RECESS_VAL * 2.0) + OVERLAP
            
            for i in range(strip_cnt + 1):
                p_z = curr_z + panel_w/2.0
                MakeBox("Panel", c4d.Vector(panel_extend_w, 5, panel_w), c4d.Vector(0, ceil_y_center, p_z), M_WHITE, root)
                curr_z += panel_w
                if i < strip_cnt:
                    l_z = curr_z + light_w/2.0
                    MakeBox("Slot_Back", c4d.Vector(real_light_len + 2.0, 2, light_w), c4d.Vector(0, slot_back_y, l_z), M_BLACK, root)
                    if enable_strips:
                        MakeBox("Light_Strip", c4d.Vector(real_light_len, 1, light_w), c4d.Vector(0, light_y_center, l_z), M_LIGHT_LINEAR, root)
                    fx_left = (-in_w/2.0 - RECESS_VAL) + filler_w/2.0 - (OVERLAP/2.0)
                    MakeBox("Filler_L", c4d.Vector(filler_w, 5, light_w), c4d.Vector(fx_left, ceil_y_center, l_z), M_WHITE, root)
                    fx_right = -fx_left
                    MakeBox("Filler_R", c4d.Vector(filler_w, 5, light_w), c4d.Vector(fx_right, ceil_y_center, l_z), M_WHITE, root)
                    curr_z += light_w
            
            if enable_spots:
                base_cx = rw/2.0 - margin/2.0
                base_cz = rd/2.0 - margin/2.0
                sy = clear_h
                cx = base_cx + expand_x
                cz = base_cz + expand_z
                MakeSpot("Corner_FL", c4d.Vector(-cx, sy, -cz), M_BLACK, show_wire, root)
                MakeSpot("Corner_FR", c4d.Vector(cx, sy, -cz), M_BLACK, show_wire, root)
                MakeSpot("Corner_BL", c4d.Vector(-cx, sy, cz), M_BLACK, show_wire, root)
                MakeSpot("Corner_BR", c4d.Vector(cx, sy, cz), M_BLACK, show_wire, root)
                
                if spot_dist < 50.0: spot_dist = 50.0
                dist_x = cx * 2.0
                cnt_x = int(dist_x / spot_dist)
                if cnt_x > 0:
                    step = dist_x / (cnt_x + 1)
                    for k in range(1, cnt_x + 1):
                        x = -cx + k*step 
                        MakeSpot(f"Spot_F_{k}", c4d.Vector(x, sy, -cz), M_BLACK, show_wire, root)
                        MakeSpot(f"Spot_B_{k}", c4d.Vector(x, sy, cz), M_BLACK, show_wire, root)
                if enable_side:
                    dist_z = cz * 2.0
                    cnt_z = int(dist_z / spot_dist)
                    if cnt_z > 0:
                        step = dist_z / (cnt_z + 1)
                        for k in range(1, cnt_z + 1):
                            z = -cz + k*step 
                            MakeSpot(f"Spot_L_{k}", c4d.Vector(-cx, sy, z), M_BLACK, show_wire, root)
                            MakeSpot(f"Spot_R_{k}", c4d.Vector(cx, sy, z), M_BLACK, show_wire, root)

        elif ct == 2: # 平顶
            MakeBox("FlatTop", c4d.Vector(rw, 5, rd), c4d.Vector(0, clear_h+2.5, 0), M_WHITE, root)
            if enable_spots:
                cx = rw/2.0 - 50.0 + expand_x
                cz = rd/2.0 - 50.0 + expand_z
                sy = clear_h
                MakeSpot("L1", c4d.Vector(-cx, sy, -cz), M_BLACK, show_wire, root)
                MakeSpot("L2", c4d.Vector(cx, sy, -cz), M_BLACK, show_wire, root)
                MakeSpot("L3", c4d.Vector(-cx, sy, cz), M_BLACK, show_wire, root)
                MakeSpot("L4", c4d.Vector(cx, sy, cz), M_BLACK, show_wire, root)
        
        return root
    except Exception as e:
        print(f"GenError: {e}")
        return c4d.BaseObject(c4d.Onull)
"""

def AddRoomController(room_null, default_h=260.0):
    for id, bc in room_null.GetUserDataContainer():
        room_null.RemoveUserData(id)

    def AddUD(name, dtype, val, unit=0, cycle=None, min_v=None, max_v=None, parent_id=None):
        bc = c4d.GetCustomDataTypeDefault(dtype)
        bc[c4d.DESC_NAME] = name
        if unit: bc[c4d.DESC_UNIT] = unit
        if cycle:
            cycle_bc = c4d.BaseContainer()
            for k, v in cycle.items(): cycle_bc.SetString(k, v)
            bc[c4d.DESC_CYCLE] = cycle_bc
        if min_v is not None: bc[c4d.DESC_MIN] = min_v
        if max_v is not None: bc[c4d.DESC_MAX] = max_v
        if parent_id: bc[c4d.DESC_PARENTGROUP] = parent_id
        
        bc[c4d.DESC_DEFAULT] = val 
        el = room_null.AddUserData(bc)
        if dtype not in[c4d.DTYPE_SEPARATOR, c4d.DTYPE_GROUP]: room_null[el] = val
        return el

    def AddGroup(name):
        bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
        bc[c4d.DESC_NAME] = name
        bc[c4d.DESC_TITLEBAR] = 1 
        return room_null.AddUserData(bc)

    # UI布局
    grp_wall = AddGroup("基础结构 (墙/地)") # ID 1
    AddUD("接缝修正 (匀速对齐)", c4d.DTYPE_REAL, 20.0, c4d.DESC_UNIT_METER, parent_id=grp_wall) # ID 2
    AddUD("反转朝向", c4d.DTYPE_BOOL, True, parent_id=grp_wall) # ID 3
    AddUD("地面厚度", c4d.DTYPE_REAL, 10.0, c4d.DESC_UNIT_METER, parent_id=grp_wall) # ID 4
    
    grp_ceil = AddGroup("智能吊顶 & 灯光") # ID 5
    AddUD("✅ 启用智能吊顶", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 6
    AddUD("🔗 替换自定义吊顶", c4d.DTYPE_BASELISTLINK, None, parent_id=grp_ceil) # ID 7
    AddUD("自定义吊顶旋转", c4d.DTYPE_VECTOR, c4d.Vector(0), c4d.DESC_UNIT_DEGREE, parent_id=grp_ceil) # ID 8
    AddUD("自定义吊顶偏移 Y", c4d.DTYPE_REAL, 0.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 9
    
    AddUD("吊顶净高", c4d.DTYPE_REAL, default_h, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 10
    opts = {1:"整体吊顶", 2:"平顶", 3:"跌级吊顶(推荐)"}
    AddUD("吊顶款式", c4d.DTYPE_LONG, 3, cycle=opts, parent_id=grp_ceil) # ID 11
    
    AddUD("--- 灯光细节 ---", c4d.DTYPE_SEPARATOR, None, parent_id=grp_ceil) # ID 12
    AddUD("💡 灯光总开关", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 13
    
    AddUD("射灯间距", c4d.DTYPE_REAL, 120.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 14
    AddUD("射灯外扩 X (左右撑开)", c4d.DTYPE_REAL, -12.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 15
    AddUD("射灯外扩 Z (前后撑开)", c4d.DTYPE_REAL, -12.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 16
    
    AddUD("开启射灯", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 17
    AddUD("开启两侧射灯", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 18
    AddUD("显示灯光线框", c4d.DTYPE_BOOL, True, parent_id=grp_ceil) # ID 19
    AddUD("吊顶边距", c4d.DTYPE_REAL, 60.0, c4d.DESC_UNIT_METER, parent_id=grp_ceil) # ID 20
    AddUD("灯带层数", c4d.DTYPE_LONG, 3, min_v=1, max_v=10, parent_id=grp_ceil) # ID 21

    # Tag脚本
    py_tag = room_null.MakeTag(c4d.Tpython)
    py_tag.SetName("RoomDriver_花花广告设计_v1.1")
    
    script =[]
    script.append("import c4d")
    script.append("from c4d import utils")
    script.append("")
    script.append("def main():")
    script.append("    room = op.GetObject()")
    script.append("    if not room: return")
    script.append("    walls =[]; floor = None; ceiling_gen = None")
    script.append("    curr = room.GetDown()")
    script.append("    while curr:")
    script.append("        name = curr.GetName()")
    script.append("        if '智能地面' in name: floor = curr")
    script.append("        elif '智能吊顶' in name: ceiling_gen = curr")
    script.append("        else: walls.append(curr)")
    script.append("        curr = curr.GetNext()")
    script.append("    if len(walls) < 4: return")
    script.append("")
    script.append("    try:")
    script.append("        val_gap = room[c4d.ID_USERDATA, 2]")
    script.append("        val_flip = room[c4d.ID_USERDATA, 3]")
    script.append("        floor_h = room[c4d.ID_USERDATA, 4]")
    script.append("        # 强制读取以触发联动")
    script.append("        _ = room[c4d.ID_USERDATA, 6]; _ = room[c4d.ID_USERDATA, 7]")
    script.append("        _ = room[c4d.ID_USERDATA, 14]; _ = room[c4d.ID_USERDATA, 21]")
    script.append("    except: val_gap=20.0; val_flip=True; floor_h=10.0")
    script.append("")
    script.append("    w1, w2, w3, w4 = walls[0], walls[1], walls[2], walls[3]")
    script.append("    def GetBakedSize(obj):")
    script.append("        try: L = obj[c4d.ID_USERDATA, 1]; T = obj[c4d.ID_USERDATA, 2]")
    script.append("        except: L=200.0; T=20.0")
    script.append("        return L, T")
    script.append("    l1, t1 = GetBakedSize(w1); l2, t2 = GetBakedSize(w2)")
    script.append("    l3, t3 = GetBakedSize(w3); l4, t4 = GetBakedSize(w4)")
    script.append("")
    script.append("    offset = utils.Rad(180) if not val_flip else 0")
    script.append("    w1.SetRelRot(c4d.Vector(utils.Rad(180)+offset,0,0)); w2.SetRelRot(c4d.Vector(utils.Rad(-90)+offset,0,0))")
    script.append("    w3.SetRelRot(c4d.Vector(utils.Rad(0)+offset,0,0)); w4.SetRelRot(c4d.Vector(utils.Rad(90)+offset,0,0))")
    script.append("")
    script.append("    # 花花广告设计 v1.1: 极简算法，不依赖标准厚度，只看 Gap")
    script.append("    base_w = max(l1, l3)")
    script.append("    base_d = max(l2, l4)")
    script.append("    z_dist = (base_d / 2.0) + val_gap")
    script.append("    x_dist = (base_w / 2.0) + val_gap")
    script.append("")
    script.append("    w1.SetRelPos(c4d.Vector(0,0,-z_dist)); w3.SetRelPos(c4d.Vector(0,0,z_dist))")
    script.append("    w2.SetRelPos(c4d.Vector(x_dist,0,0)); w4.SetRelPos(c4d.Vector(-x_dist,0,0))")
    script.append("")
    script.append("    ceil_w = (x_dist * 2.0)")
    script.append("    ceil_d = (z_dist * 2.0)")
    script.append("")
    script.append("    if floor:")
    script.append("        floor[c4d.PRIM_CUBE_LEN] = c4d.Vector(ceil_w, floor_h, ceil_d)")
    script.append("        floor.SetRelPos(c4d.Vector(0, -floor_h/2.0, 0))")
    script.append("    if ceiling_gen:")
    script.append("        ceiling_gen[c4d.ID_USERDATA, 1] = ceil_w")
    script.append("        ceiling_gen[c4d.ID_USERDATA, 2] = ceil_d")
    script.append("        ceiling_gen.SetDirty(c4d.DIRTYFLAGS_DATA)")
    script.append("        ceiling_gen.SetDirty(c4d.DIRTYFLAGS_CACHE)")
    script.append("    c4d.EventAdd()")

    py_tag[c4d.TPYTHON_CODE] = "\n".join(script)

def CreateSmartRoom(doc):
    sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
    
    # 核心：群组识别
    if len(sel) == 1 and sel[0].GetDown():
        group = sel[0]
        sel =[]
        child = group.GetDown()
        while child:
            sel.append(child)
            child = child.GetNext()
    
    if len(sel) != 4:
        gui.MessageDialog("请确保选中了 4 个墙体对象 (或 1 个包含 4 面墙的组)！")
        return

    try:
        # 花花广告设计 v1.1: 取消 reverse，恢复列表 Top->Bottom = 前->右->后->左
        sel.reverse() 

        doc.ExecutePasses(None, True, True, True, c4d.BUILDFLAGS_NONE)
        doc.StartUndo()
        CheckAndCreateMaterials(doc)

        room_group = c4d.BaseObject(c4d.Onull)
        room_group.SetName("智能展厅_花花广告设计_v1.1 (防炸稳定版)")
        room_group[c4d.NULLOBJECT_DISPLAY] = 14
        room_group[c4d.NULLOBJECT_ORIENTATION] = 1
        room_group[c4d.NULLOBJECT_RADIUS] = 200
        doc.InsertObject(room_group)
        doc.AddUndo(c4d.UNDOTYPE_NEW, room_group)

        max_wall_h = 260.0
        suffixes =["_前", "_右", "_后", "_左"]
        
        for i, obj in enumerate(sel):
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
            container, h = SmartWrapper(doc, obj, suffixes[i])
            if h > max_wall_h: max_wall_h = h
            # 关键：先从世界根目录移除，再加入组
            container.Remove()
            container.InsertUnderLast(room_group)
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, container)

        floor = c4d.BaseObject(c4d.Ocube)
        floor.SetName("智能地面_Floor")
        floor[c4d.PRIM_CUBE_LEN] = c4d.Vector(500, 10, 400)
        floor[c4d.PRIM_CUBE_DOFILLET] = True 
        floor[c4d.PRIM_CUBE_FRAD] = 0.5
        tag = floor.MakeTag(c4d.Ttexture)
        mat = doc.SearchMaterial("Pro_Floor_Wood")
        if mat: tag.SetMaterial(mat)
        tag[c4d.TEXTURETAG_PROJECTION] = 6; tag[c4d.TEXTURETAG_LENGTHX] = 200; tag[c4d.TEXTURETAG_LENGTHY] = 200
        floor.InsertUnderLast(room_group)
        doc.AddUndo(c4d.UNDOTYPE_NEW, floor)

        gen = c4d.BaseObject(c4d.Opython)
        gen.SetName("智能吊顶_Generator")
        bc_hide = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
        bc_hide[c4d.DESC_NAME] = "Auto_W"; bc_hide[c4d.DESC_HIDE] = True 
        gen.AddUserData(bc_hide); gen.AddUserData(bc_hide)
        gen[c4d.OPYTHON_CODE] = ROOM_GENERATOR_SCRIPT
        gen.InsertUnderLast(room_group)
        doc.AddUndo(c4d.UNDOTYPE_NEW, gen)

        AddRoomController(room_group, default_h=max_wall_h)

        doc.SetActiveObject(room_group)
        doc.EndUndo()
        c4d.EventAdd()
        
    except Exception as e:
        gui.MessageDialog(f"生成失败，错误信息:\n{e}\n\n请检查控制台(Shift+F10)获取详细信息")
        traceback.print_exc()

# ==============================================================================
# 花花广告设计 v1.1 - 智能弯曲墙体核心功能库 (Curved Wall Builder)
# ==============================================================================
def GetSmartDensity(obj):
    """
    计算最佳初始密度 (0.0 - 1.0)
    基于面积反向逻辑: 大面积->5cm(1.0), 小面积->15cm(0.0)
    """
    if not obj or not obj.CheckType(c4d.Oextrude):
        return 0.5 # 默认中间值

    try:
        rad = obj.GetRad()
        width = rad.x * 2.0
        height = rad.y * 2.0
        area = width * height
        
        area_min = 10000.0   # 1m x 1m
        area_max = 500000.0  # 10m x 5m
        
        if area <= area_min: return 0.0       # 小面积用稀疏
        if area >= area_max: return 1.0       # 大面积用密集
        
        # 线性插值
        ratio = (area - area_min) / (area_max - area_min)
        return ratio
    except:
        return 0.5

def OptimizeObjectTopology(obj):
    """
    花花广告设计 v1.1: 仅设置基础属性 (N-gon, 独立控制等)，尺寸交由 Tag 驱动
    """
    if obj is None: return

    # 1. 样条优化
    if obj.GetInfo() & c4d.OBJECT_ISSPLINE:
        try:
            obj[c4d.SPLINEOBJECT_INTERPOLATION] = c4d.SPLINEOBJECT_INTERPOLATION_NATURAL
            obj[c4d.SPLINEOBJECT_SUB] = 48 
        except: pass

    # 2. 挤压对象 (Extrude) 基础设置
    elif obj.CheckType(c4d.Oextrude):
        try:
            # 开启独立控制 (ID 3008)
            obj.SetParameter(c4d.DescID(3008), True, c4d.DESCFLAGS_SET_0)
            # 设置细分类型为 常规网格 (ID 3002 = 4)
            obj.SetParameter(c4d.DescID(3002), 4, c4d.DESCFLAGS_SET_0)
            # 确保封顶启用
            obj.SetParameter(c4d.DescID(2999), True, c4d.DESCFLAGS_SET_0)
            obj.SetParameter(c4d.DescID(3000), True, c4d.DESCFLAGS_SET_0)
        except Exception as e:
            print(f"基础优化失败: {e}")

    # 3. 立方体优化 (Cube)
    elif obj.CheckType(c4d.Ocube):
        try:
            rad = obj.GetRad(); len_x = rad.x * 2.0
            segs = int(len_x / 10.0)
            if segs < 1: segs = 1; 
            if segs > 400: segs = 400 
            obj[c4d.PRIM_CUBE_SUBX] = segs
        except: pass

    child = obj.GetDown()
    while child:
        OptimizeObjectTopology(child)
        child = child.GetNext()

def AddSmartController(obj, fit_mode_default, initial_density):
    # --- 1. 创建 User Data ---
    bc1 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc1[c4d.DESC_NAME] = "偏移 (Offset)"; bc1[c4d.DESC_UNIT] = c4d.DESC_UNIT_PERCENT; bc1[c4d.DESC_MIN] = 0.0; bc1[c4d.DESC_MAX] = 1.0; bc1[c4d.DESC_STEP] = 0.01
    el1 = obj.AddUserData(bc1); obj[el1] = 0.0
    id1 = int(el1[1].id) 
    
    bc2 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc2[c4d.DESC_NAME] = "结束位置 (End)"; bc2[c4d.DESC_UNIT] = c4d.DESC_UNIT_PERCENT; bc2[c4d.DESC_MIN] = 0.0; bc2[c4d.DESC_MAX] = 1.0; bc2[c4d.DESC_STEP] = 0.01
    el2 = obj.AddUserData(bc2); obj[el2] = 1.0
    id2 = int(el2[1].id)
    
    bc3 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_LONG); bc3[c4d.DESC_NAME] = "模式 (Mode)"; 
    cycle = c4d.BaseContainer(); cycle.SetString(0, "匹配样条 (伸缩)"); cycle.SetString(1, "保持长度 (不伸缩)"); 
    bc3[c4d.DESC_CYCLE] = cycle
    el3 = obj.AddUserData(bc3); obj[el3] = int(fit_mode_default)
    id3 = int(el3[1].id)
    
    bc4 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_BOOL); bc4[c4d.DESC_NAME] = "翻转墙体 (Flip)"; 
    el4 = obj.AddUserData(bc4); obj[el4] = True 
    id4 = int(el4[1].id)

    bc5 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc5[c4d.DESC_NAME] = "变形器旋转 H"; bc5[c4d.DESC_UNIT] = c4d.DESC_UNIT_DEGREE; bc5[c4d.DESC_STEP] = 1.0
    el5 = obj.AddUserData(bc5); obj[el5] = c4d.utils.Rad(0.0) 
    id5 = int(el5[1].id)

    bc6 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc6[c4d.DESC_NAME] = "变形器旋转 P"; bc6[c4d.DESC_UNIT] = c4d.DESC_UNIT_DEGREE; bc6[c4d.DESC_STEP] = 1.0
    el6 = obj.AddUserData(bc6); obj[el6] = c4d.utils.Rad(180.0) 
    id6 = int(el6[1].id)

    bc7 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL); bc7[c4d.DESC_NAME] = "变形器旋转 B"; bc7[c4d.DESC_UNIT] = c4d.DESC_UNIT_DEGREE; bc7[c4d.DESC_STEP] = 1.0
    el7 = obj.AddUserData(bc7); obj[el7] = c4d.utils.Rad(0.0) 
    id7 = int(el7[1].id)

    bc8 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_LONG); bc8[c4d.DESC_NAME] = "样条精度 (Spline Sub)"; bc8[c4d.DESC_MIN] = 0; bc8[c4d.DESC_MAX] = 500; bc8[c4d.DESC_STEP] = 1
    el8 = obj.AddUserData(bc8); obj[el8] = 48 
    id8 = int(el8[1].id)

    # === 新增：网格疏密控制 ===
    bc9 = c4d.GetCustomDataTypeDefault(c4d.DTYPE_REAL)
    bc9[c4d.DESC_NAME] = "网格疏密 (Density)"
    bc9[c4d.DESC_UNIT] = c4d.DESC_UNIT_PERCENT
    bc9[c4d.DESC_MIN] = 0.0
    bc9[c4d.DESC_MAX] = 1.0
    bc9[c4d.DESC_STEP] = 0.01
    bc9[c4d.DESC_CUSTOMGUI] = c4d.CUSTOMGUI_REALSLIDER 
    el9 = obj.AddUserData(bc9)
    obj[el9] = initial_density 
    id9 = int(el9[1].id)

    # --- 2. 生成 Python 标签 ---
    py_tag = obj.MakeTag(c4d.Tpython)
    py_tag.SetName("SmartDriver_CN_花花广告设计_v1.1")
    
    lines =[]
    lines.append("import c4d")
    lines.append("def main():")
    lines.append("    try:")
    lines.append("        host = op.GetObject()")
    lines.append("        if not host: return")
    lines.append("")
    lines.append("        val_offset  = host[c4d.ID_USERDATA, " + str(id1) + "]")
    lines.append("        val_to      = host[c4d.ID_USERDATA, " + str(id2) + "]")
    lines.append("        val_mode    = host[c4d.ID_USERDATA, " + str(id3) + "]")
    lines.append("        val_flip    = host[c4d.ID_USERDATA, " + str(id4) + "]")
    lines.append("        val_h       = host[c4d.ID_USERDATA, " + str(id5) + "]")
    lines.append("        val_p       = host[c4d.ID_USERDATA, " + str(id6) + "]")
    lines.append("        val_b       = host[c4d.ID_USERDATA, " + str(id7) + "]")
    lines.append("        val_sub     = host[c4d.ID_USERDATA, " + str(id8) + "]")
    lines.append("        val_density = host[c4d.ID_USERDATA, " + str(id9) + "]")
    lines.append("")
    lines.append("        grid_size = 15.0 - (val_density * 10.0)")
    lines.append("")
    lines.append("        wall_obj = None")
    lines.append("        spline_obj = None")
    lines.append("")
    lines.append("        child = host.GetDown()")
    lines.append("        while child:")
    lines.append("            if child.GetInfo() & c4d.OBJECT_ISSPLINE:")
    lines.append("                spline_obj = child")
    lines.append("            else:")
    lines.append("                wall_obj = child")
    lines.append("            child = child.GetNext()")
    lines.append("")
    lines.append("        if spline_obj and spline_obj.CheckType(c4d.Ospline):")
    lines.append("             if spline_obj[c4d.SPLINEOBJECT_SUB] != int(val_sub):")
    lines.append("                 spline_obj[c4d.SPLINEOBJECT_SUB] = int(val_sub)")
    lines.append("")
    lines.append("        if wall_obj:")
    lines.append("            target_wrot = c4d.utils.Rad(180) if val_flip else 0.0")
    lines.append("            cur_wrot = wall_obj.GetRelRot()")
    lines.append("            if abs(cur_wrot.x - target_wrot) > 0.001:")
    lines.append("                wall_obj.SetRelRot(c4d.Vector(target_wrot, 0, 0))")
    lines.append("")
    lines.append("            def UpdateExtrude(obj, size):")
    lines.append("                if not obj: return")
    lines.append("                if obj.CheckType(c4d.Oextrude):")
    lines.append("                    if abs(obj[3004] - size) > 0.01:")
    lines.append("                        obj[3004] = size")
    lines.append("                curr = obj.GetDown()")
    lines.append("                while curr:")
    lines.append("                    UpdateExtrude(curr, size)")
    lines.append("                    curr = curr.GetNext()")
    lines.append("")
    lines.append("            UpdateExtrude(wall_obj, grid_size)")
    lines.append("")
    lines.append("            def FindDeformer(obj):")
    lines.append("                if not obj: return None")
    lines.append("                curr = obj.GetDown()")
    lines.append("                while curr:")
    lines.append("                    if curr.CheckType(1019221): return curr")
    lines.append("                    curr = curr.GetNext()")
    lines.append("                return None")
    lines.append("")
    lines.append("            deformer = FindDeformer(wall_obj)")
    lines.append("            if deformer:")
    lines.append("                deformer[1004] = val_offset")
    lines.append("                deformer[1003] = val_to")
    lines.append("                if val_mode is not None:")
    lines.append("                    deformer[1012] = int(val_mode)")
    lines.append("                tv = c4d.Vector(val_h, val_p, val_b)")
    lines.append("                cv = deformer.GetRelRot()")
    lines.append("                if (tv - cv).GetLength() > 0.001:")
    lines.append("                    deformer.SetRelRot(tv)")
    lines.append("    except: pass")
    
    py_tag[c4d.TPYTHON_CODE] = "\n".join(lines)

def NormalizeWallGroup(doc, obj):
    old_mg = obj.GetMg()
    new_mg = c4d.Matrix(old_mg)
    new_mg.off = c4d.Vector(0,0,0)
    obj.SetMg(new_mg)

def CreateCurvedWall(doc, wall_parts, spline_obj, fit_mode):
    if len(wall_parts) > 1:
        group_null = c4d.BaseObject(c4d.Onull)
        group_null.SetName("Wall_Group_Temp")
        doc.InsertObject(group_null)
        for part in wall_parts:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, part)
            mat = part.GetMg()
            part.Remove()
            part.InsertUnder(group_null)
            part.SetMg(mat)
        wall_obj = group_null
    else:
        wall_obj = wall_parts[0]

    OptimizeObjectTopology(wall_obj) 
    OptimizeObjectTopology(spline_obj)
    
    calc_obj = wall_obj
    if wall_obj.CheckType(c4d.Onull) and wall_obj.GetDown():
        calc_obj = wall_obj.GetDown() 
    initial_density = GetSmartDensity(calc_obj)
    
    container = c4d.BaseObject(c4d.Onull)
    container.SetName("智能墙体组_" + wall_obj.GetName())
    container[c4d.NULLOBJECT_DISPLAY] = 2 
    container[c4d.NULLOBJECT_RADIUS] = 20.0 
    container[c4d.NULLOBJECT_ORIENTATION] = 1 
    
    doc.InsertObject(container, pred=wall_obj)
    doc.AddUndo(c4d.UNDOTYPE_NEW, container)
    
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, wall_obj) 
    wall_obj.Remove()
    wall_obj.InsertUnder(container) 
    
    doc.AddUndo(c4d.UNDOTYPE_CHANGE, spline_obj)
    spline_obj.Remove()
    spline_obj.InsertUnder(container)
    
    NormalizeWallGroup(doc, wall_obj) 
    
    swrap = c4d.BaseObject(ID_SPLINEWRAP)
    if not swrap: return
    swrap.SetName("样条约束 (SplineWrap)") 
    swrap[1001] = spline_obj
    swrap[1006] = 1 # +X
    swrap[1012] = int(fit_mode)
    swrap[1009] = False
    swrap.SetRelRot(c4d.Vector(0, c4d.utils.Rad(180), 0))
    
    doc.InsertObject(swrap, parent=wall_obj)
    doc.AddUndo(c4d.UNDOTYPE_NEW, swrap)
    
    AddSmartController(container, fit_mode, initial_density) 
    
    doc.SetActiveObject(container)
    wall_obj.SetRelRot(c4d.Vector(c4d.utils.Rad(180), 0, 0)) 
    
    c4d.EventAdd()
    return container

# ------------------------------------------------------------------------------
# 资产库画布类 (AssetViewer)
# ------------------------------------------------------------------------------
class AssetViewer(gui.GeUserArea):
    def __init__(self, dialog):
        self.parent_dialog = dialog
        self.assets =[]          
        self.icon_size = 130      
        self.gap = 10 
        self.text_height = 25 
        
        self.bg_color = c4d.Vector(0.25)
        self.text_color = c4d.Vector(0.9)
        self.cols = 1             
        self.needed_height = 200 
        self.last_click_time = 0
        self.last_click_index = -1
        self.selected_index = -1 

    def GetMinSize(self): return 100, self.needed_height

    def DrawMsg(self, x1, y1, x2, y2, msg):
        self.OffScreenOn()
        self.DrawSetPen(self.bg_color)
        self.DrawRectangle(x1, y1, x2, y2)
        if not self.assets:
            self.DrawSetTextCol(self.text_color, self.bg_color)
            self.DrawText("无符合条件的资产", 20, 20)
            return
        area_width = self.GetWidth()
        if area_width < 10: area_width = 400
        cell_w = self.icon_size + self.gap
        cell_h = self.icon_size + self.gap + self.text_height
        self.cols = max(1, int(area_width / cell_w))
        for i, asset in enumerate(self.assets):
            row = i // self.cols
            col = i % self.cols
            x_pos = col * cell_w + self.gap
            y_pos = row * cell_h + self.gap 
            if i == self.selected_index:
                self.DrawSetPen(c4d.Vector(0.4, 0.3, 0.2)) 
                self.DrawRectangle(x_pos-2, y_pos-2, x_pos+self.icon_size+2, y_pos+self.icon_size+30)
                self.DrawSetPen(c4d.Vector(1.0, 0.6, 0.0)) 
                self.DrawBorder(c4d.BORDER_THIN_OUT, x_pos-2, y_pos-2, x_pos+self.icon_size+2, y_pos+self.icon_size+30)
            bmp = asset.get('bmp', None)
            if bmp: self.DrawBitmap(bmp, x_pos, y_pos, self.icon_size, self.icon_size, 0, 0, bmp.GetBw(), bmp.GetBh(), c4d.BMP_ALLOWALPHA)
            else: self.DrawIcon(c4d.RESOURCEIMAGE_FILE, x_pos, y_pos, self.icon_size, self.icon_size)
            is_fav = asset.get('is_fav', False)
            star_x = x_pos + self.icon_size - 25; star_y = y_pos + 5
            if is_fav:
                self.DrawSetTextCol(c4d.Vector(1, 0.8, 0), self.bg_color) 
                self.DrawText("★", star_x, star_y)
            else:
                self.DrawSetTextCol(c4d.Vector(0.5), self.bg_color) 
                self.DrawText("☆", star_x, star_y)
            name = asset['name']
            if len(name) > 15: name = name[:13] + ".."
            self.DrawSetTextCol(self.text_color, self.bg_color)
            self.DrawText(name, x_pos, y_pos + self.icon_size + 5)

    def InputEvent(self, msg):
        dev = msg.GetLong(c4d.BFM_INPUT_DEVICE)
        chn = msg.GetLong(c4d.BFM_INPUT_CHANNEL)
        if dev == c4d.BFM_INPUT_MOUSE and chn == c4d.BFM_INPUT_MOUSELEFT:
            lx, ly = GetLocalCursorPos(self, msg)
            cell_w = self.icon_size + self.gap
            cell_h = self.icon_size + self.gap + self.text_height
            col = int(lx / cell_w)
            row = int(ly / cell_h)
            index = row * self.cols + col
            if 0 <= index < len(self.assets):
                rel_x = lx % cell_w
                rel_y = ly % cell_h
                if rel_x > (self.icon_size - 30) and rel_x < self.icon_size and rel_y < 30:
                    self.parent_dialog.ToggleFavorite(index)
                    return True
                self.selected_index = index
                self.Redraw()
                curr_time = time.time()
                if index == self.last_click_index and (curr_time - self.last_click_time) < 0.5:
                    self.last_click_index = -1 
                    self.parent_dialog.LoadAsset(self.assets[index]['path'])
                else:
                    self.last_click_index = index
                    self.last_click_time = curr_time
            else:
                self.selected_index = -1
                self.Redraw()
            return True
        return False

    def RecalculateHeight(self):
        if not self.assets: self.needed_height = 100; return
        area_width = self.GetWidth()
        if area_width < 10: area_width = 400
        cell_w = self.icon_size + self.gap
        cell_h = self.icon_size + self.gap + self.text_height
        cols = max(1, int(area_width / cell_w))
        rows = math.ceil(len(self.assets) / cols)
        self.needed_height = int(rows * cell_h + self.gap)

    def UpdateAssets(self, new_assets):
        self.assets = new_assets
        self.RecalculateHeight()
        self.Redraw()

    def UpdateScale(self, size):
        self.icon_size = size
        self.RecalculateHeight()
        self.Redraw()
        
    def GetSelectedIndex(self): return self.selected_index
    def GetAssetPath(self, index): return self.assets[index]['path'] if 0 <= index < len(self.assets) else None


class LoadProgressBar(gui.GeUserArea):
    def __init__(self):
        super(LoadProgressBar, self).__init__()
        self.percent = 0.0

    def SetProgress(self, percent):
        try:
            self.percent = max(0.0, min(100.0, float(percent)))
        except Exception:
            self.percent = 0.0
        self.Redraw()

    def GetMinSize(self):
        return 100, 8

    def DrawMsg(self, x1, y1, x2, y2, msg):
        width = max(1, x2 - x1)
        height = max(3, y2 - y1)
        self.OffScreenOn()
        self.DrawSetPen(c4d.Vector(0.12, 0.12, 0.12))
        self.DrawRectangle(x1, y1, x2, y2)
        fill_width = int(width * (self.percent / 100.0))
        if fill_width > 0:
            self.DrawSetPen(c4d.Vector(0.36, 0.52, 0.95))
            self.DrawRectangle(x1, y1, x1 + fill_width, y1 + height)
        self.DrawSetPen(c4d.Vector(0.25, 0.25, 0.25))
        self.DrawBorder(c4d.BORDER_THIN_IN, x1, y1, x2, y2)


# ==============================================================================
# 主 Dialog 类
# ==============================================================================
class AdminAuthDialog(gui.GeDialog):
    def __init__(self, parent_dialog):
        super(AdminAuthDialog, self).__init__()
        self.parent_dialog = parent_dialog

    def CreateLayout(self):
        self.SetTitle("账号授权")
        self.GroupBegin(13000, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0)
        self.GroupBorderSpace(12, 12, 12, 12)
        self.AddStaticText(ID_ADMIN_AUTH_TITLE_TEXT, c4d.BFH_SCALEFIT, name="登录花花账号")

        self.GroupBegin(13001, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="账号:")
        self.AddEditText(ID_ADMIN_ACCOUNT, c4d.BFH_SCALEFIT, 220, 0)
        self.GroupEnd()
        self.GroupBegin(13002, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="密码:")
        self.AddEditText(ID_ADMIN_PASSWORD, c4d.BFH_SCALEFIT, 220, 0)
        self.GroupEnd()

        self.GroupBegin(13003, c4d.BFH_LEFT, 4, 1)
        self.AddButton(ID_ADMIN_LOGIN_BTN, c4d.BFH_LEFT, name="登录")
        self.AddButton(ID_ADMIN_REGISTER_OPEN_BTN, c4d.BFH_LEFT, name="注册账号")
        self.AddButton(ID_ADMIN_LOGOUT_BTN, c4d.BFH_LEFT, name="退出登录")
        self.AddButton(ID_ADMIN_RELOGIN_BTN, c4d.BFH_LEFT, name="重新登录")
        self.GroupEnd()

        self.AddSeparatorH(6)
        self.AddStaticText(ID_ADMIN_USER_TEXT, c4d.BFH_SCALEFIT, name="当前账号：未登录")
        self.AddStaticText(ID_ADMIN_LICENSE_TEXT, c4d.BFH_SCALEFIT, name="授权状态：未授权")
        self.AddStaticText(ID_ADMIN_PLAN_TEXT, c4d.BFH_SCALEFIT, name="套餐：- / 到期：-")
        self.AddStaticText(ID_ADMIN_DEVICE_TEXT, c4d.BFH_SCALEFIT, name="设备记录：-")
        self.AddStaticText(ID_ADMIN_MACHINE_TEXT, c4d.BFH_SCALEFIT, name="电脑标识：-")
        self.AddStaticText(ID_ADMIN_REMAINING_TEXT, c4d.BFH_SCALEFIT, name="剩余时间：-")
        self.AddStaticText(ID_ADMIN_UPDATE_TEXT, c4d.BFH_SCALEFIT, name="当前版本：v" + CURRENT_VERSION + " / 最新版本：-")
        self.AddStaticText(ID_ADMIN_MESSAGE_TEXT, c4d.BFH_SCALEFIT, name="请输入后台账号密码")

        self.GroupBegin(13004, c4d.BFH_RIGHT, 1, 1)
        self.AddButton(ID_ADMIN_AUTH_CLOSE_BTN, c4d.BFH_RIGHT, name="关闭")
        self.GroupEnd()
        self.GroupEnd()
        return True

    def InitValues(self):
        self.RefreshValues()
        return True

    def RefreshValues(self):
        parent = self.parent_dialog
        try:
            user = parent.admin_user or {}
            license_info = parent.admin_license or {}
            update_info = parent.admin_update_info or {}
            account = parent._admin_account_label()
            auth_text = parent._admin_auth_status_text()
            plan = license_info.get("plan") or license_info.get("planName") or "-"
            expires = license_info.get("expiresAt") or license_info.get("expireAt") or "-"
            current_devices = license_info.get("currentDevices", license_info.get("deviceCount", "-"))
            latest = update_info.get("latestVersion") or update_info.get("latest_version") or update_info.get("version") or "-"
            remaining = parent._format_remaining_time(expires)
            is_logged_in = bool(parent.admin_token)
            machine_prefix = parent._admin_machine_id_prefix()

            self.SetString(ID_ADMIN_AUTH_TITLE_TEXT, "账号授权" if is_logged_in else "登录花花账号")
            self.SetString(ID_ADMIN_USER_TEXT, "当前账号：" + account)
            self.SetString(ID_ADMIN_LICENSE_TEXT, "授权状态：" + auth_text)
            self.SetString(ID_ADMIN_PLAN_TEXT, "套餐：" + str(plan) + " / 到期：" + str(expires))
            self.SetString(ID_ADMIN_DEVICE_TEXT, "设备记录：" + str(current_devices))
            self.SetString(ID_ADMIN_MACHINE_TEXT, "电脑标识：" + machine_prefix)
            self.SetString(ID_ADMIN_REMAINING_TEXT, "剩余时间：" + remaining)
            self.SetString(ID_ADMIN_UPDATE_TEXT, "当前版本：v" + CURRENT_VERSION + " / 最新版本：" + str(latest))
            message = parent.admin_message or parent.core_disabled_reason or ("授权通过" if parent.core_enabled else "请输入后台账号密码")
            self.SetString(ID_ADMIN_MESSAGE_TEXT, message)
            self.Enable(ID_ADMIN_LOGOUT_BTN, is_logged_in)
            self.Enable(ID_ADMIN_RELOGIN_BTN, True)
        except Exception as e:
            try:
                print("[Admin Auth Dialog] refresh failed: " + str(e))
            except Exception:
                pass

    def Command(self, cid, msg):
        try:
            parent = self.parent_dialog
            if cid == ID_ADMIN_LOGIN_BTN:
                account = self.GetString(ID_ADMIN_ACCOUNT).strip()
                password = self.GetString(ID_ADMIN_PASSWORD)
                if not account or not password:
                    parent._admin_set_message("请输入账号和密码")
                    self.RefreshValues()
                    return True
                parent._admin_login(account, password)
                self.SetString(ID_ADMIN_PASSWORD, "")
                self.RefreshValues()
                return True
            if cid == ID_ADMIN_REGISTER_OPEN_BTN:
                parent._open_admin_register_dialog()
                return True
            if cid == ID_ADMIN_LOGOUT_BTN:
                parent._admin_logout()
                self.SetString(ID_ADMIN_PASSWORD, "")
                self.RefreshValues()
                return True
            if cid == ID_ADMIN_RELOGIN_BTN:
                parent._admin_logout()
                parent._admin_set_message("请重新输入账号密码登录")
                self.SetString(ID_ADMIN_PASSWORD, "")
                self.RefreshValues()
                return True
            if cid == ID_ADMIN_AUTH_CLOSE_BTN or cid == c4d.DLG_CANCEL:
                self.Close()
                return True
        except Exception as e:
            gui.MessageDialog("账号授权窗口错误:\n" + str(e))
            try:
                traceback.print_exc()
            except Exception:
                pass
        return True


class AdminRegisterDialog(gui.GeDialog):
    def __init__(self, parent_dialog):
        super(AdminRegisterDialog, self).__init__()
        self.parent_dialog = parent_dialog

    def CreateLayout(self):
        self.SetTitle("注册账号")
        self.GroupBegin(13100, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0)
        self.GroupBorderSpace(12, 12, 12, 12)
        self.AddStaticText(0, c4d.BFH_SCALEFIT, name="注册花花账号")

        self.GroupBegin(13101, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="邮箱:")
        self.AddEditText(ID_ADMIN_REGISTER_EMAIL, c4d.BFH_SCALEFIT, 240, 0)
        self.GroupEnd()
        self.GroupBegin(13102, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="昵称:")
        self.AddEditText(ID_ADMIN_REGISTER_NICKNAME, c4d.BFH_SCALEFIT, 240, 0)
        self.GroupEnd()
        self.GroupBegin(13103, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="密码:")
        self.AddEditText(ID_ADMIN_REGISTER_PASSWORD, c4d.BFH_SCALEFIT, 240, 0)
        self.GroupEnd()
        self.GroupBegin(13104, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="确认密码:")
        self.AddEditText(ID_ADMIN_REGISTER_PASSWORD_CONFIRM, c4d.BFH_SCALEFIT, 240, 0)
        self.GroupEnd()

        self.AddStaticText(0, c4d.BFH_SCALEFIT, name="注册成功后请返回登录窗口登录。")
        self.GroupBegin(13105, c4d.BFH_RIGHT, 2, 1)
        self.AddButton(ID_ADMIN_REGISTER_SUBMIT_BTN, c4d.BFH_RIGHT, name="注册")
        self.AddButton(ID_ADMIN_REGISTER_CANCEL_BTN, c4d.BFH_RIGHT, name="取消")
        self.GroupEnd()
        self.GroupEnd()
        return True

    def _clear_passwords(self):
        try:
            self.SetString(ID_ADMIN_REGISTER_PASSWORD, "")
            self.SetString(ID_ADMIN_REGISTER_PASSWORD_CONFIRM, "")
        except Exception:
            pass

    def Command(self, cid, msg):
        try:
            parent = self.parent_dialog
            if cid == ID_ADMIN_REGISTER_SUBMIT_BTN:
                email = self.GetString(ID_ADMIN_REGISTER_EMAIL).strip()
                nickname = self.GetString(ID_ADMIN_REGISTER_NICKNAME).strip()
                password = self.GetString(ID_ADMIN_REGISTER_PASSWORD)
                password_confirm = self.GetString(ID_ADMIN_REGISTER_PASSWORD_CONFIRM)
                if not email or not password:
                    gui.MessageDialog("请输入邮箱和密码。")
                    return True
                if password != password_confirm:
                    self._clear_passwords()
                    gui.MessageDialog("两次输入的密码不一致。")
                    return True
                ok = parent._admin_register_account(email, password, nickname)
                self._clear_passwords()
                if ok:
                    gui.MessageDialog("注册成功，请登录。")
                    self.Close()
                    parent._open_admin_auth_dialog()
                return True
            if cid == ID_ADMIN_REGISTER_CANCEL_BTN or cid == c4d.DLG_CANCEL:
                self._clear_passwords()
                self.Close()
                return True
        except Exception as e:
            gui.MessageDialog("注册窗口错误:\n" + str(e))
            try:
                traceback.print_exc()
            except Exception:
                pass
        return True


class HHImportDialog(gui.GeDialog):
    def __init__(self):
        super(HHImportDialog, self).__init__()
        self._cap_mode = 1
        self.user_area = AssetViewer(self) 
        self.asset_path = LIBRARY_PATH
        self.load_progress_area = LoadProgressBar()
        self.full_data_cache =[] 
        self.favorites = set()    
        self.fav_file_path = os.path.join(self.asset_path, FAV_FILE_NAME)
        self.json_watch_dir = ""
        self.json_watch_seen = set()
        self.json_watch_candidates = {}
        self.json_watch_processed = set()
        self.json_watch_last_check_time = 0.0
        self.admin_config = {}
        self.admin_token = ""
        self.admin_user = None
        self.admin_license = None
        self.admin_update_info = None
        self.admin_last_check_license_result = None
        self.admin_last_register_device_result = None
        self.admin_last_check_update_result = None
        self.admin_last_heartbeat_result = None
        self.admin_last_heartbeat_at = 0.0
        self.admin_dialog = None
        self.admin_register_dialog = None
        self.admin_message = ""
        self.core_enabled = False
        self.core_disabled_reason = "未登录"
        self.device_info = {}
        self.machine_id = ""
        self.LoadFavorites()

    def CreateLayout(self):
        self.SetTitle("花花广告设计 v" + CURRENT_VERSION)
        self.GroupBegin(ID_GRP_MAIN, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0)
        self.GroupBorderSpace(5, 5, 5, 5) 

        self.GroupBegin(12030, c4d.BFH_SCALEFIT, 2, 1)
        self.GroupBegin(ID_LOAD_PROGRESS_GROUP, c4d.BFH_SCALEFIT, 1, 0)
        self.AddStaticText(ID_LOAD_PROGRESS_TEXT, c4d.BFH_SCALEFIT, 0, 0, "等待选择文件")
        self.AddUserArea(ID_LOAD_PROGRESS_BAR, c4d.BFH_SCALEFIT, 0, 8)
        self.AttachUserArea(self.load_progress_area, ID_LOAD_PROGRESS_BAR)
        self.GroupEnd()
        self.AddButton(ID_ADMIN_OPEN_DIALOG_BTN, c4d.BFH_RIGHT, 72, 20, "登录")
        self.GroupEnd()

        self.TabGroupBegin(ID_TAB_MAIN, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, c4d.TAB_TABS)
        
        # Tab 1: Basic
        self.GroupBegin(ID_TAB_GRP_BASIC, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "基础设置")
        self.GroupBorderSpace(8, 8, 8, 8)
        self.GroupBegin(2000, c4d.BFH_SCALEFIT, 1, 0) 
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 核心参数 ---")
        self.AddSeparatorH(5)
        self.GroupBegin(2001, c4d.BFH_SCALEFIT, 4, 1)
        self.AddStaticText(ID_RATIO_LABEL, c4d.BFH_LEFT, name="导入比例:")
        self.AddComboBox(ID_RATIO_COMBO, c4d.BFH_SCALEFIT, 120, 10)
        self.AddStaticText(0, c4d.BFH_LEFT, name="  手柄张力:")
        self.AddEditNumberArrows(ID_TENSION_VAL, c4d.BFH_SCALEFIT, 80, 0)
        self.GroupEnd()
        self.GroupBegin(2002, c4d.BFH_SCALEFIT, 2, 2)
        self.AddCheckbox(ID_IMPORT_TO_NEW_DOC, c4d.BFH_LEFT, 0, 0, "导入到新文件")
        self.AddCheckbox(ID_KEEP_LAYER,   c4d.BFH_LEFT, 0, 0, "保留图层结构")
        self.AddCheckbox(ID_AUTO_CLOSE,   c4d.BFH_LEFT, 0, 0, "自动闭合样条")
        self.AddCheckbox(ID_IMPORT_COLOR, c4d.BFH_LEFT, 0, 0, "创建原始材质") 
        self.AddCheckbox(ID_SMART_STACK, c4d.BFH_LEFT, 0, 0, "启用智能堆叠 (Smart Stack)")
        self.AddCheckbox(ID_GAMMA_CORRECT, c4d.BFH_LEFT, 0, 0, "颜色 Gamma 修正 (sRGB->Linear)")
        self.GroupEnd()
        self.AddSeparatorH(5)
        self.GroupBegin(3000, c4d.BFH_SCALEFIT, 2, 1)
        self.AddButton(ID_JSON_WATCH_BTN, c4d.BFH_LEFT, name="选择 JSON 监听文件夹")
        self.AddStaticText(ID_JSON_WATCH_STATUS, c4d.BFH_SCALEFIT, name="未选择监听目录")
        self.GroupEnd()
        self.GroupEnd()
        self.GroupBegin(2100, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 样条属性 ---")
        self.AddSeparatorH(5)
        self.GroupBegin(2101, c4d.BFH_SCALEFIT, 4, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="类型:")
        self.AddComboBox(ID_SPL_TYPE_COMBO, c4d.BFH_SCALEFIT, 80, 0)
        self.AddCheckbox(ID_SPL_CLOSE_CHK, c4d.BFH_LEFT, 0, 0, "闭合样条")
        self.AddStaticText(0, c4d.BFH_LEFT, name="") 
        self.GroupEnd()
        self.GroupBegin(2102, c4d.BFH_SCALEFIT, 4, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="插值:")
        self.AddComboBox(ID_SPL_INTER_COMBO, c4d.BFH_SCALEFIT, 80, 0)
        self.AddStaticText(0, c4d.BFH_LEFT, name="数量:")
        self.AddEditNumberArrows(ID_SPL_SUB_VAL, c4d.BFH_SCALEFIT, 50, 0)
        self.GroupEnd()
        self.GroupEnd()
        self.GroupBegin(3002, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 挤压建模 ---")
        self.AddSeparatorH(5)
        self.GroupBegin(3003, c4d.BFH_SCALEFIT, 4, 1)
        self.AddCheckbox(ID_EXTRUDE_ENABLE, c4d.BFH_LEFT, 0, 0, "启用挤压")
        self.AddStaticText(0, c4d.BFH_LEFT, name="深度:")
        self.AddEditNumberArrows(ID_EXTRUDE_DEPTH, c4d.BFH_LEFT, 60, 0)
        self.AddEditSlider(ID_EXTRUDE_SLIDER, c4d.BFH_SCALEFIT, 0, 0)
        self.GroupEnd()
        self.GroupBegin(3004, c4d.BFH_SCALEFIT, 2, 1)
        self.AddButton(ID_BTN_SMART_MERGE, c4d.BFH_SCALEFIT, name="按颜色合并并挤压 (Z-)")
        self.AddButton(ID_BTN_SIMPLE_EXTRUDE, c4d.BFH_SCALEFIT, name="原地层级挤压 (Z-)")
        self.GroupEnd()
        self.GroupBegin(3005, c4d.BFH_SCALEFIT, 4, 1)
        self.AddButton(ID_BTN_APPLY_DEPTH, c4d.BFH_LEFT, name="应用深度")
        self.AddButton(ID_BTN_EXTRUDE_FLIP, c4d.BFH_LEFT, name="反转方向")
        self.AddCheckbox(ID_DELETE_SPLINE, c4d.BFH_LEFT, 0, 0, "完成后删除样条")
        self.GroupEnd()
        self.GroupEnd()
        self.GroupEnd() 

        # Tab 2: Align (Super Align + Axis Tool)
        self.GroupBegin(ID_TAB_GRP_ALIGN, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "位置对齐")
        self.GroupBorderSpace(8, 8, 8, 8)
        
        # --- 1. 独立子物体探测区 ---
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_CENTER, name="--- 分布式独立探测 (防穿模贴墙) ---")
        self.GroupBegin(0, c4d.BFH_CENTER, 1, 0)
        self.AddButton(ID_BTN_RAY_UP, c4d.BFH_CENTER, 80, 24, "顶 (+Y)")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_CENTER, 4, 0)
        self.AddButton(ID_BTN_RAY_LEFT, c4d.BFH_CENTER, 60, 24, "左 (-X)")
        self.AddButton(ID_BTN_RAY_FRONT, c4d.BFH_CENTER, 40, 24, "前")
        self.AddButton(ID_BTN_RAY_BACK, c4d.BFH_CENTER, 40, 24, "后")
        self.AddButton(ID_BTN_RAY_RIGHT, c4d.BFH_CENTER, 60, 24, "右 (+X)")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_CENTER, 1, 0)
        self.AddButton(ID_BTN_RAY_DOWN, c4d.BFH_CENTER, 80, 24, "地 (-Y)")
        self.GroupEnd()
        self.GroupEnd()

        # --- 2. 九宫格对齐 ---
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 九宫格多对象对齐 ---")
        self.AddCheckbox(ID_CHK_SURFACE_MODE, c4d.BFH_LEFT, 0, 0, "边缘贴合模式 (取消勾选为中心对齐)")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 3, 0)
        self.AddButton(ID_BTN_NW, c4d.BFH_SCALEFIT, 0, 20, "↖ 左上")
        self.AddButton(ID_BTN_N,  c4d.BFH_SCALEFIT, 0, 20, "↑ 中顶")
        self.AddButton(ID_BTN_NE, c4d.BFH_SCALEFIT, 0, 20, "右上 ↗")
        self.AddButton(ID_BTN_W,  c4d.BFH_SCALEFIT, 0, 20, "← 左中")
        self.AddButton(ID_BTN_C,  c4d.BFH_SCALEFIT, 0, 20, "XY 正中")
        self.AddButton(ID_BTN_E,  c4d.BFH_SCALEFIT, 0, 20, "右中 →")
        self.AddButton(ID_BTN_SW, c4d.BFH_SCALEFIT, 0, 20, "↙ 左下")
        self.AddButton(ID_BTN_S,  c4d.BFH_SCALEFIT, 0, 20, "↓ 中底")
        self.AddButton(ID_BTN_SE, c4d.BFH_SCALEFIT, 0, 20, "右下 ↘")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 3, 0)
        self.AddButton(ID_BTN_Z_FRONT, c4d.BFH_SCALEFIT, 0, 20, "前 (Z-)")
        self.AddButton(ID_BTN_Z_MID,   c4d.BFH_SCALEFIT, 0, 20, "Z 轴中")
        self.AddButton(ID_BTN_Z_BACK,  c4d.BFH_SCALEFIT, 0, 20, "后 (Z+)")
        self.GroupEnd()
        self.GroupEnd()

        # --- 3. 全方位轴心对齐 (独立轴心) ---
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 全方位轴心对齐 (仅移动轴心) ---")
        
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 3, 3)
        self.AddButton(ID_AXIS_TL, c4d.BFH_SCALEFIT, 0, 20, "↖ 左上")
        self.AddButton(ID_AXIS_TC, c4d.BFH_SCALEFIT, 0, 20, "↑ 中上")
        self.AddButton(ID_AXIS_TR, c4d.BFH_SCALEFIT, 0, 20, "↗ 右上")
        self.AddButton(ID_AXIS_ML, c4d.BFH_SCALEFIT, 0, 20, "← 左中")
        self.AddButton(ID_AXIS_MC, c4d.BFH_SCALEFIT, 0, 20, "+ 正中")
        self.AddButton(ID_AXIS_MR, c4d.BFH_SCALEFIT, 0, 20, "→ 右中")
        self.AddButton(ID_AXIS_BL, c4d.BFH_SCALEFIT, 0, 20, "↙ 左下")
        self.AddButton(ID_AXIS_BC, c4d.BFH_SCALEFIT, 0, 20, "↓ 中下")
        self.AddButton(ID_AXIS_BR, c4d.BFH_SCALEFIT, 0, 20, "↘ 右下")
        self.GroupEnd()
        
        self.GroupBegin(0, c4d.BFH_CENTER, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="Z轴位置: ")
        self.AddRadioGroup(ID_AXIS_RADIO_Z, c4d.BFH_LEFT, columns=3)
        self.AddChild(ID_AXIS_RADIO_Z, ID_AXIS_Z_FRONT, "前 (+Z)")
        self.AddChild(ID_AXIS_RADIO_Z, ID_AXIS_Z_MID,   "中 (0)")
        self.AddChild(ID_AXIS_RADIO_Z, ID_AXIS_Z_BACK,  "后 (-Z)")
        self.GroupEnd()
        self.GroupEnd()

        # --- 4. 基础快捷与微调 ---
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 快捷与微调 ---")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 4, 1)
        self.AddButton(ID_BTN_DROP_FLOOR, c4d.BFH_SCALEFIT, name="一键落地")
        self.AddButton(ID_BTN_STAND_UP,   c4d.BFH_SCALEFIT, name="一键站立")
        self.AddButton(ID_BTN_CENTER_X,   c4d.BFH_SCALEFIT, name="X轴居中")
        self.AddButton(ID_BTN_RESET_PSR,  c4d.BFH_SCALEFIT, name="轴心归零")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 3, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="微调步长:")
        self.AddEditNumberArrows(ID_MOVE_DIST_VAL, c4d.BFH_SCALEFIT, 70, 0)
        self.AddStaticText(0, c4d.BFH_LEFT, name="cm")
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 6, 1)
        self.AddButton(ID_BTN_MOV_X_SUB, c4d.BFH_SCALEFIT, name="< X")
        self.AddButton(ID_BTN_MOV_X_ADD, c4d.BFH_SCALEFIT, name="X >")
        self.AddButton(ID_BTN_MOV_Y_ADD, c4d.BFH_SCALEFIT, name="^ Y")
        self.AddButton(ID_BTN_MOV_Y_SUB, c4d.BFH_SCALEFIT, name="v Y")
        self.AddButton(ID_BTN_MOV_Z_ADD, c4d.BFH_SCALEFIT, name="Z(出)")
        self.AddButton(ID_BTN_MOV_Z_SUB, c4d.BFH_SCALEFIT, name="Z(入)")
        self.GroupEnd()
        self.GroupEnd()
        
        self.GroupEnd()

        # Tab 3: Scene Tools
        self.GroupBegin(ID_TAB_GRP_SCENE, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "场景工具")
        self.GroupBorderSpace(8, 8, 8, 8)
        self.GroupBegin(3100, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="--- 场景工具 ---")
        self.AddSeparatorH(5)
        self.GroupBegin(3105, c4d.BFH_SCALEFIT, 2, 1)
        self.AddButton(ID_BTN_SEL_HIDDEN, c4d.BFH_SCALEFIT, name="选中红点隐藏对象")
        self.AddButton(ID_BTN_SEL_TEXTURED, c4d.BFH_SCALEFIT, name="选中带贴图对象")
        self.GroupEnd()
        self.GroupBegin(3106, c4d.BFH_SCALEFIT, 2, 1)
        self.AddButton(ID_BTN_CONNECT_DELETE, c4d.BFH_SCALEFIT, name="连接对象+删除")
        self.AddButton(ID_BTN_AXIS_CENTER, c4d.BFH_SCALEFIT, name="系统默认轴心居中")
        self.GroupEnd()
        self.AddSeparatorH(5)
        self.GroupBegin(3107, c4d.BFH_SCALEFIT, 3, 1)
        self.AddButton(ID_BTN_APPLY_TEX, c4d.BFH_SCALEFIT, name="选择贴图")
        self.AddButton(ID_BTN_APPLY_COLOR_DATA, c4d.BFH_SCALEFIT, name="重置材质")
        self.AddButton(ID_BTN_BAKE_UVW, c4d.BFH_SCALEFIT, name="强制烘焙UVW")
        self.GroupEnd()
        self.GroupBegin(3102, c4d.BFH_LEFT, 2, 1)
        self.AddStaticText(3101, c4d.BFH_LEFT, name="当前贴图选集:")
        self.AddButton(ID_CAP_SIDE_COMBO, c4d.BFH_LEFT, name="C1 (前封盖)")
        self.GroupEnd()
        self.GroupEnd()
        self.GroupEnd()

        # Tab 4: Modeling Aids (Acrylic & Signage)
        self.GroupBegin(ID_TAB_GRP_ACRYLIC, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "建模辅助工具")
        self.GroupBorderSpace(8, 8, 8, 8)
        
        self.GroupBegin(5000, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="-- 亚克力插槽生成 --")
        self.AddSeparatorH(3)
        self.GroupBegin(5001, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(ID_ACRY_DEPTH_LABEL, c4d.BFH_LEFT, 0, 0, "样条挤压高度 (cm):", 0)
        self.AddEditNumberArrows(ID_ACRY_DEPTH_INPUT, c4d.BFH_SCALEFIT, 80, 0)
        self.GroupEnd()
        self.GroupBegin(5002, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, 0, 0, "挤压方向:", 0)
        self.AddComboBox(ID_ACRY_DEPTH_DIR, c4d.BFH_LEFT, 0, 0)
        self.AddChild(ID_ACRY_DEPTH_DIR, 0, "Z+ 正向挤压")
        self.AddChild(ID_ACRY_DEPTH_DIR, 1, "Z- 反向挤压")
        self.GroupEnd()
        self.AddStaticText(0, c4d.BFH_LEFT, 0, 0, "要删除的侧面：", 0)
        self.GroupBegin(ID_ACRY_SIDE_GROUP, c4d.BFH_SCALEFIT, 2, 2)
        self.AddCheckbox(ID_ACRY_CHK_T, c4d.BFH_LEFT, 0, 0, "删顶 (+Y)")
        self.AddCheckbox(ID_ACRY_CHK_B, c4d.BFH_LEFT, 0, 0, "删底 (-Y)")
        self.AddCheckbox(ID_ACRY_CHK_L, c4d.BFH_LEFT, 0, 0, "删左 (-X)")
        self.AddCheckbox(ID_ACRY_CHK_R, c4d.BFH_LEFT, 0, 0, "删右 (+X)")
        self.GroupEnd()
        self.GroupBegin(5003, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(ID_ACRY_SHELL_LABEL, c4d.BFH_LEFT, 0, 0, "最终板厚 (cm):", 0)
        self.AddEditNumberArrows(ID_ACRY_SHELL_INPUT, c4d.BFH_SCALEFIT, 80, 0)
        self.GroupEnd()
        self.GroupBegin(5004, c4d.BFH_SCALEFIT, 1, 1)
        self.AddButton(ID_BTN_ACRY_GENERATE, c4d.BFH_SCALEFIT, name="立即生成亚克力插槽")
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(ID_SIGN_GRP_MAIN, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="-- 花花广告设计 v1.1 - 广告字工艺 --")
        self.AddSeparatorH(3)
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="基础颜色:")
        self.AddColorField(ID_SIGN_COLOR, c4d.BFH_SCALEFIT, 0, 0)
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 4, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="前厚(mm):")
        self.AddEditNumberArrows(ID_SIGN_THICK_F, c4d.BFH_SCALEFIT, 50, 0)
        self.AddStaticText(0, c4d.BFH_LEFT, name="后厚(mm):")
        self.AddEditNumberArrows(ID_SIGN_THICK_B, c4d.BFH_SCALEFIT, 50, 0)
        self.GroupEnd()
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 2)
        self.AddButton(ID_BTN_SIGN_BACK, c4d.BFH_SCALEFIT, name="🔙 背发光")
        self.AddButton(ID_BTN_SIGN_FRONT, c4d.BFH_SCALEFIT, name="🔆 正发光")
        self.AddButton(ID_BTN_SIGN_CRYSTAL, c4d.BFH_SCALEFIT, name="💎 水晶字")
        self.AddButton(ID_BTN_SIGN_DUAL, c4d.BFH_SCALEFIT, name="♊ 正背发")
        self.GroupEnd()
        self.AddStaticText(0, c4d.BFH_CENTER, name="提示: 输入0自动使用标准参数; 颜色自动继承")
        self.GroupEnd()

        self.GroupBegin(5200, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(5, 5, 5, 5)
        self.AddStaticText(0, c4d.BFH_LEFT, name="-- 花花广告设计 v1.1 - 智能灯槽生成器 --")
        self.AddSeparatorH(3)
        self.AddStaticText(0, c4d.BFH_LEFT, name="提示: 先选中模型，再打开灯槽面板执行。")
        self.AddButton(ID_BTN_OPEN_GROOVE, c4d.BFH_SCALEFIT, name="打开智能灯槽面板")
        self.GroupEnd()
        self.GroupEnd() 

        # Tab 5: Smart Scene
        self.GroupBegin(ID_TAB_GRP_SMART_SCENE, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "智能场景")
        self.GroupBorderSpace(8, 8, 8, 8)
        
        # 吊顶生成器
        self.GroupBegin(6000, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(20, 20, 20, 20)
        self.AddStaticText(0, c4d.BFH_CENTER, name="生成智能吊顶系统 (花花广告设计 v1.1)")
        self.AddSeparatorH(10)
        self.AddButton(ID_BTN_GEN_CEILING, c4d.BFH_SCALEFIT, name="生成智能吊顶对象")
        self.AddStaticText(0, c4d.BFH_LEFT, name="提示: 生成后请在对象属性面板中调整参数。")
        self.GroupEnd()
        
        # 花花广告设计 v1.1 - 智能展厅生成器
        self.GroupBegin(6001, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(20, 20, 20, 20)
        self.AddStaticText(0, c4d.BFH_CENTER, name="生成智能展厅系统 (花花广告设计 v1.1 防炸稳定版)")
        self.AddSeparatorH(10)
        self.AddStaticText(0, c4d.BFH_LEFT, name="💡 提示: 请先选中 4 个墙体对象 (或1个包含4面墙的群组)")
        self.AddStaticText(0, c4d.BFH_LEFT, name="📋 列表顺序要求 (从下到上): 前墙 -> 右墙 -> 后墙 -> 左墙")
        self.AddButton(ID_BTN_GEN_SMART_ROOM, c4d.BFH_SCALEFIT, name="🔨 一键生成智能展厅")
        self.GroupEnd()

        # 花花广告设计 v1.1 - 智能弯曲墙体生成器
        self.GroupBegin(6010, c4d.BFH_SCALEFIT, 1, 0)
        self.GroupBorder(c4d.BORDER_GROUP_IN)
        self.GroupBorderSpace(20, 20, 20, 20)
        self.AddStaticText(0, c4d.BFH_CENTER, name="生成智能弯曲墙体系统 (花花广告设计 v1.1 手动滑块版)")
        self.AddSeparatorH(10)
        self.AddStaticText(0, c4d.BFH_LEFT, name="💡 提示: 请同时选中 [1根样条] +[1个或多个墙体/挤压对象]")
        self.GroupBegin(0, c4d.BFH_SCALEFIT, 2, 1)
        self.AddStaticText(0, c4d.BFH_LEFT, name="适配模式:")
        self.AddComboBox(ID_CURVED_WALL_MODE, c4d.BFH_SCALEFIT, 150, 0)
        self.GroupEnd()
        self.AddButton(ID_BTN_CURVED_WALL, c4d.BFH_SCALEFIT, name="🧲 一键生成智能弯曲墙体")
        self.GroupEnd()

        self.GroupEnd()

        # Tab 6: Asset Manager
        self.GroupBegin(ID_TAB_GRP_ASSETS, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, 1, 0, "模型库")
        self.GroupBorderSpace(8, 8, 8, 8)
        if self.GroupBegin(7000, c4d.BFH_SCALEFIT, cols=4, rows=1, groupflags=c4d.BORDER_NONE):
            self.AddEditText(ID_ASSET_TXT_SEARCH, c4d.BFH_SCALEFIT, 200, 0)
            self.SetString(ID_ASSET_TXT_SEARCH, "") 
            self.AddButton(ID_ASSET_BTN_REFRESH, c4d.BFH_LEFT, name="刷新")
            self.AddButton(ID_ASSET_BTN_LOAD, c4d.BFH_LEFT, name="⚡ 加载")
            self.GroupEnd()
        if self.GroupBegin(7001, c4d.BFH_SCALEFIT, cols=4, rows=1, groupflags=c4d.BORDER_NONE):
            self.AddCheckbox(ID_ASSET_CHK_SIZE, c4d.BFH_LEFT, 0, 0, name="📏 匹配尺寸")
            self.AddCheckbox(ID_ASSET_CHK_ONLY_FAV, c4d.BFH_LEFT, 0, 0, name="★ 只看收藏")
            self.AddStaticText(0, c4d.BFH_LEFT, name="缩放:")
            self.AddEditSlider(ID_ASSET_SLIDER_SIZE, c4d.BFH_SCALEFIT, 150, 0)
            self.GroupEnd()
        self.AddSeparatorH(c4d.BFH_SCALEFIT)
        if self.ScrollGroupBegin(ID_ASSET_SCROLL_GRP, c4d.BFH_SCALEFIT | c4d.BFV_SCALEFIT, c4d.SCROLLGROUP_VERT):
            self.AddUserArea(ID_ASSET_USER_AREA, c4d.BFH_SCALEFIT | c4d.BFV_TOP)
            self.AttachUserArea(self.user_area, ID_ASSET_USER_AREA)
            self.GroupEnd()
        self.GroupEnd()
        
        self.GroupEnd() 
        self.AddSeparatorH(5)
        self.GroupBegin(4000, c4d.BFH_CENTER, 4, 1)
        self.AddButton(ID_IMPORT_BTN, c4d.BFH_SCALEFIT, name="  导入 AI JSON 文件  ")
        self.AddButton(ID_REPLACE_BTN, c4d.BFH_SCALEFIT, name=" ⚡ 替换选中模型 ")
        self.AddButton(ID_CHECK_UPDATE_BTN, c4d.BFH_SCALEFIT, name="检查更新")
        self.AddButton(ID_CLOSE_BTN,  c4d.BFH_SCALEFIT, name=" 关闭面板 ")
        self.GroupEnd()
        self.GroupEnd()
        return True

    def InitValues(self):
        self.AddChild(ID_RATIO_COMBO, 1, "1:1")
        self.AddChild(ID_RATIO_COMBO, 10, "1:10")
        self.AddChild(ID_RATIO_COMBO, 100, "1:100")
        self.AddChild(ID_RATIO_COMBO, 1000, "1:1000")
        self.SetInt32(ID_RATIO_COMBO, 10) 
        self.SetFloat(ID_TENSION_VAL, 0.751425, min=0.0, max=100.0, step=0.000001, format=c4d.FORMAT_FLOAT)
        
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_LINEAR, "线性")
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_CUBIC, "立方")
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_AKIMA, "阿基玛")
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_BSPLINE, "B-样条")
        self.AddChild(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_BEZIER, "贝塞尔")
        self.SetInt32(ID_SPL_TYPE_COMBO, c4d.SPLINETYPE_BEZIER)
        
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_NONE, "无")
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_NATURAL, "自然")
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_UNIFORM, "统一")
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_ADAPTIVE, "自适应")
        self.AddChild(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_SUBDIV, "细分")
        self.SetInt32(ID_SPL_INTER_COMBO, c4d.SPLINEOBJECT_INTERPOLATION_UNIFORM)
        self.SetInt32(ID_SPL_SUB_VAL, 8, min=0, max=1000, step=1)
        self.SetBool(ID_SPL_CLOSE_CHK, True) 

        self.SetInt32(ID_CAP_SIDE_COMBO, 1)
        self._cap_mode = 1
        self.SetBool(ID_IMPORT_TO_NEW_DOC, False) 
        self.SetBool(ID_KEEP_LAYER, True)
        self.SetBool(ID_AUTO_CLOSE, True)
        self.SetBool(ID_IMPORT_COLOR, True) 
        self.SetBool(ID_SMART_STACK, True)
        self.SetFloat(ID_EXTRUDE_DEPTH, 20.0)
        self.SetFloat(ID_EXTRUDE_SLIDER, 20.0, min=0.0, max=200.0, step=1.0)
        
        self.SetBool(ID_DELETE_SPLINE, True)
        self.SetBool(ID_EXTRUDE_ENABLE, False)
        
        self.SetBool(ID_GAMMA_CORRECT, False)
    
        self.SetFloat(ID_MOVE_DIST_VAL, 10.0, 0.1, 10000.0, 1.0)
        
        self.SetFloat(ID_ACRY_DEPTH_INPUT, 0.3, min=0.0, step=0.1, format=c4d.FORMAT_FLOAT)
        self.SetInt32(ID_ACRY_DEPTH_DIR, 1)
        self.SetFloat(ID_ACRY_SHELL_INPUT, 0.3, min=0.0, step=0.1, format=c4d.FORMAT_FLOAT)
        self.SetBool(ID_ACRY_CHK_T, True)
        self.SetBool(ID_ACRY_CHK_B, False)
        self.SetBool(ID_ACRY_CHK_L, False)
        self.SetBool(ID_ACRY_CHK_R, False)
        
        self.SetInt32(ID_ASSET_SLIDER_SIZE, 130, min=50, max=300, step=10)
        self.SetBool(ID_ASSET_CHK_SIZE, True) 
        self.SetBool(ID_ASSET_CHK_ONLY_FAV, False)
        
        self.SetBool(ID_CHK_SURFACE_MODE, True)
        self.SetInt32(ID_AXIS_RADIO_Z, ID_AXIS_Z_MID)

        self.SetColorField(ID_SIGN_COLOR, c4d.Vector(1, 0.2, 0.2), 1.0, 1.0, c4d.DR_COLORFIELD_NO_BRIGHTNESS)
        self.SetFloat(ID_SIGN_THICK_F, 0.0) 
        self.SetFloat(ID_SIGN_THICK_B, 0.0)

        # [新增] 智能弯曲墙体选项初始化
        self.AddChild(ID_CURVED_WALL_MODE, 0, "匹配样条 (拉伸)")
        self.AddChild(ID_CURVED_WALL_MODE, 1, "保持长度 (不拉伸)")
        self.SetInt32(ID_CURVED_WALL_MODE, 1) # 默认保持长度

        self._load_json_watch_pref()
        self._update_json_watch_status()
        self._start_json_watch_timer()

        self.ScanAndLoad()
        self.ResetLoadProgress()
        self._update_ui_from_selection()
        self._admin_init_startup()
        return True

    def _admin_log(self, message):
        try:
            print("[Huahua Admin] " + str(message))
        except Exception:
            pass

    def _admin_platform(self):
        return "windows" if os.name == "nt" else "mac"

    def _admin_os_name(self):
        try:
            system = py_platform.system()
            release = py_platform.release()
            version = py_platform.mac_ver()[0] if system == "Darwin" else py_platform.version()
            if system == "Darwin":
                return "macOS " + (version or release or "")
            if system == "Windows":
                return "Windows " + (release or version or "")
            return self._admin_platform() + " " + (release or version or "")
        except Exception:
            return self._admin_platform()

    def _admin_device_name(self):
        try:
            name = socket.gethostname()
            if name:
                return name
        except Exception:
            pass
        return "Windows PC" if self._admin_platform() == "windows" else "Mac"

    def _admin_load_config(self):
        try:
            if os.path.exists(ADMIN_CONFIG_FILE):
                with open(ADMIN_CONFIG_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        self.admin_config = data
                        return
        except Exception as e:
            self._admin_log("读取本地配置失败: " + str(e))
        self.admin_config = {}

    def _admin_save_config(self):
        try:
            if not os.path.isdir(ADMIN_CONFIG_DIR):
                os.makedirs(ADMIN_CONFIG_DIR)
            self.admin_config["API_BASE_URL"] = API_BASE_URL
            self.admin_config["pluginCode"] = PLUGIN_CODE
            self.admin_config["clientCode"] = CLIENT_CODE
            self.admin_config["platform"] = self.device_info.get("platform", self._admin_platform())
            self.admin_config["os"] = self.device_info.get("os", self._admin_os_name())
            self.admin_config["deviceName"] = self.device_info.get("deviceName", self._admin_device_name())
            self.admin_config["deviceId"] = self.device_info.get("deviceId", self.admin_config.get("deviceId", ""))
            self.admin_config["machineId"] = self.device_info.get("machineId", self.machine_id or self.admin_config.get("machineId", ""))
            with open(ADMIN_CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.admin_config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self._admin_log("保存本地配置失败: " + str(e))

    def _admin_handle_api_base_change(self):
        saved_api_base_url = str(self.admin_config.get("API_BASE_URL") or "").strip()
        if not saved_api_base_url or saved_api_base_url == API_BASE_URL:
            return False
        self._admin_log("检测到授权后台地址变更: " + saved_api_base_url + " -> " + API_BASE_URL)
        for key in ("token", "user", "license", "lastLoginAt", "lastVerifiedAt", "lastHeartbeatAt", "licenseInvalidAt"):
            self.admin_config.pop(key, None)
        self.admin_token = ""
        self.admin_user = None
        self.admin_license = None
        self.admin_config["API_BASE_URL"] = API_BASE_URL
        self.admin_config["pluginCode"] = PLUGIN_CODE
        self.admin_config["clientCode"] = CLIENT_CODE
        self._admin_save_config()
        self._admin_set_message("授权后台已切换为云端，请重新登录。")
        return True

    def _admin_init_device_info(self):
        device_id = str(self.admin_config.get("deviceId") or "").strip()
        machine_id = get_or_create_machine_id(str(self.admin_config.get("machineId") or "").strip())
        platform_value = self._admin_platform()
        device_name = self._admin_device_name()
        os_name = self._admin_os_name()
        if not device_id:
            try:
                raw = "|".join([
                    socket.gethostname(),
                    getpass.getuser(),
                    platform_value,
                    DEVICE_ID_SALT
                ])
                device_id = hashlib.sha256(raw.encode("utf-8")).hexdigest()
            except Exception:
                device_id = str(uuid.uuid4())
        self.device_info = {
            "deviceId": device_id,
            "machineId": machine_id,
            "deviceName": device_name,
            "platform": platform_value,
            "os": os_name
        }
        self.machine_id = machine_id
        self.admin_config["deviceId"] = device_id
        self.admin_config["machineId"] = machine_id
        self.admin_config["deviceName"] = device_name
        self.admin_config["platform"] = platform_value
        self.admin_config["os"] = os_name
        self.admin_config["API_BASE_URL"] = API_BASE_URL
        self.admin_config["pluginCode"] = PLUGIN_CODE
        self.admin_config["clientCode"] = CLIENT_CODE
        self._admin_save_config()
        try:
            self._admin_log("machineId 已加载: " + self._admin_machine_id_prefix())
        except Exception:
            pass

    def _admin_result_body(self, data):
        if isinstance(data, dict) and isinstance(data.get("data"), dict):
            return data.get("data")
        return data if isinstance(data, dict) else {}

    def _admin_message_from_data(self, data, default=""):
        if isinstance(data, dict):
            body = self._admin_result_body(data)
            return str(data.get("message") or data.get("error") or body.get("message") or body.get("error") or default)
        return default

    def _admin_status_from_data(self, data):
        body = self._admin_result_body(data)
        if isinstance(data, dict):
            return str(body.get("reason") or body.get("status") or data.get("reason") or data.get("status") or "").strip().lower()
        return ""

    def _admin_reason_to_message(self, reason, message=""):
        if message:
            return str(message)
        reason = str(reason or "").strip().lower()
        mapping = {
            "no_license": "当前账号暂无授权，请联系管理员开通。",
            "license_expired": "授权已到期，请联系管理员续费。",
            "expired": "授权已到期，请联系管理员续费。",
            "license_disabled": "授权已被禁用，请联系管理员。",
            "disabled": "授权已被禁用，请联系管理员。",
            "user_disabled": "账号已被禁用，请联系管理员。",
            "plugin_disabled": "插件服务已被禁用，请联系管理员。",
            "session_replaced": "账号已在其他设备登录，请重新登录。",
            "machine_replaced": "账号已在其他电脑登录，请重新登录。",
            "unauthorized": "登录已失效，请重新登录。",
            "forbidden": "登录已失效，请重新登录。",
            "token_invalid": "登录已失效，请重新登录。",
            "device_limit_exceeded": "设备数量限制，请联系管理员。",
            "device_limit": "设备数量限制，请联系管理员。"
        }
        return mapping.get(reason, "授权校验失败，请重新登录或联系管理员。")

    def _admin_is_session_replaced(self, data):
        if not isinstance(data, dict):
            return False
        status = self._admin_status_from_data(data)
        message = self._admin_message_from_data(data, "").lower()
        return status == "session_replaced" or "session_replaced" in message or "账号已在其他设备登录" in message

    def _admin_is_machine_replaced(self, data):
        if not isinstance(data, dict):
            return False
        status = self._admin_status_from_data(data)
        message = self._admin_message_from_data(data, "").lower()
        return status == "machine_replaced" or "machine_replaced" in message or "账号已在其他电脑登录" in message

    def _admin_now_iso(self):
        return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

    def _admin_parse_time(self, value):
        text = str(value or "").strip()
        if not text:
            return 0.0
        try:
            if text.endswith("Z"):
                text = text[:-1] + "+00:00"
            dt = datetime.datetime.fromisoformat(text)
            if dt.tzinfo is not None:
                return dt.timestamp()
            return time.mktime(dt.timetuple())
        except Exception:
            pass
        try:
            return time.mktime(time.strptime(text, "%Y-%m-%d %H:%M:%S"))
        except Exception:
            return 0.0

    def _admin_seconds_since_last_verified(self):
        ts = self._admin_parse_time(self.admin_config.get("lastVerifiedAt"))
        if ts <= 0:
            return None
        return time.time() - ts

    def _admin_is_explicit_rejection(self, data):
        if self._admin_is_session_replaced(data) or self._admin_is_machine_replaced(data):
            return True
        body = self._admin_result_body(data)
        http_code = int(data.get("_http_code", 0)) if isinstance(data, dict) else 0
        if http_code in (401, 403):
            return True
        status = str(body.get("status") or data.get("status") or "").strip().lower()
        if status in AUTH_REJECT_STATUSES:
            return True
        message = self._admin_message_from_data(data, "").lower()
        rejection_words = [
            "unauthorized", "forbidden", "token invalid", "invalid token",
            "license_disabled", "license_expired", "user_disabled",
            "plugin_disabled", "device_limit", "device limit",
            "session_replaced", "账号已在其他设备登录",
            "machine_replaced", "账号已在其他电脑登录",
            "未登录", "登录已过期", "授权已过期", "授权被禁用",
            "用户被禁用", "插件被禁用", "设备数量"
        ]
        for word in rejection_words:
            if word and word in message:
                return True
        if isinstance(data, dict) and data.get("success") is False and data:
            return True
        if body.get("allowed") is False or data.get("allowed") is False:
            return True
        return False

    def _admin_offline_grace_available(self):
        age = self._admin_seconds_since_last_verified()
        return age is not None and age <= OFFLINE_GRACE_SECONDS and bool(self.admin_config.get("license"))

    def _admin_apply_offline_grace(self, message):
        if self._admin_offline_grace_available():
            self.admin_license = self.admin_config.get("license") if isinstance(self.admin_config.get("license"), dict) else self.admin_license
            if isinstance(self.admin_license, dict):
                self.admin_license["allowed"] = True
            self._set_core_enabled(True, "")
            self._admin_set_message("离线授权中：网络异常，使用最近一次授权。")
            return True
        if self._admin_seconds_since_last_verified() is None:
            final_message = "授权服务器无法连接，请先联网登录并验证授权。"
        else:
            final_message = "授权服务器无法连接，已超过离线宽限时间，请联网验证授权。"
        self._set_core_enabled(False, final_message)
        return False

    def _admin_handle_session_replaced(self):
        message = "账号已在其他设备登录，请重新登录。"
        self._admin_clear_login()
        self.admin_last_heartbeat_at = 0.0
        self._admin_set_message(message)
        self._set_core_enabled(False, message)
        return False

    def _admin_handle_machine_replaced(self):
        message = "账号已在其他电脑登录，请重新登录。"
        self._admin_clear_login()
        self.admin_last_heartbeat_at = 0.0
        self._admin_set_message(message)
        self._set_core_enabled(False, message)
        return False

    def _admin_handle_auth_failure(self, data, msg, default_message):
        if self._admin_is_machine_replaced(data):
            return self._admin_handle_machine_replaced()
        if self._admin_is_session_replaced(data):
            return self._admin_handle_session_replaced()
        if self._admin_is_explicit_rejection(data):
            status = self._admin_status_from_data(data)
            if not status and int(data.get("_http_code", 0)) in (401, 403):
                status = "unauthorized"
            message = self._admin_reason_to_message(status, self._admin_message_from_data(data, msg or ""))
            if not message:
                message = default_message
            if status in ("unauthorized", "forbidden", "token_invalid") or int(data.get("_http_code", 0)) in (401, 403):
                self._admin_clear_login()
            self.admin_config["licenseInvalidAt"] = self._admin_now_iso()
            self._admin_save_config()
            self._set_core_enabled(False, message)
            return False
        return self._admin_apply_offline_grace(msg or default_message)

    def _admin_ensure_fresh_license(self):
        if DEV_DISABLE_AUTH_GATE:
            return True
        if not self.admin_token:
            self._set_core_enabled(False, "未登录：请输入后台账号密码")
            return False
        age = self._admin_seconds_since_last_verified()
        if self.core_enabled and age is not None and age <= AUTH_REFRESH_INTERVAL_SECONDS:
            return True
        self._admin_set_message("正在刷新授权...")
        return self._admin_check_license()

    def _admin_maybe_heartbeat(self):
        if DEV_DISABLE_AUTH_GATE or not self.admin_token or not self.core_enabled:
            return
        now = time.time()
        if now - self.admin_last_heartbeat_at < HEARTBEAT_INTERVAL_SECONDS:
            return
        self.admin_last_heartbeat_at = now
        self._admin_heartbeat()

    def _admin_request(self, method, path, data=None, token=None, timeout=8):
        url = API_BASE_URL.rstrip("/") + path
        body = None
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "HuahuaC4DPlugin/" + CURRENT_VERSION
        }
        if token:
            headers["Authorization"] = "Bearer " + token
        if data is not None:
            body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers=headers, method=method.upper())
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8", "replace")
                parsed = json.loads(raw) if raw.strip() else {}
                if isinstance(parsed, dict) and parsed.get("success") is False:
                    return False, parsed, self._admin_message_from_data(parsed, "请求失败")
                return True, parsed, ""
        except urllib.error.HTTPError as e:
            raw = ""
            parsed = {}
            try:
                raw = e.read().decode("utf-8", "replace")
                parsed = json.loads(raw) if raw.strip() else {}
            except Exception:
                parsed = {}
            parsed["_http_code"] = e.code
            msg = self._admin_message_from_data(parsed, "HTTP " + str(e.code))
            self._admin_log(method + " " + path + " failed: " + msg)
            return False, parsed, msg
        except Exception as e:
            self._admin_log(method + " " + path + " exception: " + type(e).__name__ + ": " + str(e))
            traceback.print_exc()
            return False, {}, str(e)

    def _admin_set_message(self, text):
        self.admin_message = str(text or "")
        try:
            self.SetString(ID_ADMIN_MESSAGE_TEXT, self.admin_message)
        except Exception:
            pass
        self._refresh_admin_dialog()

    def _admin_account_label(self):
        user = self.admin_user or {}
        return str(user.get("nickname") or user.get("email") or user.get("account") or "未登录")

    def _admin_auth_status_text(self):
        if DEV_DISABLE_AUTH_GATE:
            return "开发模式"
        if not self.admin_token:
            return "未登录"
        reason = str(self.core_disabled_reason or "")
        license_info = self.admin_license or {}
        if self.core_enabled and bool(license_info.get("allowed")):
            return "已授权"
        if "其他电脑" in reason or "machine_replaced" in reason.lower():
            return "需重新登录"
        if "其他设备" in reason or "session_replaced" in reason.lower():
            return "需重新登录"
        if "强制更新" in reason or "需更新" in reason:
            return "需更新"
        if "设备" in reason or "超限" in reason:
            return "设备限制"
        if "过期" in reason or "expired" in reason.lower():
            return "已过期"
        if "禁用" in reason or "disabled" in reason.lower():
            return "已禁用"
        if license_info and not bool(license_info.get("allowed")):
            return "未授权"
        return "授权异常"

    def _admin_top_button_text(self):
        if DEV_DISABLE_AUTH_GATE:
            return "开发模式"
        if not self.admin_token:
            return "登录"
        return self._admin_auth_status_text()

    def _admin_machine_id_prefix(self):
        machine_id = str(self.machine_id or self.device_info.get("machineId") or self.admin_config.get("machineId") or "").strip()
        return machine_id[:8] if machine_id else "-"

    def _format_remaining_time(self, expires_at):
        text = str(expires_at or "").strip()
        if not text or text == "-":
            return "-"
        try:
            if text.endswith("Z"):
                expires = datetime.datetime.fromisoformat(text[:-1] + "+00:00")
            else:
                expires = datetime.datetime.fromisoformat(text)
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=datetime.timezone.utc)
            now = datetime.datetime.now(datetime.timezone.utc)
            seconds = (expires.astimezone(datetime.timezone.utc) - now).total_seconds()
            if seconds <= 0:
                return "已过期"
            days = int(seconds // 86400)
            if days >= 1:
                return "剩余 " + str(days) + " 天"
            hours = max(1, int(seconds // 3600))
            return "剩余 " + str(hours) + " 小时"
        except Exception:
            return "-"

    def _refresh_admin_dialog(self):
        try:
            if self.admin_dialog:
                self.admin_dialog.RefreshValues()
        except Exception as e:
            self._admin_log("刷新账号授权弹窗失败: " + str(e))

    def _open_admin_auth_dialog(self):
        try:
            if self.admin_dialog is None:
                self.admin_dialog = AdminAuthDialog(self)
            opened = self.admin_dialog.Open(
                dlgtype=c4d.DLG_TYPE_ASYNC,
                pluginid=ADMIN_AUTH_DIALOG_ID,
                defaultw=420,
                defaulth=360
            )
            self._refresh_admin_dialog()
            return opened
        except Exception as e:
            self._admin_log("打开账号授权弹窗失败: " + str(e))
            traceback.print_exc()
            gui.MessageDialog("打开账号授权窗口失败:\n" + str(e))
            return False

    def _open_admin_register_dialog(self):
        try:
            if self.admin_register_dialog is None:
                self.admin_register_dialog = AdminRegisterDialog(self)
            return self.admin_register_dialog.Open(
                dlgtype=c4d.DLG_TYPE_ASYNC,
                pluginid=ADMIN_REGISTER_DIALOG_ID,
                defaultw=420,
                defaulth=260
            )
        except Exception as e:
            self._admin_log("打开注册账号弹窗失败: " + str(e))
            traceback.print_exc()
            gui.MessageDialog("打开注册账号窗口失败:\n" + str(e))
            return False

    def _admin_clear_password_field(self):
        try:
            self.SetString(ID_ADMIN_PASSWORD, "")
        except Exception:
            pass
        try:
            if self.admin_dialog:
                self.admin_dialog.SetString(ID_ADMIN_PASSWORD, "")
        except Exception as e:
            self._admin_log("清空密码输入框失败: " + str(e))

    def _admin_update_ui(self):
        try:
            self.SetString(ID_ADMIN_OPEN_DIALOG_BTN, self._admin_top_button_text())
        except Exception as e:
            self._admin_log("更新右上角授权按钮失败: " + str(e))
        self._refresh_admin_dialog()

    def _set_core_enabled(self, enabled, reason=""):
        if DEV_DISABLE_AUTH_GATE:
            if not enabled:
                self._admin_log("DEV_DISABLE_AUTH_GATE=True，开发模式：忽略核心功能禁用请求。")
            self.core_enabled = True
            self.core_disabled_reason = ""
            self.admin_message = "当前为本地开发模式，已临时跳过授权限制。"
            for cid in CORE_BUTTON_IDS:
                try:
                    self.Enable(cid, True)
                except Exception:
                    pass
            self._admin_update_ui()
            return
        self.core_enabled = bool(enabled)
        self.core_disabled_reason = str(reason or "")
        for cid in CORE_BUTTON_IDS:
            try:
                self.Enable(cid, self.core_enabled)
            except Exception:
                pass
        if not self.core_enabled and self.core_disabled_reason:
            self._admin_set_message(self.core_disabled_reason)
        self._admin_update_ui()

    def _admin_clear_login(self):
        self.admin_token = ""
        self.admin_user = None
        self.admin_license = None
        self.admin_config.pop("token", None)
        self.admin_config.pop("user", None)
        self.admin_config.pop("license", None)
        self.admin_config.pop("lastLoginAt", None)
        self.admin_config.pop("lastVerifiedAt", None)
        self.admin_config.pop("lastHeartbeatAt", None)
        self._admin_save_config()

    def _admin_register_account(self, email, password, nickname=""):
        payload = {
            "email": email,
            "password": password,
            "machineId": self.device_info.get("machineId") or self.machine_id
        }
        if nickname:
            payload["nickname"] = nickname
        ok, data, msg = self._admin_request("POST", "/api/auth/register", payload)
        if ok:
            self._admin_set_message("注册成功，请登录。")
            return True
        message = self._admin_reason_to_message(self._admin_status_from_data(data), self._admin_message_from_data(data, msg or "注册失败"))
        self._admin_set_message(message)
        gui.MessageDialog(message)
        return False

    def _admin_login(self, account, password):
        ok, data, msg = self._admin_request("POST", "/api/auth/login", {
            "account": account,
            "password": password,
            "machineId": self.device_info.get("machineId") or self.machine_id,
            "deviceId": self.device_info.get("deviceId"),
            "clientCode": CLIENT_CODE,
            "pluginCode": PLUGIN_CODE
        })
        if not ok:
            message = self._admin_reason_to_message(self._admin_status_from_data(data), self._admin_message_from_data(data, msg or "登录失败"))
            self._admin_set_message(message)
            self._set_core_enabled(False, message)
            return False
        body = self._admin_result_body(data)
        token = body.get("token") or data.get("token")
        user = body.get("user") or data.get("user") or {}
        if not token:
            self._admin_set_message("登录失败：后台未返回 token")
            self._set_core_enabled(False, "登录失败：后台未返回 token")
            return False
        self.admin_token = str(token)
        self.admin_user = user if isinstance(user, dict) else {}
        self.admin_config["token"] = self.admin_token
        self.admin_config["user"] = self.admin_user
        self.admin_config["lastLoginAt"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._admin_save_config()
        self._admin_clear_password_field()
        self._admin_set_message("登录成功，正在校验授权...")
        return self._admin_authorize_after_login()

    def _admin_get_me(self):
        ok, data, msg = self._admin_request("GET", "/api/auth/me", token=self.admin_token)
        if not ok:
            if self._admin_is_machine_replaced(data):
                return self._admin_handle_machine_replaced()
            if self._admin_is_session_replaced(data):
                return self._admin_handle_session_replaced()
            if self._admin_is_explicit_rejection(data):
                return self._admin_handle_auth_failure(data, msg, "登录状态已失效，请重新登录")
            if not self._admin_is_explicit_rejection(data) and self._admin_offline_grace_available():
                self._admin_apply_offline_grace(msg or "网络异常，使用最近一次授权")
                return True
            self._admin_clear_login()
            self._admin_set_message(msg or "登录状态已失效，请重新登录")
            self._set_core_enabled(False, msg or "登录状态已失效，请重新登录")
            return False
        body = self._admin_result_body(data)
        user = body.get("user") or body or {}
        self.admin_user = user if isinstance(user, dict) else {}
        self.admin_config["user"] = self.admin_user
        self._admin_save_config()
        return True

    def _admin_check_license(self):
        payload = {
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE,
            "version": PLUGIN_VERSION,
            "platform": self.device_info.get("platform"),
            "deviceId": self.device_info.get("deviceId"),
            "machineId": self.device_info.get("machineId") or self.machine_id,
            "deviceName": self.device_info.get("deviceName"),
            "os": self.device_info.get("os")
        }
        ok, data, msg = self._admin_request("POST", "/api/plugin/check-license", payload, token=self.admin_token)
        self.admin_last_check_license_result = {"success": ok, "data": data, "message": msg}
        if not ok:
            return self._admin_handle_auth_failure(data, msg, "授权校验失败")
        body = self._admin_result_body(data)
        allowed = bool(body.get("allowed", data.get("allowed", False)))
        if "license" in body and isinstance(body.get("license"), dict):
            license_info = body.get("license")
        else:
            license_info = body
        license_info["allowed"] = allowed
        self.admin_license = license_info
        self.admin_config["license"] = license_info
        self.admin_config["lastVerifiedAt"] = self._admin_now_iso()
        self.admin_config.pop("licenseInvalidAt", None)
        self._admin_save_config()
        if not allowed:
            return self._admin_handle_auth_failure(data, self._admin_message_from_data(data, body.get("message") or ""), "插件未授权")
        return True

    def _admin_register_device(self):
        payload = {
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE,
            "deviceId": self.device_info.get("deviceId"),
            "machineId": self.device_info.get("machineId") or self.machine_id,
            "deviceName": self.device_info.get("deviceName"),
            "os": self.device_info.get("os"),
            "platform": self.device_info.get("platform")
        }
        ok, data, msg = self._admin_request("POST", "/api/plugin/register-device", payload, token=self.admin_token)
        self.admin_last_register_device_result = {"success": ok, "data": data, "message": msg}
        if not ok:
            return self._admin_handle_auth_failure(data, msg, "设备注册失败")
        body = self._admin_result_body(data)
        allowed = bool(body.get("allowed", data.get("allowed", True)))
        if not allowed:
            return self._admin_handle_auth_failure(data, self._admin_message_from_data(data, body.get("message") or ""), "设备注册失败")
        return True

    def _admin_check_update(self, show_dialog=False):
        payload = {
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE,
            "version": PLUGIN_VERSION,
            "platform": self.device_info.get("platform", self._admin_platform()),
            "deviceId": self.device_info.get("deviceId"),
            "machineId": self.device_info.get("machineId") or self.machine_id
        }
        ok, data, msg = self._admin_request("POST", "/api/plugin/check-update", payload, token=self.admin_token)
        self.admin_last_check_update_result = {"success": ok, "data": data, "message": msg}
        if not ok:
            self._admin_log("检查后台更新失败: " + (msg or "未知错误"))
            if show_dialog:
                gui.MessageDialog("检查更新失败，请稍后重试。")
            return False
        body = self._admin_result_body(data)
        self.admin_update_info = body
        self._admin_update_ui()
        has_update = bool(body.get("hasUpdate", data.get("hasUpdate", False)))
        force_update = bool(body.get("forceUpdate", data.get("forceUpdate", False)))
        latest = body.get("latestVersion") or body.get("latest_version") or body.get("version") or CURRENT_VERSION
        notes = body.get("releaseNotes") or body.get("release_notes") or body.get("notes") or []
        if isinstance(notes, list):
            note_text = "\n".join(["- " + str(n) for n in notes])
        else:
            note_text = str(notes or "")
        if force_update:
            self._set_core_enabled(False, "检测到强制更新版本：v" + str(latest))
        if show_dialog:
            if has_update:
                gui.MessageDialog("检测到新版本：v" + str(latest) + ("\n\n" + note_text if note_text else ""))
            else:
                gui.MessageDialog("当前已经是最新版本：v" + CURRENT_VERSION)
        return True

    def _admin_heartbeat(self):
        payload = {
            "pluginCode": PLUGIN_CODE,
            "clientCode": CLIENT_CODE,
            "deviceId": self.device_info.get("deviceId"),
            "machineId": self.device_info.get("machineId") or self.machine_id,
            "version": PLUGIN_VERSION,
            "platform": self.device_info.get("platform")
        }
        ok, data, msg = self._admin_request("POST", "/api/plugin/heartbeat", payload, token=self.admin_token)
        self.admin_last_heartbeat_result = {"success": ok, "data": data, "message": msg}
        if not ok:
            self._admin_log("heartbeat 失败: " + (msg or "未知错误"))
            self._admin_handle_auth_failure(data, msg, "heartbeat 失败")
            return False
        body = self._admin_result_body(data)
        if self._admin_is_explicit_rejection(data) or body.get("allowed") is False:
            return self._admin_handle_auth_failure(data, self._admin_message_from_data(data, body.get("message") or ""), "授权已失效")
        self.admin_config["lastHeartbeatAt"] = self._admin_now_iso()
        self._admin_save_config()
        return ok

    def _admin_authorize_after_login(self):
        if not self._admin_get_me():
            return False
        if not self._admin_check_license():
            return False
        if not self._admin_register_device():
            return False
        self._admin_check_update(show_dialog=False)
        self._admin_heartbeat()
        if self.core_disabled_reason.startswith("检测到强制更新"):
            return False
        self._set_core_enabled(True, "")
        self._admin_set_message("授权通过")
        return True

    def _admin_init_startup(self):
        self._admin_load_config()
        api_base_changed = self._admin_handle_api_base_change()
        self._admin_init_device_info()
        self.admin_token = str(self.admin_config.get("token") or "")
        self.admin_user = self.admin_config.get("user") if isinstance(self.admin_config.get("user"), dict) else None
        self.admin_license = self.admin_config.get("license") if isinstance(self.admin_config.get("license"), dict) else None
        if DEV_DISABLE_AUTH_GATE:
            self._admin_log("DEV_DISABLE_AUTH_GATE=True，已跳过授权拦截，仅用于本地测试。")
            self._set_core_enabled(True, "")
            if not self.admin_token:
                self._admin_set_message("当前为本地开发模式，已临时跳过授权限制。")
                return
        self._admin_update_ui()
        if not self.admin_token:
            reason = "授权后台已切换为云端，请重新登录。" if api_base_changed else "未登录：请输入后台账号密码"
            self._set_core_enabled(False, reason)
            return
        self._admin_set_message("正在校验后台登录和授权...")
        self._admin_authorize_after_login()
        self.SetTimer(JSON_WATCH_INTERVAL_MS)

    def _admin_logout(self):
        self._admin_clear_login()
        self._admin_clear_password_field()
        self._set_core_enabled(False, "已退出登录")
        self._admin_update_ui()

    def _admin_handle_login_click(self):
        self._open_admin_auth_dialog()
        return True

    def _load_json_watch_pref(self):
        self.json_watch_dir = ""
        try:
            bc = plugins.GetWorldPluginData(PLUGIN_ID)
            if bc:
                path = bc.GetString(JSON_WATCH_PREF_PATH)
                if path and os.path.isdir(path):
                    self.json_watch_dir = path
                    self._snapshot_json_watch_dir()
                    self._json_watch_log("已读取监听目录偏好: " + path)
        except Exception as e:
            self._json_watch_log("读取监听目录偏好失败: " + str(e))

    def _save_json_watch_pref(self):
        try:
            bc = plugins.GetWorldPluginData(PLUGIN_ID)
            if bc is None:
                bc = c4d.BaseContainer()
            bc.SetString(JSON_WATCH_PREF_PATH, self.json_watch_dir or "")
            plugins.SetWorldPluginData(PLUGIN_ID, bc, True)
            self._json_watch_log("已保存监听目录: " + (self.json_watch_dir or ""))
        except Exception as e:
            self._json_watch_log("保存监听目录失败: " + str(e))

    def _update_json_watch_status(self, text=None):
        try:
            if text:
                self.SetString(ID_JSON_WATCH_STATUS, text)
            elif self.json_watch_dir:
                self.SetString(ID_JSON_WATCH_STATUS, "正在监听：" + self.json_watch_dir)
            else:
                self.SetString(ID_JSON_WATCH_STATUS, "未选择监听目录")
        except Exception as e:
            self._json_watch_log("更新监听状态失败: " + str(e))

    def _json_watch_log(self, message):
        try:
            print("[JSON Watch] " + str(message))
        except Exception:
            pass

    def _list_json_watch_files(self):
        files = set()
        if not self.json_watch_dir or not os.path.isdir(self.json_watch_dir):
            return files
        try:
            for name in os.listdir(self.json_watch_dir):
                if not name.lower().endswith(".json"):
                    continue
                path = os.path.join(self.json_watch_dir, name)
                if os.path.isfile(path):
                    files.add(os.path.abspath(path))
        except Exception as e:
            self._json_watch_log("扫描监听目录失败: " + str(e))
        return files

    def _snapshot_json_watch_dir(self):
        files = self._list_json_watch_files()
        self.json_watch_seen = set(files)
        self.json_watch_processed = set(files)
        self.json_watch_candidates = {}
        self._json_watch_log("baseline 已记录现有 JSON 数量: " + str(len(files)))

    def _start_json_watch_timer(self):
        self.SetTimer(JSON_WATCH_INTERVAL_MS)
        self._json_watch_log("Timer 已启动: " + str(JSON_WATCH_INTERVAL_MS) + "ms")
        self._update_json_watch_status()

    def _select_json_watch_dir(self):
        folder = storage.LoadDialog(title="选择 JSON 监听文件夹", flags=c4d.FILESELECT_DIRECTORY)
        if not folder:
            self._json_watch_log("用户取消选择监听目录")
            return
        self.json_watch_dir = folder
        self._json_watch_log("选择的监听目录: " + folder)
        self._save_json_watch_pref()
        self._snapshot_json_watch_dir()
        self._update_json_watch_status()
        self._start_json_watch_timer()

    def Timer(self, msg):
        self._run_json_watch_check("Timer")
        return True

    def Message(self, msg, result):
        try:
            timer_id = getattr(c4d, "BFM_TIMER", None)
            if timer_id is not None and msg and msg.GetId() == timer_id:
                self._run_json_watch_check("Message.BFM_TIMER")
                return True
        except Exception as e:
            self._json_watch_log("Timer Message 处理失败: " + str(e))
        return gui.GeDialog.Message(self, msg, result)

    def _run_json_watch_check(self, source):
        now = time.time()
        self._admin_maybe_heartbeat()
        if now - self.json_watch_last_check_time < 1.0:
            return
        self.json_watch_last_check_time = now
        self._json_watch_log("检查监听目录 source=" + source + " time=" + time.strftime("%H:%M:%S"))
        try:
            self._check_json_watch_folder()
        except Exception as e:
            self._json_watch_log("监听检查异常: " + str(e))
            traceback.print_exc()

    def _check_json_watch_folder(self):
        if not self.json_watch_dir:
            return
        if not os.path.isdir(self.json_watch_dir):
            self._json_watch_log("监听目录不存在: " + self.json_watch_dir)
            self._update_json_watch_status("监听目录不存在：" + self.json_watch_dir)
            return

        current_files = self._list_json_watch_files()
        for path in list(self.json_watch_candidates.keys()):
            if path not in current_files:
                self.json_watch_candidates.pop(path, None)

        now = time.time()
        for path in sorted(current_files):
            if path in self.json_watch_processed:
                continue
            try:
                stat_info = os.stat(path)
                size = stat_info.st_size
                mtime = stat_info.st_mtime
            except Exception as e:
                self._json_watch_log("读取文件状态失败: " + path + " / " + str(e))
                continue

            prev = self.json_watch_candidates.get(path)
            if prev and prev[0] == size and prev[1] == mtime:
                self.json_watch_seen.add(path)
                self.json_watch_processed.add(path)
                self.json_watch_candidates.pop(path, None)
                file_name = os.path.basename(path)
                self._json_watch_log("文件稳定，准备弹窗: " + file_name)
                self._update_json_watch_status("已检测到新 JSON：" + file_name)
                should_import = gui.QuestionDialog("检测到新的 JSON 文件：" + file_name + "\n是否导入？")
                if should_import:
                    self._json_watch_log("用户确认导入: " + file_name)
                    self._update_json_watch_status("正在导入：" + file_name)
                    self._json_watch_log("调用导入函数: _do_import(file_path_override=path)")
                    self._do_import(file_path_override=path)
                    self._update_json_watch_status("已导入：" + file_name)
                else:
                    self._json_watch_log("用户取消导入: " + file_name)
                    self._update_json_watch_status("已取消导入：" + file_name)
                break

            if not prev or prev[0] != size or prev[1] != mtime:
                self.json_watch_candidates[path] = (size, mtime, now)
                self._json_watch_log("发现新的 json 文件，等待稳定: " + os.path.basename(path) + " size=" + str(size))

    def _update_log(self, message):
        try:
            print("[Update Check] " + str(message))
        except Exception:
            pass

    def _parse_version(self, version_text):
        parts = []
        for part in str(version_text or "").strip().lstrip("vV").split("."):
            digits = ""
            for ch in part:
                if ch.isdigit():
                    digits += ch
                else:
                    break
            parts.append(int(digits) if digits else 0)
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts[:3])

    def _compare_versions(self, local_version, remote_version):
        local_tuple = self._parse_version(local_version)
        remote_tuple = self._parse_version(remote_version)
        if remote_tuple > local_tuple:
            return 1
        if remote_tuple < local_tuple:
            return -1
        return 0

    def _is_update_ssl_error(self, error):
        text = (type(error).__name__ + " " + str(error)).lower()
        return "certificate_verify_failed" in text or "ssl" in text or "certificate" in text

    def _read_update_url(self, url, allow_unverified_ssl=False):
        headers = {
            "User-Agent": "HuahuaC4DPlugin/" + CURRENT_VERSION,
            "Accept": "application/json,text/plain,*/*"
        }
        req = urllib.request.Request(
            url,
            headers=headers
        )
        if allow_unverified_ssl:
            context = ssl._create_unverified_context()
            response = urllib.request.urlopen(req, timeout=8, context=context)
        else:
            response = urllib.request.urlopen(req, timeout=8)

        with response:
            status_code = getattr(response, "status", None)
            if status_code is None:
                status_code = getattr(response, "code", "")
            body = response.read().decode("utf-8", "replace")
        return body, status_code

    def _fetch_update_body(self, url):
        self._update_log("请求 URL: " + url)
        try:
            body, status_code = self._read_update_url(url)
        except Exception as e:
            if not self._is_update_ssl_error(e):
                raise
            self._update_log("SSL 验证失败，尝试使用兼容模式重新请求。")
            body, status_code = self._read_update_url(url, True)
        self._update_log("HTTP 状态码: " + str(status_code))
        self._update_log("返回内容前 200 字符: " + body[:200])
        return body

    def _fetch_update_info(self):
        last_error = None
        for url in (UPDATE_JSON_URL, UPDATE_JSON_FALLBACK_URL):
            try:
                body = self._fetch_update_body(url)
                try:
                    data = json.loads(body)
                except Exception as e:
                    self._update_log("JSON 解析失败: " + type(e).__name__ + ": " + str(e))
                    self._update_log("返回内容前 200 字符: " + body[:200])
                    raise ValueError("UPDATE_JSON_FORMAT_ERROR")
                self._update_log("JSON 解析结果: " + str(data))
                self._update_log("请求成功")
                return data
            except ValueError as e:
                if str(e) == "UPDATE_JSON_FORMAT_ERROR":
                    raise
                last_error = e
            except Exception as e:
                last_error = e
                self._update_log("请求失败: " + type(e).__name__ + ": " + str(e))
                traceback.print_exc()
        if last_error:
            raise last_error
        raise RuntimeError("所有 update.json 地址请求失败")

    def _open_update_download_url(self, url):
        if not url:
            self._update_log("下载地址为空")
            gui.MessageDialog("当前版本暂未提供下载地址。")
            return
        self._update_log("打开下载地址: " + url)
        try:
            webbrowser.open(url)
        except Exception as e:
            self._update_log("打开下载地址失败: " + str(e))
            gui.MessageDialog("无法打开下载地址，请稍后再试。")

    def _action_check_update(self):
        admin_ok = self._admin_check_update(show_dialog=True)
        if admin_ok:
            return True
        self._update_log("后台检查更新失败，回退到公共 update.json")
        self._update_log("点击了检查更新")
        self._update_log("当前版本 CURRENT_VERSION: " + CURRENT_VERSION)
        try:
            info = self._fetch_update_info()
            latest_version = str(info.get("latest_version", "")).strip()
            self._update_log("latest_version: " + latest_version)
            if not latest_version:
                raise ValueError("update.json 缺少 latest_version")

            compare_result = self._compare_versions(CURRENT_VERSION, latest_version)
            self._update_log("版本比较结果: " + str(compare_result))

            if compare_result == 0:
                gui.MessageDialog("当前已经是最新版本：v" + CURRENT_VERSION)
                return True

            if compare_result < 0:
                gui.MessageDialog("当前本地版本高于发布版本：v" + CURRENT_VERSION)
                return True

            notes = info.get("release_notes", [])
            if not isinstance(notes, list):
                notes = [str(notes)]
            note_text = "\n".join(["- " + str(note) for note in notes]) if notes else "- 暂无版本说明"
            message = "检测到新版本：v" + latest_version + "\n版本说明：\n\n" + note_text + "\n\n是否前往下载？"
            if gui.QuestionDialog(message):
                self._open_update_download_url(str(info.get("manual_download_url", "")).strip())
            return True
        except Exception as e:
            self._update_log("完整异常类型: " + type(e).__name__)
            self._update_log("完整异常内容: " + repr(e))
            traceback.print_exc()
            if str(e) == "UPDATE_JSON_FORMAT_ERROR":
                gui.MessageDialog("检查更新失败：更新数据格式错误。")
                return True
            gui.MessageDialog("检查更新失败，请稍后再试。")
            return True

    def CoreMessage(self, id, msg):
        if id == c4d.EVMSG_CHANGE:
            self._update_ui_from_selection()
        return gui.GeDialog.CoreMessage(self, id, msg)

    # --- UI Helper Functions ---
    def SetLoadProgress(self, percent, message):
        percent = max(0, min(100, int(percent)))
        text = str(message or "")
        try:
            self.load_progress_area.SetProgress(percent)
            self.SetString(ID_LOAD_PROGRESS_TEXT, text)
            self.LayoutChanged(ID_LOAD_PROGRESS_GROUP)
            c4d.StatusSetText(text)
            c4d.EventAdd()
            if hasattr(c4d, "GeSyncMessage"):
                c4d.GeSyncMessage(c4d.EVMSG_CHANGE)
        except Exception as e:
            print("[Load Progress] 更新失败: " + str(e))

    def ResetLoadProgress(self):
        self.SetLoadProgress(0, "等待选择文件")

    def FinishLoadProgress(self):
        self.SetLoadProgress(100, "导入完成")

    def FailLoadProgress(self, error_message):
        msg = str(error_message).strip() or "未知错误"
        self.SetLoadProgress(0, f"导入失败：{msg}")

    def _get_target_spline(self, obj):
        if not obj: return None
        if obj.CheckType(c4d.Ospline): return obj
        if obj.CheckType(c4d.Oextrude) or obj.GetType() == C4D_EXTRUDE_TYPEID:
            child = obj.GetDown()
            if child and child.CheckType(c4d.Ospline): return child
        return None

    def _update_ui_from_selection(self):
        doc = documents.GetActiveDocument()
        if not doc: return
        obj = doc.GetActiveObject()
        if not obj: return
        
        if obj.CheckType(c4d.Oextrude) or obj.GetType() == C4D_EXTRUDE_TYPEID:
            current_depth = 0.0
            try: current_depth = abs(obj[C4D_EXTRUDE_OFFSET_ID])
            except:
                try:
                    vec = obj[c4d.EXTRUDEOBJECT_MOVE]
                    current_depth = vec.GetLength()
                except: pass
            
            ui_val = self.GetFloat(ID_EXTRUDE_DEPTH)
            if abs(ui_val - current_depth) > 0.001:
                 self.SetFloat(ID_EXTRUDE_DEPTH, current_depth)
                 self.SetFloat(ID_EXTRUDE_SLIDER, current_depth)
    
        target_spline = self._get_target_spline(obj)
        if target_spline:
            try:
                self.SetInt32(ID_SPL_TYPE_COMBO, target_spline[c4d.SPLINEOBJECT_TYPE])
                self.SetBool(ID_SPL_CLOSE_CHK, target_spline[c4d.SPLINEOBJECT_CLOSED])
                inter = target_spline[c4d.SPLINEOBJECT_INTERPOLATION]
                self.SetInt32(ID_SPL_INTER_COMBO, inter)
                if inter != c4d.SPLINEOBJECT_INTERPOLATION_ADAPTIVE:
                    self.SetInt32(ID_SPL_SUB_VAL, target_spline[c4d.SPLINEOBJECT_SUB])
            except: pass
    
    def _action_update_spline_param(self, param_id, value):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel: return
        doc.StartUndo()
        changed = False
        for obj in sel:
            target = self._get_target_spline(obj)
            if target:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, target)
                target[param_id] = value
                target.Message(c4d.MSG_UPDATE)
                changed = True
        doc.EndUndo()
        if changed: c4d.EventAdd()

    def _collect_valid_objects(self, start_nodes):
        targets =[]
        if not start_nodes: return[]
        def recurse(op):
            if not op: return
            targets.append(op)
            child = op.GetDown()
            while child:
                recurse(child)
                child = child.GetNext()
        for node in start_nodes: recurse(node)
        seen = set()
        unique =[]
        for t in targets:
            guid = t.GetGUID()
            if guid not in seen:
                unique.append(t)
                seen.add(guid)
        return unique

    def _get_real_world_bounds(self, obj):
        min_x = min_y = min_z = float('inf')
        max_x = max_y = max_z = float('-inf')
        has_points = False
        def traverse_points(op):
            nonlocal min_x, min_y, min_z, max_x, max_y, max_z, has_points
            points = None
            if op.CheckType(c4d.Opoint): points = op.GetAllPoints()
            if points:
                mg = op.GetMg()
                for p in points:
                    wp = mg * p 
                    if wp.x < min_x: min_x = wp.x
                    if wp.x > max_x: max_x = wp.x
                    if wp.y < min_y: min_y = wp.y
                    if wp.y > max_y: max_y = wp.y
                    if wp.z < min_z: min_z = wp.z
                    if wp.z > max_z: max_z = wp.z
                    has_points = True
            cache = op.GetCache()
            if cache: traverse_points(cache)
            child = op.GetDown()
            while child:
                traverse_points(child)
                child = child.GetNext()
        traverse_points(obj)
        if not has_points:
            pos = obj.GetMg().off
            return pos, pos, pos
        center = c4d.Vector((min_x + max_x)*0.5, (min_y + max_y)*0.5, (min_z + max_z)*0.5)
        min_vec = c4d.Vector(min_x, min_y, min_z)
        max_vec = c4d.Vector(max_x, max_y, max_z)
        return center, min_vec, max_vec

    def _center_axis(self, obj):
        center, _, _ = self._get_real_world_bounds(obj)
        old_mg = obj.GetMg()
        children = obj.GetChildren()
        child_mgs = [child.GetMg() for child in children]
        new_mg = c4d.Matrix(old_mg)
        new_mg.off = center
        obj.SetMg(new_mg)
        if obj.CheckType(c4d.Opoint):
            points = obj.GetAllPoints()
            inv_new_mg = ~new_mg
            new_points =[inv_new_mg * (old_mg * p) for p in points]
            obj.SetAllPoints(new_points)
            obj.Message(c4d.MSG_UPDATE)
        for child, mg in zip(children, child_mgs):
            child.SetMg(mg)

    def _action_select_hidden_objects(self):
        doc = documents.GetActiveDocument()
        if not doc: return
        c4d.CallCommand(12113) 
        found_count = 0
        def scan_hidden(op):
            nonlocal found_count
            if not op: return
            if op.GetEditorMode() == c4d.MODE_OFF: 
                op.SetBit(c4d.BIT_ACTIVE)
                found_count += 1
            child = op.GetDown()
            while child:
                scan_hidden(child)
            child = child.GetNext()
        root_obj = doc.GetFirstObject()
        while root_obj:
            scan_hidden(root_obj)
            root_obj = root_obj.GetNext()
        c4d.EventAdd()
        if found_count > 0: c4d.StatusSetText(f"已选中 {found_count} 个隐藏对象")
        else: gui.MessageDialog("当前场景中没有找到被隐藏（红点/Off）的对象。")

    def _action_select_textured_objects(self):
        doc = documents.GetActiveDocument()
        if not doc: return
        c4d.CallCommand(12113)
        found_count = 0
        def scan_textured(op):
            nonlocal found_count
            if not op: return
            has_texture = False
            tags = op.GetTags()
            for t in tags:
                if t.CheckType(c4d.Ttexture):
                    mat = t.GetMaterial()
                    if mat:
                        if mat[c4d.MATERIAL_USE_COLOR]:
                            shader = mat[c4d.MATERIAL_COLOR_SHADER]
                            if shader: has_texture = True
                        if not has_texture and mat[c4d.MATERIAL_USE_LUMINANCE]:
                            shader = mat[c4d.MATERIAL_LUMINANCE_SHADER]
                            if shader: has_texture = True
                        if has_texture: break
            if has_texture:
                op.SetBit(c4d.BIT_ACTIVE)
                found_count += 1
            child = op.GetDown()
            while child:
                scan_textured(child)
                child = child.GetNext()
        root_obj = doc.GetFirstObject()
        while root_obj:
            scan_textured(root_obj)
            root_obj = root_obj.GetNext()
        c4d.EventAdd()
        if found_count > 0: c4d.StatusSetText(f"已选中 {found_count} 个带贴图的对象")
        else: gui.MessageDialog("未找到带有纹理贴图的对象。")

    def _action_drop_to_floor(self):
        try:
            doc = documents.GetActiveDocument()
            sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if not sel: return
            doc.StartUndo()
            for obj in sel:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                _, min_vec, _ = self._get_real_world_bounds(obj)
                diff_y = -min_vec.y
                mg = obj.GetMg()
                mg.off = c4d.Vector(mg.off.x, mg.off.y + diff_y, mg.off.z)
                obj.SetMg(mg)
            doc.EndUndo()
            c4d.EventAdd()
        except Exception as e: gui.MessageDialog(f"执行出错: {e}")

    def _action_center_x(self):
        try:
            doc = documents.GetActiveDocument()
            sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if not sel: return
            doc.StartUndo()
            for obj in sel:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                center, _, _ = self._get_real_world_bounds(obj)
                diff_x = -center.x
                mg = obj.GetMg()
                mg.off = c4d.Vector(mg.off.x + diff_x, mg.off.y, mg.off.z)
                obj.SetMg(mg)
            doc.EndUndo()
            c4d.EventAdd()
        except Exception as e: gui.MessageDialog(f"执行出错: {e}")

    def _action_stand_up(self):
        try:
            doc = documents.GetActiveDocument()
            sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if not sel: return
            doc.StartUndo()
            for obj in sel:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                rot = obj.GetRelRot()
                rot.x = c4d.utils.Rad(-90)
                obj.SetRelRot(rot)
                obj.Message(c4d.MSG_UPDATE)
                _, min_vec, _ = self._get_real_world_bounds(obj)
                mg = obj.GetMg()
                mg.off = c4d.Vector(mg.off.x, mg.off.y - min_vec.y, mg.off.z)
                obj.SetMg(mg)
            doc.EndUndo()
            c4d.EventAdd()
        except Exception as e: gui.MessageDialog(f"执行出错: {e}")

    def _action_reset_psr(self):
        try:
            doc = documents.GetActiveDocument()
            sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
            if not sel: return
            doc.StartUndo()
            for obj in sel:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                obj.SetAbsRot(c4d.Vector(0))
                obj.Message(c4d.MSG_UPDATE)
                self._center_axis(obj)
                obj.SetAbsPos(c4d.Vector(0))
            doc.EndUndo()
            c4d.EventAdd()
        except Exception as e: gui.MessageDialog(f"执行出错: {e}")

    def _action_move_selection(self, vector):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_NONE)
        if not sel: return
        doc.StartUndo()
        for obj in sel:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
            mg = obj.GetMg()
            move_m = c4d.utils.MatrixMove(vector)
            new_mg = mg * move_m 
            obj.SetMg(new_mg)
        doc.EndUndo()
        c4d.EventAdd()

    # =========================================================================
    #  全方位轴心工具 (XY + Z)
    # =========================================================================
    def _get_local_hierarchy_bounds_axis(self, obj, root_inv_mg):
        min_p = c4d.Vector(1e15)
        max_p = c4d.Vector(-1e15)
        has_geometry = False

        def traverse(node):
            nonlocal min_p, max_p, has_geometry
            rad = node.GetRad()
            mp = node.GetMp()
            
            if rad.x != 0 or rad.y != 0 or rad.z != 0 or node.CheckType(c4d.Opoint):
                has_geometry = True
                corners =[
                    c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z - rad.z),
                    c4d.Vector(mp.x + rad.x, mp.y - rad.y, mp.z - rad.z),
                    c4d.Vector(mp.x - rad.x, mp.y + rad.y, mp.z - rad.z),
                    c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z - rad.z),
                    c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z + rad.z),
                    c4d.Vector(mp.x + rad.x, mp.y - rad.y, mp.z + rad.z),
                    c4d.Vector(mp.x - rad.x, mp.y + rad.y, mp.z + rad.z),
                    c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z + rad.z)
                ]
                
                node_mg = node.GetMg()
                for p in corners:
                    world_p = node_mg * p
                    root_local_p = root_inv_mg * world_p 
                    
                    if root_local_p.x < min_p.x: min_p.x = root_local_p.x
                    if root_local_p.y < min_p.y: min_p.y = root_local_p.y
                    if root_local_p.z < min_p.z: min_p.z = root_local_p.z
                    
                    if root_local_p.x > max_p.x: max_p.x = root_local_p.x
                    if root_local_p.y > max_p.y: max_p.y = root_local_p.y
                    if root_local_p.z > max_p.z: max_p.z = root_local_p.z

            for child in node.GetChildren():
                traverse(child)

        traverse(obj)
        if not has_geometry: return c4d.Vector(0), c4d.Vector(0)
        return min_p, max_p

    def _action_align_axis(self, direction):
        doc = documents.GetActiveDocument()
        doc.StartUndo() 

        selection = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not selection: 
            gui.MessageDialog("请先选中要调整轴心的对象！")
            return

        for obj in selection:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)

            mg = obj.GetMg()
            inv_mg = ~mg 

            min_local, max_local = self._get_local_hierarchy_bounds_axis(obj, inv_mg)
            size = max_local - min_local
            center = (max_local + min_local) * 0.5
            
            target_local_pos = c4d.Vector(
                center.x + (size.x * 0.5 * direction.x),
                center.y + (size.y * 0.5 * direction.y),
                center.z + (size.z * 0.5 * direction.z) 
            )
            
            offset = target_local_pos
            
            if obj.CheckType(c4d.Opoint):
                all_points = obj.GetAllPoints()
                new_points = [p - offset for p in all_points]
                obj.SetAllPoints(new_points)
                obj.Message(c4d.MSG_UPDATE)
            
            children = obj.GetChildren()
            for child in children:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, child)
                child_ml = child.GetMl()
                child_ml.off -= offset 
                child.SetMl(child_ml)

            global_offset = mg.MulV(offset)
            mg.off += global_offset
            obj.SetMg(mg)

        doc.EndUndo() 
        c4d.EventAdd() 
        c4d.StatusSetText("✅ 轴心对齐完成。")

    # =========================================================================
    #  花花广告设计 v1.1 - Super Align 核心功能区
    # =========================================================================
    def _collect_sub_object_face_points(self, root_obj, axis, direction):
        points_list =[]
        stack = [root_obj]
        while stack:
            o = stack.pop()
            rad = o.GetRad()
            if rad.GetLengthSquared() > 1e-5:
                mg = o.GetMg()
                mp = o.GetMp()
                min_l = c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z - rad.z)
                max_l = c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z + rad.z)
                
                local_pts =[]
                if axis == 0:
                    x = max_l.x if direction > 0 else min_l.x
                    local_pts =[
                        c4d.Vector(x, mp.y, mp.z), c4d.Vector(x, max_l.y, max_l.z),
                        c4d.Vector(x, max_l.y, min_l.z), c4d.Vector(x, min_l.y, max_l.z),
                        c4d.Vector(x, min_l.y, min_l.z)
                    ]
                elif axis == 1:
                    y = max_l.y if direction > 0 else min_l.y
                    local_pts =[
                        c4d.Vector(mp.x, y, mp.z), c4d.Vector(max_l.x, y, max_l.z),
                        c4d.Vector(min_l.x, y, max_l.z), c4d.Vector(max_l.x, y, min_l.z),
                        c4d.Vector(min_l.x, y, min_l.z)
                    ]
                elif axis == 2:
                    z = max_l.z if direction > 0 else min_l.z
                    local_pts =[
                        c4d.Vector(mp.x, mp.y, z), c4d.Vector(max_l.x, max_l.y, z),
                        c4d.Vector(min_l.x, max_l.y, z), c4d.Vector(max_l.x, min_l.y, z),
                        c4d.Vector(min_l.x, min_l.y, z)
                    ]
                for lp in local_pts:
                    points_list.append(mg * lp)

            children = o.GetChildren()
            if children: stack.extend(children)
            cache = o.GetCache()
            if cache: stack.append(cache)
            deform = o.GetDeformCache()
            if deform: stack.append(deform)
            
        return points_list

    def _is_layer_visible_for_raycast(self, obj, doc):
        try:
            layer = obj.GetLayerObject(doc)
            if not layer:
                return True
            layer_data = layer.GetLayerData(doc)
            if not layer_data:
                return True
            for key in ("view", "render"):
                try:
                    if hasattr(layer_data, "get"):
                        value = layer_data.get(key, True)
                    else:
                        value = layer_data[key]
                    if value is False:
                        return False
                except Exception:
                    pass
        except Exception:
            pass
        return True

    def _collect_object_tree_ids(self, root_obj):
        ids = set()
        stack = [root_obj]
        while stack:
            obj = stack.pop()
            if not obj:
                continue
            try:
                ids.add(obj.GetGUID())
            except Exception:
                pass
            child = obj.GetDown()
            while child:
                stack.append(child)
                child = child.GetNext()
            cache = obj.GetCache()
            if cache:
                stack.append(cache)
            deform = obj.GetDeformCache()
            if deform:
                stack.append(deform)
        return ids

    def _is_object_in_guid_set(self, obj, guid_set):
        try:
            return obj.GetGUID() in guid_set
        except Exception:
            return False

    def _is_descendant_of(self, obj, parent):
        node = obj
        while node:
            if node == parent:
                return True
            node = node.GetUp()
        return False

    def _get_world_aabb_fast(self, obj, mg):
        rad = obj.GetRad()
        mp = obj.GetMp()
        if rad.GetLengthSquared() <= 1e-10 and not obj.CheckType(c4d.Opoint):
            return None
        pts = [
            c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z - rad.z),
            c4d.Vector(mp.x + rad.x, mp.y - rad.y, mp.z - rad.z),
            c4d.Vector(mp.x - rad.x, mp.y + rad.y, mp.z - rad.z),
            c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z - rad.z),
            c4d.Vector(mp.x - rad.x, mp.y - rad.y, mp.z + rad.z),
            c4d.Vector(mp.x + rad.x, mp.y - rad.y, mp.z + rad.z),
            c4d.Vector(mp.x - rad.x, mp.y + rad.y, mp.z + rad.z),
            c4d.Vector(mp.x + rad.x, mp.y + rad.y, mp.z + rad.z)
        ]
        world_pts = [mg * p for p in pts]
        min_v = c4d.Vector(
            min(p.x for p in world_pts),
            min(p.y for p in world_pts),
            min(p.z for p in world_pts)
        )
        max_v = c4d.Vector(
            max(p.x for p in world_pts),
            max(p.y for p in world_pts),
            max(p.z for p in world_pts)
        )
        return min_v, max_v

    def _candidate_passes_raycast_broadphase(self, obj, obj_mg, ray_dir_world, origin_min_proj, max_distance):
        aabb = self._get_world_aabb_fast(obj, obj_mg)
        if not aabb:
            return False
        min_v, max_v = aabb
        corners = [
            c4d.Vector(min_v.x, min_v.y, min_v.z),
            c4d.Vector(max_v.x, min_v.y, min_v.z),
            c4d.Vector(min_v.x, max_v.y, min_v.z),
            c4d.Vector(max_v.x, max_v.y, min_v.z),
            c4d.Vector(min_v.x, min_v.y, max_v.z),
            c4d.Vector(max_v.x, min_v.y, max_v.z),
            c4d.Vector(min_v.x, max_v.y, max_v.z),
            c4d.Vector(max_v.x, max_v.y, max_v.z)
        ]
        projections = [p * ray_dir_world for p in corners]
        cand_min = min(projections)
        cand_max = max(projections)
        if cand_max < origin_min_proj - 0.001:
            return False
        if cand_min > origin_min_proj + max_distance:
            return False
        return True

    def _get_collision_candidates(self, root, exclude_obj):
        candidates =[]
        doc = documents.GetActiveDocument()
        exclude_ids = self._collect_object_tree_ids(exclude_obj)
        def recurse(node, parent_mg, parent_visible=True):
            while node:
                if node == exclude_obj or self._is_object_in_guid_set(node, exclude_ids):
                    node = node.GetNext()
                    continue
                if self._is_descendant_of(exclude_obj, node):
                    current_mg = parent_mg * node.GetMl()
                    recurse(node.GetDown(), current_mg, parent_visible)
                    node = node.GetNext()
                    continue

                current_mg = parent_mg * node.GetMl()
                node_visible = parent_visible
                try:
                    if node.GetEditorMode() == c4d.MODE_OFF or node.GetRenderMode() == c4d.MODE_OFF:
                        node_visible = False
                except Exception as e:
                    print("[Raycast Move] visibility check skipped: " + str(e))
                if node_visible and not self._is_layer_visible_for_raycast(node, doc):
                    node_visible = False

                if not node_visible:
                    node = node.GetNext()
                    continue

                if node.IsInstanceOf(c4d.Opolygon):
                    candidates.append((node, current_mg))
                    
                cache = node.GetCache()
                if cache: recurse(cache, current_mg, node_visible)
                deform = node.GetDeformCache()
                if deform: recurse(deform, current_mg, node_visible)
                recurse(node.GetDown(), current_mg, node_visible)
                node = node.GetNext()
        recurse(root, c4d.Matrix())
        return candidates

    def _action_raycast_move(self, axis, direction):
        if not self.core_enabled:
            gui.MessageDialog(self.core_disabled_reason or "当前未授权，无法使用核心功能。")
            return
        start_time = time.time()
        doc = documents.GetActiveDocument()
        mover = doc.GetActiveObject() 
        if not mover: 
            gui.MessageDialog("请先选中一个要移动贴合的物体！")
            return

        candidates = self._get_collision_candidates(doc.GetFirstObject(), mover)
        candidates_total = len(candidates)
        if not candidates:
            print("[Raycast Move] candidates total: 0")
            gui.MessageDialog("场景里没有找到其他模型表面可供碰撞。")
            return

        ray_origins_world = self._collect_sub_object_face_points(mover, axis, direction)
        if not ray_origins_world:
            gui.MessageDialog("选中对象没有几何体数据（包围盒为0），无法探测。")
            return
        
        mover_mg = mover.GetMg()
        rot_only_mg = c4d.Matrix(mover_mg)
        rot_only_mg.off = c4d.Vector(0)
        
        local_dir_vec = c4d.Vector(0)
        local_dir_vec[axis] = direction
        ray_dir_world = rot_only_mg * local_dir_vec
        ray_dir_world.Normalize()
        
        safety_offset = 0.5 
        ray_origins_shifted =[p + ray_dir_world * safety_offset for p in ray_origins_world]
        origin_min_proj = min(p * ray_dir_world for p in ray_origins_shifted)

        filtered_candidates = []
        for obj, obj_mg in candidates:
            if self._candidate_passes_raycast_broadphase(obj, obj_mg, ray_dir_world, origin_min_proj, RAYCAST_MAX_DISTANCE):
                filtered_candidates.append((obj, obj_mg))

        print("[Raycast Move] candidates total: " + str(candidates_total))
        print("[Raycast Move] candidates after filter: " + str(len(filtered_candidates)))
        print("[Raycast Move] ray origins: " + str(len(ray_origins_shifted)))

        min_distance = float('inf')
        hit_detected = False
        collider = utils.GeRayCollider()
        max_ray_len = RAYCAST_MAX_DISTANCE 

        for obj, obj_mg in filtered_candidates:
            if not collider.Init(obj, True): continue 
            inv_mg = ~obj_mg
            for ray_origin in ray_origins_shifted:
                local_origin_target = inv_mg * ray_origin
                local_dir_target = (inv_mg * (ray_origin + ray_dir_world * max_ray_len)) - local_origin_target
                local_dir_target.Normalize()
                
                if collider.Intersect(local_origin_target, local_dir_target, max_ray_len):
                    intersection = collider.GetNearestIntersection()
                    hit_pos_world = obj_mg * intersection['hitpos']
                    vec_to_hit = hit_pos_world - ray_origin
                    dist = vec_to_hit * ray_dir_world
                    
                    if dist < 0.001: continue 
            
                    if dist < min_distance:
                        min_distance = dist
                        hit_detected = True

        if hit_detected:
            elapsed = time.time() - start_time
            print("[Raycast Move] hit distance: " + ("%.2f" % min_distance))
            print("[Raycast Move] elapsed: " + ("%.2fs" % elapsed))
            doc.StartUndo()
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, mover)
            real_move_dist = min_distance + safety_offset
            move_vec_world = ray_dir_world * real_move_dist
            mg = mover.GetMg()
            mg.off += move_vec_world
            mover.SetMg(mg)
            doc.EndUndo()
            c4d.EventAdd()
            c4d.StatusSetText(f"✅ 多点探测贴合完成！移动距离: {real_move_dist:.2f} cm")
        else:
            elapsed = time.time() - start_time
            print("[Raycast Move] hit distance: none")
            print("[Raycast Move] elapsed: " + ("%.2fs" % elapsed))
            gui.MessageDialog("🚫 该方向没有检测到任何墙体或模型表面。")

    def _get_hierarchy_boundaries_align(self, root, ref_mg=None):
        mn = c4d.Vector(1e15); mx = c4d.Vector(-1e15)
        inv_ref = ~ref_mg if ref_mg else c4d.Matrix()
        valid = False
        stack = [root]
        while stack:
            o = stack.pop()
            rad = o.GetRad()
            if rad.GetLengthSquared() > 1e-5:
                mg = o.GetMg(); mp = o.GetMp()
                pts =[mp + c4d.Vector(rad.x*x, rad.y*y, rad.z*z) 
                       for x in (-1,1) for y in (-1,1) for z in (-1,1)]
                for p in pts:
                    world_pt = mg * p 
                    local_pt = inv_ref * world_pt if ref_mg else world_pt
                    mn = c4d.Vector(min(mn.x, local_pt.x), min(mn.y, local_pt.y), min(mn.z, local_pt.z))
                    mx = c4d.Vector(max(mx.x, local_pt.x), max(mx.y, local_pt.y), max(mx.z, local_pt.z))
                valid = True
            children = o.GetChildren()
            if children: stack.extend(children)
            cache = o.GetCache()
            if cache: stack.append(cache)
            deform = o.GetDeformCache()
            if deform: stack.append(deform)

        if not valid:
            pos = root.GetMg().off
            if ref_mg: pos = inv_ref * pos
            return pos, pos, pos
        return mn, mx, (mn+mx)*0.5

    def _action_align_multi(self, x, y, z, surf):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_SELECTIONORDER)
        if len(sel) < 2:
            gui.MessageDialog("请先选中多个物体！\n注意：最后一个选中的将作为参考目标。")
            return

        doc.StartUndo()
        mst = sel[-1]
        sel.pop() 
        
        ref_mg = mst.GetMg()
        m_mn, m_mx, m_cn = self._get_hierarchy_boundaries_align(mst, ref_mg)
            
        for o in sel:
            doc.AddUndo(c4d.UNDOTYPE_CHANGE, o)
            o_mn, o_mx, o_cn = self._get_hierarchy_boundaries_align(o, ref_mg)
            shift = c4d.Vector(0)
            def calc(m, omn, omx, ocn, mmn, mmx, mcn):
                tar = 0.0; cur = 0.0
                if m == 0: tar = mcn
                else: tar = mmn if m == -1 else mmx
                
                if m == 0: cur = ocn
                else: cur = omn if m == -1 else omx 
                
                if surf and m != 0: cur = omx if m == -1 else omn
                return tar - cur

            if x is not None: shift.x = calc(x, o_mn.x, o_mx.x, o_cn.x, m_mn.x, m_mx.x, m_cn.x)
            if y is not None: shift.y = calc(y, o_mn.y, o_mx.y, o_cn.y, m_mn.y, m_mx.y, m_cn.y)
            if z is not None: shift.z = calc(z, o_mn.z, o_mx.z, o_cn.z, m_mn.z, m_mx.z, m_cn.z)
            
            rot_mg = c4d.Matrix(ref_mg)
            rot_mg.off = c4d.Vector(0)
            shift_world = rot_mg * shift
            mg = o.GetMg(); mg.off += shift_world
            o.SetMg(mg)
            
        doc.EndUndo()
        c4d.EventAdd()
        c4d.StatusSetText("✅ 多对象九宫格对齐完成。")

    # =========================================================================
    # 其它工具方法
    # =========================================================================
    def _apply_texture_manual(self):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        targets = self._collect_valid_objects(sel)
        if not targets:
            gui.MessageDialog("请先选择要贴图的对象。")
            return
        
        selection_string = "C1" if self._cap_mode == 1 else "C2"

        tex_path = storage.LoadDialog(type=c4d.FILESELECTTYPE_IMAGES, title="请选择贴图文件", flags=c4d.FILESELECT_LOAD)
        if not tex_path: return
        doc.StartUndo()
        count = 0
        for obj in targets:
            existing_tag = None
            existing_mat = None
            for t in obj.GetTags():
                if t.CheckType(c4d.Ttexture):
                    mat = t.GetMaterial()
                    if mat and mat[c4d.MATERIAL_USE_COLOR]:
                        shader = mat[c4d.MATERIAL_COLOR_SHADER]
                        if shader and (shader.CheckType(c4d.Xbitmap) or shader.CheckType(c4d.Xlayer)):
                            existing_tag = t
                            existing_mat = mat
                            break
            if existing_mat:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, existing_mat)
                existing_mat.SetName("Mat_" + os.path.splitext(os.path.basename(tex_path))[0])
                sh = existing_mat[c4d.MATERIAL_COLOR_SHADER]
                sh[c4d.BITMAPSHADER_FILENAME] = tex_path
                if tex_path.lower().endswith(".png"):
                    existing_mat[c4d.MATERIAL_USE_ALPHA] = True
                    ash = existing_mat[c4d.MATERIAL_ALPHA_SHADER]
                    if not ash or not ash.CheckType(c4d.Xbitmap):
                        ash = c4d.BaseShader(c4d.Xbitmap)
                        existing_mat.InsertShader(ash)
                    existing_mat[c4d.MATERIAL_ALPHA_SHADER] = ash
                    ash[c4d.BITMAPSHADER_FILENAME] = tex_path
                else:
                    if existing_mat[c4d.MATERIAL_USE_ALPHA]: existing_mat[c4d.MATERIAL_USE_ALPHA] = False
                existing_mat.Message(c4d.MSG_UPDATE)
            else:
                mat_name = "Mat_" + os.path.splitext(os.path.basename(tex_path))[0]
                mat = doc.SearchMaterial(mat_name)
                if not mat:
                    mat = c4d.BaseMaterial(c4d.Mmaterial)
                    mat.SetName(mat_name)
                    doc.InsertMaterial(mat)
                    doc.AddUndo(c4d.UNDOTYPE_NEW, mat)
                    bitmap = c4d.BaseShader(c4d.Xbitmap)
                    bitmap[c4d.BITMAPSHADER_FILENAME] = tex_path
                    mat.InsertShader(bitmap)
                    mat[c4d.MATERIAL_USE_COLOR] = True
                    mat[c4d.MATERIAL_COLOR_SHADER] = bitmap
                    mat[c4d.MATERIAL_USE_ALPHA] = False
                    if tex_path.lower().endswith(".png"):
                        mat[c4d.MATERIAL_USE_ALPHA] = True
                        bitmap_alpha = c4d.BaseShader(c4d.Xbitmap)
                        bitmap_alpha[c4d.BITMAPSHADER_FILENAME] = tex_path
                        mat.InsertShader(bitmap_alpha)
                        mat[c4d.MATERIAL_ALPHA_SHADER] = bitmap_alpha
                    mat.Message(c4d.MSG_UPDATE)
                last_tag = obj.GetLastTag()
                tex_tag = obj.MakeTag(c4d.Ttexture, pred=last_tag)
                doc.AddUndo(c4d.UNDOTYPE_NEW, tex_tag)
                tex_tag.SetMaterial(mat)
                tex_tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_CUBIC
                tex_tag[c4d.TEXTURETAG_TILE] = False
                try:
                    if obj.GetType() == C4D_EXTRUDE_TYPEID:
                        tex_tag[c4d.TEXTURETAG_RESTRICTION] = selection_string
                except: pass
                doc.SetActiveTag(tex_tag)
                c4d.CallCommand(12132) 
            count += 1
        doc.EndUndo()
        c4d.EventAdd()
        c4d.StatusSetText(f"已处理 {count} 个对象。")

    def _bake_uvw_for_selection(self):
        doc = documents.GetActiveDocument()
        doc.SetMode(c4d.Mmodel)
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        targets = self._collect_valid_objects(sel)
        if not targets:
            gui.MessageDialog("未找到可处理的对象。")
            return
        doc.StartUndo()
        for obj in targets:
            doc.SetActiveObject(obj)
            c4d.EventAdd() 
            if obj.GetType() == C4D_EXTRUDE_TYPEID:
                c4d.CallCommand(12236) 
                c4d.EventAdd()
                c4d.CallCommand(16768) 
                c4d.EventAdd()
        
            obj = doc.GetActiveObject()
            if not obj or not obj.CheckType(c4d.Opolygon): continue
            all_tags = obj.GetTags()
            tex_tags =[t for t in all_tags if t.CheckType(c4d.Ttexture)]
            mat_groups = {}
            tags_to_remove =[]
            for t in tex_tags:
                mat = t.GetMaterial()
                if not mat: continue
                m_name = mat.GetName()
                if m_name not in mat_groups:
                    mat_groups[m_name] = { "global": None, "restricted":[], "seen_res": set() }
                group = mat_groups[m_name]
                res = t[c4d.TEXTURETAG_RESTRICTION]
                if not res or res == "":
                    if group["global"] is None: group["global"] = t
                    else: tags_to_remove.append(t)
                else:
                    if res in group["seen_res"]: tags_to_remove.append(t)
                    else:
                        group["seen_res"].add(res)
                        group["restricted"].append(t)
            for m_name, group in mat_groups.items():
                if group["global"]:
                    for t in group["restricted"]: tags_to_remove.append(t)
            for t in tags_to_remove:
                t.Remove()
                doc.AddUndo(c4d.UNDOTYPE_DELETE, t)
            tags_now = obj.GetTags()
            for t in tags_now:
                if t.CheckType(c4d.Ttexture):
                    mat = t.GetMaterial()
                    has_bitmap = False
                    if mat:
                        shader = mat[c4d.MATERIAL_COLOR_SHADER]
                        if shader: has_bitmap = True
                    if has_bitmap:
                        t.Remove()
                        last = obj.GetLastTag()
                        obj.InsertTag(t, last) 
            for t in reversed(obj.GetTags()): 
                if t.CheckType(c4d.Tuvw): t.Remove()
            target_tag = None
            tags_final = obj.GetTags()
            for t in reversed(tags_final):
                if t.CheckType(c4d.Ttexture):
                    target_tag = t
                    break
            if target_tag:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, target_tag)
                target_tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_CUBIC
                target_tag[c4d.TEXTURETAG_OFFSETX] = 0.0
                target_tag[c4d.TEXTURETAG_OFFSETY] = 0.0
                target_tag[c4d.TEXTURETAG_LENGTHX] = 1.0
                target_tag[c4d.TEXTURETAG_LENGTHY] = 1.0
                target_tag[c4d.TEXTURETAG_TILE] = True
                doc.SetActiveObject(obj, mode=c4d.SELECTION_NEW)
                doc.SetActiveTag(target_tag, mode=c4d.SELECTION_NEW)
                c4d.EventAdd()
                c4d.CallCommand(12235) 
            obj.Message(c4d.MSG_UPDATE)
        doc.EndUndo()
        c4d.EventAdd()
        c4d.StatusSetText("烘焙完成！UVW 已强制生成。")

    def _action_run_acrylic_generate(self):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        targets = self._collect_valid_objects(sel)
        if not targets:
            gui.MessageDialog("请选中要处理的样条或挤压对象。")
            return
        depth = self.GetFloat(ID_ACRY_DEPTH_INPUT)
        direction_mode = self.GetInt32(ID_ACRY_DEPTH_DIR) 
        target_depth = depth if direction_mode == 0 else -depth
        side_cfg = {
            "dt": self.GetBool(ID_ACRY_CHK_T), "db": self.GetBool(ID_ACRY_CHK_B),
            "dl": self.GetBool(ID_ACRY_CHK_L), "dr": self.GetBool(ID_ACRY_CHK_R),
            "skip": False
        }
        if not (side_cfg["dt"] or side_cfg["db"] or side_cfg["dl"] or side_cfg["dr"]): side_cfg["skip"] = True
        shell = self.GetFloat(ID_ACRY_SHELL_INPUT)
        for obj in targets:
            if obj.CheckType(c4d.Ospline):
                RunGenerate(target_depth, side_cfg, shell)
            elif obj.CheckType(c4d.Oextrude) or obj.GetType() == C4D_EXTRUDE_TYPEID:
                child = obj.GetDown()
                if child and child.CheckType(c4d.Ospline):
                    doc.SetActiveObject(child)
                    RunGenerate(target_depth, side_cfg, shell)

    def _update_selected_spline_tension(self, tension):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel: return
        updated = False
        for obj in sel:
            bc = obj.GetDataInstance()
            json_str = bc.GetString(ID_STORED_JSON_DATA)
            scale = bc.GetFloat(ID_STORED_SCALE_VAL)
            if not json_str or not obj.CheckType(c4d.Ospline): continue
            try:
                segments = json.loads(json_str)
                factor = AI_PT_TO_CM * scale
                total_pts_json = sum(len(seg) for seg in segments)
                if obj.GetPointCount() != total_pts_json: continue
                global_pt_idx = 0
                for seg in segments:
                    for p in seg:
                        x, y = 0, 0
                        inx, iny = 0, 0
                        outx, outy = 0, 0
                        if isinstance(p, dict):
                            x, y = p["a"]
                            inx, iny = p["in"]
                            outx, outy = p["out"]
                        elif isinstance(p, list): continue 
                        wx, wy = x * factor, -y * factor
                        p_abs = c4d.Vector(wx, wy, 0)
                        v_in_abs = c4d.Vector(inx*factor, -iny*factor, 0)
                        v_out_abs = c4d.Vector(outx*factor, -outy*factor, 0)
                        base_tan_in = v_in_abs - p_abs
                        base_tan_out = v_out_abs - p_abs
                        new_tan_in = base_tan_in * tension
                        new_tan_out = base_tan_out * tension
                        obj.SetTangent(global_pt_idx, new_tan_in, new_tan_out)
                        global_pt_idx += 1
                obj.Message(c4d.MSG_UPDATE)
                updated = True
            except: pass
        if updated: c4d.EventAdd()

    # ==============================================================================
    # 核心：导入与生成
    # ==============================================================================
    def _create_extrude_object(self, depth, name="Extrude", bevel=False, radius=1.0):
        ex = c4d.BaseObject(c4d.Oextrude)
        ex.SetName(name)
        if hasattr(c4d, "EXTRUDEOBJECT_DIRECTION"): ex[c4d.EXTRUDEOBJECT_DIRECTION] = 3 
        ex[c4d.EXTRUDEOBJECT_MOVE] = c4d.Vector(0, 0, -abs(float(depth)))
        try: ex[C4D_EXTRUDE_OFFSET_ID] = -abs(float(depth))
        except: pass
        try: ex[c4d.EXTRUDEOBJECT_CAP_TYPE] = 2 
        except: pass
        return ex

    def CreateTextureMaterial(self, doc, uid, path):
        n = "Mat_Tex_" + uid
        m = doc.SearchMaterial(n)
        if m: return m
        m = c4d.BaseMaterial(c4d.Mmaterial)
        m.SetName(n)
        m[c4d.MATERIAL_USE_REFLECTION] = True
        m[c4d.MATERIAL_USE_COLOR] = True
        s = c4d.BaseShader(c4d.Xbitmap)
        s[c4d.BITMAPSHADER_FILENAME] = path
        m.InsertShader(s)
        m[c4d.MATERIAL_COLOR_SHADER] = s
        if path.lower().endswith(".png"):
            m[c4d.MATERIAL_USE_ALPHA] = True
            ash = c4d.BaseShader(c4d.Xbitmap)
            ash[c4d.BITMAPSHADER_FILENAME] = path
            m.InsertShader(ash)
            m[c4d.MATERIAL_ALPHA_SHADER] = ash
        doc.InsertMaterial(m)
        doc.AddUndo(c4d.UNDOTYPE_NEW, m)
        return m

    def CreateColorMaterial(self, doc, r, g, b, apply_gamma=False):
        v_r = r / 255.0; v_g = g / 255.0; v_b = b / 255.0
        if apply_gamma:
            v_r = pow(v_r, 2.2); v_g = pow(v_g, 2.2); v_b = pow(v_b, 2.2)
        n = f"Mat_RGB_{int(r)}_{int(g)}_{int(b)}"
        m = doc.SearchMaterial(n)
        if m: return m
        m = c4d.BaseMaterial(c4d.Mmaterial)
        m.SetName(n)
        m[c4d.MATERIAL_USE_REFLECTION] = True
        m[c4d.MATERIAL_USE_COLOR] = True
        m[c4d.MATERIAL_COLOR_COLOR] = c4d.Vector(v_r, v_g, v_b)
        doc.InsertMaterial(m)
        doc.AddUndo(c4d.UNDOTYPE_NEW, m)
        return m

    def _create_spline_from_segments(self, segments, name, scale, auto_close, tension):
        if not segments: return None
        total_points = sum(len(seg) for seg in segments)
        segment_count = len(segments)
        if total_points == 0: return None

        sp = c4d.SplineObject(total_points, c4d.SPLINETYPE_BEZIER)
        sp.ResizeObject(total_points, segment_count) 
        sp[c4d.SPLINEOBJECT_CLOSED] = auto_close
        factor = AI_PT_TO_CM * scale
        
        min_x = min_y = float('inf')
        max_x = max_y = float('-inf')
        
        for seg in segments:
            for p in seg:
                wx, wy = p["a"][0] * factor, -p["a"][1] * factor
                if wx < min_x: min_x = wx
                if wx > max_x: max_x = wx
                if wy < min_y: min_y = wy
                if wy > max_y: max_y = wy
        
        center = c4d.Vector((min_x + max_x)*0.5, (min_y + max_y)*0.5, 0)
        has_curve = False
        global_pt_idx = 0
        
        for i, seg in enumerate(segments):
            sp.SetSegment(i, len(seg), auto_close)
            for p in seg:
                wx, wy = p["a"][0] * factor, -p["a"][1] * factor
                world_pos = c4d.Vector(wx, wy, 0)
                sp.SetPoint(global_pt_idx, world_pos - center)
                
                inx, iny = p.get("in", [p["a"][0], p["a"][1]]) 
                outx, outy = p.get("out", [p["a"][0], p["a"][1]])
                if isinstance(inx, list): inx, iny = inx[0], inx[1]
                if isinstance(outx, list): outx, outy = outx[0], outx[1]

                v_in_abs = c4d.Vector(inx*factor, -iny*factor, 0)
                v_out_abs = c4d.Vector(outx*factor, -outy*factor, 0)
                
                tan_in = (v_in_abs - world_pos) * tension
                tan_out = (v_out_abs - world_pos) * tension
                sp.SetTangent(global_pt_idx, tan_in, tan_out)
                
                if not has_curve and (tan_in.GetLengthSquared() > 1e-5 or tan_out.GetLengthSquared() > 1e-5):
                    has_curve = True
                global_pt_idx += 1
                
        sp[c4d.SPLINEOBJECT_INTERPOLATION] = c4d.SPLINEOBJECT_INTERPOLATION_ADAPTIVE
        sp[c4d.SPLINEOBJECT_ANGLE] = c4d.utils.Rad(5.0)

        sp.SetAbsPos(center)
        sp.SetName(name)
        
        try:
            json_str = json.dumps(segments)
            bc = sp.GetDataInstance()
            bc.SetString(ID_STORED_JSON_DATA, json_str)
            bc.SetFloat(ID_STORED_SCALE_VAL, float(scale))
        except: pass
        return sp

    def _parse_json(self, filepath):
        try:
            self.SetLoadProgress(10, "正在读取文件...")
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.SetLoadProgress(25, "正在解析数据...")
        except:
            self.FailLoadProgress("文件格式错误")
            return []
        items = data.get("items", [])
        res =[]
        total_items = len(items)
        refresh_step = max(1, total_items // 20) if total_items else 1
        for idx, it in enumerate(items):
            segments_data = []
            raw_segs = it.get("segments",[])
            is_single = False
            if raw_segs and len(raw_segs) > 0:
                first = raw_segs[0]
                if isinstance(first, dict): is_single = True
                elif isinstance(first, list):
                    if len(first) > 0 and isinstance(first[0], (int, float)): is_single = True
            if is_single: raw_segs = [raw_segs]

            for seg in raw_segs:
                processed_seg =[]
                for p in seg:
                    if isinstance(p, dict):
                        ax, ay = p.get("a", (0,0))
                        ix, iy = p.get("inT", (ax, ay)) 
                        ox, oy = p.get("outT", (ax, ay))
                        processed_seg.append({"a": (float(ax), float(ay)), "in": (float(ix), float(iy)), "out": (float(ox), float(oy))})
                    elif isinstance(p, list) and len(p) >= 2:
                         x, y = float(p[0]), float(p[1])
                         processed_seg.append({"a": (x, y), "in": (x, y), "out": (x, y)})
                if processed_seg: segments_data.append(processed_seg)
            if segments_data:
                res.append({
                    "name": it.get("name") or "Obj", "layer": it.get("layer") or "Default",
                    "group": it.get("group") or "", "compound": it.get("compound") or "",
                    "closed": bool(it.get("closed", True)), "segments": segments_data, 
                    "color": it.get("color", None),
                    "craftType": it.get("craftType", "none"),
                    "craftParams": it.get("craftParams", {})
                })
            if total_items and (idx % refresh_step == 0 or idx == total_items - 1):
                parse_percent = 25 + int(((idx + 1) / float(total_items)) * 20)
                self.SetLoadProgress(parse_percent, "正在解析数据...")
        return res

    def _get_or_create_layer_null(self, doc, layer_name, parent=None):
        if not layer_name: layer_name = "Default"
        name = LAYER_NULL_PREFIX + layer_name
        if parent:
            child = parent.GetDown()
            while child:
                if child.CheckType(c4d.Onull) and child.GetName() == name: return child
                child = child.GetNext()
        else:
            top = doc.GetFirstObject()
            while top:
                if top.CheckType(c4d.Onull) and top.GetName() == name: return top
                top = top.GetNext()
        null = c4d.BaseObject(c4d.Onull)
        null.SetName(name)
        if parent: null.InsertUnder(parent)
        else: doc.InsertObject(null)
        return null

    def _get_or_create_group_chain(self, doc, parent_obj, group_path):
        if not group_path: return parent_obj
        parts = group_path.split("/")
        current_parent = parent_obj
        for part in parts:
            if not part.strip(): continue
            group_name = GROUP_NULL_PREFIX + part
            found = None
            child = current_parent.GetDown()
            while child:
                if child.CheckType(c4d.Onull) and child.GetName() == group_name: 
                    found = child; break
                child = child.GetNext()
            if not found:
                new_group = c4d.BaseObject(c4d.Onull)
                new_group.SetName(group_name)
                new_group.InsertUnder(current_parent)
                current_parent = new_group
            else: current_parent = found
        return current_parent

    def _auto_craft_log(self, message):
        try:
            print("[Auto Craft] " + str(message))
        except Exception:
            pass

    def _extract_craft_info(self, item):
        if not isinstance(item, dict):
            return "none", {}
        craft_type = str(item.get("craftType") or "none").strip().lower()
        if not craft_type:
            craft_type = "none"
        craft_params = item.get("craftParams") or {}
        if not isinstance(craft_params, dict):
            craft_params = {}
        return craft_type, craft_params

    def _queue_auto_craft(self, pending_crafts, created_obj, item):
        craft_type, craft_params = self._extract_craft_info(item)
        if craft_type == "none":
            return
        if not created_obj:
            self._auto_craft_log("跳过无对象工艺: " + str(craft_type))
            return
        pending_crafts.append({
            "obj": created_obj,
            "craftType": craft_type,
            "craftParams": craft_params,
            "sourceName": item.get("name") or created_obj.GetName()
        })

    def _restore_selection(self, doc, selected_objects, active_obj):
        try:
            c4d.CallCommand(12113)
            if active_obj and active_obj.IsAlive():
                doc.SetActiveObject(active_obj, c4d.SELECTION_NEW)
                first_done = True
            else:
                first_done = False
            for obj in selected_objects or []:
                if obj and obj.IsAlive() and obj != active_obj:
                    mode = c4d.SELECTION_ADD if first_done else c4d.SELECTION_NEW
                    doc.SetActiveObject(obj, mode)
                    first_done = True
        except Exception as e:
            self._auto_craft_log("恢复选择失败: " + str(e))

    def _process_pending_crafts(self, pending_crafts):
        if not pending_crafts:
            return 0
        processed = 0
        for info in pending_crafts:
            obj = info.get("obj")
            craft_type = info.get("craftType")
            craft_params = info.get("craftParams") or {}
            source_name = info.get("sourceName") or ""
            if not obj or not obj.IsAlive():
                self._auto_craft_log("对象已失效，跳过: " + str(source_name))
                continue
            try:
                if self._apply_auto_craft(obj, craft_type, craft_params):
                    processed += 1
            except Exception as e:
                self._auto_craft_log("工艺处理失败 " + str(source_name) + " / " + str(craft_type) + ": " + str(e))
                traceback.print_exc()
        return processed

    def _apply_auto_craft(self, obj, craft_type, craft_params):
        if craft_type == "acrylic_slot":
            return self._apply_acrylic_slot_auto(obj, craft_params)
        if craft_type in ("sign_backlit", "sign_frontlit", "sign_crystal", "sign_dual_lit"):
            return self._apply_sign_craft_auto(obj, craft_type, craft_params)
        self._auto_craft_log("未知 craftType，已跳过: " + str(craft_type))
        return False

    def _float_param(self, params, key, default_value):
        try:
            value = params.get(key, default_value)
            if value is None or value == "":
                return float(default_value)
            return float(value)
        except Exception:
            return float(default_value)

    def _parse_hex_color(self, hex_string):
        if not hex_string:
            return None
        try:
            text = str(hex_string).strip()
            if text.startswith("#"):
                text = text[1:]
            if len(text) == 3:
                text = "".join([ch + ch for ch in text])
            if len(text) != 6:
                return None
            r = int(text[0:2], 16) / 255.0
            g = int(text[2:4], 16) / 255.0
            b = int(text[4:6], 16) / 255.0
            return c4d.Vector(r, g, b)
        except Exception:
            return None

    def _apply_acrylic_slot_auto(self, obj, params):
        doc = c4d.documents.GetActiveDocument()
        if not doc or not obj or not obj.IsAlive():
            return False
        selected = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
        active = doc.GetActiveObject()
        depth = self._float_param(params, "depthCm", 0.3)
        direction = str(params.get("direction", "Z+") or "Z+").upper().replace(" ", "")
        target_depth = -abs(depth) if direction == "Z-" else abs(depth)
        delete_sides = params.get("deleteSides", ["top"])
        if isinstance(delete_sides, str):
            delete_sides = [delete_sides]
        delete_sides = [str(v).strip().lower() for v in (delete_sides or [])]
        side_cfg = {
            "dt": "top" in delete_sides,
            "db": "bottom" in delete_sides,
            "dl": "left" in delete_sides,
            "dr": "right" in delete_sides,
            "skip": False
        }
        if not (side_cfg["dt"] or side_cfg["db"] or side_cfg["dl"] or side_cfg["dr"]):
            side_cfg["skip"] = True
        shell = self._float_param(params, "shellCm", 0.3)
        old_name = obj.GetName()
        self._auto_craft_log("生成亚克力插槽: " + old_name)
        try:
            c4d.CallCommand(12113)
            doc.SetActiveObject(obj, c4d.SELECTION_NEW)
            RunGenerate(target_depth, side_cfg, shell)
            generated = doc.GetActiveObject()
            if generated and generated.IsAlive():
                generated.SetName(old_name + "_亚克力插槽")
            return True
        finally:
            self._restore_selection(doc, selected, active)

    def _apply_sign_craft_auto(self, obj, craft_type, params):
        doc = c4d.documents.GetActiveDocument()
        if not doc or not obj or not obj.IsAlive():
            return False
        defaults = {
            "sign_backlit": (30.0, 10.0, "背发光", Gen_Backlit),
            "sign_frontlit": (5.0, 30.0, "正发光", Gen_Frontlit),
            "sign_crystal": (3.0, 10.0, "水晶字", Gen_Crystal),
            "sign_dual_lit": (5.0, 30.0, "正背发", Gen_DualLit)
        }
        if craft_type not in defaults:
            return False
        default_front_mm, default_back_mm, suffix, generator = defaults[craft_type]
        front_mm = self._float_param(params, "frontThicknessMm", default_front_mm)
        back_mm = self._float_param(params, "backThicknessMm", default_back_mm)
        if front_mm <= 0.001:
            front_mm = default_front_mm
        if back_mm <= 0.001:
            back_mm = default_back_mm
        front_cm = front_mm / 10.0
        back_cm = back_mm / 10.0
        color = self._parse_hex_color(params.get("color"))
        if color is None:
            color = Signage_GetObjColor(obj, c4d.Vector(1, 1, 1))
        selected = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
        active = doc.GetActiveObject()
        old_name = obj.GetName()
        self._auto_craft_log("生成广告字工艺: " + old_name + " -> " + suffix)
        try:
            c4d.CallCommand(12113)
            doc.SetActiveObject(obj, c4d.SELECTION_NEW)
            targets = Signage_GetTargets(doc)
            if not targets:
                self._auto_craft_log("未找到可用于广告字工艺的样条: " + old_name)
                return False
            doc.StartUndo()
            generator(doc, targets, front_cm, back_cm, color)
            doc.EndUndo()
            generated = doc.GetActiveObject()
            if generated and generated.IsAlive():
                generated.SetName(old_name + "_" + suffix)
            c4d.EventAdd()
            return True
        except Exception:
            try:
                doc.EndUndo()
            except Exception:
                pass
            raise
        finally:
            self._restore_selection(doc, selected, active)

    def _do_import(self, is_hot_replace=False, file_path_override=None):
        try:
            if not self._admin_ensure_fresh_license():
                msg = self.core_disabled_reason or "当前未授权，无法使用核心功能。"
                self.FailLoadProgress(msg)
                gui.MessageDialog(msg)
                return True
            self.ResetLoadProgress()
            doc = documents.GetActiveDocument()
            old_op = None
            
            if file_path_override:
                file_path = file_path_override
            # 如果是点击了替换按钮，走临时缓存，并强制关闭导入到新文件
            elif is_hot_replace:
                old_op = doc.GetActiveObject()
                if not old_op:
                    self.FailLoadProgress("未选择要替换的旧模型")
                    gui.MessageDialog("请先在 C4D 中选中你要替换的旧模型！")
                    return True
                file_path = os.path.join(tempfile.gettempdir(), "hh_c4d_hot_update.json")
                if not os.path.exists(file_path):
                    self.FailLoadProgress("找不到热更缓存数据")
                    gui.MessageDialog("找不到缓存数据！请先在 AI 中点击【⚡ 发送更新 (热更)】。")
                    return True
                self.SetBool(ID_IMPORT_TO_NEW_DOC, False) 
            else:
                # 如果是正常点击导入按钮，依然弹窗让用户选
                file_path = storage.LoadDialog(title="选择 AI 导出的 JSON 文件")
                if not file_path:
                    self.ResetLoadProgress()
                    return True
                
            ratio = self.GetInt32(ID_RATIO_COMBO)
            scale = float(ratio) if ratio > 0 else 1.0
            tension = self.GetFloat(ID_TENSION_VAL)
            ui_auto_extrude = self.GetBool(ID_EXTRUDE_ENABLE)
            ui_depth = -abs(self.GetFloat(ID_EXTRUDE_DEPTH))
            use_groups = self.GetBool(ID_KEEP_LAYER)
            import_color = self.GetBool(ID_IMPORT_COLOR)
            auto_close = self.GetBool(ID_AUTO_CLOSE)
            import_to_new = self.GetBool(ID_IMPORT_TO_NEW_DOC)
            do_smart_stack = self.GetBool(ID_SMART_STACK)
            apply_gamma = self.GetBool(ID_GAMMA_CORRECT)

            path_data = self._parse_json(file_path)
            if not path_data:
                self.FailLoadProgress("文件格式错误或无可导入数据")
                return True
            self.SetLoadProgress(45, "数据解析完成，开始创建对象...")

            if import_to_new:
                doc = c4d.documents.BaseDocument()
                c4d.documents.InsertBaseDocument(doc)
                c4d.documents.SetActiveDocument(doc)
            else: doc = documents.GetActiveDocument()

            doc.StartUndo()
            file_name = os.path.splitext(os.path.basename(file_path))[0]
            main_container = c4d.BaseObject(c4d.Onull)
            main_container.SetName(f"Import_{file_name}")
            doc.InsertObject(main_container)
            doc.AddUndo(c4d.UNDOTYPE_NEW, main_container)

            created_cnt = 0
            for idx, item in enumerate(path_data): item['_original_index'] = idx

            merged_db = {}; standalone_items =[]
            for item in path_data:
                g_name = item.get("group", "")
                c_key = (255, 255, 255) 
                if item.get("color"):
                    c_data = item["color"]
                    if isinstance(c_data, dict):
                        r = int(c_data.get('r', 0)); g = int(c_data.get('g', 0)); b = int(c_data.get('b', 0))
                        c_key = (255, 255, 255) if (r==51 and g==51 and b==51) else (r, g, b)
                    elif isinstance(c_data, list) and len(c_data)>=3:
                        r = int(c_data[0]); g = int(c_data[1]); b = int(c_data[2])
                        c_key = (255, 255, 255) if (r==51 and g==51 and b==51) else (r, g, b)
                
                d_val = 0
                match = re.search(r"_d(\d+)", item.get("name",""), re.IGNORECASE)
                if match: d_val = int(match.group(1))

                if g_name and g_name.strip():
                    full_key = (g_name, c_key, d_val)
                    if full_key not in merged_db: merged_db[full_key] = []
                    merged_db[full_key].append(item)
                else: standalone_items.append(item)

            all_groups = list(merged_db.values())
            for item in standalone_items: all_groups.append([item])
            all_groups.sort(key=lambda g: g[0]['_original_index'], reverse=True)
            
            placed_cache = []; fit_targets =[]
            pending_crafts = []
            total_groups = len(all_groups)
            refresh_step = max(1, total_groups // 25) if total_groups else 1

            for group_index, group_items in enumerate(all_groups):
                sp = None
                main_item = group_items[0]
                d_val_override = 0.0
                match = re.search(r"_d(\d+)", main_item["name"], re.IGNORECASE)
                if match: d_val_override = float(match.group(1)) / 10.0 

                all_segs =[]
                for it in group_items: all_segs.extend(it["segments"])
                
                sp = self._create_spline_from_segments(all_segs, main_item["name"], scale, auto_close, tension)
                if not sp: continue
                CenterAxis(sp)
                final_obj = sp
                
                color_vec = None
                raw_r, raw_g, raw_b = 255, 255, 255
                if import_color:
                    if main_item.get("color"):
                        c_data = main_item["color"]
                        if isinstance(c_data, dict):
                            raw_r = float(c_data.get('r', 0)); raw_g = float(c_data.get('g', 0)); raw_b = float(c_data.get('b', 0))
                        elif isinstance(c_data, list) and len(c_data) >= 3:
                             raw_r = float(c_data[0]); raw_g = float(c_data[1]); raw_b = float(c_data[2])
                        is_mask_grey = (50 < raw_r < 52 and 50 < raw_g < 52 and 50 < raw_b < 52)
                        if is_mask_grey: color_vec = c4d.Vector(1.0, 1.0, 1.0)
                        else:
                            v_r = raw_r / 255.0; v_g = raw_g / 255.0; v_b = raw_b / 255.0
                            if apply_gamma: v_r = pow(v_r, 2.2); v_g = pow(v_g, 2.2); v_b = pow(v_b, 2.2)
                            color_vec = c4d.Vector(v_r, v_g, v_b)
                    else: color_vec = c4d.Vector(1.0, 1.0, 1.0)

                tex_tag_to_fit = None 
                json_dir = os.path.dirname(file_path)
                search_dirs =[json_dir, os.path.join(json_dir, "tex")]
                clean_name = re.sub(r"_d\d+", "", main_item["name"], flags=re.IGNORECASE).strip("_")
                raw_name = main_item["name"]
                possible_names =[]
                if clean_name: possible_names.append(clean_name)
                if raw_name and raw_name != clean_name: possible_names.append(raw_name)

                supported_exts =[".jpg", ".png", ".jpeg", ".tif", ".psd"]
                found_tex_path = None
                
                # ===== 新增：读取 AI 传来的标记，如果没有贴图，彻底跳过查找 =====
                has_tex_flag = main_item.get("hasTexture", True)
                if has_tex_flag:
                    for d in search_dirs:
                        if found_tex_path: break
                        if not os.path.exists(d): continue
                        for fname in possible_names:
                            for ext in supported_exts:
                                try_path = os.path.join(d, fname + ext)
                                if os.path.exists(try_path): found_tex_path = try_path; break
                                if not found_tex_path:
                                    try:
                                        dir_files = os.listdir(d)
                                        target_lower = (fname + ext).lower()
                                        for existing_f in dir_files:
                                            if existing_f.lower() == target_lower:
                                                found_tex_path = os.path.join(d, existing_f); break
                                    except: pass
                            if found_tex_path: break
                # =======================================================

                if color_vec:
                    mat_base = self.CreateColorMaterial(doc, raw_r, raw_g, raw_b, apply_gamma)
                    if mat_base:
                        tag_base = sp.MakeTag(c4d.Ttexture)
                        tag_base.SetMaterial(mat_base)
                        tag_base[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_UVW 

                if found_tex_path:
                    base_uid = os.path.splitext(os.path.basename(found_tex_path))[0]
                    mat = self.CreateTextureMaterial(doc, base_uid, found_tex_path)
                    last_tag = sp.GetLastTag()
                    tag = sp.MakeTag(c4d.Ttexture, pred=last_tag)
                    tag.SetMaterial(mat)
                    tag[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_CUBIC
                    tag[c4d.TEXTURETAG_TILE] = False
                    tag[c4d.TEXTURETAG_MIX] = False 
                    tex_tag_to_fit = tag
                
                sp[c4d.ID_BASEOBJECT_USECOLOR] = 0 
                if not found_tex_path and color_vec: sp.GetDataInstance().SetVector(AI_COLOR_DATA_ID, color_vec)

                current_depth = 0.0
                if d_val_override > 0.001: current_depth = -d_val_override
                elif ui_auto_extrude: current_depth = ui_depth 

                if abs(current_depth) > 0.001:
                    center, _, _ = self._get_real_world_bounds(sp)
                    new_mg = sp.GetMg(); new_mg.off = center
                    all_pts = sp.GetAllPoints()
                    inv_new_mg = ~new_mg
                    sp.SetAllPoints([inv_new_mg * (sp.GetMg() * p) for p in all_pts])
                    sp.SetMg(new_mg)
                
                    ex_name = sp.GetName().replace(SPLINE_NAME_PREFIX, EXTRUDE_NAME_PREFIX)
                    ex = self._create_extrude_object(current_depth, ex_name)
                    ex.SetMg(sp.GetMg())
                    sp.InsertUnder(ex)
                    sp.SetMl(c4d.Matrix()) 
                    
                    tags = sp.GetTags()
                    for t in tags:
                        if t.CheckType(c4d.Ttexture):
                            sp_mat = t.GetMaterial()
                            is_bitmap = False
                            if sp_mat and sp_mat[c4d.MATERIAL_COLOR_SHADER]: is_bitmap = True
                            t_clone = t.GetClone()
                            last_tag = ex.GetLastTag()
                            ex.InsertTag(t_clone, pred=last_tag)
                            if t == tex_tag_to_fit: tex_tag_to_fit = t_clone
                            t.Remove()
                            if is_bitmap: t_clone[c4d.TEXTURETAG_RESTRICTION] = "C2"
                            
                    final_obj = ex
                    if color_vec: 
                        ex[c4d.ID_BASEOBJECT_USECOLOR] = 0
                        ex.GetDataInstance().SetVector(AI_COLOR_DATA_ID, color_vec)

                if do_smart_stack:
                    spline_ref = sp
                    deepest_hit_z = 0.0
                    has_hit = False
                    for cache in placed_cache:
                        if CheckSplineOverlapHybrid(spline_ref, cache['spline']):
                            has_hit = True
                            if cache['back_z'] < deepest_hit_z: deepest_hit_z = cache['back_z']
                    
                    final_pos_z = deepest_hit_z if has_hit else 0.0
                    current_mg = final_obj.GetMg()
                    current_mg.off = c4d.Vector(current_mg.off.x, current_mg.off.y, final_pos_z)
                    final_obj.SetMg(current_mg)

                    obj_thickness = abs(current_depth) if abs(current_depth) > 0.001 else 0.0
                    my_back_z = final_pos_z - obj_thickness
                    current_rect = GetSplineGlobalAABB(spline_ref)
                    placed_cache.append({'rect': current_rect, 'back_z': my_back_z, 'spline': spline_ref})

                if tex_tag_to_fit and tex_tag_to_fit.IsAlive(): fit_targets.append((final_obj, tex_tag_to_fit))

                parent = None
                if use_groups:
                    layer_null = self._get_or_create_layer_null(doc, main_item.get("layer"), parent=main_container)
                    group_name = main_item.get("group")
                    parent = self._get_or_create_group_chain(doc, layer_null, group_name)
                
                if parent: final_obj.InsertUnder(parent)
                else: final_obj.InsertUnder(main_container)

                doc.AddUndo(c4d.UNDOTYPE_NEW, final_obj)
                craft_item = main_item
                for candidate_item in group_items:
                    candidate_type, _ = self._extract_craft_info(candidate_item)
                    if candidate_type != "none":
                        craft_item = candidate_item
                        break
                self._queue_auto_craft(pending_crafts, final_obj, craft_item)
                created_cnt += 1
                if total_groups and (group_index % refresh_step == 0 or group_index == total_groups - 1):
                    create_percent = 45 + int(((group_index + 1) / float(total_groups)) * 40)
                    self.SetLoadProgress(create_percent, f"正在创建样条/对象... {group_index + 1}/{total_groups}")

            self.SetLoadProgress(90, "正在整理层级/刷新场景...")
            c4d.EventAdd()
            all_objects =[]
            def collect_hierarchy(op):
                while op:
                    all_objects.append(op)
                    collect_hierarchy(op.GetDown())
                    op = op.GetNext()
            collect_hierarchy(main_container)
            
            for op in reversed(all_objects):
                if not op.IsAlive(): continue
                if op.CheckType(c4d.Onull) and op.GetName().startswith(GROUP_NULL_PREFIX):
                    children = op.GetChildren()
                    if len(children) == 1:
                        child = children[0]
                        parent = op.GetUp()
                        mat = child.GetMg()
                        child.Remove()
                        doc.InsertObject(child, pred=op) 
                        child.SetMg(mat)
                        doc.AddUndo(c4d.UNDOTYPE_CHANGE, child)
                        op.Remove()
                        doc.AddUndo(c4d.UNDOTYPE_DELETE, op)

            if fit_targets: BatchFitTextureTags(doc, fit_targets)
            RecenterGroupAxis(main_container)

           # =================[花花广告设计 v1.1 - 夺舍替换逻辑 (完美组替换版)] =================
            if is_hot_replace and old_op and old_op.IsAlive():
                
                # 如果用户不小心选中的是样条，自动把目标换成它外层的挤压外壳
                if old_op.CheckType(c4d.Ospline) and old_op.GetUp() and old_op.GetUp().CheckType(c4d.Oextrude):
                    old_op = old_op.GetUp()

                # 提取旧物体的世界矩阵
                old_mg = old_op.GetMg()
                
                # 构造目标矩阵：继承位置和旋转，抛弃旧物体的缩放比例（强制重置比例，防止拉伸）
                target_mg = c4d.Matrix(old_mg)
                target_mg.v1 = target_mg.v1.GetNormalized()
                target_mg.v2 = target_mg.v2.GetNormalized()
                target_mg.v3 = target_mg.v3.GetNormalized()
                
                main_container.SetName(old_op.GetName())
                
                # 【关键修复 1】：先将新组放入旧物体的层级位置 
                main_container.Remove() 
                doc.InsertObject(main_container, parent=old_op.GetUp(), pred=old_op.GetPred())
                
                # 【关键修复 2】：放入层级后，再赋予世界坐标，把它死死钉在原地！
                main_container.SetMg(target_mg)
                
                # 删掉旧物体
                doc.AddUndo(c4d.UNDOTYPE_DELETE, old_op)
                old_op.Remove()
            # ========================================================

            doc.EndUndo()
            c4d.EventAdd()
            craft_cnt = self._process_pending_crafts(pending_crafts)
            self.FinishLoadProgress()
            if craft_cnt > 0:
                msg = f"成功处理 {created_cnt} 个对象，自动处理 {craft_cnt} 个工艺"
                self._auto_craft_log(msg)
                c4d.StatusSetText(msg)
            else:
                c4d.StatusSetText(f"成功处理 {created_cnt} 个对象")

        except Exception as e:
            self.FailLoadProgress(str(e))
            gui.MessageDialog(f"导入错误:\n{str(e)}\n{traceback.format_exc()}")
        return True

    def _action_simple_extrude_selected(self):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel:
            gui.MessageDialog("请先选中要挤压的样条对象。")
            return
        depth = -abs(self.GetFloat(ID_EXTRUDE_DEPTH))
        doc.StartUndo()
        for obj in sel:
            if obj.CheckType(c4d.Ospline):
                old_mg = obj.GetMg()
                ex_name = obj.GetName().replace(SPLINE_NAME_PREFIX, EXTRUDE_NAME_PREFIX)
                if ex_name == obj.GetName(): ex_name = "Extrude_" + obj.GetName()
                ex = self._create_extrude_object(depth, ex_name)
                ex.SetMg(old_mg)
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                obj.Remove()
                ex[c4d.ID_BASEOBJECT_USECOLOR] = 0
                if obj.GetUp(): doc.InsertObject(ex, pred=obj.GetUp())
                else: doc.InsertObject(ex)
                obj.InsertUnder(ex)
                obj.SetMl(c4d.Matrix())
                doc.AddUndo(c4d.UNDOTYPE_NEW, ex)
        doc.EndUndo()
        c4d.EventAdd()

    def _action_smart_merge_color(self):
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel:
            gui.MessageDialog("请选中需要合并的样条。")
            return
        color_groups = {}
        for obj in sel:
            if not obj.CheckType(c4d.Ospline): continue
            found_color = None
            for t in obj.GetTags():
                if t.CheckType(c4d.Ttexture):
                    mat = t.GetMaterial()
                    if mat and mat.CheckType(c4d.Mmaterial): 
                        if mat[c4d.MATERIAL_USE_COLOR]:
                            found_color = mat[c4d.MATERIAL_COLOR_COLOR]
                            break
            if found_color is None: found_color = obj[c4d.ID_BASEOBJECT_COLOR]
            key = (round(found_color.x, 3), round(found_color.y, 3), round(found_color.z, 3))
            if (key[0] < 0.01 and key[1] < 0.01 and key[2] < 0.01) or \
               (0.19 < key[0] < 0.21 and 0.19 < key[1] < 0.21 and 0.19 < key[2] < 0.21):
                key = (1.0, 1.0, 1.0)
            if key not in color_groups: color_groups[key] = []
            color_groups[key].append(obj)

        if not color_groups: return
        depth = -abs(self.GetFloat(ID_EXTRUDE_DEPTH))
        doc.StartUndo()
        for key, objects in color_groups.items():
            if not objects: continue
            res = utils.SendModelingCommand(command=c4d.MCOMMAND_JOIN, list=objects, mode=c4d.MODELINGCOMMANDMODE_ALL, doc=doc, flags=c4d.MODELINGCOMMANDFLAGS_NONE)
            if res and res[0]:
                merged_spline = res[0]
                r_inv = int(key[0] * 255); g_inv = int(key[1] * 255); b_inv = int(key[2] * 255)
                merged_spline.SetName(f"Merged_Spline_{r_inv}_{g_inv}_{b_inv}")
                vec_color = c4d.Vector(key[0], key[1], key[2])
                merged_spline[c4d.ID_BASEOBJECT_USECOLOR] = 0
                doc.InsertObject(merged_spline)
                doc.AddUndo(c4d.UNDOTYPE_NEW, merged_spline)
                
                ex = self._create_extrude_object(depth, merged_spline.GetName().replace("Merged_Spline", "Extrude"))
                ex.SetMg(merged_spline.GetMg())
                ex[c4d.ID_BASEOBJECT_USECOLOR] = 0
                mat = self.CreateColorMaterial(doc, r_inv, g_inv, b_inv, False)
                if mat:
                    tex = ex.MakeTag(c4d.Ttexture)
                    tex.SetMaterial(mat)
                    tex[c4d.TEXTURETAG_PROJECTION] = c4d.TEXTURETAG_PROJECTION_UVW
                
                merged_spline.InsertUnder(ex)
                merged_spline.SetMl(c4d.Matrix())
                doc.InsertObject(ex)
                doc.AddUndo(c4d.UNDOTYPE_NEW, ex)
                for old_obj in objects:
                    doc.AddUndo(c4d.UNDOTYPE_DELETE, old_obj)
                    old_obj.Remove()
        doc.EndUndo()
        c4d.EventAdd()

    def _action_apply_depth_to_selected(self):
        ui_val = self.GetFloat(ID_EXTRUDE_DEPTH)
        doc = documents.GetActiveDocument()
        sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
        if not sel: return
        doc.StartUndo()
        changed = False
        for obj in sel:
            if obj.CheckType(c4d.Oextrude) or obj.GetType() == C4D_EXTRUDE_TYPEID:
                doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                try:
                    curr_offset = obj[C4D_EXTRUDE_OFFSET_ID]
                    new_offset_val = abs(ui_val)
                    if curr_offset < 0: new_offset_val = -new_offset_val
                    elif curr_offset == 0: new_offset_val = -new_offset_val
                    obj[C4D_EXTRUDE_OFFSET_ID] = new_offset_val
                except: pass
                try:
                    current_vec = obj[c4d.EXTRUDEOBJECT_MOVE]
                    length = current_vec.GetLength()
                    if length > 0.0001:
                        direction = current_vec.GetNormalized()
                        obj[c4d.EXTRUDEOBJECT_MOVE] = direction * abs(ui_val)
                    else:
                        obj[c4d.EXTRUDEOBJECT_MOVE] = c4d.Vector(0, 0, -abs(ui_val))
                except: pass
            
                obj.Message(c4d.MSG_UPDATE)
                changed = True
        doc.EndUndo()
        if changed: c4d.EventAdd()


    # ==============================================================================
    # 资产库逻辑
    # ==============================================================================

    # ==============================================================================
    # 吊顶生成逻辑 (Action)
    # ==============================================================================
    def _action_generate_ceiling(self):
        CheckAndCreateMaterials()
        doc = c4d.documents.GetActiveDocument()
        selection = doc.GetActiveObject()
        
        init_h = 260.0; init_d = 400.0; init_link = None
        if selection:
            size, _, _, _ = GetHierarchyLocalBounds_Gen(selection)
            if size.y > 1.0: init_h = size.y
            init_link = selection

        gen = c4d.BaseObject(c4d.Opython)
        gen.SetName("智能吊顶 花花广告设计 v1.1 (按钮刷新+显隐优化)")
        
        def AddUD(obj, name, dtype, val, unit=0, cycle=None, min_val=None, max_val=None, step=None, parent_id=None):
            bc = c4d.GetCustomDataTypeDefault(dtype)
            bc[c4d.DESC_NAME] = name
            if unit: bc[c4d.DESC_UNIT] = unit
            if min_val is not None: bc[c4d.DESC_MIN] = min_val
            if max_val is not None: bc[c4d.DESC_MAX] = max_val
            if step is not None: bc[c4d.DESC_STEP] = step
            if cycle:
                cycle_bc = c4d.BaseContainer()
                for k, v in cycle.items(): cycle_bc.SetString(k, v)
                bc[c4d.DESC_CYCLE] = cycle_bc
            if parent_id is not None: bc[c4d.DESC_PARENTGROUP] = parent_id
            element = obj.AddUserData(bc)
            if dtype != c4d.DTYPE_BUTTON and dtype != c4d.DTYPE_SEPARATOR: obj[element] = val
            return element

        def AddGroup(obj, name, parent_id=None):
            bc = c4d.GetCustomDataTypeDefault(c4d.DTYPE_GROUP)
            bc[c4d.DESC_NAME] = name
            bc[c4d.DESC_TITLEBAR] = 1 
            if parent_id is not None: bc[c4d.DESC_PARENTGROUP] = parent_id
            return obj.AddUserData(bc)

        AddUD(gen, "参考对象 (决定房宽/房高)", c4d.DTYPE_BASELISTLINK, init_link)
        AddUD(gen, "🔄 立即刷新 (点击)", c4d.DTYPE_BUTTON, 0) 
        AddUD(gen, "👁️ 自动隐藏源对象", c4d.DTYPE_BOOL, True) 
        AddUD(gen, "✅ 将模型自动靠墙放置 (保留原墙)", c4d.DTYPE_BOOL, True) 
        AddUD(gen, "房高 (吊顶下净高)", c4d.DTYPE_REAL, init_h, c4d.DESC_UNIT_METER)
        AddUD(gen, "房深 (侧墙长度)", c4d.DTYPE_REAL, init_d, c4d.DESC_UNIT_METER) 
        opts = {0:"默认", 1:"整体吊顶", 2:"平顶", 3:"跌级吊顶(推荐)"}
        AddUD(gen, "吊顶类型", c4d.DTYPE_LONG, 3, cycle=opts)
        AddUD(gen, "✅ 生成前墙 (封闭室内)", c4d.DTYPE_BOOL, False)
        gen.AddUserData(c4d.GetCustomDataTypeDefault(c4d.DTYPE_SEPARATOR))

        pose_opts = {0: "正常 (无需修正)", 1: "躺平了 (-90度)", 2: "趴着呢 (+90度)", 3: "倒立了 (180度)"}
        rot_opts = {0: "0 度", 1: "90 度", 2: "180 度", 3: "270 度"}

        AddUD(gen, ">> 替换窗户模型", c4d.DTYPE_BASELISTLINK, None)
        AddUD(gen, "   └ 窗-姿态修正", c4d.DTYPE_LONG, 1, cycle=pose_opts)
        AddUD(gen, "   └ 窗-方向修正", c4d.DTYPE_LONG, 0, cycle=rot_opts)
        grp_win = AddGroup(gen, "🔧 窗户详细参数 (可折叠)")
        AddUD(gen, "✅ 使用模型原生尺寸", c4d.DTYPE_BOOL, False, parent_id=grp_win)
        AddUD(gen, "[微调] 厚度缩放", c4d.DTYPE_REAL, 1.0, unit=c4d.DESC_UNIT_PERCENT, step=0.01, parent_id=grp_win)
        AddUD(gen, "[微调] 前后位移", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=0.1, parent_id=grp_win)
        AddUD(gen, "[尺寸] 窗户宽度", c4d.DTYPE_REAL, 174.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_win)
        AddUD(gen, "[尺寸] 窗户高度", c4d.DTYPE_REAL, 164.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_win)
        AddUD(gen, "[位置] 上下移动", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_win)
        AddUD(gen, "[位置] 左右移动", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_win)
        AddUD(gen, "[旋转] X轴 (俯仰)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_win)
        AddUD(gen, "[旋转] Y轴 (偏航)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_win)
        AddUD(gen, "[旋转] Z轴 (翻滚)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_win)
        
        gen.AddUserData(c4d.GetCustomDataTypeDefault(c4d.DTYPE_SEPARATOR))

        AddUD(gen, ">> 替换门模型", c4d.DTYPE_BASELISTLINK, None)
        AddUD(gen, "   └ 门-姿态修正", c4d.DTYPE_LONG, 1, cycle=pose_opts)
        AddUD(gen, "   └ 门-方向修正", c4d.DTYPE_LONG, 0, cycle=rot_opts)
        grp_door = AddGroup(gen, "🔧 门详细参数 (可折叠)")
        AddUD(gen, "✅ 使用模型原生尺寸", c4d.DTYPE_BOOL, False, parent_id=grp_door)
        AddUD(gen, "[微调] 左右位置修正 (正右负左)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=0.1, parent_id=grp_door)
        AddUD(gen, "[微调] 上下位置修正 (解决飞天)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_METER, step=0.1, parent_id=grp_door)
        AddUD(gen, "[微调] 厚度缩放", c4d.DTYPE_REAL, 1.0, unit=c4d.DESC_UNIT_PERCENT, step=0.01, parent_id=grp_door)
        AddUD(gen, "[微调] 前后位移", c4d.DTYPE_REAL, 6.7, unit=c4d.DESC_UNIT_METER, step=0.1, parent_id=grp_door)
        AddUD(gen, "[尺寸] 门洞宽度", c4d.DTYPE_REAL, 100.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_door)
        AddUD(gen, "[尺寸] 门洞高度", c4d.DTYPE_REAL, 220.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_door)
        AddUD(gen, "[位置] 左右移动", c4d.DTYPE_REAL, 161.0, unit=c4d.DESC_UNIT_METER, step=1.0, parent_id=grp_door)
        AddUD(gen, "[旋转] X轴 (俯仰)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_door)
        AddUD(gen, "[旋转] Y轴 (偏航)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_door)
        AddUD(gen, "[旋转] Z轴 (翻滚)", c4d.DTYPE_REAL, 0.0, unit=c4d.DESC_UNIT_DEGREE, step=1.0, parent_id=grp_door)
        
        gen.AddUserData(c4d.GetCustomDataTypeDefault(c4d.DTYPE_SEPARATOR))
        AddUD(gen, "射灯间距", c4d.DTYPE_REAL, 120.0, c4d.DESC_UNIT_METER) 
        AddUD(gen, "开启射灯", c4d.DTYPE_BOOL, True) 
        AddUD(gen, "   └ 开启两侧射灯", c4d.DTYPE_BOOL, False) 
        AddUD(gen, "显示灯光线框", c4d.DTYPE_BOOL, True) 
        AddUD(gen, "吊顶边距", c4d.DTYPE_REAL, 50.0, c4d.DESC_UNIT_METER) 
        AddUD(gen, "灯带数量", c4d.DTYPE_LONG, 3) 
        
        script_code = r"""
import c4d

RECESS_VAL = 10.0
OVERLAP = 2.0

def GetMat(name):
    doc = c4d.documents.GetActiveDocument()
    if not doc: return None
    return doc.SearchMaterial(name)

def GetHierarchyLocalBounds(obj):
    if not obj: return c4d.Vector(0), c4d.Vector(0), c4d.Vector(0), c4d.Vector(0)
    root_mg = obj.GetMg()
    inv_root_mg = ~root_mg
    min_p = c4d.Vector(float('inf'))
    max_p = c4d.Vector(float('-inf'))
    found = False
    
    def traverse(op):
        nonlocal min_p, max_p, found
        curr_mg = op.GetMg()
        local_to_root = inv_root_mg * curr_mg
        points = None
        if op.CheckType(c4d.Opoint):
            points = op.GetAllPoints()
        if points:
            found = True
            for p in points:
                p_rel = local_to_root * p
                if p_rel.x < min_p.x: min_p.x = p_rel.x
                if p_rel.x > max_p.x: max_p.x = p_rel.x
                if p_rel.y < min_p.y: min_p.y = p_rel.y
                if p_rel.y > max_p.y: max_p.y = p_rel.y
                if p_rel.z < min_p.z: min_p.z = p_rel.z
                if p_rel.z > max_p.z: max_p.z = p_rel.z
        else:
            cache = op.GetCache()
            if cache: traverse(cache)
            rad = op.GetRad()
            if rad.x > 0.001 or rad.y > 0.001 or rad.z > 0.001:
                found = True
                mp = op.GetMp()
                corners =[c4d.Vector(mp.x-rad.x, mp.y-rad.y, mp.z-rad.z), c4d.Vector(mp.x+rad.x, mp.y-rad.y, mp.z-rad.z), c4d.Vector(mp.x-rad.x, mp.y+rad.y, mp.z-rad.z), c4d.Vector(mp.x+rad.x, mp.y+rad.y, mp.z-rad.z), c4d.Vector(mp.x-rad.x, mp.y-rad.y, mp.z+rad.z), c4d.Vector(mp.x+rad.x, mp.y-rad.y, mp.z+rad.z), c4d.Vector(mp.x-rad.x, mp.y+rad.y, mp.z+rad.z), c4d.Vector(mp.x+rad.x, mp.y+rad.y, mp.z+rad.z)]
                for p in corners:
                    p_rel = local_to_root * p
                    if p_rel.x < min_p.x: min_p.x = p_rel.x
                    if p_rel.x > max_p.x: max_p.x = p_rel.x
                    if p_rel.y < min_p.y: min_p.y = p_rel.y
                    if p_rel.y > max_p.y: max_p.y = p_rel.y
                    if p_rel.z < min_p.z: min_p.z = p_rel.z
                    if p_rel.z > max_p.z: max_p.z = p_rel.z
        for child in op.GetChildren(): traverse(child)
    traverse(obj)
    if not found: return c4d.Vector(0), c4d.Vector(0), c4d.Vector(0), c4d.Vector(0)
    size = max_p - min_p
    center = (min_p + max_p) * 0.5
    return size, center, min_p, max_p

def MakeBox(name, size, pos, mat_name, parent, fillet=False):
    cube = c4d.BaseObject(c4d.Ocube)
    cube.SetName(name)
    cube[c4d.PRIM_CUBE_LEN] = size
    cube.SetAbsPos(pos)
    cube[c4d.PRIM_CUBE_DOFILLET] = False 
    mat = GetMat(mat_name)
    if mat:
        t = cube.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat)
        if "Floor" in name:
            t[c4d.TEXTURETAG_PROJECTION] = 6 
            t[c4d.TEXTURETAG_LENGTHX] = 500.0
            t[c4d.TEXTURETAG_LENGTHY] = 500.0
    if parent: cube.InsertUnderLast(parent)
    return cube

def MakeSpot(name, pos, mat_body_name, show_wireframe, parent):
    group = c4d.BaseObject(c4d.Onull)
    group.SetName(name)
    group.SetAbsPos(pos)
    casing = c4d.BaseObject(c4d.Ocylinder)
    casing.SetName("Casing")
    casing[c4d.PRIM_CYLINDER_RADIUS] = 4.0
    casing[c4d.PRIM_CYLINDER_HEIGHT] = 2.0
    casing[c4d.PRIM_AXIS] = 2 
    casing[c4d.PRIM_CYLINDER_SEG] = 48
    mat_body = GetMat(mat_body_name)
    if mat_body:
        t = casing.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat_body)
    casing.InsertUnder(group)
    bulb = c4d.BaseObject(c4d.Ocylinder)
    bulb.SetName("Bulb_Face")
    bulb[c4d.PRIM_CYLINDER_RADIUS] = 3.5
    bulb[c4d.PRIM_CYLINDER_HEIGHT] = 0.1
    bulb[c4d.PRIM_AXIS] = 2 
    bulb[c4d.PRIM_CYLINDER_SEG] = 48
    bulb.SetAbsPos(c4d.Vector(0, -1.0, 0))
    mat_light = GetMat("Pro_Light_Spot")
    if mat_light:
        t = bulb.MakeTag(c4d.Ttexture)
        t.SetMaterial(mat_light)
    bulb.InsertUnder(group)
    real_light = c4d.BaseObject(c4d.Olight)
    real_light.SetName("Real_Light")
    real_light[c4d.LIGHT_TYPE] = c4d.LIGHT_TYPE_SPOT
    real_light[c4d.LIGHT_BRIGHTNESS] = 1.0
    real_light[c4d.LIGHT_DETAILS_OUTERANGLE] = 0.8
    real_light[c4d.LIGHT_SHADOWTYPE] = c4d.LIGHT_SHADOWTYPE_SOFT
    if show_wireframe:
        real_light[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_ON
    else:
        real_light[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_OFF
    real_light.SetAbsRot(c4d.Vector(0, -1.5708, 0)) 
    real_light.SetAbsPos(c4d.Vector(0, -1.5, 0))
    real_light.InsertUnder(group)
    if parent: group.InsertUnderLast(parent)
    return group

def PlaceLinkedModel(link_obj, target_size, target_pos_floor, pose_mode, rot_mode, custom_rot_vec, depth_scale, pos_offset, center_offset_x, center_offset_y, use_native_size, name, parent):
    if not link_obj: return False, target_size 
    container = c4d.BaseObject(c4d.Onull)
    container.SetName(name + "_Container")
    container.SetAbsPos(target_pos_floor)
    axis_corrector = c4d.BaseObject(c4d.Onull)
    axis_corrector.SetName("Axis_Corrector")
    axis_corrector.InsertUnder(container)
    axis_corrector.SetAbsPos(c4d.Vector(0,0,0))
    clone = link_obj.GetClone(0)
    clone.SetName(name)
    clone[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_ON
    clone[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_ON
    clone.InsertUnder(axis_corrector)
    vis_size, vis_center, min_p, max_p = GetHierarchyLocalBounds(link_obj)
    shift_x = -vis_center.x
    shift_z = -vis_center.z
    shift_y = -min_p.y
    if vis_size.x < 0.001 and vis_size.y < 0.001:
        shift_x = 0; shift_y = 0; shift_z = 0
    clone.SetAbsPos(c4d.Vector(shift_x, shift_y, shift_z))
    clone.SetAbsRot(c4d.Vector(0,0,0))
    t_thick = target_size.x; t_high  = target_size.y; t_wide  = target_size.z
    s_wide = vis_size.x if vis_size.x > 0.1 else 1.0
    s_high = vis_size.y if vis_size.y > 0.1 else 1.0
    s_thick= vis_size.z if vis_size.z > 0.1 else 1.0
    fac_x = t_wide / s_wide; fac_y = t_high / s_high; fac_z = t_thick / s_thick 
    if use_native_size:
        fac_x = 1.0 * depth_scale; fac_y = 1.0; fac_z = 1.0
    axis_corrector.SetRelScale(c4d.Vector(fac_x, fac_y, fac_z))
    final_rot = c4d.Vector(0,0,0)
    if pose_mode == 1: final_rot.x = -1.5708
    elif pose_mode == 2: final_rot.x = 1.5708
    elif pose_mode == 3: final_rot.x = 3.14159
    if rot_mode == 1: final_rot.y += 1.5708
    elif rot_mode == 2: final_rot.y += 3.14159
    elif rot_mode == 3: final_rot.y += 4.71239
    final_rot.x += custom_rot_vec.x; final_rot.y += custom_rot_vec.y; final_rot.z += custom_rot_vec.z
    axis_corrector.SetRelRot(final_rot)
    offset_vec = c4d.Vector(0,0,0)
    if rot_mode == 1 or rot_mode == 3: offset_vec.x = center_offset_x
    else: offset_vec.z = center_offset_x
    offset_vec.y = center_offset_y
    axis_corrector.SetRelPos(offset_vec)
    p = container.GetAbsPos()
    p.x += pos_offset
    container.SetAbsPos(p)
    if parent: container.InsertUnderLast(parent)
    ret_w = t_wide; ret_h = t_high
    if use_native_size:
        if rot_mode == 1 or rot_mode == 3: ret_w = s_wide
        else: ret_w = s_thick
        ret_h = s_high
    return True, c4d.Vector(target_size.x, ret_h, ret_w)

def CreateStepBorder(name, w, h, d, x, y, z, border_type, parent):
    M_WHITE = "Pro_Wall_White"
    M_LIGHT_COVE = "Pro_Light_Cove"
    h_lower = 8.0 
    h_upper = h - h_lower
    recess = RECESS_VAL 
    top_y = y + h/2
    y_upper = top_y - h_upper/2
    y_lower = top_y - h_upper - h_lower/2
    light_thick = 0.5          
    light_width = recess * 0.5 
    y_light = (y_lower + h_lower/2) + light_thick/2 
    extend_len = (recess * 2.0) + 20.0
    if border_type == "L": 
        MakeBox(name + "_Low", c4d.Vector(w, h_lower, d), c4d.Vector(x, y_lower, z), M_WHITE, parent)
        shift_x = -recess/2.0
        MakeBox(name + "_Up", c4d.Vector(w-recess, h_upper, d), c4d.Vector(x+shift_x, y_upper, z), M_WHITE, parent)
        lx = x + (w/2.0 - recess/2.0)
        MakeBox(name + "_Light", c4d.Vector(light_width, light_thick, d-2.0), c4d.Vector(lx, y_light, z), M_LIGHT_COVE, parent)
    elif border_type == "R": 
        MakeBox(name + "_Low", c4d.Vector(w, h_lower, d), c4d.Vector(x, y_lower, z), M_WHITE, parent)
        shift_x = +recess/2.0
        MakeBox(name + "_Up", c4d.Vector(w-recess, h_upper, d), c4d.Vector(x+shift_x, y_upper, z), M_WHITE, parent)
        lx = x - (w/2.0 - recess/2.0)
        MakeBox(name + "_Light", c4d.Vector(light_width, light_thick, d-2.0), c4d.Vector(lx, y_light, z), M_LIGHT_COVE, parent)
    elif border_type == "F": 
        MakeBox(name + "_Low", c4d.Vector(w, h_lower, d), c4d.Vector(x, y_lower, z), M_WHITE, parent)
        shift_z = -recess/2.0
        MakeBox(name + "_Up", c4d.Vector(w+extend_len, h_upper, d-recess), c4d.Vector(x, y_upper, z+shift_z), M_WHITE, parent)
        lz = z + (d/2.0 - recess/2.0)
        MakeBox(name + "_Light", c4d.Vector(w+extend_len, light_thick, light_width), c4d.Vector(x, y_light, lz), M_LIGHT_COVE, parent)
    elif border_type == "B": 
        MakeBox(name + "_Low", c4d.Vector(w, h_lower, d), c4d.Vector(x, y_lower, z), M_WHITE, parent)
        shift_z = +recess/2.0
        MakeBox(name + "_Up", c4d.Vector(w+extend_len, h_upper, d-recess), c4d.Vector(x, y_upper, z+shift_z), M_WHITE, parent)
        lz = z - (d/2.0 - recess/2.0)
        MakeBox(name + "_Light", c4d.Vector(w+extend_len, light_thick, light_width), c4d.Vector(x, y_light, lz), M_LIGHT_COVE, parent)

def main():
    def GetUD(id, default):
        try:
            val = op[c4d.ID_USERDATA, id]
            if val is None: return default
            return val
        except: return default
    link = GetUD(1, None)
    auto_hide = bool(GetUD(3, True)) 
    if link:
        if auto_hide:
            try:
                if link.GetEditorMode() != c4d.OBJECT_OFF:
                    link.SetEditorMode(c4d.OBJECT_OFF)
                    link.SetRenderMode(c4d.OBJECT_OFF)
            except: pass
    else:
            try:
                if link.GetEditorMode() == c4d.OBJECT_OFF:
                    link.SetEditorMode(c4d.OBJECT_UNDEF)
                    link.SetRenderMode(c4d.OBJECT_UNDEF)
            except: pass
    place_against_wall = bool(GetUD(4, False)) 
    clear_h = float(GetUD(5, 260.0)) 
    rd = float(GetUD(6, 400.0))
    ct = int(GetUD(7, 3))
    make_front_wall = bool(GetUD(8, False))
    win_link = GetUD(10, None)
    win_pose = int(GetUD(11, 1))
    win_rot  = int(GetUD(12, 0))
    win_native  = int(GetUD(14, 0)) 
    win_d_scale = float(GetUD(15, 1.0))
    win_offset  = float(GetUD(16, 0.0))
    win_w_usr = float(GetUD(17, 174.0)) 
    win_h_usr = float(GetUD(18, 164.0))
    win_move_y = float(GetUD(19, 0.0)) 
    win_move_z = float(GetUD(20, 0.0))
    wx = float(GetUD(21, 0.0)); wy = float(GetUD(22, 0.0)); wz = float(GetUD(23, 0.0))
    win_custom_vec = c4d.Vector(wx, wy, wz)
    door_link = GetUD(25, None)
    door_pose = int(GetUD(26, 1)) 
    door_rot  = int(GetUD(27, 0)) 
    door_native = int(GetUD(29, 0)) 
    door_center_x_fix = float(GetUD(30, 0.0))
    door_center_y_fix = float(GetUD(31, 0.0))
    door_d_scale = float(GetUD(32, 1.0))
    door_offset  = float(GetUD(33, 6.7)) 
    door_w_usr = float(GetUD(34, 100.0))
    door_h_usr = float(GetUD(35, 220.0))
    door_z_move = float(GetUD(36, 161.0)) 
    dx = float(GetUD(37, 0.0)); dy = float(GetUD(38, 0.0)); dz = float(GetUD(39, 0.0))
    door_custom_vec = c4d.Vector(dx, dy, dz)
    spot_dist = float(GetUD(41, 120.0)) 
    enable_spots = int(GetUD(42, 1))
    enable_side_spots = int(GetUD(43, 0))
    show_light_wire = int(GetUD(44, 1)) 
    manual_margin = float(GetUD(45, 50.0))
    light_strip_cnt = int(GetUD(46, 3))
    if link and isinstance(link, c4d.BaseObject):
        real_size, _, _, _ = GetHierarchyLocalBounds(link)
        if real_size.y > clear_h: clear_h = real_size.y
        real_w = real_size.x; rw = max(real_w, 100.0)
    else: rw = 500.0
    root = c4d.BaseObject(c4d.Onull)
    MakeBox("Floor", c4d.Vector(rw + 40.0, 10, rd), c4d.Vector(0,-5,0), "Pro_Floor_Wood", root)
    wall_h = clear_h
    MakeBox("Wall_Back", c4d.Vector(rw, wall_h, 20), c4d.Vector(0, wall_h/2, rd/2+10), "Pro_Wall_White", root)
    if make_front_wall: MakeBox("Wall_Front", c4d.Vector(rw, wall_h, 20), c4d.Vector(0, wall_h/2, -rd/2-10), "Pro_Wall_White", root)
    if link and place_against_wall and isinstance(link, c4d.BaseObject):
        container = c4d.BaseObject(c4d.Onull)
        container.SetName("Decor_Object_Placed")
        container.SetAbsPos(c4d.Vector(0, 0, 0)) 
        clone = link.GetClone(0)
        if clone:
            clone.SetAbsPos(c4d.Vector(0,0,0)); clone.SetAbsRot(c4d.Vector(0,0,0))
            clone[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = c4d.OBJECT_ON
            clone[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = c4d.OBJECT_ON
            clone.InsertUnder(container)
            _, _, min_p, max_p = GetHierarchyLocalBounds(link)
            min_y = min_p.y; move_y = 0.0 - min_y
            center_x = (min_p.x + max_p.x) * 0.5; move_x = 0.0 - center_x
            max_z = max_p.z; move_z = (rd / 2.0) - max_z
            clone.SetAbsPos(c4d.Vector(move_x, move_y, move_z))
            container.InsertUnderLast(root)
    ceil_drop = 30.0 
    if ct == 2: ceil_drop = 5.0 
    elif ct == 1: ceil_drop = 15.0 
    total_rh = clear_h + ceil_drop; side_wall_h = total_rh 
    L = c4d.BaseObject(c4d.Onull); L.SetAbsPos(c4d.Vector(-rw/2-10,0,0)); L.InsertUnderLast(root)
    ww_val = win_w_usr if win_w_usr > 1 else rd*0.5
    wh_val = win_h_usr if win_h_usr > 1 else side_wall_h*0.5
    wy_base = side_wall_h*0.55; wy = wy_base + win_move_y; wz = win_move_z
    has_win_model = False; actual_ww = ww_val; actual_wh = wh_val
    if win_link:
        success, actual_size_vec = PlaceLinkedModel(win_link, c4d.Vector(15, wh_val, ww_val), c4d.Vector(0, wy - wh_val/2, wz), win_pose, win_rot, win_custom_vec, win_d_scale, win_offset, 0.0, 0.0, win_native, "HighPoly_Window", L)
        if success: has_win_model = True; actual_wh = actual_size_vec.y; actual_ww = actual_size_vec.z
    if not has_win_model:
        MakeBox("Win_F", c4d.Vector(12, actual_wh, 6), c4d.Vector(0,wy,-actual_ww/2+wz), "Pro_Metal_Dark", L)
        MakeBox("Win_B", c4d.Vector(12, actual_wh, 6), c4d.Vector(0,wy,actual_ww/2+wz), "Pro_Metal_Dark", L)
        MakeBox("Win_T", c4d.Vector(12, 6, actual_ww), c4d.Vector(0,wy+actual_wh/2,wz), "Pro_Metal_Dark", L)
        MakeBox("Win_D", c4d.Vector(12, 6, actual_ww), c4d.Vector(0,wy-actual_wh/2,wz), "Pro_Metal_Dark", L)
        MakeBox("Glass", c4d.Vector(2, actual_wh-10, actual_ww-10), c4d.Vector(0,wy,wz), "Pro_Glass", L)
    h_bot = wy - actual_wh/2
    if h_bot > 0: MakeBox("W_Bot", c4d.Vector(20, h_bot, rd), c4d.Vector(0, h_bot/2, 0), "Pro_Wall_White", L)
    h_top = side_wall_h - (wy + actual_wh/2)
    if h_top > 0: MakeBox("W_Top", c4d.Vector(20, h_top, rd), c4d.Vector(0, side_wall_h - h_top/2, 0), "Pro_Wall_White", L)
    len_f = (wz - actual_ww/2) + rd/2
    if len_f > 0: pos_f = -rd/2 + len_f/2; MakeBox("W_F", c4d.Vector(20, actual_wh, len_f), c4d.Vector(0, wy, pos_f), "Pro_Wall_White", L)
    len_b = rd/2 - (wz + actual_ww/2)
    if len_b > 0: pos_b = rd/2 - len_b/2; MakeBox("W_B", c4d.Vector(20, actual_wh, len_b), c4d.Vector(0, wy, pos_b), "Pro_Wall_White", L)
    R = c4d.BaseObject(c4d.Onull); R.SetAbsPos(c4d.Vector(rw/2+10,0,0)); R.InsertUnderLast(root)
    dw = door_w_usr; dh = door_h_usr; dz = (-rd*0.2) + door_z_move; actual_dw = dw; actual_dh = dh
    bool_op = c4d.BaseObject(c4d.Oboole)
    bool_op[c4d.BOOLEOBJECT_SINGLE_OBJECT] = True; bool_op[c4d.BOOLEOBJECT_TYPE] = c4d.BOOLEOBJECT_TYPE_SUBTRACT 
    bool_op.InsertUnder(R)
    MakeBox("Wall_Solid", c4d.Vector(20, side_wall_h, rd), c4d.Vector(0,side_wall_h/2,0), "Pro_Wall_White", bool_op)
    has_door_model = False
    if door_link:
        success, actual_size_vec = PlaceLinkedModel(door_link, c4d.Vector(20, dh, dw), c4d.Vector(0, 0, dz), door_pose, door_rot, door_custom_vec, door_d_scale, door_offset, door_center_x_fix, door_center_y_fix, door_native, "HighPoly_Door", R)
        if success: has_door_model = True; actual_dh = actual_size_vec.y; actual_dw = actual_size_vec.z
    cutter_h = actual_dh + 10.0; cutter_y = (actual_dh / 2.0) - 5.0
    cutter = MakeBox("Cutter", c4d.Vector(40, cutter_h, actual_dw), c4d.Vector(0, cutter_y, dz), "Pro_Wall_White", bool_op)
    cutter[c4d.ID_BASEOBJECT_VISIBILITY_EDITOR] = 1; cutter[c4d.ID_BASEOBJECT_VISIBILITY_RENDER] = 1 
    if not has_door_model:
        MakeBox("Door_F", c4d.Vector(24, actual_dh, 10), c4d.Vector(0,actual_dh/2,dz-actual_dw/2), "Pro_Metal_Dark", R)
        MakeBox("Door_B", c4d.Vector(24, actual_dh, 10), c4d.Vector(0,actual_dh/2,dz+actual_dw/2), "Pro_Metal_Dark", R)
        MakeBox("Door_T", c4d.Vector(24, 10, actual_dw), c4d.Vector(0,actual_dh,dz), "Pro_Metal_Dark", R)
        MakeBox("Panel", c4d.Vector(4, actual_dh, actual_dw), c4d.Vector(0,actual_dh/2,dz), "Pro_Door_Wood", R)
    if ct == 0: ct = 3
    if ct == 3:
        M_WHITE = "Pro_Wall_White"; M_BLACK = "Pro_Metal_Dark"; M_LIGHT_LINEAR = "Pro_Light_Linear"
        MakeBox("Structure_Slab", c4d.Vector(rw, 2, rd), c4d.Vector(0, total_rh+1.0, 0), M_BLACK, root)
        margin_x = manual_margin; margin_z = manual_margin
        drop_h = ceil_drop; drop_y = clear_h + drop_h / 2.0
        CreateStepBorder("Drop_L", margin_x, drop_h, rd, -rw/2.0+margin_x/2.0, drop_y, 0, "L", root)
        CreateStepBorder("Drop_R", margin_x, drop_h, rd, rw/2.0-margin_x/2.0, drop_y, 0, "R", root)
        in_w = rw - margin_x*2.0
        CreateStepBorder("Drop_F", in_w, drop_h, margin_z, 0, drop_y, -rd/2.0+margin_z/2.0, "F", root)
        CreateStepBorder("Drop_B", in_w, drop_h, margin_z, 0, drop_y, rd/2.0-margin_z/2.0, "B", root)
        if enable_spots:
            spot_y = clear_h; cx = rw/2.0 - margin_x/2.0; cz = rd/2.0 - margin_z/2.0
            MakeSpot("C_FL", c4d.Vector(-cx, spot_y, -cz), M_BLACK, show_light_wire, root)
            MakeSpot("C_FR", c4d.Vector(cx, spot_y, -cz), M_BLACK, show_light_wire, root)
            MakeSpot("C_BL", c4d.Vector(-cx, spot_y, cz), M_BLACK, show_light_wire, root)
            MakeSpot("C_BR", c4d.Vector(cx, spot_y, cz), M_BLACK, show_light_wire, root)
            if enable_side_spots:
                dist_z = cz - (-cz)
                if dist_z > 10:
                    seg_z = int(round(dist_z / spot_dist))
                    if seg_z >= 1:
                        step_z = dist_z / float(seg_z)
                        for i in range(1, seg_z): zp = -cz + step_z * i; MakeSpot("SL", c4d.Vector(-cx, spot_y, zp), M_BLACK, show_light_wire, root); MakeSpot("SR", c4d.Vector(cx, spot_y, zp), M_BLACK, show_light_wire, root)
            dist_x = cx - (-cx)
            if dist_x > 10:
                seg_x = int(round(dist_x / spot_dist))
                if seg_x >= 1:
                    step_x = dist_x / float(seg_x)
                    for i in range(1, seg_x): xp = -cx + step_x * i; MakeSpot("SF", c4d.Vector(xp, spot_y, -cz), M_BLACK, show_light_wire, root); MakeSpot("SB", c4d.Vector(xp, spot_y, cz), M_BLACK, show_light_wire, root)
        in_d_base = rd - margin_z*2.0
        in_d_extended = in_d_base + (RECESS_VAL * 2.0) + OVERLAP 
        light_count = light_strip_cnt; light_w = 8.0
        total_light_w = light_count * light_w; total_panel_w = in_d_extended - total_light_w
        panel_w = total_panel_w / float(light_count + 1)
        light_padding = 35.0; real_light_len = in_w - (light_padding * 2.0)
        if real_light_len < 10: real_light_len = 10
        curr_z = -in_d_extended/2.0; ceil_y_center = total_rh - 2.5; light_y_center = total_rh - 4.3; slot_back_y = total_rh - 1.0; panel_extend_w = in_w + (RECESS_VAL * 2.0) + OVERLAP 
        for i in range(light_count + 1):
            p_z = curr_z + panel_w/2.0
            MakeBox("Ceil_Panel", c4d.Vector(panel_extend_w, 5, panel_w), c4d.Vector(0, ceil_y_center, p_z), M_WHITE, root)
            curr_z += panel_w
            if i < light_count:
                l_z = curr_z + light_w/2.0
                MakeBox("Slot_Back", c4d.Vector(real_light_len + 2.0, 2, light_w), c4d.Vector(0, slot_back_y, l_z), M_BLACK, root)
                MakeBox("Light_Strip", c4d.Vector(real_light_len, 1, light_w), c4d.Vector(0, light_y_center, l_z), M_LIGHT_LINEAR, root)
                filler_w = light_padding + RECESS_VAL + OVERLAP
                fx_left = (-in_w/2.0 - RECESS_VAL) + filler_w/2.0 - (OVERLAP/2.0); fx_right = -fx_left 
                MakeBox("Filler_L", c4d.Vector(filler_w, 5, light_w), c4d.Vector(fx_left, ceil_y_center, l_z), M_WHITE, root)
                MakeBox("Filler_R", c4d.Vector(filler_w, 5, light_w), c4d.Vector(fx_right, ceil_y_center, l_z), M_WHITE, root)
                curr_z += light_w
    elif ct == 2: MakeBox("Top", c4d.Vector(rw,5,rd), c4d.Vector(0, clear_h + 2.5, 0), "Pro_Wall_White", root)
    elif ct == 1: MakeBox("Ceil", c4d.Vector(rw,10,rd), c4d.Vector(0, clear_h + 5.0, 0), "Pro_Wall_White", root)
    return root
"""
        gen[c4d.OPYTHON_CODE] = script_code
        doc.InsertObject(gen)
        c4d.EventAdd()

    def LoadFavorites(self):
        if os.path.exists(self.fav_file_path):
            try:
                with open(self.fav_file_path, 'r') as f:
                    self.favorites = set(json.load(f))
            except: pass

    def SaveFavorites(self):
        try:
            with open(self.fav_file_path, 'w') as f:
                json.dump(list(self.favorites), f)
        except: pass

    def ToggleFavorite(self, index):
        if 0 <= index < len(self.user_area.assets):
            item = self.user_area.assets[index]
            fname = item['name']
            if fname in self.favorites:
                self.favorites.remove(fname)
                item['is_fav'] = False
            else:
                self.favorites.add(fname)
                item['is_fav'] = True
            self.SaveFavorites()
            self.user_area.Redraw()
            if self.GetBool(ID_ASSET_CHK_ONLY_FAV):
                self.ApplyAssetFilter()

    def ScanAndLoad(self):
        if not os.path.exists(self.asset_path): return
        self.full_data_cache =[] 
        limit = 500; count = 0
        for root, dirs, files in os.walk(self.asset_path):
            current_files_map = {f.lower(): f for f in files}
            for filename in files:
                if filename.lower().endswith('.c4d'):
                    file_path = os.path.join(root, filename)
                    base_name = os.path.splitext(filename)[0].lower()
                    img_path = None
                    possible =[base_name + ".jpg", base_name + ".png", base_name + ".jpeg"]
                    for p in possible:
                        if p in current_files_map: img_path = os.path.join(root, current_files_map[p]); break
                    if not img_path:
                        for f_lower, f_real in current_files_map.items():
                            if f_lower.startswith(base_name) and f_lower.endswith(('.jpg', '.png', '.jpeg')):
                                if f_lower == filename.lower(): continue
                                img_path = os.path.join(root, f_real); break
                    bmp = None
                    if img_path: bmp = SafeLoadBitmap(img_path)
                    self.full_data_cache.append({
                        "path": file_path, 
                        "bmp": bmp, 
                        "name": filename,
                        "is_fav": filename in self.favorites
                    })
                    count += 1
                    if count >= limit: break
            if count >= limit: break
        self.ApplyAssetFilter()

    def ApplyAssetFilter(self):
        search_txt = self.GetString(ID_ASSET_TXT_SEARCH).lower()
        only_fav = self.GetBool(ID_ASSET_CHK_ONLY_FAV)
        filtered_data =[]
        for item in self.full_data_cache:
            if search_txt and search_txt not in item['name'].lower(): continue
            if only_fav and item['name'] not in self.favorites: continue
            item['is_fav'] = item['name'] in self.favorites
            filtered_data.append(item)
        self.user_area.UpdateAssets(filtered_data)
        self.LayoutChanged(ID_ASSET_SCROLL_GRP)

    def LoadAsset(self, path):
        doc = c4d.documents.GetActiveDocument()
        if not doc: return
        target_objs = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
        is_replace_mode = len(target_objs) > 0
        do_size_match = self.GetBool(ID_ASSET_CHK_SIZE)
        c4d.CallCommand(12113) 
        
        if not os.path.exists(path):
            gui.MessageDialog(f"文件不存在：{path}")
            return
        c4d.StatusSetText(f"正在读取... {os.path.basename(path)}")
        
        def RecursivelyRelink(op, old_mats_list, new_mats_list):
            if not op: return
            tags = op.GetTags()
            for t in tags:
                if t.CheckType(c4d.Ttexture):
                    used_mat = t.GetMaterial()
                    if used_mat:
                        try:
                            idx = old_mats_list.index(used_mat)
                            if 0 <= idx < len(new_mats_list):
                                t.SetMaterial(new_mats_list[idx])
                        except ValueError: pass
            for child in op.GetChildren():
                RecursivelyRelink(child, old_mats_list, new_mats_list)

        try:
            temp_doc = c4d.documents.LoadDocument(path, c4d.SCENEFILTER_OBJECTS | c4d.SCENEFILTER_MATERIALS)
            if not temp_doc: return
            source_objs = temp_doc.GetObjects()
            source_mats = temp_doc.GetMaterials()
            if not source_objs: return

            doc.StartUndo()
            cloned_mats =[]
            for mat in source_mats:
                new_mat = mat.GetClone()
                doc.InsertMaterial(new_mat)
                doc.AddUndo(c4d.UNDOTYPE_NEW, new_mat)
                cloned_mats.append(new_mat)
            if cloned_mats: FixTexturePaths(cloned_mats, path)
                
            seed_obj = source_objs[0].GetClone()
            RecursivelyRelink(seed_obj, source_mats, cloned_mats)
            
            if is_replace_mode:
                for target in target_objs:
                    new_op = seed_obj.GetClone()
                    doc.InsertObject(new_op)
                    doc.AddUndo(c4d.UNDOTYPE_NEW, new_op)
                    ProcessReplacement(doc, new_op, target, do_size_match)
                    doc.AddUndo(c4d.UNDOTYPE_DELETE, target)
                    target.Remove()
                c4d.StatusSetText(f"成功替换 {len(target_objs)} 个对象")
            else:
                doc.InsertObject(seed_obj)
                doc.AddUndo(c4d.UNDOTYPE_NEW, seed_obj)
                mg = seed_obj.GetMg()
                mg.off = c4d.Vector(0, 0, 0)
                seed_obj.SetMg(mg)
                doc.SetActiveObject(seed_obj, c4d.SELECTION_NEW)
                c4d.StatusSetText("导入完成")
        except Exception as e:
            traceback.print_exc()
        finally:
            doc.EndUndo()
            c4d.EventAdd()
            if 'temp_doc' in locals() and temp_doc:
                c4d.documents.KillDocument(temp_doc)

    def Command(self, cid, msg):
        try:
            if cid == ID_ADMIN_OPEN_DIALOG_BTN:
                self._open_admin_auth_dialog()
                return True
            if cid == ID_ADMIN_LOGIN_BTN:
                return self._admin_handle_login_click()
            if cid == ID_ADMIN_LOGOUT_BTN:
                self._admin_logout()
                return True
            if cid == ID_ADMIN_RELOGIN_BTN:
                self._admin_logout()
                self._admin_set_message("请重新输入账号密码登录")
                return True

            if cid in CORE_BUTTON_IDS and not self._admin_ensure_fresh_license():
                gui.MessageDialog(self.core_disabled_reason or "当前未授权，无法使用核心功能。")
                return True

            # --- 基础与样条事件 ---
            if cid == ID_TENSION_VAL:
                t = self.GetFloat(ID_TENSION_VAL)
                self._update_selected_spline_tension(t)
                return True
            if cid == ID_SPL_TYPE_COMBO:
                self._action_update_spline_param(c4d.SPLINEOBJECT_TYPE, self.GetInt32(ID_SPL_TYPE_COMBO))
                return True
            if cid == ID_SPL_CLOSE_CHK:
                self._action_update_spline_param(c4d.SPLINEOBJECT_CLOSED, self.GetBool(ID_SPL_CLOSE_CHK))
                return True
            if cid == ID_SPL_INTER_COMBO:
                self._action_update_spline_param(c4d.SPLINEOBJECT_INTERPOLATION, self.GetInt32(ID_SPL_INTER_COMBO))
                return True
            if cid == ID_SPL_SUB_VAL:
                self._action_update_spline_param(c4d.SPLINEOBJECT_SUB, self.GetInt32(ID_SPL_SUB_VAL))
                return True
            if cid == ID_EXTRUDE_DEPTH:
                d = self.GetFloat(ID_EXTRUDE_DEPTH)
                slider_max = 200.0
                if d > slider_max: slider_max = d
                self.SetFloat(ID_EXTRUDE_SLIDER, d, min=0.0, max=slider_max, step=1.0)
                self._action_apply_depth_to_selected()
                return True
            if cid == ID_EXTRUDE_SLIDER:
                d = self.GetFloat(ID_EXTRUDE_SLIDER)
                self.SetFloat(ID_EXTRUDE_DEPTH, d)
                self._action_apply_depth_to_selected()
                return True
            if cid == ID_SPLINE_BTN:
                f = storage.LoadDialog(flags=c4d.FILESELECT_DIRECTORY)
                if f: self.SetString(ID_SPLINE_PATH, f)
                return True
            if cid == ID_TEX_BTN:
                f = storage.LoadDialog(flags=c4d.FILESELECT_DIRECTORY)
                if f: self.SetString(ID_TEX_PATH, f)
                return True
            if cid == ID_JSON_WATCH_BTN:
                self._select_json_watch_dir()
                return True
            if cid == ID_BTN_EXTRUDE_FLIP:
                doc = documents.GetActiveDocument()
                doc.StartUndo()
                for obj in doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN):
                    if obj.GetType() == C4D_EXTRUDE_TYPEID:
                        doc.AddUndo(c4d.UNDOTYPE_CHANGE, obj)
                        try: 
                            cur = obj[C4D_EXTRUDE_OFFSET_ID]
                            obj[C4D_EXTRUDE_OFFSET_ID] = -cur
                        except: pass
                doc.EndUndo()
                c4d.EventAdd()
                return True

            # --- Super Align 事件绑定 ---
            # 独立多点射线探测
            if cid == ID_BTN_RAY_LEFT:    self._action_raycast_move(0, -1); return True
            if cid == ID_BTN_RAY_RIGHT:   self._action_raycast_move(0, 1); return True
            if cid == ID_BTN_RAY_UP:      self._action_raycast_move(1, 1); return True
            if cid == ID_BTN_RAY_DOWN:    self._action_raycast_move(1, -1); return True
            if cid == ID_BTN_RAY_FRONT:   self._action_raycast_move(2, -1); return True
            if cid == ID_BTN_RAY_BACK:    self._action_raycast_move(2, 1); return True

            # 九宫格多对象对齐
            if cid in[ID_BTN_NW, ID_BTN_N, ID_BTN_NE, ID_BTN_W, ID_BTN_C, ID_BTN_E, 
                       ID_BTN_SW, ID_BTN_S, ID_BTN_SE, ID_BTN_Z_FRONT, ID_BTN_Z_MID, ID_BTN_Z_BACK]:
                is_surface = self.GetBool(ID_CHK_SURFACE_MODE)
                if cid == ID_BTN_NW:   self._action_align_multi(-1, 1, None, is_surface)
                elif cid == ID_BTN_NE: self._action_align_multi(1, 1, None, is_surface)
                elif cid == ID_BTN_SW: self._action_align_multi(-1, -1, None, is_surface)
                elif cid == ID_BTN_SE: self._action_align_multi(1, -1, None, is_surface)
                elif cid == ID_BTN_N:  self._action_align_multi(0, 1, None, is_surface)
                elif cid == ID_BTN_S:  self._action_align_multi(0, -1, None, is_surface)
                elif cid == ID_BTN_W:  self._action_align_multi(-1, 0, None, is_surface)
                elif cid == ID_BTN_E:  self._action_align_multi(1, 0, None, is_surface)
                elif cid == ID_BTN_C:  self._action_align_multi(0, 0, None, False)
                elif cid == ID_BTN_Z_FRONT: self._action_align_multi(None, None, -1, is_surface)
                elif cid == ID_BTN_Z_MID:   self._action_align_multi(None, None, 0, False)
                elif cid == ID_BTN_Z_BACK:  self._action_align_multi(None, None, 1, is_surface)
                return True
                
            # --- 全方位轴心对齐 (独立轴心) 事件 ---
            if cid in[ID_AXIS_TL, ID_AXIS_TC, ID_AXIS_TR, 
                       ID_AXIS_ML, ID_AXIS_MC, ID_AXIS_MR, 
                       ID_AXIS_BL, ID_AXIS_BC, ID_AXIS_BR]:
                z_mode = self.GetInt32(ID_AXIS_RADIO_Z)
                z_val = 0.0
                if z_mode == ID_AXIS_Z_FRONT: z_val = 1.0
                elif z_mode == ID_AXIS_Z_BACK: z_val = -1.0
                
                direction = None
                if cid == ID_AXIS_TL:   direction = c4d.Vector(-1, 1, z_val)
                elif cid == ID_AXIS_TC: direction = c4d.Vector( 0, 1, z_val)
                elif cid == ID_AXIS_TR: direction = c4d.Vector( 1, 1, z_val)
                elif cid == ID_AXIS_ML: direction = c4d.Vector(-1, 0, z_val)
                elif cid == ID_AXIS_MC: direction = c4d.Vector( 0, 0, z_val)
                elif cid == ID_AXIS_MR: direction = c4d.Vector( 1, 0, z_val)
                elif cid == ID_AXIS_BL: direction = c4d.Vector(-1,-1, z_val)
                elif cid == ID_AXIS_BC: direction = c4d.Vector( 0,-1, z_val)
                elif cid == ID_AXIS_BR: direction = c4d.Vector( 1,-1, z_val)

                if direction is not None:
                    self._action_align_axis(direction)
                return True

            # 基础微调对齐
            if cid == ID_BTN_DROP_FLOOR:
                self._action_drop_to_floor()
                return True
            if cid == ID_BTN_STAND_UP:
                self._action_stand_up()
                return True
            if cid == ID_BTN_CENTER_X:
                self._action_center_x()
                return True
            if cid == ID_BTN_RESET_PSR:
                self._action_reset_psr()
                return True
            if cid == ID_BTN_MOV_X_ADD:
                self._action_move_selection(c4d.Vector(self.GetFloat(ID_MOVE_DIST_VAL), 0, 0))
                return True
            if cid == ID_BTN_MOV_X_SUB:
                self._action_move_selection(c4d.Vector(-self.GetFloat(ID_MOVE_DIST_VAL), 0, 0))
                return True
            if cid == ID_BTN_MOV_Y_ADD:
                self._action_move_selection(c4d.Vector(0, self.GetFloat(ID_MOVE_DIST_VAL), 0))
                return True
            if cid == ID_BTN_MOV_Y_SUB:
                self._action_move_selection(c4d.Vector(0, -self.GetFloat(ID_MOVE_DIST_VAL), 0))
                return True
            if cid == ID_BTN_MOV_Z_ADD:
                self._action_move_selection(c4d.Vector(0, 0, self.GetFloat(ID_MOVE_DIST_VAL)))
                return True
            if cid == ID_BTN_MOV_Z_SUB:
                self._action_move_selection(c4d.Vector(0, 0, -self.GetFloat(ID_MOVE_DIST_VAL)))
                return True
            
            # --- 场景与生成工具 ---
            if cid == ID_BTN_SEL_HIDDEN:
                self._action_select_hidden_objects()
                return True
            if cid == ID_BTN_SEL_TEXTURED:
                self._action_select_textured_objects()
                return True
            if cid == ID_BTN_SMART_MERGE:
                self._action_smart_merge_color()
                return True
            if cid == ID_BTN_SIMPLE_EXTRUDE:
                 self._action_simple_extrude_selected()
                 return True
            if cid == ID_BTN_CONNECT_DELETE:
                c4d.CallCommand(16768)
                return True
            if cid == ID_BTN_AXIS_CENTER:
                c4d.CallCommand(1011982)
                return True
            if cid == ID_BTN_APPLY_TEX:
                self._apply_texture_manual()
                return True
            if cid == ID_BTN_APPLY_DEPTH:
                self._action_apply_depth_to_selected()
                return True
            if cid == ID_BTN_BAKE_UVW:
                self._bake_uvw_for_selection()
                return True
            if cid == ID_BTN_ACRY_GENERATE:
                self._action_run_acrylic_generate()
                return True

            # 广告字事件
            if cid in[ID_BTN_SIGN_BACK, ID_BTN_SIGN_FRONT, ID_BTN_SIGN_CRYSTAL, ID_BTN_SIGN_DUAL]:
                doc = documents.GetActiveDocument()
                targets = Signage_GetTargets(doc)
                if not targets:
                    gui.MessageDialog("请先选中包含样条的对象！")
                    return True
                
                color_data = self.GetColorField(ID_SIGN_COLOR)
                col = color_data['color']
                
                # 读取输入(mm) 转 cm
                raw_f = self.GetFloat(ID_SIGN_THICK_F)
                raw_b = self.GetFloat(ID_SIGN_THICK_B)
                user_f = raw_f / 10.0
                user_b = raw_b / 10.0
                
                doc.StartUndo()
                if cid == ID_BTN_SIGN_BACK: # 背发光 (默认: 前3cm 后1cm)
                    f = user_f if user_f > 0.001 else 3.0
                    b = user_b if user_b > 0.001 else 1.0
                    Gen_Backlit(doc, targets, f, b, col)
                    
                elif cid == ID_BTN_SIGN_FRONT: # 正发光 (默认: 前0.5cm 后3cm)
                    f = user_f if user_f > 0.001 else 0.5
                    b = user_b if user_b > 0.001 else 3.0
                    Gen_Frontlit(doc, targets, f, b, col)
                    
                elif cid == ID_BTN_SIGN_CRYSTAL: # 水晶字 (默认: 前0.3cm 后1cm)
                    f = user_f if user_f > 0.001 else 0.3
                    b = user_b if user_b > 0.001 else 1.0
                    Gen_Crystal(doc, targets, f, b, col)
                    
                elif cid == ID_BTN_SIGN_DUAL: # 正背发 (默认: 前0.5cm 中3cm)
                    f = user_f if user_f > 0.001 else 0.5
                    b = user_b if user_b > 0.001 else 3.0
                    Gen_DualLit(doc, targets, f, b, col)
                
                doc.EndUndo()
                c4d.EventAdd()
                return True

            if cid == ID_BTN_OPEN_GROOVE:
                open_groove_dialog()
                return True
        
            if cid == ID_CAP_SIDE_COMBO:
                self._cap_mode = 2 if self._cap_mode == 1 else 1
                new_sel_name = "C1" if self._cap_mode == 1 else "C2"
                self.SetString(ID_CAP_SIDE_COMBO, f"{new_sel_name} ({'前' if self._cap_mode == 1 else '后'}封盖)")
                doc = documents.GetActiveDocument()
                sel = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_CHILDREN)
                if sel:
                    doc.StartUndo()
                    for obj in sel:
                        for tag in obj.GetTags():
                            if tag.CheckType(c4d.Ttexture):
                                if obj.GetType() == C4D_EXTRUDE_TYPEID:
                                    doc.AddUndo(c4d.UNDOTYPE_CHANGE, tag)
                                    tag[c4d.TEXTURETAG_RESTRICTION] = new_sel_name
                                    tag.Message(c4d.MSG_UPDATE)
                    doc.EndUndo()
                    c4d.EventAdd()
                return True
            
            # --- 主功能与生成器事件 ---
            if cid == ID_IMPORT_BTN:
                self._do_import()
                return True

            if cid == ID_REPLACE_BTN:
                self._do_import(is_hot_replace=True)
                return True

            if cid == ID_CHECK_UPDATE_BTN:
                self._action_check_update()
                return True

            if cid == ID_BTN_GEN_CEILING:
             self._action_generate_ceiling()
             return True
            
            # [触发] 智能展厅生成
            if cid == ID_BTN_GEN_SMART_ROOM:
                doc = c4d.documents.GetActiveDocument()
                CreateSmartRoom(doc)
                return True

# ==========================================
            #[新增触发] 智能弯曲墙体生成
            # ==========================================
            if cid == ID_BTN_CURVED_WALL:
                doc = c4d.documents.GetActiveDocument()
                sel = doc.GetActiveObjects(0) 
                
                if len(sel) < 2: 
                    gui.MessageDialog("请至少选择 2 个对象！\n1. 样条线\n2. 墙体/挤压对象")
                    return True
                
                spline = None
                # 使用 list() 绕过系统截断 Bug
                wall_parts = list() 
                
                for obj in sel:
                    if obj.GetInfo() & c4d.OBJECT_ISSPLINE:
                        if spline is None: 
                            spline = obj
                        else: 
                            wall_parts.append(obj)
                    else:
                        wall_parts.append(obj)
                
                if not spline:
                    gui.MessageDialog("未找到样条线！")
                    return True
                
                if len(wall_parts) == 0:
                    gui.MessageDialog("未找到墙体对象！")
                    return True
                
                mode = self.GetInt32(ID_CURVED_WALL_MODE)
                doc.StartUndo()
                CreateCurvedWall(doc, wall_parts, spline, mode)
                doc.EndUndo()
                c4d.EventAdd()
                return True

            # --- 资产库事件 ---
            if cid == ID_ASSET_BTN_REFRESH: 
                self.ScanAndLoad()
                return True
            if cid == ID_ASSET_SLIDER_SIZE:
                size = self.GetInt32(ID_ASSET_SLIDER_SIZE)
                self.user_area.UpdateScale(size); self.LayoutChanged(ID_ASSET_SCROLL_GRP)
                return True
            if cid == ID_ASSET_BTN_LOAD:
                idx = self.user_area.GetSelectedIndex()
                if idx != -1: self.LoadAsset(self.user_area.GetAssetPath(idx))
                return True
            if cid == ID_ASSET_TXT_SEARCH:
                self.ApplyAssetFilter()
                return True
            if cid == ID_ASSET_CHK_ONLY_FAV:
                self.ApplyAssetFilter()
                return True
            if cid == ID_CLOSE_BTN:
                self.Close()
                return True

        except Exception as e:
            gui.MessageDialog(f"未知错误:\n{str(e)}\n\n{traceback.format_exc()}")
        return False

# ==============================================================================
# 花花广告设计 v1.1 - 内置灯槽模块
# ==============================================================================

GROOVE_DIALOG_ID = 1061042
GROOVE_PLUGIN_NAME = "智能灯槽生成器"
EMISSIVE_SELECTION_NAME = "灯槽发光面"
EMISSIVE_MATERIAL_NAME = "灯槽发光材质"


class GrooveSettingsDialog(gui.GeDialog):
    ID_PERCENT_LABEL = 1001
    ID_PERCENT = 1002
    ID_DEPTH_LABEL = 1003
    ID_DEPTH = 1004
    ID_SIDE_LABEL = 1005
    ID_SIDE = 10054
    ID_ALIGN_LABEL = 1006
    ID_ALIGN_GROUP = 1007
    ID_ALIGN_CENTER = 10050
    ID_ALIGN_FRONT = 10051
    ID_ALIGN_BACK = 10052
    ID_DIR_LABEL = 10060
    ID_DIR_UP = 10061
    ID_DIR_DOWN = 10062
    ID_DIR_LEFT = 10063
    ID_DIR_RIGHT = 10064
    ID_HINT = 10067
    ID_APPLY = 10068
    ID_CURVE_MODE_LABEL = 10069
    ID_CURVE_MODE = 10070
    ID_SIDE_MODE_LABEL = 10071
    ID_SIDE_MODE = 10072
    def __init__(self):
        self.percentage = 30.0
        self.groove_depth = 5.0
        self.side_margin = 10.0
        self.align_mode = 0
        self.dir_up = True
        self.dir_down = False
        self.dir_left = False
        self.dir_right = False
        self.curve_mode = 0
        self.surface_mode = 0

    def CreateLayout(self):
        self.SetTitle("智能灯槽生成器 花花广告设计 v1.1")
        self.GroupBegin(id=1000, flags=c4d.BFH_SCALEFIT, cols=1, rows=9)
        self.GroupBorderSpace(15, 15, 15, 15)

        self.GroupBegin(id=1100, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_PERCENT_LABEL, flags=c4d.BFH_LEFT, name="槽边宽度占对象厚度 (%):")
        self.AddEditNumberArrows(id=self.ID_PERCENT, flags=c4d.BFH_SCALEFIT)
        self.GroupEnd()

        self.GroupBegin(id=1101, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_DEPTH_LABEL, flags=c4d.BFH_LEFT, name="灯槽向里开多深 (cm):")
        self.AddEditNumberArrows(id=self.ID_DEPTH, flags=c4d.BFH_SCALEFIT)
        self.GroupEnd()

        self.GroupBegin(id=1102, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_SIDE_LABEL, flags=c4d.BFH_LEFT, name="两端各保留槽口长度 (%):")
        self.AddEditNumberArrows(id=self.ID_SIDE, flags=c4d.BFH_SCALEFIT)
        self.GroupEnd()

        self.GroupBegin(id=1103, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_ALIGN_LABEL, flags=c4d.BFH_LEFT | c4d.BFV_TOP, name="边界计算基准:")
        self.GroupBegin(id=self.ID_ALIGN_GROUP, flags=c4d.BFH_LEFT, cols=1, rows=3)
        self.AddRadioButton(id=self.ID_ALIGN_CENTER, flags=c4d.BFH_LEFT, name="居中 (前后等宽槽)")
        self.AddRadioButton(id=self.ID_ALIGN_FRONT, flags=c4d.BFH_LEFT, name="以前面为基准 (开口向后)")
        self.AddRadioButton(id=self.ID_ALIGN_BACK, flags=c4d.BFH_LEFT, name="以后面为基准 (开口向前)")
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(id=1104, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_DIR_LABEL, flags=c4d.BFH_LEFT | c4d.BFV_TOP, name="灯槽方向:")
        self.GroupBegin(id=10065, flags=c4d.BFH_LEFT, cols=2, rows=2)
        self.GroupBorderSpace(0, 0, 0, 0)
        self.AddButton(id=self.ID_DIR_UP, flags=c4d.BFH_LEFT, initw=120, inith=0, name="上")
        self.AddButton(id=self.ID_DIR_DOWN, flags=c4d.BFH_LEFT, initw=120, inith=0, name="下")
        self.AddButton(id=self.ID_DIR_LEFT, flags=c4d.BFH_LEFT, initw=120, inith=0, name="左")
        self.AddButton(id=self.ID_DIR_RIGHT, flags=c4d.BFH_LEFT, initw=120, inith=0, name="右")
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(id=1105, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_CURVE_MODE_LABEL, flags=c4d.BFH_LEFT, name="模型识别模式:")
        self.AddComboBox(id=self.ID_CURVE_MODE, flags=c4d.BFH_SCALEFIT)
        self.AddChild(self.ID_CURVE_MODE, 0, "标准模式")
        self.AddChild(self.ID_CURVE_MODE, 1, "自动曲面识别")
        self.AddChild(self.ID_CURVE_MODE, 2, "强制曲面模式")
        self.GroupEnd()

        self.GroupBegin(id=1106, flags=c4d.BFH_SCALEFIT, cols=2, rows=1)
        self.AddStaticText(id=self.ID_SIDE_MODE_LABEL, flags=c4d.BFH_LEFT, name="表面选择:")
        self.AddComboBox(id=self.ID_SIDE_MODE, flags=c4d.BFH_SCALEFIT)
        self.AddChild(self.ID_SIDE_MODE, 0, "自动")
        self.AddChild(self.ID_SIDE_MODE, 1, "外侧")
        self.AddChild(self.ID_SIDE_MODE, 2, "内侧")
        self.GroupEnd()
        self.GroupEnd()

        self.GroupBegin(id=10066, flags=c4d.BFH_CENTER, cols=2, rows=1)
        self.AddButton(id=self.ID_APPLY, flags=c4d.BFH_CENTER, initw=160, inith=0, name="执行灯槽")
        self.AddButton(id=c4d.DLG_CANCEL, flags=c4d.BFH_CENTER, initw=100, inith=0, name="关闭")
        self.GroupEnd()

        self.AddStaticText(
            id=self.ID_HINT,
            flags=c4d.BFH_LEFT,
            initw=0,
            inith=0,
            name="平面常用“上”；拱形/弧形顶部常用“上+左+右”。",
        )
        self.GroupEnd()
        return True

    def InitValues(self):
        self.SetFloat(id=self.ID_PERCENT, value=self.percentage, min=1.0, max=99.0, step=1.0)
        self.SetFloat(id=self.ID_DEPTH, value=self.groove_depth, min=0.1, max=1000.0, step=0.5)
        self.SetFloat(id=self.ID_SIDE, value=self.side_margin, min=0.0, max=45.0, step=1.0)
        self.SetBool(self.ID_ALIGN_CENTER, self.align_mode == 0)
        self.SetBool(self.ID_ALIGN_FRONT, self.align_mode == 1)
        self.SetBool(self.ID_ALIGN_BACK, self.align_mode == 2)
        self.SetInt32(self.ID_CURVE_MODE, self.curve_mode)
        self.SetInt32(self.ID_SIDE_MODE, self.surface_mode)
        self._refresh_direction_labels()
        return True

    def _refresh_direction_labels(self):
        self.SetString(self.ID_DIR_UP, ("[x] " if self.dir_up else "[ ] ") + "上")
        self.SetString(self.ID_DIR_DOWN, ("[x] " if self.dir_down else "[ ] ") + "下")
        self.SetString(self.ID_DIR_LEFT, ("[x] " if self.dir_left else "[ ] ") + "左")
        self.SetString(self.ID_DIR_RIGHT, ("[x] " if self.dir_right else "[ ] ") + "右")

    def Command(self, cid, msg):
        if cid == self.ID_ALIGN_CENTER:
            self.SetBool(self.ID_ALIGN_CENTER, True)
            self.SetBool(self.ID_ALIGN_FRONT, False)
            self.SetBool(self.ID_ALIGN_BACK, False)
        elif cid == self.ID_ALIGN_FRONT:
            self.SetBool(self.ID_ALIGN_CENTER, False)
            self.SetBool(self.ID_ALIGN_FRONT, True)
            self.SetBool(self.ID_ALIGN_BACK, False)
        elif cid == self.ID_ALIGN_BACK:
            self.SetBool(self.ID_ALIGN_CENTER, False)
            self.SetBool(self.ID_ALIGN_FRONT, False)
            self.SetBool(self.ID_ALIGN_BACK, True)
        elif cid == self.ID_DIR_UP:
            self.dir_up = not self.dir_up
            self._refresh_direction_labels()
            return True
        elif cid == self.ID_DIR_DOWN:
            self.dir_down = not self.dir_down
            self._refresh_direction_labels()
            return True
        elif cid == self.ID_DIR_LEFT:
            self.dir_left = not self.dir_left
            self._refresh_direction_labels()
            return True
        elif cid == self.ID_DIR_RIGHT:
            self.dir_right = not self.dir_right
            self._refresh_direction_labels()
            return True

        if cid == self.ID_APPLY:
            self.percentage = self.GetFloat(self.ID_PERCENT)
            self.groove_depth = self.GetFloat(self.ID_DEPTH)
            self.side_margin = self.GetFloat(self.ID_SIDE)
            self.curve_mode = self.GetInt32(self.ID_CURVE_MODE)
            self.surface_mode = self.GetInt32(self.ID_SIDE_MODE)

            if self.GetBool(self.ID_ALIGN_CENTER):
                self.align_mode = 0
            elif self.GetBool(self.ID_ALIGN_FRONT):
                self.align_mode = 1
            elif self.GetBool(self.ID_ALIGN_BACK):
                self.align_mode = 2

            if not any((self.dir_up, self.dir_down, self.dir_left, self.dir_right)):
                gui.MessageDialog("请至少选择一个方向：上 / 下 / 左 / 右。")
                return True
            apply_groove_from_dialog(self)
            return True
        elif cid == c4d.DLG_CANCEL:
            self.Close()
        return True


def clean_useless_selections(op):
    tags = op.GetTags()
    used_selections = set()

    for tag in tags:
        if tag.GetType() == c4d.Ttexture:
            restriction = tag[c4d.TEXTURETAG_RESTRICTION]
            if restriction:
                for part in restriction.split(","):
                    used_selections.add(part.strip())

    for tag in reversed(op.GetTags()):
        if tag.GetType() == c4d.Tpolygonselection:
            name = tag.GetName()
            sel = tag.GetBaseSelect()
            if sel.GetCount() == 0 or name not in used_selections:
                if name != EMISSIVE_SELECTION_NAME:
                    tag.Remove()


def remove_previous_groove_tags(op):
    for tag in reversed(op.GetTags()):
        if tag.GetType() == c4d.Ttexture and tag[c4d.TEXTURETAG_RESTRICTION] == EMISSIVE_SELECTION_NAME:
            tag.Remove()
        elif tag.GetType() == c4d.Tpolygonselection and tag.GetName() == EMISSIVE_SELECTION_NAME:
            tag.Remove()


def get_polygon_center(poly, points):
    corners = [poly.a, poly.b, poly.c]
    if poly.c != poly.d:
        corners.append(poly.d)
    center = c4d.Vector(0)
    count = 0
    for idx in corners:
        if 0 <= idx < len(points):
            center += points[idx]
            count += 1
    return center / float(count) if count else c4d.Vector(0)


def get_selection_point_bounds(op, sel):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    xs = []
    ys = []
    zs = []

    for index, poly in enumerate(polys):
        if not sel.IsSelected(index):
            continue
        for point_index in (poly.a, poly.b, poly.c, poly.d):
            if 0 <= point_index < len(points):
                point = points[point_index]
                xs.append(point.x)
                ys.append(point.y)
                zs.append(point.z)

    if not xs:
        return None

    return {
        "x": (min(xs), max(xs)),
        "y": (min(ys), max(ys)),
        "z": (min(zs), max(zs)),
    }


def get_local_plane_axes(local_dir_vec):
    abs_components = [
        ("x", abs(local_dir_vec.x)),
        ("y", abs(local_dir_vec.y)),
        ("z", abs(local_dir_vec.z)),
    ]
    abs_components.sort(key=lambda item: item[1], reverse=True)
    normal_axis = abs_components[0][0]
    plane_axes = [axis for axis in ("x", "y", "z") if axis != normal_axis]
    return plane_axes


def get_axis_vector(axis_name):
    if axis_name == "x":
        return c4d.Vector(1, 0, 0)
    if axis_name == "y":
        return c4d.Vector(0, 1, 0)
    return c4d.Vector(0, 0, 1)


def get_object_bounds(op):
    points = op.GetAllPoints()
    if not points:
        return None

    xs = [point.x for point in points]
    ys = [point.y for point in points]
    zs = [point.z for point in points]
    return {
        "x": (min(xs), max(xs)),
        "y": (min(ys), max(ys)),
        "z": (min(zs), max(zs)),
    }


def get_object_center(op):
    bounds = get_object_bounds(op)
    if not bounds:
        return c4d.Vector(0)
    return c4d.Vector(
        (bounds["x"][0] + bounds["x"][1]) * 0.5,
        (bounds["y"][0] + bounds["y"][1]) * 0.5,
        (bounds["z"][0] + bounds["z"][1]) * 0.5,
    )


def get_side_margin_scale(op, sel, local_dir_vec, side_margin_percent):
    bounds = get_object_bounds(op)
    if not bounds:
        return None

    plane_axes = get_local_plane_axes(local_dir_vec)
    spans = []
    for axis in plane_axes:
        min_v, max_v = bounds[axis]
        spans.append((axis, max_v - min_v))

    if not spans:
        return None

    spans.sort(key=lambda item: item[1], reverse=True)
    major_axis, major_span = spans[0]
    if major_span <= 0.001:
        return None

    clamped_percent = max(0.0, min(side_margin_percent, 45.0))
    scale = max(0.05, 1.0 - (clamped_percent * 2.0 / 100.0))
    return major_axis, scale


def get_bounds_for_selected_polygons(op, sel):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    xs = []
    ys = []
    zs = []

    for index, poly in enumerate(polys):
        if not sel.IsSelected(index):
            continue
        for point_index in (poly.a, poly.b, poly.c, poly.d):
            if 0 <= point_index < len(points):
                point = points[point_index]
                xs.append(point.x)
                ys.append(point.y)
                zs.append(point.z)

    if not xs:
        return None

    return {
        "x": (min(xs), max(xs)),
        "y": (min(ys), max(ys)),
        "z": (min(zs), max(zs)),
    }


def get_side_margin_axis_for_selection(op, sel, local_dir_vec):
    bounds = get_bounds_for_selected_polygons(op, sel)
    if not bounds:
        return None

    plane_axes = get_local_plane_axes(local_dir_vec)
    spans = []
    for axis in plane_axes:
        min_v, max_v = bounds[axis]
        spans.append((axis, max_v - min_v))

    if not spans:
        return None

    spans.sort(key=lambda item: item[1], reverse=True)
    major_axis, major_span = spans[0]
    if major_span <= 0.001:
        return None
    return major_axis


def trim_selection_by_length(op, sel, local_dir_vec, side_margin_percent):
    original = c4d.BaseSelect()
    sel.CopyTo(original)

    if side_margin_percent <= 0.0:
        return original

    scaled = get_side_margin_scale(op, sel, local_dir_vec, side_margin_percent)
    if not scaled:
        return original

    trimmed = c4d.BaseSelect()
    axis_name, _ = scaled
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    trim_ratio = max(0.0, min(side_margin_percent, 45.0)) / 100.0

    for component in get_polygon_components(op):
        centers = []
        for index in component:
            if not sel.IsSelected(index):
                continue
            center = get_polygon_center(polys[index], points)
            centers.append((index, getattr(center, axis_name)))

        if not centers:
            continue

        values = [value for _, value in centers]
        min_v = min(values)
        max_v = max(values)
        span = max(max_v - min_v, 0.001)
        trim_len = span * trim_ratio

        if trim_len <= 0.0001:
            for index, _ in centers:
                trimmed.Select(index)
            continue

        lower = min_v + trim_len
        upper = max_v - trim_len

        for index, value in centers:
            if lower <= value <= upper:
                trimmed.Select(index)

    if trimmed.GetCount() > 0:
        return trimmed
    return original


def is_curved_multi_direction_selection(op, sel, selected_dirs):
    direction_targets = get_direction_targets(selected_dirs)
    if len(direction_targets) <= 1:
        return False

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    adjacency = build_polygon_adjacency(op)
    considered = 0
    strong = 0
    mid = 0
    smooth_pairs = 0

    for index, poly in enumerate(polys):
        if not sel.IsSelected(index):
            continue
        normal = get_local_polygon_normal(poly, points)
        if normal is None:
            continue

        best_dot = max((normal.Dot(axis) for _, axis in direction_targets), default=-1.0)
        considered += 1
        if best_dot >= 0.78:
            strong += 1
        elif best_dot >= 0.2:
            mid += 1

        for neighbor in adjacency.get(index, ()):
            if neighbor <= index or not sel.IsSelected(neighbor):
                continue
            neighbor_normal = get_local_polygon_normal(polys[neighbor], points)
            if neighbor_normal is None:
                continue
            continuity = normal.Dot(neighbor_normal)
            if 0.2 <= continuity <= 0.98:
                smooth_pairs += 1

    if considered < 6:
        return False
    if smooth_pairs >= max(3, considered // 6):
        return True
    return mid >= max(3, strong // 3)


def trim_selection_by_length_grouped(op, sel, local_dir_vec, side_margin_percent, selected_dirs):
    original = c4d.BaseSelect()
    sel.CopyTo(original)

    if side_margin_percent <= 0.0:
        return original

    direction_groups = classify_selected_polygons(op, sel, selected_dirs)
    non_empty_groups = [indices for indices in direction_groups.values() if indices]
    if len(non_empty_groups) <= 1:
        return trim_selection_by_length(op, sel, local_dir_vec, side_margin_percent)

    # 曲面模型里会有大量法线处于过渡区的面，无法被明确归到上/左/右单一方向。
    # 这时如果强行按方向分组裁切，会把连续灯槽切断，所以回退到整体裁切。
    if is_curved_multi_direction_selection(op, sel, selected_dirs):
        return trim_selection_by_length(op, sel, local_dir_vec, side_margin_percent)

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    trimmed = c4d.BaseSelect()
    trim_ratio = max(0.0, min(side_margin_percent, 45.0)) / 100.0

    for indices in non_empty_groups:
        group_sel = c4d.BaseSelect()
        for index in indices:
            group_sel.Select(index)

        axis_name = get_side_margin_axis_for_selection(op, group_sel, local_dir_vec)
        if axis_name is None:
            for index in indices:
                trimmed.Select(index)
            continue

        values = []
        for index in indices:
            center = get_polygon_center(polys[index], points)
            values.append((index, getattr(center, axis_name)))

        if not values:
            continue

        raw_values = [value for _, value in values]
        min_v = min(raw_values)
        max_v = max(raw_values)
        span = max(max_v - min_v, 0.001)
        trim_len = span * trim_ratio

        if trim_len <= 0.0001:
            for index, _ in values:
                trimmed.Select(index)
            continue

        lower = min_v + trim_len
        upper = max_v - trim_len
        for index, value in values:
            if lower <= value <= upper:
                trimmed.Select(index)

    if trimmed.GetCount() > 0:
        return trimmed
    return original


def get_local_polygon_normal(poly, points):
    if poly.a >= len(points) or poly.b >= len(points) or poly.c >= len(points):
        return None
    v1 = points[poly.b] - points[poly.a]
    v2 = points[poly.c] - points[poly.a]
    cross = v1.Cross(v2)
    if cross.GetLengthSquared() <= 1e-8:
        return None
    return cross.GetNormalized()


def get_direction_targets(selected_dirs):
    targets = []
    if selected_dirs["up"]:
        targets.append(("up", c4d.Vector(0, 1, 0)))
    if selected_dirs["down"]:
        targets.append(("down", c4d.Vector(0, -1, 0)))
    if selected_dirs["left"]:
        targets.append(("left", c4d.Vector(-1, 0, 0)))
    if selected_dirs["right"]:
        targets.append(("right", c4d.Vector(1, 0, 0)))
    return targets


def get_single_selected_direction(selected_dirs):
    targets = get_direction_targets(selected_dirs)
    if len(targets) != 1:
        return None
    return targets[0]


def classify_selected_polygons(op, base_sel, selected_dirs):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    direction_targets = get_direction_targets(selected_dirs)
    grouped = {name: [] for name, _ in direction_targets}

    for index, poly in enumerate(polys):
        if not base_sel.IsSelected(index):
            continue
        normal = get_local_polygon_normal(poly, points)
        if normal is None:
            continue

        best_name = None
        best_dot = 0.0
        for name, axis in direction_targets:
            dot = normal.Dot(axis)
            if dot > best_dot:
                best_dot = dot
                best_name = name

        if best_name and best_dot >= 0.65:
            grouped[best_name].append(index)

    return grouped


def auto_select_polygon_faces(op, world_dir_vec, selected_dirs):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    auto_sel = c4d.BaseSelect()
    direction_targets = get_direction_targets(selected_dirs)
    local_dir_vec = (~op.GetMg()).MulV(world_dir_vec).GetNormalized()

    for index, poly in enumerate(polys):
        normal = get_local_polygon_normal(poly, points)
        if normal is None:
            continue

        # 先排除前后盖帽，只处理真正的四周表面。
        if abs(normal.Dot(local_dir_vec)) > 0.22:
            continue

        for _, axis in direction_targets:
            if normal.Dot(axis) >= 0.42:
                auto_sel.Select(index)
                break

    return auto_sel


def auto_select_polygon_faces_by_position(op, selected_dirs, world_dir_vec=None):
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    local_dir_vec = None
    if world_dir_vec is not None:
        local_dir_vec = (~op.GetMg()).MulV(world_dir_vec).GetNormalized()
    auto_sel = c4d.BaseSelect()
    for component in get_polygon_components(op):
        centers = []

        for index in component:
            poly = polys[index]
            if local_dir_vec is not None:
                normal = get_local_polygon_normal(poly, points)
                if normal is None:
                    continue
                if abs(normal.Dot(local_dir_vec)) > 0.22:
                    continue
            center = get_polygon_center(poly, points)
            centers.append((index, center))

        if not centers:
            continue

        xs = [center.x for _, center in centers]
        ys = [center.y for _, center in centers]
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        span_x = max(max_x - min_x, 0.001)
        span_y = max(max_y - min_y, 0.001)

        # 曲面/弧面模型通常无法用单一法线阈值识别边缘面，这里退化为按位置带宽来抓边。
        band_x = span_x * 0.28
        band_y = span_y * 0.28

        for index, center in centers:
            matched = False
            if selected_dirs["up"] and center.y >= max_y - band_y:
                matched = True
            if selected_dirs["down"] and center.y <= min_y + band_y:
                matched = True
            if selected_dirs["left"] and center.x <= min_x + band_x:
                matched = True
            if selected_dirs["right"] and center.x >= max_x - band_x:
                matched = True
            if matched:
                auto_sel.Select(index)

    return auto_sel


def get_top_seed_selection(op, selected_dirs):
    direction = get_single_selected_direction(selected_dirs)
    if direction is None:
        return c4d.BaseSelect()

    direction_name, _ = direction
    if direction_name != "up":
        return auto_select_polygon_faces_by_position(op, selected_dirs)

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    if not points or not polys:
        return c4d.BaseSelect()

    centers = [(index, get_polygon_center(poly, points)) for index, poly in enumerate(polys)]
    max_y = max(center.y for _, center in centers)
    min_y = min(center.y for _, center in centers)
    span_y = max(max_y - min_y, 0.001)
    threshold = max_y - (span_y * 0.18)

    seed = c4d.BaseSelect()
    for index, center in centers:
        if center.y >= threshold:
            seed.Select(index)
    return seed


def grow_curve_region_by_crease(op, seed_sel, selected_dirs):
    direction = get_single_selected_direction(selected_dirs)
    if direction is None or seed_sel.GetCount() == 0:
        return seed_sel

    direction_name, axis = direction
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    adjacency = build_polygon_adjacency(op)
    expanded = c4d.BaseSelect()
    normals = {}

    for index, poly in enumerate(polys):
        normals[index] = get_local_polygon_normal(poly, points)
        if seed_sel.IsSelected(index):
            expanded.Select(index)

    frontier = [index for index in range(len(polys)) if seed_sel.IsSelected(index)]
    selected_set = set(frontier)
    # 只有遇到接近 90 度的明显折角才停止，把整条连续曲面尽量吃全。
    crease_limit = 0.0

    while frontier:
        next_frontier = []
        for source in frontier:
            source_normal = normals.get(source)
            if source_normal is None:
                continue

            for neighbor in adjacency.get(source, ()):
                if neighbor in selected_set:
                    continue

                neighbor_normal = normals.get(neighbor)
                if neighbor_normal is None:
                    continue

                continuity = source_normal.Dot(neighbor_normal)
                if continuity >= crease_limit:
                    expanded.Select(neighbor)
                    selected_set.add(neighbor)
                    next_frontier.append(neighbor)
        frontier = next_frontier

    return expanded


def grow_curve_region_multi(op, seed_sel, selected_dirs, world_dir_vec):
    if seed_sel.GetCount() == 0:
        return seed_sel

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    adjacency = build_polygon_adjacency(op)
    direction_targets = get_direction_targets(selected_dirs)
    local_dir_vec = (~op.GetMg()).MulV(world_dir_vec).GetNormalized()
    expanded = c4d.BaseSelect()
    normals = {}

    for index, poly in enumerate(polys):
        normals[index] = get_local_polygon_normal(poly, points)
        if seed_sel.IsSelected(index):
            expanded.Select(index)

    frontier = [index for index in range(len(polys)) if seed_sel.IsSelected(index)]
    selected_set = set(frontier)
    crease_limit = 0.2

    while frontier:
        next_frontier = []
        for source in frontier:
            source_normal = normals.get(source)
            if source_normal is None:
                continue

            for neighbor in adjacency.get(source, ()):
                if neighbor in selected_set:
                    continue

                neighbor_normal = normals.get(neighbor)
                if neighbor_normal is None:
                    continue

                if abs(neighbor_normal.Dot(local_dir_vec)) > 0.22:
                    continue

                best_dot = max((neighbor_normal.Dot(axis) for _, axis in direction_targets), default=-1.0)
                if best_dot < -0.05:
                    continue

                continuity = source_normal.Dot(neighbor_normal)
                if continuity >= crease_limit:
                    expanded.Select(neighbor)
                    selected_set.add(neighbor)
                    next_frontier.append(neighbor)
        frontier = next_frontier

    return expanded


def should_use_curve_mode(op, selected_dirs, auto_detect, force_curve_mode):
    if force_curve_mode:
        return True
    if not auto_detect:
        return False

    direction = get_single_selected_direction(selected_dirs)
    if direction is None:
        return False

    _, axis = direction
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    pos_sel = auto_select_polygon_faces_by_position(op, selected_dirs)
    dots = []

    for index, poly in enumerate(polys):
        if not pos_sel.IsSelected(index):
            continue
        normal = get_local_polygon_normal(poly, points)
        if normal is None:
            continue
        dots.append(normal.Dot(axis))

    if len(dots) < 6:
        return False

    strong = sum(1 for value in dots if value >= 0.72)
    mid = sum(1 for value in dots if 0.12 <= value < 0.72)
    weak = sum(1 for value in dots if value < 0.12)

    # 顶部/侧部同时存在大量中间法线时，通常就是曲面或不规则过渡面。
    return strong > 0 and mid >= max(4, strong // 2) and weak < len(dots)


def get_polygon_edge_keys(poly):
    corners = [poly.a, poly.b, poly.c]
    if poly.c != poly.d:
        corners.append(poly.d)

    edge_keys = []
    count = len(corners)
    for i in range(count):
        a = corners[i]
        b = corners[(i + 1) % count]
        if a == b:
            continue
        edge_keys.append(tuple(sorted((a, b))))
    return edge_keys


def build_polygon_adjacency(op):
    polys = op.GetAllPolygons()
    edge_to_polys = {}
    adjacency = {index: set() for index in range(len(polys))}

    for index, poly in enumerate(polys):
        for edge_key in get_polygon_edge_keys(poly):
            edge_to_polys.setdefault(edge_key, []).append(index)

    for poly_indices in edge_to_polys.values():
        if len(poly_indices) < 2:
            continue
        for source in poly_indices:
            for target in poly_indices:
                if source != target:
                    adjacency[source].add(target)

    return adjacency


def get_polygon_components(op):
    polys = op.GetAllPolygons()
    adjacency = build_polygon_adjacency(op)
    components = []
    visited = set()

    for start in range(len(polys)):
        if start in visited:
            continue
        stack = [start]
        component = []
        visited.add(start)

        while stack:
            current = stack.pop()
            component.append(current)
            for neighbor in adjacency.get(current, ()):
                if neighbor in visited:
                    continue
                visited.add(neighbor)
                stack.append(neighbor)

        components.append(component)

    return components


def get_component_bounds(points, polys, poly_indices):
    xs = []
    ys = []
    zs = []

    for poly_index in poly_indices:
        poly = polys[poly_index]
        for point_index in (poly.a, poly.b, poly.c, poly.d):
            if 0 <= point_index < len(points):
                point = points[point_index]
                xs.append(point.x)
                ys.append(point.y)
                zs.append(point.z)

    if not xs:
        return None

    return {
        "x": (min(xs), max(xs)),
        "y": (min(ys), max(ys)),
        "z": (min(zs), max(zs)),
    }


def get_component_center(points, polys, poly_indices):
    bounds = get_component_bounds(points, polys, poly_indices)
    if not bounds:
        return c4d.Vector(0)
    return c4d.Vector(
        (bounds["x"][0] + bounds["x"][1]) * 0.5,
        (bounds["y"][0] + bounds["y"][1]) * 0.5,
        (bounds["z"][0] + bounds["z"][1]) * 0.5,
    )


def filter_selection_by_surface_mode(op, sel, surface_mode):
    if surface_mode == 0 or sel.GetCount() == 0:
        return sel

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    filtered = c4d.BaseSelect()
    inward_count = 0
    outward_count = 0

    for component in get_polygon_components(op):
        component_center = get_component_center(points, polys, component)

        for index in component:
            if not sel.IsSelected(index):
                continue

            poly = polys[index]
            normal = get_local_polygon_normal(poly, points)
            if normal is None:
                continue

            center = get_polygon_center(poly, points)
            radial = center - component_center
            if radial.GetLengthSquared() <= 1e-8:
                continue

            facing = normal.Dot(radial.GetNormalized())
            if facing > 0.05:
                outward_count += 1
                if surface_mode == 1:
                    filtered.Select(index)
            elif facing < -0.05:
                inward_count += 1
                if surface_mode == 2:
                    filtered.Select(index)

    if filtered.GetCount() == 0:
        return sel
    if surface_mode == 2 and inward_count == 0:
        return sel
    if surface_mode == 1 and outward_count == 0:
        return sel

    return filtered


def expand_selection_for_curved_surfaces(op, base_sel, selected_dirs):
    if base_sel.GetCount() == 0:
        return base_sel

    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    direction_targets = get_direction_targets(selected_dirs)
    adjacency = build_polygon_adjacency(op)
    expanded = c4d.BaseSelect()

    for index in range(len(polys)):
        if base_sel.IsSelected(index):
            expanded.Select(index)

    frontier = [index for index in range(len(polys)) if base_sel.IsSelected(index)]
    visited = set(frontier)

    for _ in range(2):
        next_frontier = []
        for source in frontier:
            for neighbor in adjacency.get(source, ()):
                if neighbor in visited:
                    continue
                visited.add(neighbor)

                normal = get_local_polygon_normal(polys[neighbor], points)
                if normal is None:
                    continue

                include = False
                for _, axis in direction_targets:
                    if normal.Dot(axis) >= 0.18:
                        include = True
                        break

                if include:
                    expanded.Select(neighbor)
                    next_frontier.append(neighbor)
        frontier = next_frontier
        if not frontier:
            break

    return expanded


def shrink_selection_to_direction_bands(op, sel, selected_dirs):
    selected_indices = []
    points = op.GetAllPoints()
    polys = op.GetAllPolygons()
    centers = []

    for index, poly in enumerate(polys):
        if sel.IsSelected(index):
            center = get_polygon_center(poly, points)
            centers.append((index, center))
            selected_indices.append(index)

    if not centers:
        return sel

    xs = [center.x for _, center in centers]
    ys = [center.y for _, center in centers]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    span_x = max(max_x - min_x, 0.001)
    span_y = max(max_y - min_y, 0.001)

    new_sel = c4d.BaseSelect()
    band_x = span_x * 0.35
    band_y = span_y * 0.35

    for index, center in centers:
        matched = False
        if selected_dirs["up"] and center.y >= max_y - band_y:
            matched = True
        if selected_dirs["down"] and center.y <= min_y + band_y:
            matched = True
        if selected_dirs["left"] and center.x <= min_x + band_x:
            matched = True
        if selected_dirs["right"] and center.x >= max_x - band_x:
            matched = True
        if matched:
            new_sel.Select(index)

    if new_sel.GetCount() > 0:
        return new_sel
    return sel


def build_target_selection(op, world_dir_vec, selected_dirs, auto_curve_detect, force_curve_mode, surface_mode):
    dir_count = sum(1 for value in selected_dirs.values() if value)

    auto_sel = auto_select_polygon_faces(op, world_dir_vec, selected_dirs)
    pos_sel = auto_select_polygon_faces_by_position(op, selected_dirs, world_dir_vec)

    # 单方向时优先信任法线识别，避免位置回退把高位侧面也一起吞进去。
    if dir_count == 1:
        if should_use_curve_mode(op, selected_dirs, auto_curve_detect, force_curve_mode):
            seed_sel = get_top_seed_selection(op, selected_dirs)
            curve_sel = grow_curve_region_by_crease(op, seed_sel, selected_dirs)
            if curve_sel.GetCount() > 0:
                return filter_selection_by_surface_mode(op, curve_sel, surface_mode), False
        if auto_sel.GetCount() > 0:
            return filter_selection_by_surface_mode(op, expand_selection_for_curved_surfaces(op, auto_sel, selected_dirs), surface_mode), False
        return filter_selection_by_surface_mode(op, pos_sel, surface_mode), False

    if (
        selected_dirs.get("up")
        and not selected_dirs.get("down")
        and (selected_dirs.get("left") or selected_dirs.get("right"))
    ):
        combined_probe = c4d.BaseSelect()
        polys = op.GetAllPolygons()
        for index in range(len(polys)):
            if auto_sel.IsSelected(index) or pos_sel.IsSelected(index):
                combined_probe.Select(index)

        curve_sel = grow_curve_region_multi(op, combined_probe, selected_dirs, world_dir_vec)
        if curve_sel.GetCount() > 0:
            # 曲面上+左+右时，如果连续生长后的选区明显大于原始并集，
            # 说明中间过渡带被补出来了，这时必须和整体裁切绑定使用。
            if curve_sel.GetCount() > combined_probe.GetCount() or is_curved_multi_direction_selection(op, curve_sel, selected_dirs):
                return filter_selection_by_surface_mode(op, curve_sel, surface_mode), True

    combined = c4d.BaseSelect()
    polys = op.GetAllPolygons()
    for index in range(len(polys)):
        if auto_sel.IsSelected(index) or pos_sel.IsSelected(index):
            combined.Select(index)

    if combined.GetCount() > 0:
        return filter_selection_by_surface_mode(op, combined, surface_mode), False
    if auto_sel.GetCount() > 0:
        return filter_selection_by_surface_mode(op, auto_sel, surface_mode), False
    return filter_selection_by_surface_mode(op, pos_sel, surface_mode), False


def process_single_object(
    op,
    doc,
    percentage,
    groove_depth,
    side_margin,
    align_mode,
    selected_dirs,
    surface_mode,
    emissive_mat,
    auto_curve_detect,
    force_curve_mode,
):
    is_extrude = op.IsInstanceOf(c4d.Oextrude)
    orig_mg = op.GetMg()
    orig_name = op.GetName()

    world_dir_vec = orig_mg.MulV(c4d.Vector(0, 0, 1)).GetNormalized()

    if is_extrude:
        local_dir = c4d.Vector(0, 0, 1)
        if hasattr(c4d, "EXTRUDEOBJECT_DIRECTION"):
            direction = op[c4d.EXTRUDEOBJECT_DIRECTION]
            if direction == getattr(c4d, "EXTRUDEOBJECT_DIRECTION_X", 1):
                local_dir = c4d.Vector(1, 0, 0)
            elif direction == getattr(c4d, "EXTRUDEOBJECT_DIRECTION_Y", 2):
                local_dir = c4d.Vector(0, 1, 0)
        try:
            move_vec = op[c4d.EXTRUDEOBJECT_MOVE]
            if move_vec is not None and move_vec.GetLength() > 0.001:
                local_dir = move_vec.GetNormalized()
        except Exception:
            pass
        world_dir_vec = orig_mg.MulV(local_dir).GetNormalized()

    if not op.IsInstanceOf(c4d.Opolygon):
        orig_mats = doc.GetMaterials()
        orig_tex_tags = [tag.GetClone() for tag in op.GetTags() if tag.GetType() == c4d.Ttexture]

        result = c4d.utils.SendModelingCommand(
            command=c4d.MCOMMAND_CURRENTSTATETOOBJECT,
            list=[op],
            mode=c4d.MODELINGCOMMANDMODE_ALL,
            doc=doc,
        )
        if not result:
            return False, "无法将对象转换为多边形。"

        new_op = result[0]
        if not new_op.IsInstanceOf(c4d.Opolygon):
            join_result = c4d.utils.SendModelingCommand(
                command=c4d.MCOMMAND_JOIN,
                list=[new_op],
                mode=c4d.MODELINGCOMMANDMODE_ALL,
                doc=doc,
            )
            if join_result:
                new_op = join_result[0]
            else:
                return False, "转换后的对象无法合并为多边形。"

        if not new_op or not new_op.IsInstanceOf(c4d.Opolygon):
            return False, "转换后不是多边形对象。"

        current_mg = new_op.GetMg()
        inv_orig_mg = ~orig_mg
        pts = new_op.GetAllPoints()
        for i in range(len(pts)):
            world_p = current_mg * pts[i]
            pts[i] = inv_orig_mg * world_p

        new_op.SetAllPoints(pts)
        new_op.SetMg(orig_mg)
        new_op.InsertAfter(op)
        new_op.SetName(orig_name)
        doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, new_op)
        doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, op)
        op.Remove()
        op = new_op

        for tag in reversed(op.GetTags()):
            if tag.GetType() == c4d.Ttexture:
                tag.Remove()

        for tag in reversed(orig_tex_tags):
            op.InsertTag(tag)

        current_mats = doc.GetMaterials()
        for mat in current_mats:
            if mat not in orig_mats:
                doc.AddUndo(c4d.UNDOTYPE_DELETEOBJ, mat)
                mat.Remove()

        bc_opt = c4d.BaseContainer()
        bc_opt[c4d.MDATA_OPTIMIZE_TOLERANCE] = 0.01
        bc_opt[c4d.MDATA_OPTIMIZE_POINTS] = True
        c4d.utils.SendModelingCommand(c4d.MCOMMAND_OPTIMIZE, [op], c4d.MODELINGCOMMANDMODE_ALL, bc_opt, doc)
        c4d.utils.SendModelingCommand(c4d.MCOMMAND_ALIGNNORMALS, [op], c4d.MODELINGCOMMANDMODE_ALL, c4d.BaseContainer(), doc)

    target_sel, force_overall_trim = build_target_selection(op, world_dir_vec, selected_dirs, auto_curve_detect, force_curve_mode, surface_mode)
    if target_sel.GetCount() == 0:
        return False, "没有找到符合方向条件的面。请检查模型朝向，或先手动选面后再运行。"

    doc.AddUndo(c4d.UNDOTYPE_CHANGE, op)
    live_sel = op.GetPolygonS()
    live_sel.DeselectAll()
    target_sel.CopyTo(live_sel)

    pts = op.GetAllPoints()
    polys = op.GetAllPolygons()
    local_dir_vec = (~op.GetMg()).MulV(world_dir_vec).GetNormalized()
    use_full_loop = all(selected_dirs.values())
    min_proj = float("inf")
    max_proj = float("-inf")
    has_pts = False

    for index, poly in enumerate(polys):
        if live_sel.IsSelected(index):
            for idx in (poly.a, poly.b, poly.c, poly.d):
                if idx < len(pts):
                    proj = pts[idx].Dot(local_dir_vec)
                    min_proj = min(min_proj, proj)
                    max_proj = max(max_proj, proj)
                    has_pts = True

    total_depth = (max_proj - min_proj) if has_pts else 10.0
    if total_depth < 0.01:
        total_depth = 10.0

    dynamic_margin = total_depth * (percentage / 2.0)
    bc_inner = c4d.BaseContainer()
    bc_inner[c4d.MDATA_EXTRUDEINNER_OFFSET] = dynamic_margin
    bc_inner[c4d.MDATA_EXTRUDEINNER_PRESERVEGROUPS] = True
    angle_id_inner = getattr(c4d, "MDATA_EXTRUDEINNER_ANGLE", getattr(c4d, "MDATA_EXTRUDEINNER_MAXANGLE", 1134))
    bc_inner[angle_id_inner] = c4d.utils.Rad(181)

    res_inner = c4d.utils.SendModelingCommand(
        command=c4d.ID_MODELING_EXTRUDE_INNER_TOOL,
        list=[op],
        mode=c4d.MODELINGCOMMANDMODE_POLYGONSELECTION,
        bc=bc_inner,
        doc=doc,
    )
    if not res_inner:
        return False, "内挤压失败。"

    if align_mode != 0:
        pts = op.GetAllPoints()
        polys = op.GetAllPolygons()
        live_sel = op.GetPolygonS()
        modified_pts = set()

        shift_vec = -local_dir_vec * dynamic_margin if align_mode == 1 else local_dir_vec * dynamic_margin
        for index, poly in enumerate(polys):
            if live_sel.IsSelected(index):
                for idx in (poly.a, poly.b, poly.c, poly.d):
                    if idx not in modified_pts and idx < len(pts):
                        pts[idx] = pts[idx] + shift_vec
                        modified_pts.add(idx)
        op.SetAllPoints(pts)
        op.Message(c4d.MSG_UPDATE)

    # 四方向全选时默认做完整回形灯槽，不启用两端保留长度。
    if not use_full_loop:
        if force_overall_trim:
            live_sel = trim_selection_by_length(op, op.GetPolygonS(), local_dir_vec, side_margin)
        else:
            live_sel = trim_selection_by_length_grouped(op, op.GetPolygonS(), local_dir_vec, side_margin, selected_dirs)
        op.GetPolygonS().DeselectAll()
        live_sel.CopyTo(op.GetPolygonS())

    bc_extrude = c4d.BaseContainer()
    bc_extrude[c4d.MDATA_EXTRUDE_OFFSET] = -groove_depth
    bc_extrude[c4d.MDATA_EXTRUDE_PRESERVEGROUPS] = True
    angle_id_extrude = getattr(c4d, "MDATA_EXTRUDE_ANGLE", getattr(c4d, "MDATA_EXTRUDE_MAXANGLE", 1144))
    bc_extrude[angle_id_extrude] = c4d.utils.Rad(181)

    res_extrude = c4d.utils.SendModelingCommand(
        command=c4d.ID_MODELING_EXTRUDE_TOOL,
        list=[op],
        mode=c4d.MODELINGCOMMANDMODE_POLYGONSELECTION,
        bc=bc_extrude,
        doc=doc,
    )
    if not res_extrude:
        return False, "开槽挤压失败。"

    bc_opt_final = c4d.BaseContainer()
    bc_opt_final[c4d.MDATA_OPTIMIZE_TOLERANCE] = 0.01
    bc_opt_final[c4d.MDATA_OPTIMIZE_POINTS] = True
    bc_opt_final[c4d.MDATA_OPTIMIZE_POLYGONS] = True
    c4d.utils.SendModelingCommand(c4d.MCOMMAND_OPTIMIZE, [op], c4d.MODELINGCOMMANDMODE_ALL, bc_opt_final, doc)

    remove_previous_groove_tags(op)
    clean_useless_selections(op)

    selection_tag = c4d.BaseTag(c4d.Tpolygonselection)
    selection_tag.SetName(EMISSIVE_SELECTION_NAME)
    tags = op.GetTags()
    last_tag = tags[-1] if tags else None
    op.InsertTag(selection_tag, last_tag)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, selection_tag)

    live_sel = op.GetPolygonS()
    tag_sel = selection_tag.GetBaseSelect()
    live_sel.CopyTo(tag_sel)

    tex_tag = c4d.BaseTag(c4d.Ttexture)
    tex_tag[c4d.TEXTURETAG_MATERIAL] = emissive_mat
    tex_tag[c4d.TEXTURETAG_RESTRICTION] = EMISSIVE_SELECTION_NAME
    tags = op.GetTags()
    last_tag = tags[-1] if tags else None
    op.InsertTag(tex_tag, last_tag)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, tex_tag)
    op.Message(c4d.MSG_UPDATE)
    return True, ""


def get_or_create_emissive_material(doc):
    for mat in doc.GetMaterials():
        if mat.GetName() == EMISSIVE_MATERIAL_NAME:
            return mat

    emissive_mat = c4d.BaseMaterial(c4d.Mmaterial)
    emissive_mat.SetName(EMISSIVE_MATERIAL_NAME)
    emissive_mat[c4d.MATERIAL_USE_COLOR] = False
    emissive_mat[c4d.MATERIAL_USE_LUMINANCE] = True
    emissive_mat[c4d.MATERIAL_LUMINANCE_COLOR] = c4d.Vector(1.0, 0.95, 0.8)
    emissive_mat[c4d.MATERIAL_LUMINANCE_BRIGHTNESS] = 2.0
    doc.InsertMaterial(emissive_mat)
    doc.AddUndo(c4d.UNDOTYPE_NEWOBJ, emissive_mat)
    return emissive_mat


def apply_groove_from_dialog(dialog):
    doc = c4d.documents.GetActiveDocument()
    if doc is None:
        gui.MessageDialog("当前没有活动文档。")
        return False

    objects = doc.GetActiveObjects(c4d.GETACTIVEOBJECTFLAGS_0)
    if not objects:
        gui.MessageDialog("请先在场景里选中至少一个模型，然后再点“执行灯槽”。")
        return False

    user_percentage = dialog.percentage / 100.0
    user_depth = dialog.groove_depth
    user_side_margin = dialog.side_margin
    user_mode = dialog.align_mode
    selected_dirs = {
        "up": dialog.dir_up,
        "down": dialog.dir_down,
        "left": dialog.dir_left,
        "right": dialog.dir_right,
    }
    surface_mode = dialog.surface_mode
    auto_curve_detect = dialog.curve_mode == 1
    force_curve_mode = dialog.curve_mode == 2

    doc.StartUndo()
    try:
        emissive_mat = get_or_create_emissive_material(doc)
        success_count = 0
        messages = []

        for op in list(objects):
            ok, message = process_single_object(
                op,
                doc,
                user_percentage,
                user_depth,
                user_side_margin,
                user_mode,
                selected_dirs,
                surface_mode,
                emissive_mat,
                auto_curve_detect,
                force_curve_mode,
            )
            if ok:
                success_count += 1
            else:
                messages.append(f"{op.GetName()}: {message}")

        doc.EndUndo()
        c4d.EventAdd()

        if success_count:
            c4d.StatusSetText(f"成功为 {success_count} 个对象生成灯槽。")
        if messages:
            gui.MessageDialog("部分对象未处理成功：\n\n" + "\n".join(messages[:10]))
        return success_count > 0
    except Exception as exc:
        doc.EndUndo()
        gui.MessageDialog(f"执行出错：\n{exc}\n\n详细信息：\n{traceback.format_exc()}")
        return False

_groove_dialog_instance = None

def open_groove_dialog():
    global _groove_dialog_instance
    if _groove_dialog_instance is None:
        _groove_dialog_instance = GrooveSettingsDialog()
    return _groove_dialog_instance.Open(dlgtype=c4d.DLG_TYPE_ASYNC, pluginid=GROOVE_DIALOG_ID, defaultw=560, defaulth=420)


# ==============================================================================
# 插件注册
# ==============================================================================
class HHImportCommand(plugins.CommandData):
    dialog = None
    def Execute(self, doc):
        if self.dialog is None: self.dialog = HHImportDialog()
        return self.dialog.Open(dlgtype=c4d.DLG_TYPE_ASYNC, pluginid=PLUGIN_ID, defaultw=400, defaulth=500)
    def RestoreLayout(self, sec_ref):
        if self.dialog is None: self.dialog = HHImportDialog()
        return self.dialog.Restore(pluginid=PLUGIN_ID, secret=sec_ref)

if __name__ == "__main__":
    plugins.RegisterCommandPlugin(
        id=PLUGIN_ID, 
        str="花花广告设计 v" + CURRENT_VERSION,
        info=0, 
        icon=None, 
        help="Import AI to C4D + Smart Room + Asset Library", 
        dat=HHImportCommand()
    )
